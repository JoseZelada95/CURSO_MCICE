# S04-2 Demos

## Objetivos

Hasta ahora todos los proyectos del curso han sido un único módulo: una carpeta con su propio `pom.xml`, su propio `src/main/java` y su propio JAR resultante. Es una estructura que funciona bien mientras el proyecto es pequeño, pero deja de funcionar en cuanto el proyecto crece. Una aplicación real de Spring separa su código en piezas con responsabilidades distintas (la lógica de negocio, el acceso a datos, la capa web...), y cada una de esas piezas suele vivir en su propio módulo Maven, dentro de un mismo proyecto. En esta parte aprendemos a construir esa estructura: un proyecto Maven con un **POM padre** que agrupa varios **módulos**, cada uno con su propio `pom.xml` y su propio código, pero todos construidos con un único comando desde la raíz.

La segunda mitad de la parte resuelve un problema que aparece en cuanto el proyecto tiene más de un módulo: ¿qué pasa cuando dos módulos necesitan la misma librería externa, pero cada uno declara una versión distinta? Vemos el problema con `commons-lang3` y lo resolvemos centralizando la versión en el POM padre con `dependencyManagement`, el mismo mecanismo que ya se vio de pasada en S03-1 al leer el `pom.xml` del archetype quickstart (un bloque que fija versiones sin añadir dependencias). De paso, contrastamos ese mecanismo con la herencia real de dependencias: una `<dependency>` en el padre, fuera de `dependencyManagement`, sí llega a todos los módulos hijos sin que estos tengan que declarar nada.

Al terminar esta parte los alumnos son capaces de:
- Crear un proyecto Maven multi-módulo con un POM padre y varios módulos, usando el asistente de IntelliJ.
- Explicar qué relación establece la etiqueta `<parent>` entre un módulo y el POM padre, y qué datos hereda un módulo sin tener que declararlos.
- Construir el proyecto completo con `mvn install` desde la raíz y leer el resumen del reactor.
- Diagnosticar, con `mvn dependency:tree`, un conflicto de versiones entre módulos del mismo proyecto.
- Centralizar la versión de una dependencia compartida con `dependencyManagement` en el POM padre.
- Explicar la diferencia entre una dependencia gestionada (`dependencyManagement`) y una dependencia heredada (`<dependencies>` del padre).

---

## Demo 1: Estructura multi-módulo

### Por qué dividir un proyecto en módulos

Imaginemos una aplicación de gestión de pedidos con Spring e Hibernate. Tiene entidades y repositorios que acceden a la base de datos, servicios con la lógica de negocio (calcular totales, aplicar descuentos, validar stock) y, más adelante en el curso, controladores REST que exponen esa lógica por HTTP. Todo ese código podría vivir en un único módulo, como los proyectos que hemos construido hasta ahora. Funcionaría, pero tendría un problema: cualquier cambio en la capa de acceso a datos obliga a recompilar y volver a probar toda la aplicación, aunque el cambio no afecte a la capa web. Y si dentro de un año se quiere reutilizar la lógica de negocio en otra aplicación (por ejemplo, un proceso por lotes que no necesita capa web), habría que copiar código a mano, sin ninguna garantía de que las dos copias se mantengan sincronizadas.

Separar el proyecto en **módulos** resuelve ambos problemas. Un módulo es, en la práctica, un proyecto Maven normal (con su propio `pom.xml`, su propio `src/main/java`, su propio JAR), pero que vive dentro de un proyecto más grande y puede depender de otros módulos del mismo proyecto exactamente igual que depende de una librería externa como `commons-lang3`: declarando una `<dependency>` en su `pom.xml`. En esta demo construimos la versión más pequeña posible de esta estructura: un módulo `core` con una única clase de lógica, y un módulo `app` que depende de `core` y la usa. Es la misma relación que, más adelante en el curso, tendrán los módulos `domain`, `repository` y `service` de un proyecto Spring real.

### Creamos el POM padre y los dos módulos

Empezamos igual que cualquier otro proyecto del curso: vamos a `File > New > Project`. En el panel izquierdo, dentro de `New Project`, seleccionamos `Java`. Rellenamos:

- **Name**: `multimodulo`.
- **Location**: la carpeta donde guardamos los proyectos del curso.
- **Create Git repository**: desmarcada.
- **Build system**: `Maven`.
- **JDK**: `21`.
- **Add sample code**: desmarcada.

Desplegamos `Advanced Settings` y rellenamos **GroupId**: `com.curso` y **ArtifactId**: `multimodulo`. Hacemos clic en `Create`. IntelliJ genera el proyecto exactamente igual que cualquier otro del curso: `src/main/java` y `src/test/java` vacías, y un `pom.xml` con las coordenadas del proyecto y las tres propiedades habituales (`maven.compiler.source`, `maven.compiler.target`, `project.build.sourceEncoding`).

Este proyecto raíz, sin embargo, no va a tener ninguna clase propia: no es un módulo de código, es el que va a agrupar y coordinar a los módulos `core` y `app`. Por eso, antes de crear nada más, hacemos dos cambios:

1. Borramos la carpeta `src` completa.
2. Añadimos, a mano, justo debajo de `<version>`, la etiqueta `<packaging>pom</packaging>`:

```xml
<packaging>pom</packaging>
```

`<packaging>` ya la vimos en S02-1: cuando no aparece en el `pom.xml`, Maven empaqueta el proyecto como JAR por defecto. `pom` es el otro valor posible, y le dice a Maven que este `pom.xml` no compila nada: solo sirve para coordinar a sus módulos y, como veremos enseguida, para compartirles configuración.

Con el proyecto ya convertido en agregador, creamos los dos módulos. En el panel de proyecto, clic derecho sobre `multimodulo` (la raíz) y seleccionamos `New > Module`. Se abre un asistente parecido al de `New Project`, pero más corto: como ya estamos dentro de un proyecto Maven, IntelliJ no vuelve a preguntar el `GroupId` ni el `Build system`, porque los toma del proyecto padre. Rellenamos **Name**: `core`, **JDK**: `21`, y hacemos clic en `Create`. IntelliJ hace dos cosas a la vez: crea la carpeta `core` con su propio `pom.xml` y su estructura `src/main/java`, `src/test/java`, y añade una entrada `<module>core</module>` dentro de un bloque `<modules>` en el `pom.xml` del padre (lo crea si todavía no existe). Repetimos exactamente el mismo proceso para el segundo módulo: **Name**: `app`, **JDK**: `21`, `Create`.

Después de crear los dos módulos, el `pom.xml` de la raíz queda así:

<pre>
&amp;lt;project xmlns="http://maven.apache.org/POM/4.0.0"&amp;gt;
    &amp;lt;modelVersion&amp;gt;4.0.0&amp;lt;/modelVersion&amp;gt;

    &amp;lt;groupId&amp;gt;com.curso&amp;lt;/groupId&amp;gt;
    &amp;lt;artifactId&amp;gt;multimodulo&amp;lt;/artifactId&amp;gt;
    &amp;lt;version&amp;gt;1.0-SNAPSHOT&amp;lt;/version&amp;gt;
    &amp;lt;packaging&amp;gt;pom&amp;lt;/packaging&amp;gt;

    &amp;lt;modules&amp;gt;
        &amp;lt;module&amp;gt;core&amp;lt;/module&amp;gt;
        &amp;lt;module&amp;gt;app&amp;lt;/module&amp;gt;
    &amp;lt;/modules&amp;gt;

    &amp;lt;properties&amp;gt;
        &amp;lt;maven.compiler.source&amp;gt;21&amp;lt;/maven.compiler.source&amp;gt;
        &amp;lt;maven.compiler.target&amp;gt;21&amp;lt;/maven.compiler.target&amp;gt;
        &amp;lt;project.build.sourceEncoding&amp;gt;UTF-8&amp;lt;/project.build.sourceEncoding&amp;gt;
    &amp;lt;/properties&amp;gt;

&amp;lt;/project&amp;gt;
</pre>

El bloque `<modules>` es una simple lista de nombres de carpeta: le dice a Maven qué subcarpetas, dentro de esta, son proyectos Maven que hay que construir junto con este. Cada nombre tiene que coincidir exactamente con el nombre de la carpeta que contiene el `pom.xml` de ese módulo. Este `pom.xml` no se escribe a mano (lo genera y lo mantiene IntelliJ cada vez que añadimos un módulo): se muestra aquí solo para leerlo y entender qué ha quedado.

### core: la clase de lógica

IntelliJ genera el `pom.xml` de `core` con este contenido:

<pre>
&amp;lt;project xmlns="http://maven.apache.org/POM/4.0.0"&amp;gt;
    &amp;lt;modelVersion&amp;gt;4.0.0&amp;lt;/modelVersion&amp;gt;

    &amp;lt;parent&amp;gt;
        &amp;lt;groupId&amp;gt;com.curso&amp;lt;/groupId&amp;gt;
        &amp;lt;artifactId&amp;gt;multimodulo&amp;lt;/artifactId&amp;gt;
        &amp;lt;version&amp;gt;1.0-SNAPSHOT&amp;lt;/version&amp;gt;
    &amp;lt;/parent&amp;gt;

    &amp;lt;artifactId&amp;gt;core&amp;lt;/artifactId&amp;gt;

&amp;lt;/project&amp;gt;
</pre>

Este `pom.xml` es mucho más corto que el del padre, y la razón es la etiqueta `<parent>`. Un módulo que declara `<parent>` establece una relación de **herencia** con ese otro `pom.xml`: todo lo que el padre define (propiedades, dependencias, gestión de versiones...) se aplica también a este módulo, sin que haya que volver a escribirlo aquí. Por eso `core/pom.xml` no repite `maven.compiler.source`, `maven.compiler.target` ni `project.build.sourceEncoding`: los tres ya están en el padre, y `core` los hereda automáticamente. Si hoy comprobamos que `core` usa Java 21, es exclusivamente porque el padre lo declara.

Fijémonos también en qué contiene `<parent>`: `groupId`, `artifactId` y `version`, las tres coordenadas completas del padre, exactamente igual que se identificaría cualquier dependencia externa en un `pom.xml`. Maven necesita las tres para localizar el `pom.xml` del padre sin ambigüedad. Lo que sí es nuevo respecto a una dependencia normal es que `core` no necesita declarar su propio `groupId` ni su propia `version`: los hereda del padre en cuanto declara `<parent>`. Lo único que `core` aporta de su cosecha es su `artifactId`, `core`, el nombre que lo distingue de los demás módulos.

Creamos ahora, a mano, el paquete `com.curso.core` dentro de `core/src/main/java` (clic derecho sobre `src/main/java`, `New > Package`, escribimos `com.curso.core`) y, dentro, la clase `Saludador` (clic derecho sobre el paquete, `New > Java Class`, escribimos `Saludador`):

```java
package com.curso.core;

/**
 * S04-2 Demo 1: Estructura multi-módulo
 *
 * Objetivo: definir la lógica de negocio en un módulo independiente (core)
 * que otro módulo (app) pueda usar como dependencia.
 *
 * Lo que hace este ejemplo:
 *   - Define la clase Saludador en el paquete com.curso.core
 *   - Implementa el método saludar(nombre), la única pieza de lógica de este módulo
 *
 * Concepto clave: core no sabe nada de app. No importa nada de fuera de su
 * propio paquete y no depende de que exista ningún otro módulo. Es una
 * librería autocontenida que otro proyecto podría usar sin cambiar una
 * sola línea, exactamente como Maven hace con commons-lang3 o con
 * cualquier librería de Maven Central.
 */
public class Saludador {

    /**
     * Construye un saludo de bienvenida al curso para el nombre recibido.
     *
     * Ejemplo:
     *   saludar("Ana")    →  "Bienvenida al curso, Ana!"
     *   saludar("Carlos") →  "Bienvenida al curso, Carlos!"
     *
     * @param nombre el nombre de la persona a saludar
     * @return el mensaje de bienvenida completo
     */
    public String saludar(String nombre) {
        // Concatenamos el texto fijo de bienvenida con el nombre recibido.
        // Este método es idéntico en espíritu a Saludo.saludar() de S02-1:
        // lo único que cambia es que ahora la clase vive en su propio módulo Maven.
        return "Bienvenida al curso, " + nombre + "!";
    }
}
```

Nótese que esta clase no sabe absolutamente nada del módulo `app`, ni de que va a ser usada desde fuera de este módulo. `core` simplemente hace su trabajo, como cualquier librería.

### app: consume la clase de core

El `pom.xml` que IntelliJ genera para `app` es, de entrada, idéntico en estructura al de `core`: solo `<parent>` y `<artifactId>app</artifactId>`. Para que `app` pueda usar la clase `Saludador` de `core`, tenemos que declarar esa relación explícitamente: `app` no ve automáticamente el código de `core` por el simple hecho de estar en el mismo proyecto. Añadimos, a mano, una `<dependency>` sobre `core`:

```xml
<dependency>
    <groupId>com.curso</groupId>
    <artifactId>core</artifactId>
    <version>${project.version}</version>
</dependency>
```

Es exactamente la misma sintaxis que se usó en S03-1 para declarar `commons-lang3`: `groupId`, `artifactId` y `version`. La única diferencia es de dónde viene el artefacto: `commons-lang3` se descarga de Maven Central, mientras que `core` se resuelve desde el repositorio local del propio ordenador (`~/.m2`), donde Maven lo deja después de construirlo, como veremos enseguida. Usamos `${project.version}` en lugar de escribir `1.0-SNAPSHOT` a mano: es una propiedad predefinida de Maven, ya vista en S04-1, que toma el valor de la etiqueta `<version>` del propio proyecto. Escribirla así, en lugar de repetir el número, evita tener que actualizar esta línea si el día de mañana el proyecto pasa a la versión `2.0`.

Con esa dependencia añadida, el `pom.xml` completo de `app` queda así:

<pre>
&amp;lt;project xmlns="http://maven.apache.org/POM/4.0.0"&amp;gt;
    &amp;lt;modelVersion&amp;gt;4.0.0&amp;lt;/modelVersion&amp;gt;

    &amp;lt;parent&amp;gt;
        &amp;lt;groupId&amp;gt;com.curso&amp;lt;/groupId&amp;gt;
        &amp;lt;artifactId&amp;gt;multimodulo&amp;lt;/artifactId&amp;gt;
        &amp;lt;version&amp;gt;1.0-SNAPSHOT&amp;lt;/version&amp;gt;
    &amp;lt;/parent&amp;gt;

    &amp;lt;artifactId&amp;gt;app&amp;lt;/artifactId&amp;gt;

    &amp;lt;dependencies&amp;gt;
        &amp;lt;dependency&amp;gt;
            &amp;lt;groupId&amp;gt;com.curso&amp;lt;/groupId&amp;gt;
            &amp;lt;artifactId&amp;gt;core&amp;lt;/artifactId&amp;gt;
            &amp;lt;version&amp;gt;${project.version}&amp;lt;/version&amp;gt;
        &amp;lt;/dependency&amp;gt;
    &amp;lt;/dependencies&amp;gt;

&amp;lt;/project&amp;gt;
</pre>

Creamos el paquete `com.curso.app` dentro de `app/src/main/java` y, dentro, la clase `Main`:

```java
package com.curso.app;

// Importamos Saludador del módulo core.
// Maven la ha puesto en el classpath de app porque el pom.xml de app
// declara una <dependency> sobre com.curso:core, igual que declararía
// una dependencia sobre commons-lang3 o sobre cualquier librería externa.
// La única diferencia es que este artefacto no viene de Maven Central,
// sino del repositorio local (~/.m2), donde `mvn install` lo ha dejado.
import com.curso.core.Saludador;

/**
 * S04-2 Demo 1: Estructura multi-módulo
 *
 * Objetivo: usar, desde el módulo app, una clase definida en el módulo core.
 *
 * Lo que hace este ejemplo:
 *   - Crea una instancia de Saludador, la clase del módulo core
 *   - Llama a su método saludar() y muestra el resultado
 *
 * Concepto clave: app no contiene lógica propia todavía, solo consume la de
 * core. Esta es exactamente la relación que tendrán más adelante los
 * módulos domain, repository y service de un proyecto Spring: cada uno con
 * una responsabilidad y una dependencia declarada hacia el que necesita.
 */
public class Main {

    // main() es el punto de entrada de app. Lo único que hace es demostrar
    // que la dependencia sobre core funciona: crea el objeto que viene de
    // otro módulo y usa su método como si fuera una clase más del proyecto.
    public static void main(String[] args) {
        // Creamos una instancia de Saludador, la clase que vive en el módulo core.
        // Para que esta línea compile, Maven tiene que haber resuelto la
        // dependencia declarada en el pom.xml de app y haber puesto el JAR
        // de core (con su .class) en el classpath de compilación.
        Saludador saludador = new Saludador();

        // Llamamos al método definido en el otro módulo y mostramos el resultado.
        System.out.println(saludador.saludar("Ana"));      // → Bienvenida al curso, Ana!
        System.out.println(saludador.saludar("Carlos"));   // → Bienvenida al curso, Carlos!
    }
}
```

Si en este momento intentamos ejecutar `Main` desde IntelliJ, la clase compila sin problema: el propio IDE resuelve la dependencia sobre `core` internamente, dentro del proyecto abierto. Pero eso no basta para entender lo que ocurre en un build real: para comprobarlo de verdad, y para preparar el terreno para cualquier otra herramienta que use este proyecto desde fuera de IntelliJ (como Jenkins, más adelante en el curso), lo construimos desde la terminal.

### Construir el proyecto completo con mvn install

En S03-2 vimos el ciclo de vida de Maven: `compile`, `test`, `package`. `mvn package` genera el JAR de un módulo en su propia carpeta `target/`, pero no lo deja en ningún sitio donde otro proyecto (o otro módulo) pueda encontrarlo como dependencia. Para que `app` pueda resolver su `<dependency>` sobre `core`, Maven necesita encontrar el JAR de `core` en el **repositorio local** (`~/.m2`), el mismo sitio donde guarda las librerías descargadas de Maven Central.

La fase que copia el artefacto generado a `~/.m2` es `install`, la fase inmediatamente posterior a `package` en el ciclo de vida (y anterior a `deploy`, que ya se mencionó en S04-1: `deploy` sube el artefacto a un repositorio remoto, `install` lo deja en el repositorio local de esta misma máquina). Como todas las fases del ciclo de vida, `install` incluye automáticamente a todas las anteriores: ejecutar `mvn install` compila, testea, empaqueta e instala, en ese orden. En un proyecto multi-módulo, `mvn install` es casi siempre la fase que se necesita, porque es la que garantiza que cada módulo deja su artefacto disponible para que los demás módulos del mismo proyecto lo encuentren.

Ejecutamos, desde la carpeta raíz del proyecto (`multimodulo/`, donde está el `pom.xml` con `<packaging>pom</packaging>`), el comando que compila, testea, empaqueta e instala los tres proyectos (el padre y los dos módulos) de una sola vez:

```bash
mvn clean install
```

Maven no construye solo el `pom.xml` de la raíz: lee su `<modules>`, descubre que hay que construir también `core` y `app`, y calcula el orden correcto entre los tres. A este mecanismo, que coordina la construcción de varios módulos relacionados en un único comando, se le llama **reactor**. Antes de compilar nada, Maven imprime el orden que ha calculado:

<pre>
[INFO] Reactor Build Order:
[INFO] 
[INFO] multimodulo                                                        [pom]
[INFO] core                                                               [jar]
[INFO] app                                                                [jar]
</pre>

El orden no es casualidad ni es el orden en que aparecen en `<modules>` (aquí coincide, pero en la Práctica 1 veremos un caso en que no): Maven ha leído que `app` depende de `core`, así que construye primero `core`. Si intentara construir `app` antes, la compilación de `app` fallaría, porque el `import com.curso.core.Saludador` no encontraría nada en el repositorio local todavía.

Al final del build, Maven imprime un resumen por módulo:

<pre>
[INFO] Reactor Summary for multimodulo 1.0-SNAPSHOT:
[INFO] 
[INFO] multimodulo ........................................ SUCCESS [  0.267 s]
[INFO] core ............................................... SUCCESS [  1.192 s]
[INFO] app ................................................ SUCCESS [  0.125 s]
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
</pre>

Cada módulo aparece con su propio veredicto. Si `core` hubiera fallado, `app` habría quedado marcado como `SKIPPED`, sin ni siquiera intentarse (en la Práctica 2 provocamos este caso a propósito).

Comprobamos, con un comando de terminal normal (no de Maven), que `mvn install` ha dejado, de verdad, el artefacto de `core` en `~/.m2`:

```bash
dir %USERPROFILE%\.m2\repository\com\curso\core\1.0-SNAPSHOT\
```

<pre>
_remote.repositories
core-1.0-SNAPSHOT.jar
core-1.0-SNAPSHOT.pom
maven-metadata-local.xml
</pre>

La ruta reproduce exactamente el mecanismo que ya vimos en S03-1 para librerías de Maven Central: `groupId` convertido en carpetas (`com/curso`), luego el `artifactId` (`core`) y luego la `version` (`1.0-SNAPSHOT`). Para Maven, en este momento, `core` es indistinguible de cualquier otra dependencia externa: está en `~/.m2`, con su `.jar` y su `.pom`, listo para que cualquier otro proyecto de esta máquina lo use.

Con `core` ya instalado, ejecutamos `app`. Para eso usamos otra vez `exec-maven-plugin`, el plugin (ya usado en S03-2 y S04-1) que ejecuta directamente una clase con `main()`, usando el classpath completo que Maven ya ha resuelto: no genera ningún JAR nuevo, simplemente arranca la JVM con las clases del proyecto y sus dependencias ya en el classpath, y llama al `main()` de la clase indicada.

```bash
mvn -pl app exec:java -Dexec.mainClass=com.curso.app.Main
```

El parámetro `-pl app` (*project list*) le dice a Maven que, aunque estamos en la raíz del proyecto, solo queremos ejecutar el comando sobre el módulo `app`, no sobre los tres. Sin `-pl`, Maven intentaría ejecutar `exec:java` también en `multimodulo` y en `core`, y fallaría en ambos porque ninguno de los dos tiene una clase `com.curso.app.Main`.

Salida esperada:

<pre>
Bienvenida al curso, Ana!
Bienvenida al curso, Carlos!
</pre>

`app` ha usado, sin ningún problema, una clase que no está en su propio código: viene del JAR de `core` que `mvn install` dejó en `~/.m2`, resuelto por Maven exactamente igual que resolvería `commons-lang3`.

---

## Demo 2: Herencia y dependencyManagement

### El problema: cada módulo elige su propia versión

Un proyecto con varios módulos tiene un riesgo que un proyecto de un solo módulo no tiene: que dos módulos distintos usen dos versiones distintas de la misma librería externa, sin que nadie se dé cuenta. Lo reproducimos a propósito. Añadimos `commons-lang3` a `core`, con la versión `3.12.0`:

```xml
<dependency>
    <groupId>org.apache.commons</groupId>
    <artifactId>commons-lang3</artifactId>
    <version>3.12.0</version>
</dependency>
```

Y añadimos la misma librería a `app`, pero con la versión `3.17.0`, la que se usó en S03-1:

```xml
<dependency>
    <groupId>org.apache.commons</groupId>
    <artifactId>commons-lang3</artifactId>
    <version>3.17.0</version>
</dependency>
```

Nada en este momento impide que esto ocurra: cada `pom.xml` es, en principio, independiente, y nadie ha comprobado que las dos versiones coincidan. Ninguno de los dos módulos da ningún error todavía: el problema no se manifiesta como un fallo de compilación, sino como una versión distinta silenciosamente usada según quién construya el proyecto.

Para verlo hay que preguntarle a Maven qué versión ha elegido realmente. `mvn dependency:tree`, ya usado en S03-1, imprime el árbol completo de dependencias de un módulo (las que declara y las que arrastra de forma transitiva), con la versión final que Maven ha resuelto para cada una. Lo ejecutamos sobre `app`:

```bash
mvn -pl app dependency:tree
```

<pre>
[INFO] com.curso:app:jar:1.0-SNAPSHOT
[INFO] +- com.curso:core:jar:1.0-SNAPSHOT:compile
[INFO] \- org.apache.commons:commons-lang3:jar:3.17.0:compile
</pre>

El árbol solo muestra la versión `3.17.0`: es la que `app` declara directamente, y ya vimos en S03-1 que una versión declarada de forma directa en el propio `pom.xml` siempre gana, sin necesidad de ningún ajuste. Para ver qué ha pasado con la versión `3.12.0` que declara `core`, añadimos `-Dverbose`, que muestra también las versiones descartadas y por qué:

```bash
mvn -pl app dependency:tree -Dverbose
```

<pre>
[INFO] com.curso:app:jar:1.0-SNAPSHOT
[INFO] +- com.curso:core:jar:1.0-SNAPSHOT:compile
[INFO] |  \- (org.apache.commons:commons-lang3:jar:3.12.0:compile - omitted for conflict with 3.17.0)
[INFO] \- org.apache.commons:commons-lang3:jar:3.17.0:compile
</pre>

Ahora sí aparece la línea que faltaba: la `3.12.0` que trae `core` (como dependencia transitiva de `app`, puesto que `app` depende de `core`) queda `omitted for conflict with 3.17.0`. Este dato tiene una consecuencia que conviene detenerse a pensar: **dentro de `app`, el código de `core` se ejecuta contra `commons-lang3` 3.17.0**, una versión que `core` nunca declaró y con la que sus propios tests, si los tuviera, nunca se han ejecutado. Si `core` se construye y se prueba de forma aislada (por ejemplo, con `mvn test` dentro de la propia carpeta `core`), usa la 3.12.0; en cuanto pasa a formar parte de `app`, usa la 3.17.0 sin que nadie lo haya decidido explícitamente. Es un conflicto silencioso: no hay ningún error, ni ahora ni probablemente durante mucho tiempo, hasta que algún método se comporte de forma distinta entre una versión y otra.

### La solución: centralizar la versión en el padre

La solución no es elegir cuál de las dos versiones se queda (eso es lo que Maven ya hace por su cuenta, sin que lo pidamos). La solución es que ningún módulo tenga que decidir su propia versión: que la decisión se tome una sola vez, en el padre, y que todos los módulos la usen sin tener que conocerla.

Esto es exactamente lo que ya vimos, sin entrar en detalle, en el `pom.xml` del archetype quickstart en S02-1: un bloque `<dependencyManagement>` en el padre. Lo añadimos al `pom.xml` de `multimodulo`:

```xml
<dependencyManagement>
    <dependencies>
        <dependency>
            <groupId>org.apache.commons</groupId>
            <artifactId>commons-lang3</artifactId>
            <version>3.17.0</version>
        </dependency>
    </dependencies>
</dependencyManagement>
```

Y quitamos la `<version>` de las dos declaraciones en `core` y en `app`, dejando solo `groupId` y `artifactId`:

```xml
<dependency>
    <groupId>org.apache.commons</groupId>
    <artifactId>commons-lang3</artifactId>
</dependency>
```

Ya vimos en S03-1 la definición de `dependencyManagement`: fija la versión de un artefacto para todo el proyecto, sin declararlo como dependencia por sí solo. Eso significa algo importante que hay que remarcar aquí: **`dependencyManagement` no añade `commons-lang3` a ningún módulo**. Si un módulo no tiene su propia `<dependency>` sobre `commons-lang3` (con o sin versión), no lo va a tener por el simple hecho de que el padre lo mencione en `dependencyManagement`. Lo único que hace `dependencyManagement` es decir: "si algún módulo declara esta dependencia, que use esta versión". Por eso `core` y `app` siguen necesitando su propia `<dependency>`, solo que ahora sin `<version>`, porque la toman del padre.

Para que el contraste quede claro, añadimos también JUnit al `pom.xml` del padre, pero esta vez **fuera** de `dependencyManagement`, en un bloque `<dependencies>` normal:

```xml
<dependencies>
    <dependency>
        <groupId>org.junit.jupiter</groupId>
        <artifactId>junit-jupiter</artifactId>
        <version>5.11.3</version>
        <scope>test</scope>
    </dependency>
</dependencies>
```

Esta vez sí: una `<dependency>` normal, declarada en el padre fuera de `dependencyManagement`, se hereda automáticamente en todos los módulos hijos. Ni `core` ni `app` tienen que escribir nada en su propio `pom.xml` para tener JUnit disponible en `src/test/java`. Es la diferencia clave entre los dos bloques: `dependencyManagement` gestiona versiones sin añadir nada por sí solo; `<dependencies>` en el padre sí añade la dependencia a todos los módulos, sin que estos tengan que pedirla.

Lo comprobamos con un test real en `core`, sin declarar JUnit en `core/pom.xml`:

```java
package com.curso.core;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * S04-2 Demo 2: Herencia y dependencyManagement
 *
 * Objetivo: comprobar que el módulo core puede usar JUnit sin declararlo
 * en su propio pom.xml, porque lo hereda del pom padre.
 *
 * Lo que hace este ejemplo:
 *   - Escribe un test JUnit normal sobre Saludador
 *   - Compila y se ejecuta sin que core/pom.xml declare JUnit como dependencia
 *
 * Concepto clave: esta clase compila y se ejecuta con `mvn test` aunque
 * core/pom.xml no tiene ninguna <dependency> de JUnit. La dependencia
 * viene heredada del bloque <dependencies> del padre: eso es lo que
 * diferencia una <dependency> normal del padre de una entrada en
 * <dependencyManagement>, que solo fija versión y no añade nada por sí sola.
 */
class SaludadorTest {

    @Test
    void saludarIncluyeElNombreRecibido() {
        Saludador saludador = new Saludador();

        // Comprobamos que el mensaje generado contiene el nombre pasado como argumento.
        // Si esta línea compila y el test se ejecuta con `mvn test`, es la prueba de que
        // JUnit está disponible en core sin haberlo declarado aquí: viene del padre.
        assertEquals("Bienvenida al curso, Ana!", saludador.saludar("Ana"));
    }
}
```

Reconstruimos el proyecto completo, para comprobar que todo compila y que el test nuevo pasa:

```bash
mvn clean install
```

<pre>
[INFO] Reactor Build Order:
[INFO] 
[INFO] multimodulo                                                        [pom]
[INFO] core                                                               [jar]
[INFO] app                                                                [jar]
...
[INFO] --- surefire:3.2.5:test (default-test) @ core ---
[INFO] Using auto detected provider org.apache.maven.surefire.junitplatform.JUnitPlatformProvider
[INFO] 
[INFO] -------------------------------------------------------
[INFO]  T E S T S
[INFO] -------------------------------------------------------
[INFO] Running com.curso.core.SaludadorTest
[INFO] Tests run: 1, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 0.061 s -- in com.curso.core.SaludadorTest
[INFO] 
[INFO] Results:
[INFO] 
[INFO] Tests run: 1, Failures: 0, Errors: 0, Skipped: 0
...
[INFO] Reactor Summary for multimodulo 1.0-SNAPSHOT:
[INFO] 
[INFO] multimodulo ........................................ SUCCESS [  0.233 s]
[INFO] core ............................................... SUCCESS [  2.057 s]
[INFO] app ................................................ SUCCESS [  0.119 s]
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
</pre>

El test pasa. `core/pom.xml` sigue sin tener ninguna línea sobre JUnit, y aun así `SaludadorTest` compila y se ejecuta.

### Confirmamos el resultado

Repetimos `dependency:tree -Dverbose` sobre `app`, ahora con `dependencyManagement` ya en marcha, para comprobar que el conflicto de versiones ha desaparecido:

```bash
mvn -pl app dependency:tree -Dverbose
```

<pre>
[INFO] com.curso:app:jar:1.0-SNAPSHOT
[INFO] +- com.curso:core:jar:1.0-SNAPSHOT:compile
[INFO] |  \- (org.apache.commons:commons-lang3:jar:3.17.0:compile - version managed from 3.17.0; omitted for duplicate)
[INFO] +- org.apache.commons:commons-lang3:jar:3.17.0:compile
[INFO] \- org.junit.jupiter:junit-jupiter:jar:5.11.3:test
[INFO]    +- org.junit.jupiter:junit-jupiter-api:jar:5.11.3:test
[INFO]    |  +- org.opentest4j:opentest4j:jar:1.3.0:test
[INFO]    |  +- org.junit.platform:junit-platform-commons:jar:1.11.3:test
[INFO]    |  |  \- (org.apiguardian:apiguardian-api:jar:1.1.2:test - omitted for duplicate)
[INFO]    |  \- org.apiguardian:apiguardian-api:jar:1.1.2:test
[INFO]    +- org.junit.jupiter:junit-jupiter-params:jar:5.11.3:test
[INFO]    |  +- (org.junit.jupiter:junit-jupiter-api:jar:5.11.3:test - omitted for duplicate)
[INFO]    |  \- (org.apiguardian:apiguardian-api:jar:1.1.2:test - omitted for duplicate)
[INFO]    \- org.junit.jupiter:junit-jupiter-engine:jar:5.11.3:test
[INFO]       +- org.junit.platform:junit-platform-engine:jar:1.11.3:test
[INFO]       |  +- (org.opentest4j:opentest4j:jar:1.3.0:test - omitted for duplicate)
[INFO]       |  +- (org.junit.platform:junit-platform-commons:jar:1.11.3:test - omitted for duplicate)
[INFO]       |  \- (org.apiguardian:apiguardian-api:jar:1.1.2:test - omitted for duplicate)
[INFO]       +- (org.junit.jupiter:junit-jupiter-api:jar:5.11.3:test - omitted for duplicate)
[INFO]       \- (org.apiguardian:apiguardian-api:jar:1.1.2:test - omitted for duplicate)
</pre>

Dos cosas que confirmar en esta salida. Primero, la anotación `version managed from 3.17.0`: ya no dice `omitted for conflict`, sino `version managed from`, la marca que ya vimos en S03-1 para indicar que una versión viene fijada por `dependencyManagement`. Ahora `core` y `app` piden exactamente la misma versión, porque los dos la toman del mismo sitio: ya no hay dos números distintos compitiendo, hay una única fuente de verdad. Segundo, el árbol completo de JUnit y sus dependencias transitivas (`opentest4j`, `junit-platform-commons`, `apiguardian-api`...) cuelga de `app` sin que `app` los haya pedido uno a uno: todos vienen del `junit-jupiter` que se heredó del padre.

Para terminar de confirmar qué ha heredado `app` del padre sin escribir nada en su propio `pom.xml`, usamos otro goal de `maven-help-plugin` (ya se usó `help:evaluate` y `help:active-profiles` en S04-1): `help:effective-pom`, que muestra el **POM efectivo**, es decir, el resultado de combinar el `pom.xml` real del módulo con todo lo que hereda de su padre. Es la forma más directa de comprobar, sin adivinar, qué llega de verdad a un módulo por herencia:

```bash
mvn -pl app help:effective-pom
```

<pre>
&amp;lt;project ...&amp;gt;
  &amp;lt;modelVersion&amp;gt;4.0.0&amp;lt;/modelVersion&amp;gt;
  &amp;lt;parent&amp;gt;
    &amp;lt;groupId&amp;gt;com.curso&amp;lt;/groupId&amp;gt;
    &amp;lt;artifactId&amp;gt;multimodulo&amp;lt;/artifactId&amp;gt;
    &amp;lt;version&amp;gt;1.0-SNAPSHOT&amp;lt;/version&amp;gt;
  &amp;lt;/parent&amp;gt;
  &amp;lt;groupId&amp;gt;com.curso&amp;lt;/groupId&amp;gt;
  &amp;lt;artifactId&amp;gt;app&amp;lt;/artifactId&amp;gt;
  &amp;lt;version&amp;gt;1.0-SNAPSHOT&amp;lt;/version&amp;gt;
  &amp;lt;properties&amp;gt;
    &amp;lt;maven.compiler.source&amp;gt;21&amp;lt;/maven.compiler.source&amp;gt;
    &amp;lt;maven.compiler.target&amp;gt;21&amp;lt;/maven.compiler.target&amp;gt;
    &amp;lt;project.build.sourceEncoding&amp;gt;UTF-8&amp;lt;/project.build.sourceEncoding&amp;gt;
  &amp;lt;/properties&amp;gt;
  &amp;lt;dependencyManagement&amp;gt;
    &amp;lt;dependencies&amp;gt;
      &amp;lt;dependency&amp;gt;
        &amp;lt;groupId&amp;gt;org.apache.commons&amp;lt;/groupId&amp;gt;
        &amp;lt;artifactId&amp;gt;commons-lang3&amp;lt;/artifactId&amp;gt;
        &amp;lt;version&amp;gt;3.17.0&amp;lt;/version&amp;gt;
      &amp;lt;/dependency&amp;gt;
    &amp;lt;/dependencies&amp;gt;
  &amp;lt;/dependencyManagement&amp;gt;
  &amp;lt;dependencies&amp;gt;
    &amp;lt;dependency&amp;gt;
      &amp;lt;groupId&amp;gt;com.curso&amp;lt;/groupId&amp;gt;
      &amp;lt;artifactId&amp;gt;core&amp;lt;/artifactId&amp;gt;
      &amp;lt;version&amp;gt;1.0-SNAPSHOT&amp;lt;/version&amp;gt;
      &amp;lt;scope&amp;gt;compile&amp;lt;/scope&amp;gt;
    &amp;lt;/dependency&amp;gt;
    &amp;lt;dependency&amp;gt;
      &amp;lt;groupId&amp;gt;org.apache.commons&amp;lt;/groupId&amp;gt;
      &amp;lt;artifactId&amp;gt;commons-lang3&amp;lt;/artifactId&amp;gt;
      &amp;lt;version&amp;gt;3.17.0&amp;lt;/version&amp;gt;
      &amp;lt;scope&amp;gt;compile&amp;lt;/scope&amp;gt;
    &amp;lt;/dependency&amp;gt;
    &amp;lt;dependency&amp;gt;
      &amp;lt;groupId&amp;gt;org.junit.jupiter&amp;lt;/groupId&amp;gt;
      &amp;lt;artifactId&amp;gt;junit-jupiter&amp;lt;/artifactId&amp;gt;
      &amp;lt;version&amp;gt;5.11.3&amp;lt;/version&amp;gt;
      &amp;lt;scope&amp;gt;test&amp;lt;/scope&amp;gt;
    &amp;lt;/dependency&amp;gt;
  &amp;lt;/dependencies&amp;gt;
  ...
&amp;lt;/project&amp;gt;
</pre>

El `pom.xml` real de `app` (el que hemos escrito nosotros) solo tenía `<parent>`, `<artifactId>` y dos `<dependency>` sin versión. El POM efectivo tiene, además, las tres propiedades del compilador, el bloque `dependencyManagement` completo y la dependencia de JUnit con su versión ya resuelta. Todo eso ha llegado a `app` sin que nadie lo escribiera en `app/pom.xml`: es la herencia en acción, la misma que ya se intuía al ver que `core` no necesitaba declarar `maven.compiler.source` en la sección anterior.

### Por qué esto importa para Spring Boot

Cuando en S05 se cree el primer proyecto Spring, su `pom.xml` empezará con un `<parent>` que apunta a `spring-boot-starter-parent`. Es exactamente el mismo mecanismo que acabamos de construir aquí a mano: un POM padre con un `dependencyManagement` gigantesco que fija, de una sola vez, las versiones de Spring, Hibernate, Jackson y decenas de librerías más, de forma que cada módulo o proyecto que hereda de él solo tiene que escribir `groupId` y `artifactId` de lo que necesita, sin preocuparse de qué versión concreta usar ni de que dos dependencias transitivas traigan versiones incompatibles entre sí. Sin haber entendido `<parent>` y `dependencyManagement` con un ejemplo pequeño como este, esa primera línea del `pom.xml` de Spring Boot sería difícil de interpretar correctamente.
