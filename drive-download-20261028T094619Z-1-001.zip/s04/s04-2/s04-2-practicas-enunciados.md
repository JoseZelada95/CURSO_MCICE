# S04-2 Prácticas

## Objetivos

En estas prácticas se construye, desde cero, un proyecto Maven multi-módulo con tres módulos en lugar de dos, siguiendo el mismo patrón de la Demo 1: un POM padre que agrupa a sus módulos y les hereda la configuración común. Con tres módulos aparece un aspecto que con solo dos no se aprecia bien: el orden en que Maven construye los módulos no depende del orden en que se declaran en `<modules>`, sino del grafo de dependencias real entre ellos. También se comprueba, provocando un error a propósito, qué ocurre en el reactor cuando uno de los módulos falla: el resto de módulos que dependen de él no llegan ni a intentarse.

---

## Práctica 1: Módulo de utilidades

Se crea un proyecto Maven multi-módulo llamado `practicas-multimodulo`, con groupId `com.curso`, que gestiona precios con IVA. El proyecto tiene tres módulos:

- **`utils`**: una clase de utilidad para formatear importes en euros, sin ninguna dependencia propia.
- **`core`**: la lógica de negocio del cálculo de precios con IVA, que depende de `utils` para formatear el resultado.
- **`app`**: un punto de entrada que usa tanto `core` como `utils`.

Se sigue exactamente el mismo procedimiento que en la Demo 1 para crear el proyecto padre y los dos primeros módulos, y después se añade el tercero.

**Pasos**
1. Se crea el proyecto padre con el asistente de IntelliJ (`File > New > Project`, `Java`, Build system `Maven`, JDK `21`, *Add sample code* desmarcada). GroupId `com.curso`, ArtifactId `practicas-multimodulo`, en `Advanced Settings`.
2. Se borra la carpeta `src` del proyecto raíz y se añade `<packaging>pom</packaging>` al `pom.xml`.
3. Se crea el módulo `core` (`New > Module` sobre la raíz, Name `core`, JDK `21`).
4. Se crea el módulo `app` de la misma forma.
5. En `app/pom.xml` se añade la dependencia sobre `core`, con `groupId com.curso`, `artifactId core` y `version ${project.version}`.
6. Se crea la clase `CalculadoraPrecios` en el paquete `com.curso.core`, con un método `calcularTotalConIva(double precioBase, double tipoIvaPorcentaje)` que devuelve el precio total con el IVA incluido.
7. Se crea la clase `Main` en el paquete `com.curso.app`, que usa `CalculadoraPrecios` para calcular y mostrar el total con IVA de un par de precios.
8. Se comprueba que el proyecto compila con `mvn install` desde la raíz.
9. Se crea un tercer módulo, `utils`, de la misma forma que los anteriores (`New > Module`, Name `utils`, JDK `21`).
10. En `utils` se crea la clase `Formato`, en el paquete `com.curso.utils`, con un método `formatearEuros(double importe)` que devuelve el importe como texto, con dos decimales, la coma como separador decimal y el símbolo `€` al final.
11. Se añade la dependencia de `utils` en `core/pom.xml`, y se modifica `CalculadoraPrecios` para que use `Formato` en un nuevo método, `totalConIvaFormateado(double precioBase, double tipoIvaPorcentaje)`, que devuelve el resultado ya formateado.
12. Se añade también la dependencia de `utils` en `app/pom.xml`, y se usa `Formato` directamente desde `Main`, sin pasar por `core`, para formatear un importe suelto.
13. Se declaran los tres módulos en el `<modules>` del padre en este orden: `app`, `core`, `utils` (el orden inverso al de sus dependencias).
14. Se ejecuta `mvn install` desde la raíz y se anota el orden real en que Maven ha construido los tres módulos, leyendo el `Reactor Build Order` que imprime al principio.

**Pistas**
- El orden de `<modules>` en el `pom.xml` del padre es solo la lista de carpetas que Maven tiene que revisar; no determina el orden de construcción.
- `Formato` no necesita depender de nada: es la clase con menos dependencias del proyecto, y por eso puede ser usada tanto por `core` como por `app`.
- `String.format("%.2f", importe)` redondea un `double` a dos decimales y usa el punto como separador; hay que sustituirlo por una coma después.
- Antes de que `core` pueda usar `Formato`, Maven tiene que haber instalado `utils` en el repositorio local: sin `mvn install`, la dependencia no se resuelve.

---

## Práctica 2: Build completo del proyecto

Se añaden tests a los módulos `utils` y `core` del proyecto de la Práctica 1, se construye el proyecto completo y se comprueba el comportamiento del reactor cuando uno de los módulos tiene un error de compilación.

**Pasos**
1. Se añade la dependencia de JUnit al `pom.xml` del padre, en un bloque `<dependencies>` (no en `<dependencyManagement>`), con scope `test`, para que los tres módulos la hereden sin declararla cada uno.
2. Se escribe un test para `Formato`, en `utils`, que compruebe que `formatearEuros` redondea correctamente a dos decimales y que usa la coma como separador.
3. Se escribe un test para `CalculadoraPrecios`, en `core`, que compruebe el cálculo del total con IVA y el resultado formateado.
4. Se ejecuta `mvn clean install` desde la raíz y se comprueba que los tres módulos se construyen, se testean y pasan, en el orden calculado por el reactor.
5. Se introduce un error de compilación deliberado en `CalculadoraPrecios` (por ejemplo, quitando un punto y coma) y se ejecuta de nuevo `mvn clean install` desde la raíz.
6. Se observa, en el `Reactor Summary` final, qué estado tiene cada módulo: cuáles han llegado a construirse y cuál no.
7. Se corrige el error y se repite el build para comprobar que vuelve a terminar en `BUILD SUCCESS`.

**Pistas**
- Un test de `utils` no necesita ningún otro módulo del proyecto: puede probar `Formato` de forma completamente aislada.
- Un test de `core` sí depende, indirectamente, de que `utils` esté bien construido: si `Formato` no compilara, tampoco compilaría el test de `core`.
- El estado de un módulo que no ha llegado a intentarse porque uno de los módulos de los que depende ha fallado no es `FAILURE`: es otra palabra, que aparece justo debajo del que sí ha fallado en el resumen del reactor.
- El mensaje de error de compilación indica el fichero y la línea exactos donde falta el punto y coma; no hace falta adivinarlo.
