# S04-2 Soluciones

## Práctica 1: Módulo de utilidades

El proyecto se construye siguiendo exactamente el mismo procedimiento que en la Demo 1: `File > New > Project`, `Java`, Build system `Maven`, JDK `21`, *Add sample code* desmarcada, GroupId `com.curso`, ArtifactId `practicas-multimodulo`. Se borra `src` y se añade `<packaging>pom</packaging>`. Con `New > Module` se crean, uno detrás de otro, los módulos `core`, `app` y, más tarde, `utils`.

### El pom.xml del padre

<pre>
&amp;lt;project xmlns="http://maven.apache.org/POM/4.0.0"&amp;gt;
    &amp;lt;modelVersion&amp;gt;4.0.0&amp;lt;/modelVersion&amp;gt;

    &amp;lt;groupId&amp;gt;com.curso&amp;lt;/groupId&amp;gt;
    &amp;lt;artifactId&amp;gt;practicas-multimodulo&amp;lt;/artifactId&amp;gt;
    &amp;lt;version&amp;gt;1.0-SNAPSHOT&amp;lt;/version&amp;gt;
    &amp;lt;packaging&amp;gt;pom&amp;lt;/packaging&amp;gt;

    &amp;lt;!-- Los módulos se declaran aquí en el orden app, core, utils: el orden
         inverso al de sus dependencias (utils no depende de nadie, core
         depende de utils, app depende de core y de utils). Maven no
         construye en este orden: calcula el orden real a partir del grafo
         de dependencias de los pom.xml de cada módulo, no de esta lista. --&amp;gt;
    &amp;lt;modules&amp;gt;
        &amp;lt;module&amp;gt;app&amp;lt;/module&amp;gt;
        &amp;lt;module&amp;gt;core&amp;lt;/module&amp;gt;
        &amp;lt;module&amp;gt;utils&amp;lt;/module&amp;gt;
    &amp;lt;/modules&amp;gt;

    &amp;lt;properties&amp;gt;
        &amp;lt;maven.compiler.source&amp;gt;21&amp;lt;/maven.compiler.source&amp;gt;
        &amp;lt;maven.compiler.target&amp;gt;21&amp;lt;/maven.compiler.target&amp;gt;
        &amp;lt;project.build.sourceEncoding&amp;gt;UTF-8&amp;lt;/project.build.sourceEncoding&amp;gt;
    &amp;lt;/properties&amp;gt;

&amp;lt;/project&amp;gt;
</pre>

**Decisiones tomadas**
- Los tres módulos se declaran en `<modules>` en el orden `app`, `core`, `utils`, el inverso al de sus dependencias reales, precisamente para comprobar que ese orden no es el que Maven usa para construir. Si se declararan en el orden "natural" (`utils`, `core`, `app`), el orden de construcción coincidiría con el de la lista por pura casualidad, y no quedaría demostrado que uno depende del otro y no de la posición en el fichero.
- `commons-lang3` no aparece en este `pom.xml`: la Práctica 1 no necesita esa librería, así que no se repite el mecanismo de `dependencyManagement` de la Demo 2 sin una razón real para usarlo aquí.

### utils: el módulo sin dependencias

`utils/pom.xml` es el más simple de los tres: solo `<parent>` y `<artifactId>`, sin ninguna `<dependency>` propia.

<pre>
&amp;lt;project xmlns="http://maven.apache.org/POM/4.0.0"&amp;gt;
    &amp;lt;modelVersion&amp;gt;4.0.0&amp;lt;/modelVersion&amp;gt;

    &amp;lt;parent&amp;gt;
        &amp;lt;groupId&amp;gt;com.curso&amp;lt;/groupId&amp;gt;
        &amp;lt;artifactId&amp;gt;practicas-multimodulo&amp;lt;/artifactId&amp;gt;
        &amp;lt;version&amp;gt;1.0-SNAPSHOT&amp;lt;/version&amp;gt;
    &amp;lt;/parent&amp;gt;

    &amp;lt;artifactId&amp;gt;utils&amp;lt;/artifactId&amp;gt;

&amp;lt;/project&amp;gt;
</pre>

```java
package com.curso.utils;

/**
 * S04-2 Práctica 1: Módulo de utilidades
 *
 * Objetivo: definir una clase de utilidad, sin ninguna dependencia de otros
 * módulos, que puedan usar a la vez core y app.
 *
 * Aplica las técnicas de S04:
 *   1. Módulo Maven independiente (packaging jar), sin dependencias propias
 *   2. Clase reutilizable desde varios módulos del mismo proyecto multi-módulo
 *
 * Concepto clave: utils no depende de core ni de app. Es una librería de
 * apoyo, igual que commons-lang3 o Guava, solo que en vez de venir de Maven
 * Central viene de otro módulo del propio proyecto.
 */
public class Formato {

    /**
     * Formatea un importe en euros con dos decimales y el símbolo de moneda.
     *
     * Ejemplo:
     *   formatearEuros(12.5)    →  "12,50 €"
     *   formatearEuros(99.999)  →  "100,00 €"
     *
     * @param importe la cantidad a formatear
     * @return el importe formateado con dos decimales y el símbolo de moneda
     */
    public String formatearEuros(double importe) {
        // String.format con la máscara "%.2f" redondea a dos decimales.
        // La coma en vez del punto decimal es una decisión deliberada del
        // formato: en España el separador decimal habitual es la coma.
        String importeConDosDecimales = String.format("%.2f", importe).replace('.', ',');
        return importeConDosDecimales + " €";
    }
}
```

**Decisiones tomadas**
- `formatearEuros` es un método de instancia, no `static`: se mantiene el mismo estilo que el resto de clases del curso (`Saludo`, `Saludador`), donde se crea siempre una instancia con `new` antes de llamar al método, en lugar de introducir aquí, sin necesidad, el matiz de los métodos estáticos.
- El redondeo se resuelve con `String.format("%.2f", ...)`, que ya redondea el número antes de convertirlo a texto; no hace falta redondear el `double` por separado con otra operación.
- La coma como separador decimal no viene de ninguna configuración regional del sistema (que podría variar de un ordenador a otro): se fuerza explícitamente con `.replace('.', ',')`, así el resultado es el mismo en cualquier máquina donde se ejecute.

### core: lógica de negocio que usa utils

`core/pom.xml` añade la dependencia sobre `utils`, con la misma sintaxis que ya se usó en la Demo 1 para que `app` dependiera de `core`:

<pre>
&amp;lt;project xmlns="http://maven.apache.org/POM/4.0.0"&amp;gt;
    &amp;lt;modelVersion&amp;gt;4.0.0&amp;lt;/modelVersion&amp;gt;

    &amp;lt;parent&amp;gt;
        &amp;lt;groupId&amp;gt;com.curso&amp;lt;/groupId&amp;gt;
        &amp;lt;artifactId&amp;gt;practicas-multimodulo&amp;lt;/artifactId&amp;gt;
        &amp;lt;version&amp;gt;1.0-SNAPSHOT&amp;lt;/version&amp;gt;
    &amp;lt;/parent&amp;gt;

    &amp;lt;artifactId&amp;gt;core&amp;lt;/artifactId&amp;gt;

    &amp;lt;dependencies&amp;gt;
        &amp;lt;dependency&amp;gt;
            &amp;lt;groupId&amp;gt;com.curso&amp;lt;/groupId&amp;gt;
            &amp;lt;artifactId&amp;gt;utils&amp;lt;/artifactId&amp;gt;
            &amp;lt;version&amp;gt;${project.version}&amp;lt;/version&amp;gt;
        &amp;lt;/dependency&amp;gt;
    &amp;lt;/dependencies&amp;gt;

&amp;lt;/project&amp;gt;
</pre>

```java
package com.curso.core;

// Importamos Formato del módulo utils.
// Maven la ha puesto en el classpath de core porque el pom.xml de core
// declara una <dependency> sobre com.curso:utils, resuelta desde el
// repositorio local (~/.m2), igual que la dependencia de core sobre app
// en las demos.
import com.curso.utils.Formato;

/**
 * S04-2 Práctica 1: Módulo de utilidades
 *
 * Objetivo: implementar la lógica de negocio del cálculo de precios con IVA
 * en el módulo core, apoyándose en el módulo utils para formatear el resultado.
 *
 * Aplica las técnicas de S04:
 *   1. Módulo Maven que depende de otro módulo del mismo proyecto (utils)
 *   2. Uso de una clase de otro módulo exactamente igual que si fuera una
 *      librería externa
 *
 * Concepto clave: core contiene la lógica de negocio (el cálculo), pero
 * delega el formateo del resultado en utils en lugar de reimplementarlo.
 * Cada módulo tiene una responsabilidad distinta.
 */
public class CalculadoraPrecios {

    // Creamos una instancia de Formato para poder usar su método formatearEuros().
    // Es un campo de la clase porque lo necesitan varios métodos.
    private final Formato formato = new Formato();

    /**
     * Calcula el precio total de un producto sumando el IVA correspondiente.
     *
     * Ejemplo:
     *   calcularTotalConIva(100.0, 21.0)  →  121.0
     *   calcularTotalConIva(50.0, 10.0)   →  55.0
     *
     * @param precioBase el precio sin impuestos
     * @param tipoIvaPorcentaje el tipo de IVA aplicable, en porcentaje (21 para el 21%)
     * @return el precio total, con el IVA ya incluido
     */
    public double calcularTotalConIva(double precioBase, double tipoIvaPorcentaje) {
        // Convertimos el porcentaje a una proporción: 21 → 0.21
        double proporcionIva = tipoIvaPorcentaje / 100.0;

        // El importe del IVA es el precio base multiplicado por esa proporción.
        double importeIva = precioBase * proporcionIva;

        // El total es el precio base más el IVA calculado.
        return precioBase + importeIva;
    }

    /**
     * Calcula el precio total con IVA y lo devuelve ya formateado como texto.
     *
     * Ejemplo:
     *   totalConIvaFormateado(100.0, 21.0)  →  "121,00 €"
     *   totalConIvaFormateado(50.0, 10.0)   →  "55,00 €"
     *
     * @param precioBase el precio sin impuestos
     * @param tipoIvaPorcentaje el tipo de IVA aplicable, en porcentaje
     * @return el precio total con IVA, formateado con formatearEuros() de utils
     */
    public String totalConIvaFormateado(double precioBase, double tipoIvaPorcentaje) {
        // Reutilizamos el cálculo anterior en lugar de repetir la fórmula.
        double total = calcularTotalConIva(precioBase, tipoIvaPorcentaje);

        // Delegamos el formateo en la clase Formato del módulo utils:
        // core no sabe ni le importa cómo se construye el texto final.
        return formato.formatearEuros(total);
    }
}
```

**Decisiones tomadas**
- `calcularTotalConIva` y `totalConIvaFormateado` son dos métodos distintos, no uno solo: separar el cálculo (que devuelve `double`) del formateo (que devuelve `String`) permite reutilizar el cálculo puro en un contexto que no necesite texto, por ejemplo, para sumar varios totales antes de formatear solo el resultado final.
- `totalConIvaFormateado` llama a `calcularTotalConIva` en lugar de repetir la fórmula: evita tener la misma operación escrita dos veces y con riesgo de que, si se corrige un error algún día, se corrija solo en un sitio.
- `core` delega el formateo en `utils` en lugar de construir el texto con `String.format` directamente en `CalculadoraPrecios`: si mañana cambia el formato de moneda (por ejemplo, para soportar dólares), el cambio se hace una sola vez, en `Formato`, y `core` no se entera.

### app: usa core y utils a la vez

`app/pom.xml` declara dos dependencias: sobre `core` y también, de forma independiente, sobre `utils`.

<pre>
&amp;lt;project xmlns="http://maven.apache.org/POM/4.0.0"&amp;gt;
    &amp;lt;modelVersion&amp;gt;4.0.0&amp;lt;/modelVersion&amp;gt;

    &amp;lt;parent&amp;gt;
        &amp;lt;groupId&amp;gt;com.curso&amp;lt;/groupId&amp;gt;
        &amp;lt;artifactId&amp;gt;practicas-multimodulo&amp;lt;/artifactId&amp;gt;
        &amp;lt;version&amp;gt;1.0-SNAPSHOT&amp;lt;/version&amp;gt;
    &amp;lt;/parent&amp;gt;

    &amp;lt;artifactId&amp;gt;app&amp;lt;/artifactId&amp;gt;

    &amp;lt;dependencies&amp;gt;
        &amp;lt;dependency&amp;gt;
            &amp;lt;groupId&amp;gt;com.curso&amp;lt;/groupId&amp;gt;
            &amp;lt;artifactId&amp;gt;core&amp;lt;/artifactId&amp;gt;
            &amp;lt;version&amp;gt;${project.version}&amp;lt;/version&amp;gt;
        &amp;lt;/dependency&amp;gt;
        &amp;lt;dependency&amp;gt;
            &amp;lt;groupId&amp;gt;com.curso&amp;lt;/groupId&amp;gt;
            &amp;lt;artifactId&amp;gt;utils&amp;lt;/artifactId&amp;gt;
            &amp;lt;version&amp;gt;${project.version}&amp;lt;/version&amp;gt;
        &amp;lt;/dependency&amp;gt;
    &amp;lt;/dependencies&amp;gt;

&amp;lt;/project&amp;gt;
</pre>

```java
package com.curso.app;

// Importamos CalculadoraPrecios del módulo core.
import com.curso.core.CalculadoraPrecios;

// Importamos también Formato del módulo utils, directamente en app,
// no solo a través de core: app declara su propia dependencia sobre utils
// en su pom.xml, aunque core ya dependa también de utils.
import com.curso.utils.Formato;

/**
 * S04-2 Práctica 1: Módulo de utilidades
 *
 * Objetivo: comprobar que app puede usar tanto core como utils, y que
 * utils funciona igual usado desde app que usado desde dentro de core.
 *
 * Aplica las técnicas de S04:
 *   1. Módulo que depende de dos módulos distintos del mismo proyecto
 *   2. Reutilización de una clase de utilidad desde varios puntos del proyecto
 *
 * Concepto clave: utils no pertenece a core ni a app: es un módulo común que
 * cualquiera de los dos puede usar de forma independiente. Aquí app usa
 * Formato para un caso que no pasa por CalculadoraPrecios.
 */
public class Main {

    public static void main(String[] args) {
        // Creamos la calculadora del módulo core y calculamos un total con IVA.
        CalculadoraPrecios calculadora = new CalculadoraPrecios();
        System.out.println(calculadora.totalConIvaFormateado(100.0, 21.0));  // → 121,00 €
        System.out.println(calculadora.totalConIvaFormateado(50.0, 10.0));   // → 55,00 €

        // Usamos Formato directamente desde app, sin pasar por core, para
        // formatear un importe que no viene de ningún cálculo de IVA.
        Formato formato = new Formato();
        System.out.println(formato.formatearEuros(9.9));  // → 9,90 €
    }
}
```

**Decisiones tomadas**
- `app` declara su propia dependencia sobre `utils`, aunque ya la obtiene indirectamente a través de `core`: Maven, de hecho, sí resolvería `Formato` en el classpath de `app` aunque no se declarase explícitamente (por dependencia transitiva de `core`), pero declararla explícitamente deja claro, con solo leer el `pom.xml`, que `app` usa `utils` directamente, no solo de rebote a través de `core`. Es una decisión de claridad, no una necesidad técnica estricta.

### mvn install y el orden real del reactor

Se ejecuta desde la raíz:

```bash
mvn clean install
```

El `Reactor Build Order` que Maven imprime al principio, antes de compilar nada:

<pre>
[INFO] Reactor Build Order:
[INFO] 
[INFO] practicas-multimodulo                                              [pom]
[INFO] utils                                                              [jar]
[INFO] core                                                               [jar]
[INFO] app                                                                [jar]
</pre>

El orden real de construcción es `utils`, `core`, `app`, justo el opuesto al orden en que se declararon en `<modules>` (`app`, `core`, `utils`). Maven ha leído los `pom.xml` de los tres módulos, ha visto que `core` depende de `utils` y que `app` depende de `core` y de `utils`, y ha calculado el único orden posible en el que cada módulo encuentra ya construido todo lo que necesita: primero el que no depende de nadie (`utils`), después el que depende solo de ese (`core`), y al final el que depende de los otros dos (`app`).

---

## Práctica 2: Build completo del proyecto

### JUnit heredado del padre

Se añade JUnit al `pom.xml` del padre, en `<dependencies>`, fuera de `dependencyManagement`, igual que se hizo en la Demo 2:

```xml
<dependencies>
    <dependency>
        <groupId>org.junit.jupiter</groupId>
        <artifactId>junit-jupiter</artifactId>
        <version>5.11.3</version>
        <scope>test</scope>
    </dependency>
</dependencies>
```

Ni `utils`, ni `core`, ni `app` necesitan añadir nada a su propio `pom.xml` para poder escribir tests: los tres heredan esta dependencia del padre.

### Test de Formato

```java
package com.curso.utils;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * S04-2 Práctica 2: Build completo del proyecto
 *
 * Objetivo: comprobar que Formato redondea y formatea correctamente antes de
 * construir el proyecto completo con mvn clean install.
 *
 * Aplica las técnicas de S04:
 *   1. Test JUnit en un módulo sin dependencias, heredando JUnit del padre
 *
 * Concepto clave: cada módulo tiene sus propios tests, y mvn install los
 * ejecuta en todos los módulos, en el orden que calcula el reactor.
 */
class FormatoTest {

    @Test
    void formatearEurosRedondeaADosDecimales() {
        Formato formato = new Formato();

        // 99.999 redondeado a dos decimales sube a 100,00.
        assertEquals("100,00 €", formato.formatearEuros(99.999));
    }

    @Test
    void formatearEurosUsaComaComoSeparadorDecimal() {
        Formato formato = new Formato();

        assertEquals("12,50 €", formato.formatearEuros(12.5));
    }
}
```

**Decisiones tomadas**
- El caso `99.999` no es arbitrario: comprueba específicamente el redondeo en el límite (sube a `100,00`, no se queda en `99,99` ni en `100,000`), el tipo de caso que un test con un número "normal" como `50.0` no detectaría.

### Test de CalculadoraPrecios

```java
package com.curso.core;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * S04-2 Práctica 2: Build completo del proyecto
 *
 * Objetivo: comprobar que CalculadoraPrecios calcula bien el total con IVA
 * antes de construir el proyecto completo con mvn clean install.
 *
 * Aplica las técnicas de S04:
 *   1. Test JUnit en un módulo que depende de otro módulo del proyecto (utils)
 *
 * Concepto clave: este test verifica core, pero para compilarse y ejecutarse
 * necesita que utils esté ya compilado y en el classpath. Es exactamente lo
 * que fuerza al reactor a construir utils antes que core.
 */
class CalculadoraPreciosTest {

    @Test
    void calcularTotalConIvaSumaElImporteDelIva() {
        CalculadoraPrecios calculadora = new CalculadoraPrecios();

        assertEquals(121.0, calculadora.calcularTotalConIva(100.0, 21.0), 0.001);
    }

    @Test
    void totalConIvaFormateadoDevuelveElTextoConSimboloDeMoneda() {
        CalculadoraPrecios calculadora = new CalculadoraPrecios();

        // Este test comprueba, de paso, que core usa correctamente
        // Formato del módulo utils: si utils no estuviera en el classpath,
        // el proyecto ni siquiera compilaría.
        assertEquals("121,00 €", calculadora.totalConIvaFormateado(100.0, 21.0));
    }
}
```

**Decisiones tomadas**
- `calcularTotalConIvaSumaElImporteDelIva` usa `assertEquals` con un tercer argumento (`0.001`), el delta ya visto en S02-2: al comparar `double`, no se puede confiar en una igualdad exacta.
- Se prueban por separado el cálculo puro (`calcularTotalConIva`, que devuelve `double`) y el cálculo formateado (`totalConIvaFormateado`, que devuelve `String`): así, si un test falla, se sabe inmediatamente si el problema está en la aritmética o en el formateo, sin tener que revisar los dos a la vez.

### Build completo, en el orden correcto

```bash
mvn clean install
```

<pre>
[INFO] Reactor Build Order:
[INFO] 
[INFO] practicas-multimodulo                                              [pom]
[INFO] utils                                                              [jar]
[INFO] core                                                               [jar]
[INFO] app                                                                [jar]
...
[INFO] --- surefire:3.2.5:test (default-test) @ utils ---
[INFO] Using auto detected provider org.apache.maven.surefire.junitplatform.JUnitPlatformProvider
[INFO] 
[INFO] -------------------------------------------------------
[INFO]  T E S T S
[INFO] -------------------------------------------------------
[INFO] Running com.curso.utils.FormatoTest
[INFO] Tests run: 2, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 0.064 s -- in com.curso.utils.FormatoTest
[INFO] 
[INFO] Results:
[INFO] 
[INFO] Tests run: 2, Failures: 0, Errors: 0, Skipped: 0
...
[INFO] --- surefire:3.2.5:test (default-test) @ core ---
[INFO] Using auto detected provider org.apache.maven.surefire.junitplatform.JUnitPlatformProvider
[INFO] 
[INFO] -------------------------------------------------------
[INFO]  T E S T S
[INFO] -------------------------------------------------------
[INFO] Running com.curso.core.CalculadoraPreciosTest
[INFO] Tests run: 2, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 0.044 s -- in com.curso.core.CalculadoraPreciosTest
[INFO] 
[INFO] Results:
[INFO] 
[INFO] Tests run: 2, Failures: 0, Errors: 0, Skipped: 0
...
[INFO] Reactor Summary for practicas-multimodulo 1.0-SNAPSHOT:
[INFO] 
[INFO] practicas-multimodulo .............................. SUCCESS [  0.357 s]
[INFO] utils .............................................. SUCCESS [  2.032 s]
[INFO] core ............................................... SUCCESS [  0.636 s]
[INFO] app ................................................ SUCCESS [  0.059 s]
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
</pre>

Los tests de `utils` se ejecutan antes que los de `core`, y los de `core` antes que `app`: el mismo orden que calculó el reactor en la Práctica 1, ahora con tests de por medio.

### El fallo en cascada

Se introduce un error deliberado en `CalculadoraPrecios`, quitando el punto y coma de la última línea de `calcularTotalConIva`:

```java
// antes:
return precioBase + importeIva;

// después, con el error deliberado:
return precioBase + importeIva  // falta el punto y coma, error deliberado
```

Se ejecuta de nuevo:

```bash
mvn clean install
```

<pre>
[INFO] Reactor Build Order:
[INFO] 
[INFO] practicas-multimodulo                                              [pom]
[INFO] utils                                                              [jar]
[INFO] core                                                               [jar]
[INFO] app                                                                [jar]
...
[INFO] --- compiler:3.13.0:compile (default-compile) @ core ---
[INFO] Recompiling the module because of changed dependency.
[INFO] Compiling 1 source file with javac [debug target 21] to target/classes
[INFO] -------------------------------------------------------------
[ERROR] COMPILATION ERROR : 
[INFO] -------------------------------------------------------------
[ERROR] /ruta/practicas-multimodulo/core/src/main/java/com/curso/core/CalculadoraPrecios.java:[50,39] ';' expected
[INFO] 1 error
[INFO] -------------------------------------------------------------
[INFO] ------------------------------------------------------------------------
[INFO] Reactor Summary for practicas-multimodulo 1.0-SNAPSHOT:
[INFO] 
[INFO] practicas-multimodulo .............................. SUCCESS [  0.270 s]
[INFO] utils .............................................. SUCCESS [  1.908 s]
[INFO] core ............................................... FAILURE [  0.061 s]
[INFO] app ................................................ SKIPPED
[INFO] ------------------------------------------------------------------------
[INFO] BUILD FAILURE
[INFO] ------------------------------------------------------------------------
</pre>

`utils` se construye con normalidad: no depende de `core`, así que el error no le afecta. `core` termina en `FAILURE`, con el mensaje de `javac` señalando el fichero y la línea exactos (`CalculadoraPrecios.java:[50,39]`). `app` aparece como `SKIPPED`: Maven ni siquiera lo intenta, porque `app` depende de `core` y `core` no ha llegado a generar un JAR utilizable. Es exactamente el mismo comportamiento que detectaría un pipeline de Jenkins más adelante en el curso: si un módulo base no compila, no tiene sentido gastar tiempo en construir lo que depende de él.

### Corrección

Se repone el punto y coma:

```java
return precioBase + importeIva;
```

Y se repite el build:

```bash
mvn clean install
```

<pre>
[INFO] Reactor Summary for practicas-multimodulo 1.0-SNAPSHOT:
[INFO] 
[INFO] practicas-multimodulo .............................. SUCCESS [  0.273 s]
[INFO] utils .............................................. SUCCESS [  2.037 s]
[INFO] core ............................................... SUCCESS [  0.602 s]
[INFO] app ................................................ SUCCESS [  0.067 s]
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
</pre>

Los tres módulos vuelven a construirse, testearse e instalarse sin ningún problema.
