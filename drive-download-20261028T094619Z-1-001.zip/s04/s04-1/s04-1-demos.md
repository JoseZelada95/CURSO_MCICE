# S04-1 Demos

## Objetivos

Cualquier aplicación real, al arrancar, necesita saber cosas sobre sí misma y sobre dónde está corriendo. Cuando algo falla en producción, la primera pregunta de soporte suele ser "¿qué versión tienes desplegada?"; cuando un desarrollador se conecta a una base de datos equivocada por descuido, el problema casi siempre es que la configuración del entorno no estaba clara o se cambió a mano y se olvidó volver a cambiarla. Las tres demos de esta parte construyen, paso a paso, la solución a los dos problemas a la vez: **un panel de arranque** que la aplicación imprime nada más iniciar, con el entorno en el que corre, la base de datos a la que se conecta, y la versión y fecha de compilación exactas de ese despliegue.

Las tres demos trabajan sobre **un único proyecto**, `s04-1-demos`, que se va ampliando demo a demo: no se crea un proyecto nuevo en ninguna de ellas, y no se abandona nada de lo construido en una demo al pasar a la siguiente. Cada demo resuelve la pregunta que deja abierta la anterior:

- **Demo 1** resuelve cómo hacer que la URL de base de datos (y cualquier otro valor) cambie según el entorno, sin tocar el código a mano: con perfiles Maven. Para comprobar que funciona rápido, sin montar nada más, se hace una verificación provisional desde Java con un mecanismo sencillo (propiedades del sistema).
- **Demo 2** sustituye esa verificación provisional por la forma en que una aplicación real gestiona su configuración: un fichero, `application.properties`, que la aplicación carga al arrancar. Aquí nace el panel de arranque, con el entorno y la base de datos.
- **Demo 3** completa el panel de arranque añadiéndole la versión y la fecha de compilación, ampliando el mismo fichero con datos que Maven ya conoce sobre el propio proyecto, sin que nadie los escriba a mano.

Al terminar esta parte los alumnos son capaces de:
- Definir perfiles Maven con propiedades propias y comprobar cuál está activo, con y sin código Java.
- Activar el filtrado de recursos y explicar en qué momento del ciclo de vida de Maven ocurre y por qué.
- Construir un fichero de configuración cuyo contenido depende del perfil activo, y leerlo desde Java con el encoding correcto.
- Usar propiedades predefinidas de Maven sobre el propio proyecto (versión, artefacto, fecha de compilación).

---

## Demo 1: Definición de perfiles

### El problema

Imaginemos un equipo con varios desarrolladores trabajando en el mismo proyecto. La aplicación se conecta a una base de datos, y esa URL de conexión tiene que ser distinta según dónde se ejecute: en el ordenador de cada desarrollador, apunta a una base de datos local, vacía, para hacer pruebas sin riesgo; en el servidor de producción, apunta a la base de datos real, con los datos de los usuarios.

Si esa URL estuviera escrita directamente en el código o en una única propiedad del `pom.xml`, alguien tendría que cambiarla a mano cada vez que el proyecto pasa de un entorno a otro, y volver a cambiarla de vuelta después. Esto es exactamente el tipo de tarea manual y repetitiva de la que salen los incidentes más tontos y más caros: alguien compila para producción sin acordarse de cambiar la URL, y la aplicación se conecta a la base de datos de pruebas de otro compañero, vacía; o, al revés, alguien prueba algo "rápido" en su máquina y por error apunta a la base de datos real, con el riesgo de estropear datos de verdad.

Los **perfiles Maven** resuelven este problema de raíz: permiten definir, dentro del mismo `pom.xml`, varias configuraciones alternativas y elegir cuál se usa en cada compilación, sin tocar ni el código ni el `pom.xml` entre un entorno y otro. Nadie vuelve a tener que acordarse de cambiar nada a mano.

### Crear el proyecto

Partimos de cero, con el mismo patrón de creación de siempre: `File > New > Project`, `Java` en el panel izquierdo, Build system `Maven`, JDK `21`, **Add sample code** desmarcada. En `Advanced Settings`: GroupId `com.curso`, ArtifactId `s04-1-demos`.

El proyecto recién creado tiene la estructura habitual, con `src/main/java/com/curso` y `src/main/resources` vacías (esta última se usará por primera vez en la Demo 2), y un `pom.xml` mínimo, sin nada relacionado con perfiles todavía:

```xml
<project xmlns="http://maven.apache.org/POM/4.0.0" ...>
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.curso</groupId>
    <artifactId>s04-1-demos</artifactId>
    <version>1.0-SNAPSHOT</version>

    <properties>
        <maven.compiler.source>21</maven.compiler.source>
        <maven.compiler.target>21</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    </properties>
</project>
```

Este es el punto de partida. **A partir de aquí, todo lo que se añade en el resto de la demo es nuevo**; cuando se muestre un fragmento de `pom.xml`, será siempre una ampliación de este mismo fichero, nunca uno distinto.

### Añadir los perfiles

Añadimos un bloque `<profiles>`, con un `<profile>` por entorno. Cada uno declara sus propias propiedades, con el mismo nombre en los dos perfiles, pero con valores distintos:

```xml
<profiles>
    <!-- Perfil dev: valores de entorno de desarrollo. -->
    <profile>
        <id>dev</id>
        <properties>
            <app.entorno>desarrollo</app.entorno>
            <app.db.url>jdbc:h2:mem:devdb</app.db.url>
        </properties>
    </profile>

    <!-- Perfil prod: valores de entorno de producción. -->
    <profile>
        <id>prod</id>
        <properties>
            <app.entorno>producción</app.entorno>
            <app.db.url>jdbc:postgresql://servidor-prod:5432/appdb</app.db.url>
        </properties>
    </profile>
</profiles>
```

Un **perfil** es un bloque de configuración adicional dentro del `pom.xml`, identificado por un `id`, que se activa o no según se indique en el comando con el que se invoca Maven. Mientras un perfil no está activo, todo lo que contiene se ignora por completo, como si no estuviera escrito. Un proyecto puede tener definidos varios perfiles a la vez (aquí, dos); lo habitual es activar como mucho uno en cada compilación.

Dentro de un perfil se puede declarar casi cualquier cosa que se declara fuera de uno (propiedades, dependencias, plugins...); en esta demo cada perfil define únicamente dos **propiedades**: `app.entorno` y `app.db.url`. Una propiedad Maven, como ya se sabe desde S02-1, es un valor con nombre, `${nombre}`, que Maven sustituye por su valor antes de hacer nada más. Lo importante aquí es que los dos perfiles definen **el mismo nombre de propiedad** con **valores distintos**. Esto no es casualidad: es precisamente lo que hace útil a un perfil. El resto del proyecto usará siempre `${app.entorno}` y `${app.db.url}`, sin saber ni necesitar saber qué perfil está activo; el valor concreto lo decide, en cada compilación, el perfil que se active.

`app.db.url` de `dev` apunta a `jdbc:h2:mem:devdb`, una base de datos en memoria (H2 se usará de verdad más adelante, en el módulo de Hibernate); la de `prod` apunta a un servidor PostgreSQL ficticio. Ninguna de las dos URL se conecta de verdad en esta demo: por ahora se trata solo de comprobar que Maven elige el valor correcto según el perfil.

### Un valor por defecto para cuando no hay ningún perfil activo

Si no se activa ningún perfil, `${app.entorno}` y `${app.db.url}` no tienen ningún valor de `<profiles>` de donde tomar su valor. Para que el proyecto también funcione en ese caso (por ejemplo, la primera vez que alguien lo compila sin saber todavía que existen los perfiles `dev` y `prod`), añadimos las mismas dos propiedades, con un valor por defecto, en el bloque `<properties>` que ya existía:

```xml
<properties>
    <maven.compiler.source>21</maven.compiler.source>
    <maven.compiler.target>21</maven.compiler.target>
    <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>

    <!-- Valores por defecto de app.entorno y app.db.url cuando no hay ningún
         perfil activo. Los perfiles dev y prod, más abajo, sobrescriben estos
         mismos nombres de propiedad cuando están activos. -->
    <app.entorno>sin-perfil</app.entorno>
    <app.db.url>sin-configurar</app.db.url>
</properties>
```

Cuando un perfil está activo, su valor de `app.entorno` sustituye al de `<properties>`, porque tienen el mismo nombre y el perfil activo tiene prioridad. Cuando no hay ningún perfil activo, se usa el valor de `<properties>` tal cual, sin que Maven dé ningún error ni deje el valor vacío. Con esto, el proyecto compila y se ejecuta igual de bien con o sin perfil, y el caso "sin perfil" queda identificado con un valor propio y reconocible (`sin-perfil`) en vez de fallar o quedar en blanco de forma silenciosa.

**A modo de resumen de lo añadido hasta aquí:** el `pom.xml` original (sin nada) ha pasado a tener dos propiedades por defecto más dos perfiles que las sobrescriben. Nada más ha cambiado.

### Comprobar qué perfil está activo, sin escribir ningún código

Antes de meternos con Java, conviene comprobar que el mecanismo en sí funciona, usando únicamente herramientas de Maven. Esto no es un paso de relleno: en el día a día, cuando algo con perfiles no se comporta como se espera, la primera pregunta siempre es "¿qué perfil está activo de verdad, ahora mismo, con este comando?", y responderla arrancando toda la aplicación es mucho más lento que preguntárselo directamente a Maven.

`mvn help:active-profiles` es un goal del plugin `maven-help-plugin` (no hace falta declararlo en el `pom.xml`: se descarga solo la primera vez que se usa, igual que `mvn dependency:tree` en S03-1) que muestra qué perfiles están activos para una invocación concreta de Maven.

```bash
mvn help:active-profiles -Pdev
```

`-P` seguido del `id` del perfil, sin espacio entre `-P` y `dev`, le dice a Maven que active ese perfil para esta ejecución.

Salida esperada (resumida):

<pre>
Active Profiles for Project 'com.curso:s04-1-demos:jar:1.0-SNAPSHOT':

The following profiles are active:

 - dev (source: com.curso:s04-1-demos:1.0-SNAPSHOT)
</pre>

`source: com.curso:s04-1-demos:1.0-SNAPSHOT` indica que el perfil `dev` está definido en el propio `pom.xml` del proyecto.

Saber que un perfil está activo no dice, por sí solo, qué valor toma una propiedad concreta; para eso está `mvn help:evaluate`, otro goal del mismo plugin, que responde a la pregunta "¿qué valor tiene esta propiedad ahora mismo?". `-Dexpression=app.entorno` indica qué propiedad se quiere consultar; `-DforceStdout` hace que el resultado se imprima directamente en la terminal, sin decoración adicional (sin él, `help:evaluate` abre un modo interactivo pensado para otro uso).

```bash
mvn help:evaluate -Dexpression=app.entorno -DforceStdout
```
<pre>
sin-perfil
</pre>

```bash
mvn help:evaluate -Dexpression=app.entorno -DforceStdout -Pdev
```
<pre>
desarrollo
</pre>

```bash
mvn help:evaluate -Dexpression=app.entorno -DforceStdout -Pprod
```
<pre>
producción
</pre>

El mismo `pom.xml`, sin tocarlo entre una prueba y otra, da tres valores distintos según qué perfil se active. Esto confirma que el mecanismo de perfiles funciona, sin haber escrito todavía ni una línea de código Java, y son dos comandos que se van a seguir usando durante el resto del curso cada vez que haga falta comprobar, rápido y sin ambigüedad, qué perfil está realmente activo.

### Una comprobación provisional desde Java

Las dos herramientas anteriores confirman que Maven elige bien el valor, pero eso no basta para dar por resuelto el problema del principio: la aplicación de verdad, escrita en Java, todavía no se entera de nada. Antes de montar el mecanismo definitivo (que llega en la Demo 2), conviene hacer una comprobación rápida: ¿se puede hacer que un programa Java, sin más aparato, reciba el valor de una propiedad Maven?

La forma más directa de pasarle un valor a un programa Java desde fuera es una **propiedad del sistema**: un par clave-valor que se le entrega a la JVM en el momento de arrancarla, y que el programa puede leer con `System.getProperty("clave")`. Ya se ha visto un caso concreto de propiedad del sistema en S03-2, con `-DskipTests`; aquí se generaliza la idea: cualquier propiedad, no solo `skipTests`, se puede pasar así.

`exec-maven-plugin`, que ya se usó en S03-2 para ejecutar una clase con `mvn exec:java`, permite configurar qué propiedades del sistema recibe la JVM que ejecuta la clase, con `<systemProperties>`. Lo añadimos al `pom.xml`:

```xml
<build>
    <plugins>
        <!-- exec-maven-plugin ya se usó en S03-2 para ejecutar una clase con
             mvn exec:java. Aquí no se fija <mainClass>, porque el proyecto va a
             tener varias clases ejecutables (una por demo): cada comando indica
             la que le toca con -Dexec.mainClass=... -->
        <plugin>
            <groupId>org.codehaus.mojo</groupId>
            <artifactId>exec-maven-plugin</artifactId>
            <version>3.2.0</version>
            <configuration>
                <!-- systemProperties: propiedades del sistema que Maven pasa a la JVM
                     que ejecuta la clase, accesibles con System.getProperty("clave").
                     ${app.entorno} y ${app.db.url} se sustituyen por el valor del
                     perfil activo antes de arrancar la JVM. -->
                <systemProperties>
                    <systemProperty>
                        <key>app.entorno</key>
                        <value>${app.entorno}</value>
                    </systemProperty>
                    <systemProperty>
                        <key>app.db.url</key>
                        <value>${app.db.url}</value>
                    </systemProperty>
                </systemProperties>
            </configuration>
        </plugin>
    </plugins>
</build>
```

A diferencia de S03-2, aquí no se fija ningún `<mainClass>` en la configuración del plugin, porque este proyecto va a tener varias clases ejecutables y `<mainClass>` solo admite un valor a la vez. En su lugar, cada comando indica qué clase ejecutar con la propiedad `-Dexec.mainClass=...`, que sustituye al valor de `<mainClass>` cuando este no está definido en el `pom.xml`. Este mismo patrón (`-D` seguido del nombre de una propiedad y su valor) es el que ya se usa para pasar `app.entorno` y `app.db.url`: `-D` es, en general, la forma de pasarle a Maven (y, a través de él, a la JVM) una propiedad por línea de comandos.

La clase `MostrarEntorno` se limita a leer esas dos propiedades del sistema y a imprimirlas:

```java
package com.curso;

/**
 * S04-1 Demo 1: Definición de perfiles
 *
 * Objetivo: comprobar que un perfil Maven cambia el valor de una propiedad
 * en tiempo de construcción, y que ese cambio llega hasta un programa Java
 * en ejecución. Es una comprobación provisional: la Demo 2 sustituye este
 * mecanismo por la forma en que una aplicación real gestiona su
 * configuración.
 *
 * Lo que hace este ejemplo:
 *   - Lee dos propiedades del sistema, app.entorno y app.db.url
 *   - Esas propiedades no las define quien ejecuta el programa a mano: las
 *     rellena Maven, con el valor del perfil activo, justo antes de arrancar
 *     la JVM
 *   - Imprime ambos valores para comprobar qué perfil estaba activo
 *
 * Concepto clave: esta clase no sabe nada de Maven ni de perfiles. Solo lee
 * dos propiedades del sistema con System.getProperty(), el mismo mecanismo
 * que usa cualquier programa Java para leer un valor que le llega desde
 * fuera con -D. Toda la lógica de "qué valor toca según el entorno" vive en
 * el pom.xml, no aquí.
 */
public class MostrarEntorno {

    // main() se ejecuta con mvn compile exec:java. Los valores de
    // app.entorno y app.db.url no existen todavía cuando se ejecuta con el
    // botón ▶ de IntelliJ: solo los rellena exec-maven-plugin, y solo
    // cuando es Maven quien arranca el programa.
    public static void main(String[] args) {
        // System.getProperty(clave) devuelve el valor de una propiedad del
        // sistema, o null si no existe ninguna con ese nombre. Aquí las dos
        // propiedades siempre existen: si no hay ningún perfil activo,
        // exec-maven-plugin las rellena igualmente, con el valor por
        // defecto declarado en <properties> (sin-perfil, sin-configurar).
        String entorno = System.getProperty("app.entorno");
        String dbUrl = System.getProperty("app.db.url");

        System.out.println("Entorno activo: " + entorno);     // → depende del perfil
        System.out.println("URL de base de datos: " + dbUrl); // → depende del perfil
    }
}
```

### Ejecutar

```bash
mvn compile exec:java -Dexec.mainClass=com.curso.MostrarEntorno
```

`compile` va antes de `exec:java` para asegurar que las clases están compiladas; `exec:java` es el goal de `exec-maven-plugin` que arranca una JVM y ejecuta en ella la clase indicada.

Salida esperada, sin ningún perfil activo:

<pre>
Entorno activo: sin-perfil
URL de base de datos: sin-configurar
</pre>

Con `-Pdev`:

```bash
mvn compile exec:java -Dexec.mainClass=com.curso.MostrarEntorno -Pdev
```

<pre>
Entorno activo: desarrollo
URL de base de datos: jdbc:h2:mem:devdb
</pre>

Con `-Pprod`:

```bash
mvn compile exec:java -Dexec.mainClass=com.curso.MostrarEntorno -Pprod
```

<pre>
Entorno activo: producción
URL de base de datos: jdbc:postgresql://servidor-prod:5432/appdb
</pre>

El código de `MostrarEntorno` no ha cambiado entre las tres ejecuciones. Lo único que ha cambiado es qué perfil se activó al invocar Maven, y eso ha bastado para cambiar por completo lo que el programa imprime.

Una nota práctica antes de cerrar la demo: esta clase no se ejecuta con el botón ▶ de IntelliJ como se ha hecho hasta ahora. Si se ejecutara así, ninguna propiedad del sistema estaría definida (IntelliJ no sabe qué escribir ahí) y `System.getProperty("app.entorno")` devolvería `null`, así que el programa imprimiría `Entorno activo: null`. Las propiedades del sistema solo existen cuando es Maven, a través de `exec-maven-plugin`, quien arranca el programa; por eso a partir de aquí se trabaja desde la terminal con comandos `mvn`.

**Con esto queda demostrado que el mecanismo de perfiles funciona de punta a punta, hasta llegar a Java.** Pero `MostrarEntorno` no es una solución que se pueda dar por buena: ninguna aplicación real recibe su configuración así, con propiedades del sistema fabricadas por un plugin de Maven cada vez que se arranca desde la terminal con un comando concreto. Es momento de construir la forma en que una aplicación real lo hace de verdad, en la Demo 2.

---

## Demo 2: El panel de arranque (filtrado de recursos)

### Por qué la comprobación de la Demo 1 no es la solución final

Piensa en cualquier programa que tengas instalado (un servidor web, una base de datos, un editor con plugins). Ninguno de ellos recibe su configuración por un argumento secreto que alguien tiene que teclear cada vez que lo arranca: leen un **fichero de configuración**, una vez, al arrancar, que se puede abrir con cualquier editor de texto y modificar sin tocar el programa ni recompilar nada. `MostrarEntorno` no funciona así: depende de que quien ejecute el comando escriba exactamente `exec.mainClass` y de que `exec-maven-plugin` esté configurado con `<systemProperties>`, algo muy específico de cómo se ha montado esta demo en Maven, no una forma de configuración que vaya a reconocer nadie fuera de este curso.

Aquí nace el **panel de arranque**: una clase Java que, nada más ejecutarse, imprime en pantalla los datos que identifican esa instancia concreta de la aplicación. Por ahora, solo el entorno y la base de datos; en la Demo 3 se completa con la versión y la fecha de compilación. Para construirlo hace falta un mecanismo nuevo: el **filtrado de recursos**, que traslada un valor calculado por Maven a un fichero de texto normal, que cualquier programa Java puede leer de la forma habitual, sin pasar por `exec-maven-plugin` ni por propiedades del sistema.

### El filtrado de recursos

Hasta ahora, todo lo que hubiera en `src/main/resources` se copiaría tal cual a `target/classes` al compilar, sin que Maven tocara su contenido (de hecho, esa carpeta ha estado vacía desde que se creó el primer proyecto Maven del curso, en S02-1). El **filtrado de recursos** cambia ese comportamiento: cuando está activado, Maven recorre cada fichero de `src/main/resources` y sustituye cualquier `${propiedad}` que encuentre por su valor, igual que hace dentro del propio `pom.xml`, antes de copiar el resultado a `target/classes`. Se activa con `<filtering>true</filtering>`:

```xml
<build>
    <!-- filtering: true activa el filtrado de recursos. Maven sustituye,
         dentro de cada fichero de src/main/resources, cualquier ${propiedad}
         por su valor antes de copiarlo a target/classes. Sin esta línea,
         los ficheros de recursos se copian tal cual, sin sustituir nada. -->
    <resources>
        <resource>
            <directory>src/main/resources</directory>
            <filtering>true</filtering>
        </resource>
    </resources>
</build>
```

Sin esta configuración, `<resources>` no hace falta declararlo en absoluto: Maven ya copia `src/main/resources` a `target/classes` por defecto, sin filtrar nada. Declarar `<resources>` de forma explícita es precisamente lo que permite añadir `<filtering>true</filtering>`, algo que no existe de ninguna otra forma.

Una forma útil de pensarlo, con una analogía: el fichero en `src/main/resources` es como una carta modelo con huecos ("Estimado/a **[NOMBRE]**, su pedido **[NÚMERO]** ha sido..."), y el filtrado de recursos es como una combinación de correspondencia que rellena esos huecos con datos reales antes de imprimir la carta final. El fichero modelo (con los huecos) es el que está en `src/main/resources`; la carta ya rellena es la que aparece en `target/classes` después de compilar.

### Por qué basta con `mvn compile`

El filtrado ocurre en la fase `process-resources` del ciclo de vida de Maven. Esta fase no se ha mencionado hasta ahora en el curso (en S03-2 se vieron `compile`, `test` y `package`), y va **antes** que `compile` en el orden del ciclo de vida. Como ya se sabe desde S03-2, invocar una fase de Maven ejecuta automáticamente, en orden, todas las fases anteriores; por eso, al ejecutar `mvn compile`, Maven ejecuta primero `process-resources` (aunque no se haya escrito ese nombre en ningún sitio) y solo después `compile`. Se puede ver en la propia salida de Maven, en el orden exacto en que aparecen los goals:

```bash
mvn clean compile
```

<pre>
[INFO] --- clean:3.2.0:clean (default-clean) @ s04-1-demos ---
[INFO] Deleting .../target
[INFO]
[INFO] --- resources:3.3.1:resources (default-resources) @ s04-1-demos ---
[INFO] Copying 1 resource from src/main/resources to target/classes
[INFO]
[INFO] --- compiler:3.13.0:compile (default-compile) @ s04-1-demos ---
[INFO] Compiling 2 source files with javac [debug target 21] to target/classes
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
</pre>

`resources:resources` (que es donde ocurre el filtrado) sale antes que `compiler:compile`, sin que se haya pedido explícitamente. Esto es exactamente por lo que, cuando en la Demo 1 se ejecutaba `mvn compile exec:java`, no hacía falta añadir ningún paso más: `mvn compile` ya incluye, por composición, todo lo necesario para dejar los recursos filtrados y listos en `target/classes` antes de que el código compilado (y, más tarde, `exec:java`) pueda leerlos.

### El fichero de configuración: application.properties

`application.properties` es un fichero de texto con el formato `clave=valor`, una pareja por línea. Se coloca en `src/main/resources`, la carpeta que existe desde S02-1 pero que hasta ahora estaba vacía. Por ahora, solo con las dos propiedades del panel de arranque que ya conocemos de la Demo 1:

```
app.entorno=${app.entorno}
app.db.url=${app.db.url}
```

Tal como está escrito aquí, este fichero **no contiene ningún valor real**: contiene dos marcadores, exactamente los mismos nombres de propiedad ya definidos en los perfiles `dev` y `prod` del `pom.xml`. Solo se convierte en un fichero con valores reales después de que Maven lo filtre, en la fase `process-resources`.

### Leerlo desde Java: la clase PanelArranque

Para leer un fichero de propiedades desde Java se usa `java.util.Properties`, una clase de la librería estándar (no hace falta ninguna dependencia externa) diseñada exactamente para este formato de fichero.

```java
package com.curso;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

/**
 * S04-1 Demo 2: El panel de arranque (filtrado de recursos)
 *
 * Objetivo: leer, desde código Java, application.properties, el fichero de
 * configuración que Maven ha rellenado con los valores del perfil activo
 * mediante el filtrado de recursos.
 *
 * Lo que hace este ejemplo:
 *   - Carga application.properties desde el classpath con getResourceAsStream
 *   - Lo interpreta con java.util.Properties, con el encoding correcto
 *   - Imprime cada valor para comprobar que Maven los ha sustituido de verdad
 *
 * Concepto clave: el fichero que esta clase lee en tiempo de ejecución
 * (target/classes/application.properties) no es el mismo que el fichero que
 * hemos escrito en src/main/resources. Maven copia uno a partir del otro,
 * sustituyendo cada ${propiedad} por su valor, antes de que el programa
 * arranque.
 */
public class PanelArranque {

    // main() se ejecuta con mvn compile exec:java. No usamos IntelliJ (▶)
    // directamente porque application.properties solo queda filtrado en
    // target/classes cuando Maven procesa los recursos primero (fase
    // process-resources); mvn compile la incluye automáticamente.
    public static void main(String[] args) throws IOException {
        // Properties es una clase de la librería estándar de Java (java.util)
        // pensada exactamente para este formato: ficheros de texto con líneas
        // clave=valor. No hace falta ninguna dependencia externa para usarla.
        Properties propiedades = new Properties();

        // getResourceAsStream busca el fichero dentro del classpath, no en el
        // disco por ruta absoluta. El classpath del proyecto compilado incluye
        // target/classes, así que "/application.properties" (con la barra
        // inicial, que indica la raíz del classpath) encuentra el fichero que
        // Maven acaba de generar con el filtrado ya aplicado.
        //
        // try-with-resources: los recursos que abren getResourceAsStream y
        // el InputStreamReader se cierran automáticamente al salir del bloque
        // try, incluso si load() lanza una excepción.
        //
        // load(Reader), no load(InputStream): este último interpreta el
        // fichero siempre en ISO-8859-1, y "producción" (perfil prod) se leería
        // mal. Envolviendo el InputStream en un InputStreamReader con
        // StandardCharsets.UTF_8 se lee con el mismo encoding con el que se
        // escribió. Se explica en detalle más abajo.
        try (InputStream entrada = PanelArranque.class.getResourceAsStream("/application.properties");
             InputStreamReader lector = new InputStreamReader(entrada, StandardCharsets.UTF_8)) {
            propiedades.load(lector);
        }

        // getProperty(clave) devuelve el valor asociado a esa clave como String,
        // o null si la clave no existe en el fichero.
        System.out.println("=== Panel de arranque ===");
        System.out.println("Entorno: " + propiedades.getProperty("app.entorno"));
        System.out.println("Base de datos: " + propiedades.getProperty("app.db.url"));
    }
}
```

Varios elementos de este código son nuevos y merecen explicación por separado, sin dar nada por sabido.

**`java.util.Properties`**: es una clase pensada para cargar y consultar exactamente este tipo de fichero. Se comporta, por dentro, de forma parecida a un diccionario: una vez cargado el fichero con `load(...)`, cada línea `clave=valor` queda accesible llamando a `getProperty("clave")`. Por ejemplo, si el fichero cargado contiene la línea `app.entorno=desarrollo`, entonces `propiedades.getProperty("app.entorno")` devuelve el `String` `"desarrollo"`; si se pidiera una clave que no existe en el fichero, el resultado sería `null`, no un error.

**El classpath y `getResourceAsStream`**: el **classpath** es el conjunto de carpetas y JARs donde la JVM busca clases y recursos cuando el programa los pide en tiempo de ejecución. Para un proyecto Maven compilado, el classpath incluye `target/classes`, que es justo donde el filtrado de recursos ha dejado copiado (y ya sustituido) `application.properties`. El método `getResourceAsStream("/application.properties")` busca un fichero **dentro de ese classpath**, no en el disco por una ruta de sistema de ficheros. La barra inicial en `"/application.properties"` indica que la búsqueda empieza en la raíz del classpath; sin esa barra, `getResourceAsStream` buscaría dentro del paquete de la clase que hace la llamada (aquí, dentro de `com/curso/`), donde el fichero no está, porque `application.properties` está en la raíz de `target/classes`, no dentro de `target/classes/com/curso/`.

Un ejemplo concreto de por qué importa esta distinción: si se intentara leer el fichero con una ruta de disco, como `new FileInputStream("src/main/resources/application.properties")`, el programa leería el fichero **sin filtrar**, con los marcadores `${...}` todavía sin sustituir, porque esa ruta apunta directamente al fichero fuente, no al que ha generado Maven. `getResourceAsStream`, en cambio, siempre encuentra la versión que está en el classpath en tiempo de ejecución, que es la ya filtrada.

Otro caso que conviene anticipar, porque es fácil de encontrarse por accidente: si el fichero de recursos no existiera en absoluto en `src/main/resources` (por ejemplo, por haberlo borrado o llamado con otro nombre), `getResourceAsStream` no lanzaría ninguna excepción: devolvería `null`, sin más. El error aparecería una línea después, al intentar usar ese `null` como si fuera un `InputStream` válido: `Properties.load(...)` comprueba internamente que su argumento no sea `null` y, si lo es, lanza un `NullPointerException` con el mensaje `inStream parameter is null`. Es un fallo real y frecuente, así que conviene saber leerlo: no significa que Maven se haya negado a compilar (el build de `mvn compile` termina en `BUILD SUCCESS` igualmente, porque copiar cero ficheros de una carpeta no es un error para Maven), significa que el código ha intentado leer un recurso que no estaba en el classpath en el momento de ejecutarse.

**`try-with-resources`**: es la forma `try (Tipo variable = ...) { ... }`, ya usada de forma implícita en prácticas anteriores del curso para otros recursos, y explicada aquí en detalle por primera vez. Cualquier objeto que implemente la interfaz `AutoCloseable` (como `InputStream` o `Reader`) se puede declarar dentro del paréntesis de un `try`; al salir del bloque `try`, con o sin excepción, Java llama automáticamente a su método `close()`. Sin `try-with-resources`, habría que escribir algo como esto:

```java
InputStream entrada = PanelArranque.class.getResourceAsStream("/application.properties");
InputStreamReader lector = new InputStreamReader(entrada, StandardCharsets.UTF_8);
try {
    propiedades.load(lector);
} finally {
    lector.close();
}
```

con el riesgo de olvidar el `close()` (dejando el recurso abierto más tiempo del necesario) o de escribirlo mal si `load()` lanza una excepción antes de llegar a esa línea. `try-with-resources` hace innecesario este código repetitivo y evita ese riesgo por completo.

### Aparte: por qué se lee con `load(Reader)` y no con `load(InputStream)`

Este es el punto más delicado de la demo. Se explica aparte, con calma, porque es fácil de pasar por alto y produce resultados confusos en un proyecto real: el programa compila, se ejecuta, no lanza ninguna excepción, y aun así un dato concreto sale mal, sin ningún aviso.

**El problema, en una frase:** `Properties.load(InputStream)` interpreta el contenido del fichero asumiendo el juego de caracteres **ISO-8859-1** (también llamado Latin-1), sea cual sea el encoding real con el que se guardó el fichero en disco.

Para entender por qué esto es un problema, hace falta un ejemplo concreto de cómo se representa un carácter en bytes. Un **encoding** (o codificación de caracteres) es la regla que dice cómo convertir cada carácter de texto en una secuencia de bytes, y viceversa. ISO-8859-1 es un encoding antiguo, anterior a UTF-8, en el que **cada carácter ocupa exactamente un byte**; UTF-8, el encoding que usa este proyecto (declarado en `project.build.sourceEncoding` desde que se creó, en S02-1), representa los caracteres ASCII básicos (letras sin tilde, números, la mayoría de los símbolos) también con un byte, pero representa una letra con tilde o una eñe con **dos bytes**. Por ejemplo, la letra "ó" en UTF-8 se guarda como los dos bytes `0xC3 0xB3`.

Cuando `load(InputStream)` lee esos dos bytes (`0xC3 0xB3`) interpretándolos como si fueran ISO-8859-1, no ve "una letra ó": ve **dos caracteres ISO-8859-1 distintos**, uno por cada byte (`0xC3` es "Ã" en ISO-8859-1, y `0xB3` es "³"). El resultado es una secuencia de caracteres irreconocible, algo parecido a `producciÃ³n` en vez de `producción`. No es un error que Java detecte ni que interrumpa el programa: es, sencillamente, un dato incorrecto que compila y se ejecuta sin ningún aviso, y que solo se descubre mirando el resultado con atención.

**La solución:** usar `Properties.load(Reader)` en lugar de `Properties.load(InputStream)`. Un `Reader` en Java es un flujo de **caracteres** ya decodificados, no de bytes en bruto; a diferencia de `load(InputStream)`, `load(Reader)` no impone ningún encoding por su cuenta: usa el que tenga el `Reader` que se le pase. Envolviendo el `InputStream` en un `InputStreamReader`, construido con `StandardCharsets.UTF_8` como segundo argumento, se le dice explícitamente a Java: "estos bytes están en UTF-8, decodifícalos así, no asumas nada por tu cuenta". Con ese `Reader`, `load(...)` obtiene los caracteres ya correctos, porque decodifica los mismos bytes con el mismo encoding con el que se escribieron.

Esta es la razón por la que, en cualquier proyecto real que maneje texto en español (o en cualquier idioma con tildes, eñes o símbolos fuera del ASCII básico), es buena práctica leer siempre los ficheros de texto indicando el encoding de forma explícita, en vez de confiar en el que la API elija por defecto. El propio nombre del método, `load(InputStream)`, no deja ver que interpreta el encoding "a su manera"; solo se descubre leyendo su documentación o, como aquí, viendo el resultado equivocado con un dato concreto.

### Ejecutar sin perfil, compilando cada vez

El filtrado ocurre al **compilar**, no al ejecutar (esto se explicó unas secciones más arriba, y aquí se vuelve importante de verdad): por eso cada una de las tres pruebas siguientes empieza con `mvn clean`, para borrar `target` y forzar que el filtrado se repita desde cero con el perfil indicado en cada caso. Si se saltara este paso, sería fácil pensar que se está viendo el efecto de un perfil que en realidad no se ha vuelto a aplicar, porque el fichero filtrado de la compilación anterior seguiría ahí.

```bash
mvn clean
mvn compile exec:java -Dexec.mainClass=com.curso.PanelArranque
```

Salida esperada:

<pre>
=== Panel de arranque ===
Entorno: sin-perfil
Base de datos: sin-configurar
</pre>

### Compilar con -Pdev

```bash
mvn clean
mvn compile exec:java -Dexec.mainClass=com.curso.PanelArranque -Pdev
```

Salida esperada:

<pre>
=== Panel de arranque ===
Entorno: desarrollo
Base de datos: jdbc:h2:mem:devdb
</pre>

### Compilar con -Pprod

```bash
mvn clean
mvn compile exec:java -Dexec.mainClass=com.curso.PanelArranque -Pprod
```

Salida esperada:

<pre>
=== Panel de arranque ===
Entorno: producción
Base de datos: jdbc:postgresql://servidor-prod:5432/appdb
</pre>

Nótese que "producción" sale bien, con su tilde, gracias al cambio de `load(InputStream)` a `load(Reader)` explicado más arriba. El panel de arranque ya funciona de verdad: es una clase Java corriente, que cualquiera podría llamar al arrancar la aplicación, y que lee su configuración de un fichero normal, sin ningún truco de Maven de por medio. El truco (el filtrado) ha ocurrido antes, al compilar, y el programa no sabe ni necesita saber que ha ocurrido.

---

## Demo 3: Completar el panel con los datos de compilación

### El problema que queda abierto

El panel de arranque ya dice en qué entorno está corriendo la aplicación y a qué base de datos se conecta. Pero ante un incidente real, la primera pregunta de soporte casi siempre es otra: "¿qué versión tienes desplegada, y de cuándo es ese build?". Sin esa información en algún sitio visible, hay que ir a mirarlo a mano (al historial de despliegues, al pipeline de integración continua...), perdiendo un tiempo que en un incidente activo es crítico.

La buena noticia es que Maven ya conoce esos datos sobre el propio proyecto, sin que nadie los escriba a mano en ningún sitio: la versión está en `<version>` del `pom.xml`, y la fecha de compilación es, literalmente, el momento en que se está ejecutando Maven ahora mismo. Solo hace falta llevarlos hasta el panel de arranque, con el mismo mecanismo que ya tenemos montado: el filtrado de recursos.

### Las propiedades predefinidas de Maven

Además de las propiedades que se declaran a mano en `<properties>` o dentro de un perfil, Maven calcula por su cuenta un conjunto de propiedades sobre el propio proyecto: su versión, su nombre, la fecha en que se está compilando... Se llaman **propiedades predefinidas** porque existen siempre, en cualquier proyecto Maven, sin que nadie las declare. Se usan igual que cualquier otra propiedad, con `${nombre}`.

Las tres que necesita el panel de arranque:

- `${project.version}`: la versión del proyecto, tal como aparece en `<version>` del `pom.xml` (`1.0-SNAPSHOT` en este curso).
- `${project.artifactId}`: el `artifactId` del proyecto (`s04-1-demos` en este caso).
- `${maven.build.timestamp}`: la fecha y hora exactas en que se está ejecutando Maven, calculada en el momento de arrancar el build, en formato ISO-8601 y hora UTC por defecto (por ejemplo, `2026-09-28T12:52:58Z`).

**Una propiedad predefinida se puede escribir dentro del propio `pom.xml` sin ningún paso adicional**, igual que cualquier otra propiedad; eso ya se sabe de S02-1 en adelante. Lo que no se puede hacer directamente es escribirla dentro de un fichero `.java`: un fichero `.java` no lo procesa Maven, lo procesa el compilador de Java, así que un `${project.version}` escrito dentro de un `.java` no significaría nada para Java; se quedaría como texto literal, sin sustituir. Para que este valor llegue al código hace falta el mismo mecanismo que ya conocemos, el filtrado de recursos: exactamente el que ya está montado y funcionando desde la Demo 2.

### Ampliar application.properties

No se crea ningún fichero nuevo: se añaden tres líneas más al `application.properties` que ya existe, con el mismo formato `clave=valor` que las dos que ya había:

```
app.entorno=${app.entorno}
app.db.url=${app.db.url}
app.version=${project.version}
app.nombre=${project.artifactId}
app.compilado=${maven.build.timestamp}
```

Las dos primeras líneas toman su valor de un perfil (o de los valores por defecto, si no hay ninguno activo); las tres últimas toman su valor de propiedades que Maven ya conocía sobre el proyecto, sin que ningún perfil las declare. Para el filtrado de recursos, la diferencia entre unas y otras no existe: recorre el fichero línea a línea y sustituye cualquier `${propiedad}` que reconozca, sea cual sea su origen. Es la misma razón por la que, dentro del `pom.xml`, se puede mezclar libremente una propiedad declarada a mano con una predefinida: para Maven, en el momento de resolver un `${...}`, todas las propiedades viven en el mismo sitio.

### Ampliar PanelArranque

La clase no cambia de forma, solo se amplía con tres líneas más, que leen las claves nuevas de la misma forma que ya se leían las dos anteriores. Así queda `PanelArranque` completa, en su versión final:

```java
package com.curso;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

/**
 * S04-1 Demos 2 y 3: El panel de arranque
 *
 * Objetivo: leer, desde código Java, application.properties, el fichero de
 * configuración que Maven ha rellenado mediante el filtrado de recursos,
 * combinando dos tipos de valores:
 *   - Propiedades de un perfil Maven (app.entorno, app.db.url), que cambian
 *     según el perfil activo al compilar (Demo 2)
 *   - Propiedades predefinidas de Maven sobre el propio proyecto
 *     (app.version, app.nombre, app.compilado), que Maven ya conoce sin que
 *     nadie las declare (Demo 3)
 *
 * Concepto clave: PanelArranque no distingue entre los dos tipos de
 * propiedades. Para cuando el filtrado de recursos ha terminado, ambas están
 * ya sustituidas en el mismo fichero, con el mismo formato clave=valor; el
 * código las lee todas de la misma forma, sin saber ni necesitar saber de
 * dónde ha sacado Maven cada valor.
 */
public class PanelArranque {

    // main() se ejecuta con mvn compile exec:java. No usamos IntelliJ (▶)
    // directamente porque application.properties solo queda filtrado en
    // target/classes cuando Maven procesa los recursos primero (fase
    // process-resources); mvn compile la incluye automáticamente.
    public static void main(String[] args) throws IOException {
        // Properties es una clase de la librería estándar de Java (java.util)
        // pensada exactamente para este formato: ficheros de texto con líneas
        // clave=valor. No hace falta ninguna dependencia externa para usarla.
        Properties propiedades = new Properties();

        // getResourceAsStream busca el fichero dentro del classpath, no en el
        // disco por ruta absoluta. El classpath del proyecto compilado incluye
        // target/classes, así que "/application.properties" (con la barra
        // inicial, que indica la raíz del classpath) encuentra el fichero que
        // Maven acaba de generar con el filtrado ya aplicado.
        //
        // try-with-resources: los recursos que abren getResourceAsStream y
        // el InputStreamReader se cierran automáticamente al salir del bloque
        // try, incluso si load() lanza una excepción.
        //
        // load(Reader), no load(InputStream): este último interpreta el
        // fichero siempre en ISO-8859-1, y "producción" (perfil prod) se leería
        // mal. Envolviendo el InputStream en un InputStreamReader con
        // StandardCharsets.UTF_8 se lee con el mismo encoding con el que se
        // escribió. Se explica en detalle en la Demo 2.
        try (InputStream entrada = PanelArranque.class.getResourceAsStream("/application.properties");
             InputStreamReader lector = new InputStreamReader(entrada, StandardCharsets.UTF_8)) {
            propiedades.load(lector);
        }

        // getProperty(clave) devuelve el valor asociado a esa clave como String,
        // o null si la clave no existe en el fichero.
        System.out.println("=== Panel de arranque ===");
        System.out.println("Entorno: " + propiedades.getProperty("app.entorno"));
        System.out.println("Base de datos: " + propiedades.getProperty("app.db.url"));
        System.out.println("Versión: " + propiedades.getProperty("app.version"));
        System.out.println("Artefacto: " + propiedades.getProperty("app.nombre"));
        System.out.println("Compilado el: " + propiedades.getProperty("app.compilado"));
    }
}
```

Nada cambia de lo que ya funcionaba en la Demo 2: ni el `try-with-resources`, ni el `load(Reader)` con UTF-8, ni la forma de llamar a `getResourceAsStream`. Solo hay tres claves más que leer del mismo fichero.

### Ejecutar

Como en la Demo 2, cada prueba empieza con `mvn clean` para forzar que el filtrado se repita desde cero.

```bash
mvn clean
mvn compile exec:java -Dexec.mainClass=com.curso.PanelArranque
```

<pre>
=== Panel de arranque ===
Entorno: sin-perfil
Base de datos: sin-configurar
Versión: 1.0-SNAPSHOT
Artefacto: s04-1-demos
Compilado el: 2026-09-28T15:17:48Z
</pre>

```bash
mvn clean
mvn compile exec:java -Dexec.mainClass=com.curso.PanelArranque -Pdev
```

<pre>
=== Panel de arranque ===
Entorno: desarrollo
Base de datos: jdbc:h2:mem:devdb
Versión: 1.0-SNAPSHOT
Artefacto: s04-1-demos
Compilado el: 2026-09-28T15:17:50Z
</pre>

```bash
mvn clean
mvn compile exec:java -Dexec.mainClass=com.curso.PanelArranque -Pprod
```

<pre>
=== Panel de arranque ===
Entorno: producción
Base de datos: jdbc:postgresql://servidor-prod:5432/appdb
Versión: 1.0-SNAPSHOT
Artefacto: s04-1-demos
Compilado el: 2026-09-28T15:17:54Z
</pre>

(La fecha de `Compilado el` cambia en cada ejecución, porque `maven.build.timestamp` se recalcula en cada build.)

El panel de arranque queda completo: entorno, base de datos, versión y fecha de compilación, todo en un único fichero de configuración que la aplicación carga al arrancar, generado automáticamente por Maven a partir de dos fuentes distintas (un perfil y las propiedades predefinidas del proyecto) que, para el código Java que lo lee, son indistinguibles.

### Una referencia hacia delante: Spring Boot

El nombre `application.properties` no se ha elegido al azar: es el nombre real que usa Spring Boot, que se verá en el módulo de Spring, para exactamente esta misma función, un fichero de configuración que la aplicación lee al arrancar. Spring Boot añade sus propios mecanismos por encima (ficheros distintos por perfil, como `application-dev.properties`, y su propia forma de activar un perfil con `-Dspring.profiles.active=dev`, que recuerda mucho al `System.getProperty` provisional de la Demo 1), pero la idea de fondo, un fichero de texto con pares `clave=valor` que la aplicación carga una vez al arrancar, es exactamente la que se acaba de construir aquí a mano, con Maven puro.
