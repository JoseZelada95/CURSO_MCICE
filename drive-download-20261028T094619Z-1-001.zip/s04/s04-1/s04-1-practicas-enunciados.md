# S04-1 Prácticas

## Objetivos

Se aplica lo aprendido en las demos: perfiles Maven con propiedades propias y filtrado de recursos para trasladar esas propiedades a un fichero de configuración que el código Java lee. Las tres prácticas se hacen sobre el mismo proyecto Maven, y avanzan desde configurar una base de datos por perfil, pasando por automatizar cuándo se activa un perfil, hasta proteger una credencial real fuera del `pom.xml`.

---

## Práctica 1: Configuración de base de datos por perfil

Se crea un proyecto Maven nuevo con dos perfiles, `dev` y `prod`, cada uno con sus propias propiedades de conexión a base de datos. Se usa el filtrado de recursos para que un fichero `db.properties` tome esos valores según el perfil activo, y una clase `ConfiguracionDB` los lee e imprime.

**Pasos**

1. Creamos un nuevo proyecto Maven en IntelliJ desde `File > New > Project`, con `Java` seleccionado en el panel izquierdo: Name `s04-1-practicas`, Build system `Maven`, JDK `21` y **Add sample code** desmarcada. En `Advanced Settings`, usamos `com.curso` como GroupId y `s04-1-practicas` como ArtifactId.
2. En el `pom.xml`, añadimos un bloque `<profiles>` con dos perfiles: `dev` y `prod`. Cada uno define dos propiedades, `db.url` y `db.usuario`, con valores distintos (por ejemplo, para `dev` una URL de H2 en memoria; para `prod` una URL de PostgreSQL ficticia).
3. En `<properties>`, añadimos las mismas dos propiedades (`db.url` y `db.usuario`) con un valor por defecto, para el caso en que no haya ningún perfil activo.
4. Activamos el filtrado de recursos en `<build><resources>`, igual que en la Demo 2 y la Demo 3 de `s04-1-demos`.
5. Creamos el paquete `com.curso` (clic derecho sobre `src/main/java`, `New > Package`) y, dentro, el fichero de recursos `db.properties` en `src/main/resources` con dos líneas: `db.url=${db.url}` y `db.usuario=${db.usuario}`.
6. Creamos la clase `ConfiguracionDB` en el paquete `com.curso`, con un `main()` que carga `db.properties` desde el classpath con `java.util.Properties` y muestra los dos valores.
7. Añadimos también `exec-maven-plugin` al `pom.xml`, igual que en `s04-1-demos`, para poder ejecutar `ConfiguracionDB` desde Maven.
8. Compilamos y ejecutamos sin perfil, con `-Pdev` y con `-Pprod`, comprobando que los valores impresos cambian en cada caso. No hay que olvidar `mvn clean` entre una compilación y la siguiente para que el filtrado se repita desde cero.

**Pistas**

- El `db.usuario` y la `db.url` de producción no llevan ninguna contraseña: eso se resuelve aparte, en la Práctica 3, precisamente para no dejar una credencial real en el `pom.xml`, que normalmente está en un repositorio de código compartido.
- Si el fichero filtrado en `target/classes/db.properties` sigue mostrando `${db.url}` sin sustituir después de compilar con un perfil, hay que revisar que `<filtering>true</filtering>` está en el `pom.xml` y que el nombre de la propiedad en `db.properties` coincide exactamente (mayúsculas y minúsculas incluidas) con el nombre declarado en el perfil.
- Para leer `db.properties` desde Java, se necesita `getResourceAsStream("/db.properties")` (con la barra inicial) y `java.util.Properties`, igual que en `InfoProyecto` e `InfoEntorno` de las demos.
- Si alguno de los valores fuera a llevar alguna vez tildes o eñes, conviene leer el fichero con un `Reader` en UTF-8 en lugar de con `load(InputStream)` directamente, como se explica en la Demo 3.

---

## Práctica 2: Activación por propiedad del sistema

En el mismo proyecto, se añade un tercer perfil, `ci`, que no se activa con `-P` como `dev` y `prod`, sino automáticamente cuando se pasa una propiedad del sistema concreta al comando de Maven.

**Pasos**

1. En el `pom.xml`, añadimos un tercer perfil con `id` `ci`, con sus propias `db.url` y `db.usuario`.
2. A este perfil le añadimos un bloque `<activation>` con una condición de activación automática basada en una propiedad del sistema: se activa cuando existe una propiedad llamada `entorno` con el valor exacto `ci`.
3. Verificamos la activación automática con `mvn help:active-profiles`, primero sin pasar la propiedad (el perfil `ci` no debe aparecer como activo) y después pasando `-Dentorno=ci` (el perfil `ci` sí debe aparecer).
4. Ejecutamos `ConfiguracionDB` pasando `-Dentorno=ci` y comprobamos que toma los valores del perfil `ci`.
5. Probamos también con un valor distinto, por ejemplo `-Dentorno=otracosa`, y comprobamos que el perfil `ci` no se activa en ese caso.

**Pistas**

- La activación automática va dentro de `<profile><activation><property>`, con dos etiquetas: `<name>` para el nombre de la propiedad del sistema y `<value>` para el valor exacto que tiene que tener.
- La propiedad del sistema se pasa con `-D`, igual que `-DskipTests` en S03-2 o `-Dexec.mainClass` en las demos de esta parte: `-Dentorno=ci`.
- Si el perfil `ci` aparece siempre activo, sin importar el valor de `-Dentorno`, es señal de que falta la etiqueta `<value>` dentro de `<property>` (sin ella, el perfil se activa con que la propiedad exista, tenga el valor que tenga).
- En un pipeline de Jenkins (módulo posterior del curso), este mismo mecanismo permite que el perfil de entorno se active solo con que el job defina una variable de entorno adecuada, sin que nadie tenga que escribir `-P` a mano en cada ejecución.

---

## Práctica 3: Seguridad en la configuración Maven

Sin escribir ningún código Java. Se configura un fichero `settings.xml` propio del proyecto con las credenciales de un servidor privado ficticio, con la contraseña cifrada, y se añade `<distributionManagement>` al `pom.xml` para apuntar a ese repositorio.

**Pasos**

1. En el `pom.xml`, añadimos un bloque `<distributionManagement>` con un `<repository>` que tenga un `id` (por ejemplo, `repo-curso-privado`), un `<name>` descriptivo y una `<url>` ficticia (no hace falta que exista de verdad).
2. Generamos una contraseña maestra cifrada con `mvn --encrypt-master-password`, pasándole una contraseña maestra elegida por nosotros. Guardamos el resultado en un fichero propio del proyecto, `settings-security-curso.xml`, dentro de una etiqueta `<settingsSecurity><master>...</master></settingsSecurity>`.
3. Cifrar la contraseña real del servidor con `mvn --encrypt-password`, indicando con `-Dsettings.security` la ruta al fichero del paso anterior, para que Maven use esa contraseña maestra al cifrar.
4. Creamos un fichero `settings-curso.xml`, también propio del proyecto (no el `~/.m2/settings.xml` del sistema), con un bloque `<servers><server>` que tenga el mismo `id` que el `<repository>` del paso 1, un `<username>` y, como `<password>`, el resultado cifrado del paso 3.
5. Verificamos la configuración con `mvn -s settings-curso.xml -Dsettings.security=settings-security-curso.xml help:effective-settings`, comprobando cómo se muestra la contraseña en la salida.
6. Verificamos con `mvn -s settings-curso.xml help:effective-pom` que el `<distributionManagement>` aparece correctamente en el POM efectivo.
7. Como comprobación final, intentamos `mvn -s settings-curso.xml -Dsettings.security=settings-security-curso.xml clean deploy -DskipTests` contra la URL ficticia y observamos el resultado.

**Pistas**

- `mvn --encrypt-master-password` y `mvn --encrypt-password` no necesitan ningún proyecto Maven en particular: se pueden ejecutar desde cualquier carpeta.
- No se toca el `~/.m2/settings.xml` real de la máquina en ningún paso: todo se hace con los ficheros `settings-curso.xml` y `settings-security-curso.xml` del propio proyecto, indicados con `-s` y `-Dsettings.security` en cada comando.
- El `id` del `<server>` en `settings-curso.xml` y el `id` del `<repository>` en `<distributionManagement>` tienen que ser exactamente el mismo texto: es la forma en que Maven relaciona una URL con sus credenciales.
- El intento de `mvn deploy` del último paso está pensado para fallar: la URL del repositorio es ficticia y no existe ningún servidor detrás. Lo que hay que observar no es que el `deploy` tenga éxito, sino en qué punto exacto falla y qué mensaje da Maven, para comprobar que ha llegado a intentar la conexión con las credenciales correctas.
