# S04-1 Soluciones

## Práctica 1: Configuración de base de datos por perfil

La solución sigue exactamente el mismo patrón que las Demos 1 y 3 de `s04-1-demos`: perfiles con propiedades propias, filtrado de recursos y una clase Java que lee el fichero filtrado. Lo nuevo aquí no es la técnica, sino aplicarla a un caso con sentido real: la configuración de conexión a una base de datos, que en cualquier proyecto real cambia entre desarrollo y producción.

En el `pom.xml`, los dos perfiles y sus valores por defecto:

```xml
<properties>
    <maven.compiler.source>21</maven.compiler.source>
    <maven.compiler.target>21</maven.compiler.target>
    <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>

    <!-- Valores por defecto de las propiedades de base de datos cuando no
         hay ningún perfil dev o prod activo. -->
    <db.url>jdbc:h2:mem:sindb</db.url>
    <db.usuario>sin-configurar</db.usuario>
</properties>

<profiles>
    <!-- Perfil dev: base de datos de desarrollo. -->
    <profile>
        <id>dev</id>
        <properties>
            <db.url>jdbc:h2:mem:cursodb_dev</db.url>
            <db.usuario>usuario_dev</db.usuario>
        </properties>
    </profile>

    <!-- Perfil prod: base de datos de producción. La contraseña real no
         va aquí: se resuelve en la Práctica 3 con settings.xml cifrado. -->
    <profile>
        <id>prod</id>
        <properties>
            <db.url>jdbc:postgresql://servidor-prod:5432/cursodb</db.url>
            <db.usuario>usuario_prod</db.usuario>
        </properties>
    </profile>
</profiles>
```

Y el filtrado de recursos, igual que en las demos:

```xml
<build>
    <resources>
        <resource>
            <directory>src/main/resources</directory>
            <filtering>true</filtering>
        </resource>
    </resources>
</build>
```

El fichero `db.properties`:

```
db.url=${db.url}
db.usuario=${db.usuario}
```

Y la clase `ConfiguracionDB`:

```java
package com.curso;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

/**
 * S04-1 Práctica 1: Configuración de base de datos por perfil
 *
 * Objetivo: leer, desde una clase Java, la configuración de conexión a base
 * de datos que corresponde al perfil activo en el momento de compilar.
 *
 * Aplica las técnicas de S04:
 *   1. Perfiles Maven con propiedades distintas (dev, prod)
 *   2. Filtrado de recursos para trasladar esas propiedades a un fichero
 *      de configuración
 *
 * Concepto clave: separar la configuración de base de datos por perfil evita
 * mezclar credenciales de desarrollo y de producción en el mismo sitio. La
 * clase Java no decide a qué base de datos conectarse: solo lee lo que Maven
 * ha dejado en db.properties según el perfil con el que se compiló.
 */
public class ConfiguracionDB {

    public static void main(String[] args) throws IOException {
        Properties propiedades = new Properties();

        // Se usa load(Reader) con UTF-8 explícito, igual que en InfoEntorno
        // (s04-1-demos, Demo 3): load(InputStream) sin más interpreta el
        // fichero en ISO-8859-1 y corrompería cualquier valor con tildes o
        // eñes. Aquí db.url y db.usuario son ASCII, pero se mantiene la
        // misma forma de leer para no depender de que el valor de turno
        // tenga o no acentos.
        try (InputStream entrada = ConfiguracionDB.class.getResourceAsStream("/db.properties");
             InputStreamReader lector = new InputStreamReader(entrada, StandardCharsets.UTF_8)) {
            propiedades.load(lector);
        }

        System.out.println("URL de conexión: " + propiedades.getProperty("db.url"));
        System.out.println("Usuario: " + propiedades.getProperty("db.usuario"));
    }
}
```

Ejecución sin perfil, con `-Pdev` y con `-Pprod` (cada una precedida de `mvn clean` para forzar que el filtrado se repita):

```bash
mvn clean compile exec:java -Dexec.mainClass=com.curso.ConfiguracionDB
```

<pre>
URL de conexión: jdbc:h2:mem:sindb
Usuario: sin-configurar
</pre>

```bash
mvn clean compile exec:java -Dexec.mainClass=com.curso.ConfiguracionDB -Pdev
```

<pre>
URL de conexión: jdbc:h2:mem:cursodb_dev
Usuario: usuario_dev
</pre>

```bash
mvn clean compile exec:java -Dexec.mainClass=com.curso.ConfiguracionDB -Pprod
```

<pre>
URL de conexión: jdbc:postgresql://servidor-prod:5432/cursodb
Usuario: usuario_prod
</pre>

**Decisiones tomadas**

- Se ha usado `load(Reader)` con UTF-8 en lugar de `load(InputStream)` directamente, aunque en este caso concreto ninguno de los dos valores lleva tildes. La razón es mantener siempre la misma forma segura de leer un fichero de propiedades, en lugar de decidir caso por caso según si el valor de turno tiene o no caracteres especiales: una URL de base de datos hoy no lleva acentos, pero un usuario o un nombre de esquema en un proyecto real sí podría llevarlos.
- No se ha incluido ninguna contraseña de base de datos en `db.properties` ni en los perfiles `dev` y `prod`. Para `dev`, con una base de datos H2 en memoria, no hace falta contraseña real. Para `prod`, incluir aquí una contraseña sería exactamente el error que la Práctica 3 corrige: cualquier credencial real va en `settings.xml`, nunca en el `pom.xml` ni en un fichero de recursos versionado.

---

## Práctica 2: Activación por propiedad del sistema

La solución añade un tercer perfil al mismo `pom.xml` de la Práctica 1. La diferencia con `dev` y `prod` es que este perfil no se activa nunca con `-P`: se activa solo, cuando se cumple una condición.

El perfil se añade dentro del mismo bloque `<profiles>` que ya contenía `dev` y `prod` (Práctica 1), como un tercer `<profile>`:

```xml
<!-- Perfil ci: no se activa con -P, sino solo, cuando la propiedad
     del sistema "entorno" vale exactamente "ci". Práctica 2. -->
<profile>
    <id>ci</id>
    <activation>
        <property>
            <name>entorno</name>
            <value>ci</value>
        </property>
    </activation>
    <properties>
        <db.url>jdbc:h2:mem:cursodb_ci</db.url>
        <db.usuario>usuario_ci</db.usuario>
    </properties>
</profile>
```

El bloque `<activation><property>` es una condición: en lugar de `<id>ci</id>` como único criterio de selección, Maven comprueba en cada ejecución si existe una propiedad del sistema llamada `entorno` (la que da `<name>`) con el valor exacto `ci` (el que da `<value>`). Si la condición se cumple, el perfil se activa como si se hubiera escrito `-Pci`, sin que nadie lo pida explícitamente. Si se omitiera `<value>`, el perfil se activaría con que la propiedad `entorno` existiera, con cualquier valor.

Verificación sin la propiedad:

```bash
mvn help:active-profiles
```

<pre>
Active Profiles for Project 'com.curso:s04-1-practicas:jar:1.0-SNAPSHOT':

The following profiles are active:

</pre>

Ningún perfil aparece activo: `ci` no se activa porque la propiedad `entorno` no existe en el comando.

Verificación con la propiedad:

```bash
mvn help:active-profiles -Dentorno=ci
```

<pre>
Active Profiles for Project 'com.curso:s04-1-practicas:jar:1.0-SNAPSHOT':

The following profiles are active:

 - ci (source: com.curso:s04-1-practicas:1.0-SNAPSHOT)
</pre>

Ejecución con la propiedad:

```bash
mvn clean compile exec:java -Dexec.mainClass=com.curso.ConfiguracionDB -Dentorno=ci
```

<pre>
URL de conexión: jdbc:h2:mem:cursodb_ci
Usuario: usuario_ci
</pre>

Verificación con un valor que no coincide:

```bash
mvn help:active-profiles -Dentorno=otracosa
```

<pre>
Active Profiles for Project 'com.curso:s04-1-practicas:jar:1.0-SNAPSHOT':

The following profiles are active:

</pre>

Con `-Dentorno=otracosa`, la propiedad existe pero su valor no coincide con `ci`, así que el perfil sigue sin activarse: la comparación de `<value>` es exacta, no basta con que la propiedad esté presente.

**Decisiones tomadas**

- Se ha elegido el nombre `entorno` para la propiedad de activación, y no `ci` directamente, porque `-Dentorno=ci` deja claro en el propio comando qué se está indicando (un entorno de ejecución) y no compromete el nombre de la propiedad a coincidir con el `id` del perfil. En un pipeline de Jenkins real, esa misma propiedad se pasaría como variable de entorno del job, sin intervención manual.
- No se ha usado `<os>`, `<jdk>` ni ninguna otra condición de activación de las que ofrece Maven (hay varias, además de `<property>`): la propiedad del sistema es la que tiene sentido para simular una variable que un pipeline de CI controla, que es el caso de uso que se quiere ilustrar.

---

## Práctica 3: Seguridad en la configuración Maven

Esta práctica no añade código Java: añade configuración de Maven y dos ficheros de seguridad propios del proyecto, sin tocar el `~/.m2/settings.xml` real de la máquina.

### distributionManagement en el pom.xml

```xml
<!-- distributionManagement: le dice a "mvn deploy" a qué repositorio
     subir el artefacto que genera este proyecto. El id "repo-curso-privado"
     tiene que coincidir exactamente con el id del <server> configurado en
     settings.xml (Práctica 3): así Maven sabe qué usuario y qué contraseña
     cifrada usar para autenticarse en esa URL en concreto. -->
<distributionManagement>
    <repository>
        <id>repo-curso-privado</id>
        <name>Repositorio privado del curso (ficticio)</name>
        <url>https://nexus.curso.local/repository/maven-releases/</url>
    </repository>
</distributionManagement>
```

`nexus.curso.local` es un dominio ficticio: no existe ningún servidor detrás. El objetivo de esta práctica no es completar un `deploy` real, sino configurar correctamente las credenciales y comprobar que Maven las usa.

### Contraseña maestra cifrada

Antes de cifrar la contraseña del servidor, hace falta una **contraseña maestra**: una contraseña que protege a todas las demás contraseñas cifradas en `settings.xml`. Sin ella, cualquiera que abriera `settings.xml` podría, en teoría, intentar descifrar las contraseñas de los servidores; con ella, hace falta conocer también la contraseña maestra.

```bash
mvn --encrypt-master-password 'ClaveMaestraCurso2026'
```

Salida real:

<pre>
{QbsrtnGWeQMH+h29YUIXzoei2OK/tdDleejU9TyNnZitgE92XbQ3oLee8BTvWULT}
</pre>

Este valor, entre llaves, es la contraseña maestra cifrada. Se guarda en un fichero propio del proyecto, `settings-security-curso.xml` (no en el `~/.m2/settings-security.xml` del sistema, que Jesús puede tener configurado con otra contraseña maestra distinta):

```xml
<settingsSecurity>
  <master>{QbsrtnGWeQMH+h29YUIXzoei2OK/tdDleejU9TyNnZitgE92XbQ3oLee8BTvWULT}</master>
</settingsSecurity>
```

### Contraseña del servidor cifrada con la maestra

Con la contraseña maestra ya en su fichero, se cifra la contraseña real del servidor, indicando con `-Dsettings.security` dónde está esa contraseña maestra:

```bash
mvn --encrypt-password 'ContraseñaServidorCurso' -Dsettings.security=settings-security-curso.xml
```

Salida real:

<pre>
{Dg6vIeDgW/wHycCeMUQDLJNTjIPSRFznDRBLlKk3lCr8IWYnT2Im+d7THGh11I7g}
</pre>

### El settings.xml del proyecto

```xml
<settings xmlns="http://maven.apache.org/SETTINGS/1.2.0">
  <servers>
    <server>
      <id>repo-curso-privado</id>
      <username>usuario-ci</username>
      <password>{Dg6vIeDgW/wHycCeMUQDLJNTjIPSRFznDRBLlKk3lCr8IWYnT2Im+d7THGh11I7g}</password>
    </server>
  </servers>
</settings>
```

El `id` del `<server>` (`repo-curso-privado`) es idéntico, carácter por carácter, al `id` del `<repository>` en `<distributionManagement>`. Es la única forma en que Maven relaciona una URL de repositorio con las credenciales que debe usar para autenticarse en ella: no hay ninguna otra referencia cruzada entre `pom.xml` y `settings.xml` más que ese `id` compartido.

### Verificación con effective-settings

```bash
mvn -s settings-curso.xml -Dsettings.security=settings-security-curso.xml help:effective-settings
```

Salida real (fragmento relevante):

<pre>
&lt;settings ...&gt;
  &lt;localRepository&gt;/root/.m2/repository&lt;/localRepository&gt;
  &lt;servers&gt;
    &lt;server&gt;
      &lt;username&gt;usuario-ci&lt;/username&gt;
      &lt;password&gt;***&lt;/password&gt;
      &lt;id&gt;repo-curso-privado&lt;/id&gt;
    &lt;/server&gt;
  &lt;/servers&gt;
  ...
&lt;/settings&gt;
</pre>

`help:effective-settings` muestra la contraseña como `***`, no el valor cifrado ni el valor real: el propio plugin de ayuda de Maven la enmascara en la salida, precisamente para que un `mvn help:effective-settings` no se convierta en una forma de filtrar contraseñas, ni siquiera cifradas, a la salida de la terminal o a un log de Jenkins.

### Verificación con effective-pom

```bash
mvn -s settings-curso.xml help:effective-pom
```

Salida real (fragmento relevante):

<pre>
&lt;distributionManagement&gt;
  &lt;repository&gt;
    &lt;id&gt;repo-curso-privado&lt;/id&gt;
    &lt;name&gt;Repositorio privado del curso (ficticio)&lt;/name&gt;
    &lt;url&gt;https://nexus.curso.local/repository/maven-releases/&lt;/url&gt;
  &lt;/repository&gt;
&lt;/distributionManagement&gt;
</pre>

El POM efectivo confirma que `distributionManagement` está bien formado y que el `id` es el esperado.

### El intento de deploy

```bash
mvn -s settings-curso.xml -Dsettings.security=settings-security-curso.xml clean deploy -DskipTests
```

Salida real (fragmento final):

<pre>
[WARNING] Could not transfer metadata com.curso:s04-1-practicas:1.0-SNAPSHOT/maven-metadata.xml from/to repo-curso-privado (https://nexus.curso.local/repository/maven-releases/): nexus.curso.local: Name or service not known
[INFO] ------------------------------------------------------------------------
[INFO] BUILD FAILURE
[INFO] ------------------------------------------------------------------------
[ERROR] Failed to execute goal org.apache.maven.plugins:maven-deploy-plugin:3.1.2:deploy (default-deploy) on project s04-1-practicas: Failed to retrieve remote metadata com.curso:s04-1-practicas:1.0-SNAPSHOT/maven-metadata.xml: Could not transfer metadata com.curso:s04-1-practicas:1.0-SNAPSHOT/maven-metadata.xml from/to repo-curso-privado (https://nexus.curso.local/repository/maven-releases/): nexus.curso.local: Name or service not known: Unknown host nexus.curso.local: Name or service not known -> [Help 1]
</pre>

`Name or service not known` es el mensaje que da el sistema operativo cuando no puede resolver un nombre de dominio: como `nexus.curso.local` no existe, ni siquiera se llega a intentar una conexión de red, falla ya en la resolución del nombre. Este es exactamente el resultado esperado: el `deploy` falla, pero falla en el paso correcto (intentando resolver la URL del repositorio configurado), lo que confirma que el `id` compartido entre `pom.xml` y `settings.xml` ha funcionado y que Maven ha llegado hasta el punto de intentar la conexión, no antes.

**Decisiones tomadas**

- Se ha usado un `settings-curso.xml` y un `settings-security-curso.xml` propios del proyecto, activados con `-s` y `-Dsettings.security` en cada comando, en lugar de escribir directamente en `~/.m2/settings.xml`. Modificar el `settings.xml` real de la máquina añadiría un servidor y una contraseña maestra que podrían chocar con una configuración ya existente en el ordenador de cada alumno, y complicaría deshacer la práctica. Con ficheros propios del proyecto, la práctica es autocontenida y reproducible.
- Se ha incluido el intento de `deploy` fallido, en lugar de detenerse en `effective-settings` y `effective-pom`, porque ver el mensaje de error exacto (y entender por qué falla ahí y no antes) es la comprobación más real de que toda la cadena, desde la contraseña maestra hasta el `id` compartido, está bien construida.
