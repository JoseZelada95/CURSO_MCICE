&nbsp;

```
"%LOCALAPPDATA%\Programs\DockerDesktop\Docker Desktop.exe"

```

&nbsp;