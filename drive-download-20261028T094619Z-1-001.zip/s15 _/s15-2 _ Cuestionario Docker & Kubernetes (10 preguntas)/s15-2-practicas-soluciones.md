# S15-2 Soluciones

## Práctica 1: Servidor web en un contenedor

La solución usa el puerto 8085 del equipo. Cada persona habrá elegido el suyo: la única condición es que esté libre y no sea el 8080, el 5432 ni el 27017. Todos los comandos se escriben en un `cmd`.

Empezamos comprobando que no quedan contenedores de las demos:

```bash
docker ps -a
```

La lista tiene que salir vacía, solo con la cabecera de las columnas. Después ejecutamos el contenedor:

```bash
docker run -d -p 8085:80 --name web-practica nginx
```

La imagen `nginx` ya se descargó en la Demo 2, así que ahora Docker no descarga nada y solo escribe el identificador del contenedor:

<pre>
C:\Users\Mananas>docker run -d -p 8085:80 --name web-practica nginx
5d1e0c7a9b3f...
</pre>

Comprobamos el estado:

```bash
docker ps
```

<pre>
C:\Users\Mananas>docker ps
CONTAINER ID   IMAGE     COMMAND                  CREATED          STATUS          PORTS                                     NAMES
5d1e0c7a9b3f   nginx     "/docker-entrypoint.…"   12 seconds ago   Up 11 seconds   0.0.0.0:8085->80/tcp, [::]:8085->80/tcp   web-practica
</pre>

`STATUS` es `Up` y `PORTS` muestra `8085->80`: el puerto 8085 del equipo redirigido al 80 del contenedor. En el navegador abrimos `http://localhost:8085` y aparece «Welcome to nginx!».

Tras refrescar la página tres veces con `F5`, consultamos los registros:

```bash
docker logs web-practica
```

Al final de la salida hay una línea por cada petición:

<pre>
... "GET / HTTP/1.1" 200 ...
... "GET / HTTP/1.1" 304 ...
... "GET / HTTP/1.1" 304 ...
... "GET / HTTP/1.1" 304 ...
</pre>

La primera petición, al abrir la página, devuelve `200`: nginx envía la página completa. Los refrescos con `F5` suelen devolver `304` (*Not Modified*): el navegador ya tiene una copia, pregunta si ha cambiado y nginx responde que no, sin volver a enviarla. Con `Ctrl+F5` el navegador se salta su copia y el código vuelve a ser `200`. El código exacto de cada línea depende del navegador, y lo importante es saber leerlo: `GET /` es la petición, y el número, el resultado.

Provocamos el primer error, repitiendo el mismo comando:

```bash
docker run -d -p 8085:80 --name web-practica nginx
```

<pre>
docker: Error response from daemon: Conflict. The container name "/web-practica" is already in use by container "5d1e0c7a9b3f...". You have to remove (or rename) that container to be able to reuse that name.
</pre>

El nombre de un contenedor es único, y mientras el contenedor exista, aunque esté parado, no se puede reutilizar. Docker no lo sobrescribe ni lo ignora: dice qué contenedor tiene el nombre y propone borrarlo o renombrarlo.

Provocamos el segundo, con otro nombre y el mismo puerto del equipo:

```bash
docker run -d -p 8085:80 --name web-practica2 nginx
```

<pre>
docker: Error response from daemon: ... Bind for 0.0.0.0:8085 failed: port is already allocated
</pre>

Esta vez el nombre es nuevo, pero el puerto 8085 ya lo ha publicado `web-practica`. El texto completo del mensaje varía con la versión de Docker y con el sistema; lo que identifica el error es `port is already allocated` (o `ports are not available`, como en la Demo 2 con Jenkins): el puerto del equipo ya tiene dueño. Comprobamos en qué estado ha quedado el segundo contenedor:

```bash
docker ps -a
```

<pre>
C:\Users\Mananas>docker ps -a
CONTAINER ID   IMAGE     COMMAND                  CREATED          STATUS          PORTS                                     NAMES
8c4b7e21f0aa   nginx     "/docker-entrypoint.…"   5 seconds ago    Created                                                   web-practica2
5d1e0c7a9b3f   nginx     "/docker-entrypoint.…"   2 minutes ago    Up 2 minutes    0.0.0.0:8085->80/tcp, [::]:8085->80/tcp   web-practica
</pre>

`web-practica2` está en estado `Created`: Docker lo creó, intentó arrancarlo y falló al publicar el puerto. Es el mismo caso de `web2` en la Demo 2. Sigue existiendo y sigue ocupando su nombre, así que lo borramos. Por último, detenemos y borramos el contenedor bueno:

```bash
docker rm web-practica2
```

```bash
docker stop web-practica
```

```bash
docker rm web-practica
```

```bash
docker ps -a
```

La lista vuelve a salir vacía.

**Decisiones tomadas**

- Se publica en el 8085 porque es un puerto libre, no coincide con ninguno de los servicios del curso y no se confunde con los 8080 y 8081 de las demos. Lo esencial de la práctica es que el número de la izquierda de `-p` es el del equipo y el de la derecha es el del contenedor, que para `nginx` es siempre el 80.
- Se usa `-d` para que la terminal quede libre. Sin él, el comando se quedaría mostrando los registros del contenedor y habría que abrir otra terminal para seguir trabajando.
- Se pone nombre al contenedor para no depender del identificador. Con un nombre, `logs`, `stop` y `rm` se escriben sin copiar ninguna cadena larga.
- Los dos errores provocados se eligen porque son los dos que más se encuentran al empezar: el nombre repetido y el puerto ocupado. Reconocerlos por su mensaje evita buscar la causa a ciegas.
- El contenedor del segundo error se borra aparte porque sigue existiendo en estado `Created`. Es un fallo habitual: tras un `docker run` fallido queda un contenedor sin arrancar que ocupa un nombre.
- Se borra con `stop` y `rm` por separado, como en la Demo 2, para practicar la secuencia. `docker rm -f` haría lo mismo en un paso, y se usará cuando solo interese limpiar.

---

## Práctica 2: Ciclo de vida completo

La solución usa el puerto 8086. Creamos el contenedor sin arrancarlo:

```bash
docker create -p 8086:80 --name ciclo nginx
```

<pre>
C:\Users\Mananas>docker create -p 8086:80 --name ciclo nginx
7a90c3e18d52...
</pre>

`docker create` crea el contenedor a partir de la imagen y escribe su identificador, pero no arranca nada. Es la primera mitad de lo que hace `docker run`. Comprobamos qué ve Docker:

```bash
docker ps
```

```bash
docker ps -a
```

<pre>
C:\Users\Mananas>docker ps
CONTAINER ID   IMAGE     COMMAND   CREATED   STATUS    PORTS     NAMES

C:\Users\Mananas>docker ps -a
CONTAINER ID   IMAGE     COMMAND                  CREATED          STATUS    PORTS     NAMES
7a90c3e18d52   nginx     "/docker-entrypoint.…"   10 seconds ago   Created             ciclo
</pre>

`docker ps` no lo muestra porque solo lista los contenedores en marcha; `docker ps -a` sí, con el estado `Created`. Si abrimos `http://localhost:8086`, el navegador no puede conectar: el contenedor existe, pero ningún programa está ejecutándose dentro, y nada escucha en el puerto 8086. Que exista un contenedor no significa que esté funcionando.

Lo arrancamos:

```bash
docker start ciclo
```

```bash
docker ps -a
```

El estado pasa a `Up` seguido del tiempo que lleva en marcha (por ejemplo, `Up 5 seconds`), y ahora la página abre. Lo detenemos y comprobamos:

```bash
docker stop ciclo
```

```bash
docker ps -a
```

El estado pasa a `Exited (0)` seguido de cuánto hace que terminó. El `0` es el código de salida del programa: cero significa que terminó sin errores. La página deja de responder. Lo reiniciamos:

```bash
docker restart ciclo
```

`docker restart` es `stop` seguido de `start`. Con el contenedor detenido, simplemente lo arranca, y el estado vuelve a ser `Up`. Intentamos borrarlo mientras está en marcha:

```bash
docker rm ciclo
```

<pre>
Error response from daemon: cannot remove container "/ciclo": container is running: stop the container before removing or force remove
</pre>

Docker rechaza el borrado y el contenedor sigue en marcha, con la página respondiendo. Lo detenemos, lo borramos y comprobamos:

```bash
docker stop ciclo
```

```bash
docker rm ciclo
```

```bash
docker ps -a
```

La tabla completada:

| Paso | Comando | `STATUS` en `docker ps -a` | ¿Responde el navegador? |
|---|---|---|---|
| 1 | `create` | `Created` | No |
| 4 | `start` | `Up` y el tiempo en marcha | Sí |
| 5 | `stop` | `Exited (0)` y cuánto hace | No |
| 6 | `restart` | `Up` y el tiempo en marcha | Sí |
| 7 | `rm` (en marcha) | Sigue en `Up`: el borrado se rechaza | Sí |
| 8 | `stop` y `rm` | No aparece | No |

**Ampliación.** Creamos un contenedor publicado en el 8080, que ocupa Jenkins:

```bash
docker create -p 8080:80 --name ciclo2 nginx
```

`docker create` termina bien y escribe el identificador. Al arrancarlo es cuando falla:

```bash
docker start ciclo2
```

<pre>
Error response from daemon: ports are not available: exposing port TCP 0.0.0.0:8080 -> 127.0.0.1:0: listen tcp 0.0.0.0:8080: bind: Only one usage of each socket address (protocol/network address/port) is normally permitted.
Error: failed to start containers: ciclo2
</pre>

El contenedor queda en estado `Created`, que se comprueba con `docker ps -a`. Lo borramos:

```bash
docker rm ciclo2
```

**Decisiones tomadas**

- Se separa `create` de `start` porque `docker run` hace las dos cosas a la vez y oculta la diferencia. Con los pasos por separado se ve que los estados `Created`, `Up` y `Exited` son tres situaciones distintas, y se entiende por qué `docker ps -a` hace falta para ver contenedores que existen pero no están en marcha.
- Se anota el navegador en cada paso porque el estado que escribe Docker y lo que de verdad ocurre en el servicio deben coincidir. Si `STATUS` dice `Up` pero la página no carga, el problema está en otro sitio (el puerto, por ejemplo).
- No se usa `-f` en el paso 7 a propósito: se quiere ver el rechazo de Docker. Un contenedor en marcha no se borra por accidente, y para hacerlo hay que decirlo expresamente, con `-f`, o detenerlo antes.
- En la ampliación, el error aparece en `start` y no en `create` porque Docker solo reserva el puerto del equipo cuando el contenedor arranca. Es lo que ocurrió con `web2` en la Demo 2: el `docker run` falló en su segunda mitad, la de arrancar, y por eso quedó el contenedor `Created`.

---

## Práctica 3: MongoDB en un contenedor

Primero comprobamos que el MongoDB local está en marcha y qué bases de datos tiene:

```bash
mongosh
```

```javascript
show dbs
```

Aparecen las bases de datos del servicio local (`admin`, `config`, `local` y las que se hayan creado en S12-1). Salimos con `exit`. Ahora ejecutamos MongoDB en un contenedor:

```bash
docker run -d --name mongo-practica -p 27018:27017 mongo:8
```

- `--name mongo-practica`: el nombre del contenedor.
- `-p 27018:27017`: el servidor escucha dentro del contenedor en el 27017, el puerto habitual de MongoDB. Lo publicamos en el 27018 del equipo, porque el 27017 lo ocupa el servicio local. Si publicáramos el 27017 ocurriría el mismo error de puerto ocupado que con Jenkins.
- `mongo:8`: la imagen oficial de MongoDB, en la etiqueta `8`. Se fija la versión para que todos los equipos usen la misma.

No hace falta ninguna variable de entorno. La primera vez Docker descarga la imagen, que tarda. Comprobamos:

```bash
docker ps
```

<pre>
C:\Users\Mananas>docker ps
CONTAINER ID   IMAGE     COMMAND                  CREATED          STATUS          PORTS                                           NAMES
...            mongo:8   "docker-entrypoint.s…"   15 seconds ago   Up 14 seconds   0.0.0.0:27018->27017/tcp, [::]:27018->27017/tcp   mongo-practica
</pre>

```bash
docker logs mongo-practica
```

Entre las líneas del registro, que están en formato JSON, buscamos la que contiene el mensaje `Waiting for connections`: el servidor ya acepta conexiones. Nos conectamos con `mongosh`, indicando el puerto publicado:

```bash
mongosh "mongodb://localhost:27018"
```

Es la misma forma de conexión de S12-1, con el puerto 27018 en lugar del 27017. Dentro de `mongosh`:

```javascript
use practica
```

```javascript
db.notas.insertOne({ titulo: "Primera nota", texto: "Guardada en un contenedor", importante: true })
```

```javascript
db.notas.find()
```

<pre>
test> use practica
switched to db practica
practica> db.notas.insertOne({ titulo: "Primera nota", texto: "Guardada en un contenedor", importante: true })
{
  acknowledged: true,
  insertedId: ObjectId('...')
}
practica> db.notas.find()
[
  {
    _id: ObjectId('...'),
    titulo: 'Primera nota',
    texto: 'Guardada en un contenedor',
    importante: true
  }
]
</pre>

Igual que en S12-1, `use` no crea la base de datos: aparece al guardar el primer documento, y la colección `notas` se crea con el `insertOne`. Salimos con `exit`.

En Compass pulsamos `Add new connection` (o el botón equivalente de la pantalla de conexiones), escribimos en el campo **URI** `mongodb://localhost:27018` y pulsamos `Connect`. En el panel izquierdo aparece la base de datos `practica` con la colección `notas`, y en la pestaña `Documents` el documento insertado.

Para comprobar que son dos servidores distintos, nos conectamos al local y listamos sus bases de datos:

```bash
mongosh
```

```javascript
show dbs
```

La base de datos `practica` no aparece: el documento se guardó en el servidor del contenedor, no en el servicio de Windows. Salimos con `exit` y limpiamos:

```bash
docker rm -f mongo-practica
```

```bash
docker ps -a
```

```bash
docker images
```

`docker ps -a` sale vacío. `docker images` sigue mostrando `mongo`, además de `nginx`, `postgres` y `hello-world`: se borró el contenedor, no la imagen. Los datos de `practica` han desaparecido con el contenedor, igual que la tabla de PostgreSQL en la Demo 3.

**Variante con `exec`.** La imagen `mongo` incluye `mongosh`, así que también se puede trabajar sin el puerto publicado:

```bash
docker exec -it mongo-practica mongosh
```

Abre una sesión de `mongosh` dentro del contenedor, con las mismas órdenes. Es el mismo mecanismo que `docker exec -it postgres-demo psql -U postgres` de la Demo 3.

**Decisiones tomadas**

- Se publica en el 27018 y no en el 27017 por el mismo motivo que PostgreSQL en el 5433: el servicio local ya ocupa el puerto habitual, y un contenedor que lo intente publicar falla al arrancar.
- Se fija la etiqueta `8` y no se usa `latest`. Así todo el grupo trabaja con la misma versión de MongoDB, y el resultado de la práctica no cambia el día que Docker Hub actualice `latest`.
- No se configuran usuario ni contraseña, igual que en la instalación local de S11-2. Es aceptable en un contenedor de usar y tirar, solo accesible desde el propio equipo; en un entorno real se activaría la autenticación.
- Se comprueba la lista de bases de datos del servidor local para hacer visible que contenedor y servicio son servidores independientes. Es la misma idea que tener dos instancias de PostgreSQL (5432 y 5433) con tablas distintas.
- Se borra con `docker rm -f` porque en este momento solo interesa dejar el equipo limpio, y el contenedor sigue en marcha. La imagen no se borra: borrar imágenes se trabaja en S16-1.
