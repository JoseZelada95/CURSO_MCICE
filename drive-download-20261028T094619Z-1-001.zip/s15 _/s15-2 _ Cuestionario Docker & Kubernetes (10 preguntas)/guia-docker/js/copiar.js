// Botones «Copiar»: copia al portapapeles el comando del bloque .cmd
document.addEventListener('click', function (e) {
  var boton = e.target.closest('.copy');
  if (!boton) return;

  var codigo = boton.previousElementSibling;
  var texto = codigo.textContent;

  function copiado() {
    boton.textContent = 'Copiado';
    boton.classList.add('done');
    setTimeout(function () {
      boton.textContent = 'Copiar';
      boton.classList.remove('done');
    }, 1500);
  }

  // Si el navegador no permite copiar, selecciona el texto para Ctrl+C
  function seleccionar() {
    var rango = document.createRange();
    rango.selectNodeContents(codigo);
    var seleccion = getSelection();
    seleccion.removeAllRanges();
    seleccion.addRange(rango);
    boton.textContent = 'Selecciona y pulsa Ctrl+C';
    setTimeout(function () {
      boton.textContent = 'Copiar';
    }, 2500);
  }

  try {
    navigator.clipboard.writeText(texto).then(copiado, seleccionar);
  } catch (err) {
    seleccionar();
  }
});
