# Cuestionario tipo test · IFCD0014 · Docker y Kubernetes (S15-2 a S17-2)

**Curso:** IFCD0014 – Desarrollo de Aplicaciones con Spring e Hibernate (26/2138)
**Nivel:** fácil · **Preguntas:** 10, en el orden en que se imparte el temario · **Formato:** 4 opciones, solo una correcta, con explicación de la correcta y de cada incorrecta.

**Nota:** borrador adelantado. Se ha redactado a partir de `planificacion-s11-s20.md` y del guion oficial, antes de que existan las demos de estas partes. Conviene revisarlo cuando se generen S15-2 a S17-2, para que los términos y los ejemplos coincidan con lo que se explique en clase.

Al final hay una tabla con las respuestas.

---

## S15-2 · Instalación de Docker y primeros contenedores

### Pregunta 1 (S15-2 · Imagen y contenedor)

¿Qué relación hay entre una imagen y un contenedor en Docker?

**A)** Son lo mismo: dos nombres para el mismo concepto.

**B)** El contenedor es la plantilla y la imagen es cada ejecución de esa plantilla.

**C)** La imagen es una plantilla de solo lectura con una aplicación y sus dependencias, y un contenedor es una ejecución de esa imagen, igual que una clase y sus objetos.

**D)** La imagen es el programa Docker que se instala en el equipo y el contenedor es el fichero donde se guardan los datos.

**Respuesta correcta: C.**

**C (correcta):** una imagen contiene lo necesario para ejecutar una aplicación (el programa y las librerías que usa) y no cambia. Cuando se ejecuta, se crea un contenedor a partir de ella. Es la misma relación que en Java entre una clase y sus objetos: de una sola clase se pueden crear muchos objetos, y de una sola imagen se pueden crear muchos contenedores. Un contenedor se crea, se arranca, se detiene y se borra sin dejar rastro en el equipo.

**A:** no son lo mismo. La imagen es la plantilla y el contenedor es una ejecución viva de esa plantilla.

**B:** está invertida. La plantilla es la imagen, y cada ejecución es un contenedor.

**D:** el programa que se instala en el equipo es Docker (en Windows, Docker Desktop). Un contenedor no es un fichero de datos: es una ejecución de una imagen.

---

### Pregunta 2 (S15-2 · Contenedores y máquinas virtuales)

¿Qué diferencia principal hay entre un contenedor y una máquina virtual?

**A)** Un contenedor comparte el núcleo del sistema operativo y solo lleva la aplicación con sus dependencias, mientras que una máquina virtual lleva un sistema operativo completo propio.

**B)** Un contenedor lleva un sistema operativo completo y por eso pesa más que una máquina virtual.

**C)** Un contenedor solo puede ejecutarse en Linux, así que en Windows no se puede usar Docker.

**D)** Contenedores y máquinas virtuales son lo mismo: solo cambia el nombre.

**Respuesta correcta: A.**

**A (correcta):** una máquina virtual simula un ordenador entero y arranca encima su propio sistema operativo, y eso la hace pesada y lenta de arrancar. Un contenedor no trae sistema operativo propio: aprovecha el núcleo del sistema que ya está en marcha y empaqueta solo la aplicación y lo que necesita. Por eso es mucho más ligero y se crea y arranca en segundos. Es lo que permite, por ejemplo, tener una base de datos completa funcionando en segundos sin instalar nada.

**B:** está invertida. Lo que lleva un sistema operativo completo es la máquina virtual.

**C:** en Windows se puede usar Docker. Docker Desktop crea una máquina Linux ligera sobre WSL2 (la capa de Windows que ejecuta Linux), y es ahí donde viven los contenedores. Por eso exige tener la virtualización activada en el equipo.

**D:** no son lo mismo. Las dos tecnologías sirven para aislar aplicaciones, pero lo hacen de formas distintas y con un peso muy diferente.

---

## S16-1 · Imágenes y Dockerfile

### Pregunta 3 (S16-1 · Capas de una imagen)

Una imagen se construye por capas, y cada capa añade un cambio sobre la anterior. ¿Qué ventaja tiene esto?

**A)** Que la imagen se ejecuta más rápido cuantas más capas tiene.

**B)** Que cada capa es una copia de seguridad de los datos del contenedor.

**C)** Que la imagen no necesita ningún nombre.

**D)** Que dos imágenes que parten de la misma base comparten esas capas, y así ahorran espacio en disco y tiempo de descarga.

**Respuesta correcta: D.**

**D (correcta):** si dos imágenes empiezan con la misma base, por ejemplo una imagen con Java, esa base se descarga y se guarda una sola vez, y cada imagen solo añade sus capas propias. El comando `docker history` muestra las capas de una imagen, con la instrucción que creó cada una.

**A:** el número de capas no cambia la velocidad con la que se ejecuta la aplicación.

**B:** las capas de una imagen son de solo lectura y no guardan datos del contenedor. Lo que debe permanecer cuando se borra un contenedor se guarda en un volumen.

**C:** toda imagen se identifica con un nombre y una etiqueta (*tag*), que suele indicar la versión. Por ejemplo, `contactos:1.0` es la imagen `contactos` en su versión 1.0.

---

### Pregunta 4 (S16-1 · Dockerfile)

¿Qué es un `Dockerfile`?

**A)** Un fichero que describe todos los contenedores de una aplicación y que se levanta con `docker compose up`.

**B)** Un fichero de texto que describe, instrucción a instrucción, cómo construir una imagen: por ejemplo, partir de una imagen con Java, copiar el JAR y ejecutarlo.

**C)** La imagen ya construida, lista para ejecutarse.

**D)** Un registro con las peticiones que ha recibido un contenedor.

**Respuesta correcta: B.**

**B (correcta):** el `Dockerfile` es la receta de la imagen, y el comando `docker build` la sigue para construirla. Sus instrucciones más básicas son `FROM` (la imagen de la que se parte), `COPY` (copia ficheros dentro de la imagen), `EXPOSE` (indica el puerto en el que escucha la aplicación) y `ENTRYPOINT` (el comando que se ejecuta al arrancar el contenedor). Como está escrito en un fichero, cualquiera puede reconstruir la imagen y el fichero se versiona junto al código, como el `pom.xml` o el `Jenkinsfile`.

**A:** eso describe un fichero de Docker Compose (`docker-compose.yml`), que reúne varios servicios. El `Dockerfile` describe una sola imagen.

**C:** la imagen es el resultado de `docker build`. El `Dockerfile` es la receta, no el plato terminado.

**D:** las peticiones que recibe un contenedor se consultan con `docker logs`, no se guardan en un `Dockerfile`.

---

## S16-2 · Docker Compose

### Pregunta 5 (S16-2 · Volúmenes)

Una base de datos guarda sus datos dentro de un contenedor. Se borra el contenedor y no se había usado ningún volumen. ¿Qué pasa con los datos?

**A)** Desaparecen con el contenedor.

**B)** Se conservan siempre en el equipo, aunque no se haya usado un volumen.

**C)** Se guardan dentro de la imagen y los recupera cualquier contenedor nuevo.

**D)** Pasan automáticamente al siguiente contenedor que se cree, aunque sea de otra imagen.

**Respuesta correcta: A.**

**A (correcta):** el sistema de ficheros de un contenedor vive y muere con él. Un volumen es un espacio de almacenamiento que Docker guarda fuera del contenedor, de modo que sobrevive a su borrado. Con Compose se puede comprobar: `docker compose down` borra los contenedores pero el volumen sigue ahí, y los datos reaparecen con un nuevo `docker compose up`; en cambio, `docker compose down -v` borra también el volumen y los datos se pierden.

**B:** sin volumen no se conserva nada. Por eso, para una base de datos, un volumen es imprescindible.

**C:** la imagen es de solo lectura y no se modifica cuando el contenedor guarda datos. Un contenedor nuevo parte de la imagen original, sin los datos del anterior.

**D:** cada contenedor tiene su propio sistema de ficheros, y los datos no pasan de uno a otro por sí solos.

---

### Pregunta 6 (S16-2 · Docker Compose)

¿Qué hace Docker Compose?

**A)** Sustituye a Docker: con Compose ya no hace falta tener Docker instalado.

**B)** Crea las imágenes de forma automática sin necesidad de ningún `Dockerfile`.

**C)** Describe en un solo fichero YAML todos los servicios de una aplicación, por ejemplo la API y su base de datos, y los pone en marcha con un solo comando.

**D)** Es el servicio de Internet donde se publican las imágenes para compartirlas.

**Respuesta correcta: C.**

**C (correcta):** YAML es un formato de texto en el que las líneas se organizan por sangría (los espacios al principio de cada línea), y por eso un fallo de sangría es un error muy frecuente. En el fichero `docker-compose.yml` se escribe lo que antes eran los parámetros de cada `docker run`. Con `docker compose up` se crea una red, se arrancan los contenedores en el orden correcto y se conectan entre sí por su nombre, y con `docker compose down` se retira todo. Así, quien clona el proyecto lo pone en marcha con un solo comando.

**A:** Compose trabaja sobre Docker, no lo sustituye. Automatiza los mismos comandos que se escribirían a mano.

**B:** Compose usa imágenes ya hechas o construye las propias, pero siempre a partir de un `Dockerfile`. No lo reemplaza.

**D:** las imágenes se publican en el servicio de imágenes de Docker (Docker Hub) con `docker push`. Compose no es un servicio de Internet.

---

## S17-1 · Introducción a Kubernetes

### Pregunta 7 (S17-1 · Orquestador y estado deseado)

¿Qué es Kubernetes y qué problema resuelve?

**A)** Un programa para escribir el código Java de una aplicación.

**B)** Una herramienta para construir imágenes a partir de un `Dockerfile`.

**C)** Una base de datos donde se guardan los contenedores.

**D)** Un orquestador de contenedores: se le indica el estado deseado (cuántas copias de qué imagen) y se encarga de mantenerlo, reiniciando lo que falla.

**Respuesta correcta: D.**

**D (correcta):** Compose basta para trabajar en un equipo, pero no resuelve qué pasa cuando un contenedor falla, cuando hay que repartir la carga entre varias copias o cuando se despliega en varias máquinas. Un orquestador se ocupa de eso. El modelo de Kubernetes es declarativo: se describe en un fichero lo que se quiere tener (el estado deseado) y el sistema trabaja hasta conseguirlo y lo sigue manteniendo aunque algo falle por el camino. Es distinto del modo imperativo, en el que se ordena a mano cada acción con un comando.

**A:** el código de la aplicación se escribe con un IDE como IntelliJ. Kubernetes se ocupa de ejecutar y mantener la aplicación ya empaquetada.

**B:** las imágenes se construyen con `docker build`. Kubernetes parte de imágenes que ya existen y se ocupa de ejecutarlas.

**C:** Kubernetes no guarda datos. Gestiona contenedores y, como mucho, les da acceso a almacenamiento.

---

### Pregunta 8 (S17-1 · Arquitectura)

¿Cómo se organiza un clúster de Kubernetes?

**A)** En un único programa que decide y ejecuta todo a la vez, sin dividirse en partes.

**B)** En un plano de control, que decide, y en nodos, que son las máquinas que ejecutan los contenedores.

**C)** En nodos que deciden y un plano de control que ejecuta los contenedores.

**D)** En un nodo por cada contenedor, sin nada que los coordine.

**Respuesta correcta: B.**

**B (correcta):** un clúster es el conjunto formado por el plano de control y los nodos. El plano de control recibe las órdenes por su API (la puerta de entrada del clúster), decide dónde y cuándo ejecutar cada cosa y vigila que se cumpla el estado deseado. Cada nodo es una máquina que ejecuta los contenedores y lleva un agente, el *kubelet*, que arranca lo que le encargan. Con `kubectl`, la herramienta con la que se habla con el clúster, se ve el nodo con `kubectl get nodes`.

**A:** Kubernetes separa a propósito quien decide (plano de control) de quien ejecuta (nodos).

**C:** está invertida. Los nodos ejecutan y el plano de control decide.

**D:** hay un plano de control que coordina todo. Un nodo no se corresponde con un contenedor: en un mismo nodo pueden ejecutarse muchos.

---

### Pregunta 9 (S17-1 · Pod y deployment)

¿Qué diferencia hay entre un pod y un deployment en Kubernetes?

**A)** El pod mantiene un número de réplicas y el deployment envuelve un único contenedor.

**B)** Son lo mismo: *deployment* es el nombre antiguo del pod.

**C)** El pod es la unidad mínima de Kubernetes y envuelve uno o varios contenedores; el deployment mantiene un número de réplicas de un pod y recrea los que se pierden.

**D)** El pod es el fichero YAML donde se describe la aplicación y el deployment es la herramienta con la que se ejecuta.

**Respuesta correcta: C.**

**C (correcta):** una réplica es una copia de un pod. Un pod suelto que se borra desaparece y nadie lo recupera. En cambio, un pod gestionado por un deployment se recrea de forma automática hasta alcanzar el número de réplicas que se pidió: es la autorreparación. Se puede comprobar creando un deployment de tres réplicas, borrando un pod con `kubectl delete` y viendo con `kubectl get pods` cómo Kubernetes crea otro de inmediato. También se puede escalar con `kubectl scale`.

**A:** está invertida. El deployment es quien mantiene las réplicas, y el pod es la unidad que envuelve los contenedores.

**B:** no son el mismo objeto. Un deployment gestiona pods; no es otro nombre para ellos.

**D:** el fichero YAML es la forma de describir un objeto de Kubernetes, sea un pod o un deployment. La herramienta con la que se aplica es `kubectl apply`.

---

## S17-2 · Orquestación de una aplicación con base de datos

### Pregunta 10 (S17-2 · Service)

En Kubernetes, ¿para qué sirve un *service*?

**A)** Para dar a los pods un nombre y una dirección estables. Los pods nacen y mueren y cada uno tiene una dirección distinta, pero el service mantiene un nombre fijo con el que otros pods pueden encontrarlos.

**B)** Para guardar las credenciales de la base de datos y entregarlas a los pods como variables de entorno.

**C)** Para mantener el número de réplicas de un pod.

**D)** Para ser la máquina (el nodo) donde se ejecutan los pods.

**Respuesta correcta: A.**

**A (correcta):** gracias al service, la API puede apuntar a `postgres` como nombre del servidor de la base de datos, aunque el pod de PostgreSQL se recree con otra dirección. Es la misma idea que ya se vio en Compose, donde los contenedores se encontraban por el nombre del servicio en la red que Docker crea.

**B:** eso lo hace un *secret*, el objeto de Kubernetes para guardar datos sensibles, igual que el fichero `.env` de Compose. Los pods lo reciben como variables de entorno.

**C:** eso lo hace el deployment.

**D:** esa máquina es el nodo. El service no ejecuta nada: solo da un nombre estable de acceso a los pods.

---

## Tabla de respuestas

| Nº | Sesión | Resp. |
|---|---|---|
| 1 | S15-2 | C |
| 2 | S15-2 | A |
| 3 | S16-1 | D |
| 4 | S16-1 | B |
| 5 | S16-2 | A |
| 6 | S16-2 | C |
| 7 | S17-1 | D |
| 8 | S17-1 | B |
| 9 | S17-1 | C |
| 10 | S17-2 | A |
