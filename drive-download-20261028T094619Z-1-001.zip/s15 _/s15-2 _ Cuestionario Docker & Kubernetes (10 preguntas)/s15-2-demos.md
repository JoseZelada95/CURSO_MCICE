# S15-2 Demos

## Objetivos

Hasta ahora, todas las herramientas del curso se han instalado directamente en el ordenador: Java, Maven, IntelliJ, PostgreSQL, MongoDB, Jenkins. Funciona, pero tiene un problema conocido: un programa que funciona en un ordenador puede fallar en otro porque cambia la versión de Java, la de la base de datos o una variable de entorno. **Docker** resuelve ese problema empaquetando la aplicación con todo lo que necesita, de modo que se ejecuta igual en cualquier equipo dentro de un **contenedor**.

Dos ideas se usan durante toda la parte. Una **imagen** es una plantilla de solo lectura con una aplicación y sus dependencias. Un **contenedor** es una ejecución de esa imagen: se crea, se arranca, se detiene y se borra sin dejar rastro en el equipo. La relación es la de una clase y sus objetos (S02-1): la clase es la plantilla y cada `new` crea un objeto distinto; la imagen es la plantilla y cada `docker run` crea un contenedor distinto.

Un contenedor se parece a una máquina virtual en que aísla la aplicación del resto del equipo, pero comparte el núcleo del sistema operativo en lugar de arrancar uno completo. Por eso arranca en segundos y consume una fracción de los recursos.

La parte empieza por lo más delicado, instalar Docker Desktop en Windows, para lo que hay una guía con pantallazos reales. Después se recorre el ciclo de vida de un contenedor con un servidor web, y se termina con una base de datos PostgreSQL funcionando en segundos sin instalar nada. Un hilo conductor atraviesa las tres demos: los puertos. Los equipos ya tienen programas escuchando en puertos conocidos (Jenkins en el 8080, PostgreSQL en el 5432 y MongoDB en el 27017), y un contenedor que intente publicar uno de esos puertos choca con ellos. Aprender a leer ese error y a resolverlo es parte del trabajo.

Al terminar esta parte los alumnos son capaces de:
- Instalar WSL 2 y Docker Desktop en Windows siguiendo la guía y comprobar que el motor responde.
- Explicar la diferencia entre una imagen y un contenedor.
- Ejecutar un contenedor, listarlo, ver sus registros, detenerlo, arrancarlo de nuevo y borrarlo.
- Explicar qué hace `-p` y reconocer y resolver el error de un puerto ocupado.
- Ejecutar PostgreSQL en un contenedor sin instalarlo, conectarse con pgAdmin y explicar qué ocurre con los datos al borrar el contenedor.

---

## Demo 1: Instalación de WSL 2 y Docker Desktop, y cuenta de Docker

### Qué instalamos y por qué

**Docker Desktop** es la aplicación de Docker para Windows. Instala tres cosas a la vez: el **motor**, un programa que crea y ejecuta los contenedores y que queda en marcha en segundo plano; el **cliente**, que es el comando `docker` que escribimos en la terminal y que se limita a enviar órdenes al motor; y una interfaz gráfica para ver contenedores e imágenes. Por eso `docker version` muestra dos bloques, `Client` y `Server`: el comando y el motor son programas distintos que se hablan entre sí.

Los contenedores usan funciones del núcleo de Linux. Windows no es Linux, así que Docker Desktop crea una máquina Linux muy ligera en la que viven los contenedores, y la ejecuta con **WSL 2** (*Windows Subsystem for Linux*), la capa de Windows que permite ejecutar Linux dentro de Windows. La versión 2 usa un núcleo Linux real, y para ello necesita la **virtualización**: una función del procesador, que se activa en el firmware del equipo (la BIOS o UEFI), que permite ejecutar un sistema dentro de otro. Por eso las comprobaciones de S14-2 (permisos de administrador, virtualización y estado de WSL) eran un requisito previo.

### La guía de instalación

Para esta demo hay una guía de instalación: la carpeta `guia-docker`, que se abre haciendo doble clic en `guia-docker/index.html` y se ve en el navegador. Contiene los 15 pasos con los pantallazos reales del equipo de prueba (Windows 11 Pro, compilación 26300; WSL 3.0.3; Docker Desktop 4.96.3; 26/10/2026), con los comandos listos para copiar con un clic en el botón **Copiar**. Los comandos se escriben en un `cmd`.

La guía tiene dos usos. En clase, la abrimos en pantalla y seguimos con ella la lista de pasos de esta demo. Después, cada alumno la conserva para repetir la instalación en otro equipo o para ponerse al día si se ha quedado atrás. Las pantallas pueden variar un poco de un equipo a otro (versiones, idioma), pero el orden de los pasos y los comandos son los mismos.

### Lista de pasos para instalar Docker

Entre paréntesis, el número del paso en la guía.

1. Abrimos un `cmd` como administrador y comprobamos los permisos y la versión de Windows (paso 1).
2. Comprobamos el estado de WSL y la virtualización (paso 2).
3. Instalamos WSL sin distribución con `wsl --install --no-distribution` (paso 3).
4. Reiniciamos el equipo.
5. Comprobamos WSL tras el reinicio con `wsl --status` (paso 4).
6. Comprobamos el servicio «Servidor» y la versión de WSL (paso 5).
7. Descargamos `Docker Desktop Installer.exe` desde la página oficial (paso 6).
8. Ejecutamos el instalador y dejamos la configuración como viene (paso 7).
9. Esperamos a «Installation succeeded» y pulsamos `Close` (paso 8).
10. Abrimos Docker Desktop, cerramos la ventana de WSL y pulsamos `Skip` (paso 9).
11. Esperamos a que Docker Desktop muestre «Engine running» (paso 10).
12. Comprobamos Docker desde la terminal con `docker version` y `docker run hello-world` (paso 11).
13. Creamos la cuenta de Docker (paso 14).
14. Iniciamos sesión desde la terminal con `docker login` (paso 14).

Los pasos 12, 13 y 15 de la guía (servidor web en el puerto 8081, conflicto con el 8080 y limpieza de contenedores) son la Demo 2.

### Recorrido de los pasos

#### Pasos 1 y 2: comprobaciones previas

Abrimos un `cmd` como administrador: clic derecho sobre `Símbolo del sistema` y `Ejecutar como administrador`. La barra de título debe decir «Administrador». Ejecutamos:

```bash
net session
```

```bash
systeminfo | findstr /B /C:"Nombre del sistema operativo" /C:"Versión del sistema operativo" /C:"OS Name" /C:"OS Version"
```

`net session` lista las sesiones que otros equipos tienen abiertas con este, una consulta que Windows solo permite a un administrador. Si responde «No hay entradas en la lista», hay permisos de administrador; si responde acceso denegado (error de sistema 5), el `cmd` no es de administrador. `systeminfo` da los datos del sistema, y `findstr` (con la barra vertical `|`, que pasa la salida de un comando al siguiente) se queda solo con las dos líneas del sistema operativo.

Salida esperada:

<pre>
C:\Windows\System32>net session
No hay entradas en la lista.

C:\Windows\System32>systeminfo | findstr /B /C:"Nombre del sistema operativo" ...
Nombre del sistema operativo:              Microsoft Windows 11 Pro
Versión del sistema operativo:             10.0.26300 N/D Compilación 26300
</pre>

La guía indica como requisito Windows 11 Pro, Enterprise o Education, versión 23H2 (compilación 22631) o posterior. En el equipo de prueba se cumple.

Seguimos en el mismo `cmd`, ahora con WSL y la virtualización:

```bash
wsl --status
```

```bash
systeminfo | findstr /i "hipervisor hypervisor virtualiz"
```

Salida esperada en un equipo que todavía no tiene WSL:

<pre>
C:\Windows\System32>wsl --status
El Subsistema de Windows para Linux no está instalado. Para instalar, ejecute "wsl.exe --install".
Para obtener más información, visite https://aka.ms/wslinstall

C:\Windows\System32>systeminfo | findstr /i "hipervisor hypervisor virtualiz"
Seguridad basada en virtualización:        Estado: No habilitado
                                           Se habilitó la virtualización en el firmware: Sí
</pre>

Que WSL no esté instalado es lo esperado. De la segunda salida solo importa la línea `Se habilitó la virtualización en el firmware: Sí`. La línea `Seguridad basada en virtualización: Estado: No habilitado` es otra función de Windows y no afecta a Docker. Si la virtualización estuviera desactivada, se activa en la BIOS o UEFI del equipo antes de seguir; si Windows ya usa un hipervisor, `systeminfo` lo indica en lugar de mostrar esas líneas, y también vale.

#### Pasos 3 a 6: instalar y comprobar WSL

En el mismo `cmd` de administrador instalamos WSL sin ninguna distribución de Linux:

```bash
wsl --install --no-distribution
```

Normalmente WSL instala también una distribución, como Ubuntu, para que el usuario trabaje en ella. Aquí no hace falta: Docker Desktop crea la suya. `--no-distribution` evita descargar una que no usaremos.

Salida esperada (abreviada):

<pre>
C:\Windows\System32>wsl --install --no-distribution
Descargando: Subsistema de Windows para Linux 3.0.3
Instalando: Subsistema de Windows para Linux 3.0.3
Se ha instalado Subsistema de Windows para Linux 3.0.3.
Instalando componente opcional de Windows: VirtualMachinePlatform
...
La operación solicitada se realizó correctamente. Los cambios se aplicarán una vez que se reinicie el sistema.
</pre>

El comando instala WSL y el componente `VirtualMachinePlatform`, la parte de Windows que permite crear máquinas virtuales ligeras. Los cambios solo se aplican al reiniciar, así que reiniciamos el equipo antes de seguir.

Tras el reinicio abrimos de nuevo un `cmd` como administrador y comprobamos:

```bash
wsl --status
```

<pre>
C:\Windows\System32>wsl --status
Versión predeterminada: 2
WSL1 no es compatible con la configuración actual del equipo.
Habilita el componente opcional "Subsistema de Windows para Linux" para usar WSL1.
</pre>

Lo que buscamos es `Versión predeterminada: 2`. Las dos líneas siguientes no son un error: dicen que WSL 1 no está disponible, y Docker usa WSL 2.

Docker Desktop exige además que el servicio de Windows llamado «Servidor» (`LanmanServer`) arranque automáticamente y que WSL sea 2.1.5 o posterior. Lo comprobamos:

```bash
sc qc LanmanServer
```

```bash
wsl --version
```

`sc qc` (*query config*, el mismo comando `sc` de S13-1) muestra cómo está configurado un servicio.

<pre>
C:\Windows\System32>sc qc LanmanServer
[SC] QueryServiceConfig CORRECTO

NOMBRE_SERVICIO: LanmanServer
        TIPO               : 20  WIN32_SHARE_PROCESS
        TIPO_INICIO        : 2   AUTO_START
        ...
        NOMBRE_MOSTRAR     : Servidor

C:\Windows\System32>wsl --version
Versión de WSL: 3.0.3.0
...
</pre>

Los dos requisitos se cumplen: `TIPO_INICIO : 2   AUTO_START` (inicio automático) y una versión de WSL muy superior a la 2.1.5.

#### Pasos 7 a 11: instalar Docker Desktop

En `https://www.docker.com/products/docker-desktop/` pulsamos **Download Docker Desktop** y elegimos Windows con arquitectura **x86_64 (AMD64)**. Se descarga el fichero `Docker Desktop Installer.exe`.

Lo ejecutamos con doble clic. La primera pantalla es la de configuración: dejamos todo como viene y pulsamos `OK`. Quedan marcadas **Per-user installation (Recommended)** y **Add shortcut to desktop**. La instalación por usuario instala Docker solo para el usuario de Windows actual, no pide permisos de administrador y usa WSL 2. No marcamos **All-users installation**.

El instalador descarga y copia los ficheros. Al terminar aparece «Installation succeeded» (en el equipo de prueba, Docker Desktop 4.96.3) y pulsamos `Close`. No pidió reiniciar; en otros equipos podría pedirlo.

Abrimos Docker Desktop desde el acceso directo del escritorio. En el primer arranque aparecen dos ventanas: una informativa, «Te damos la bienvenida a WSL», que se puede cerrar, y otra, «Welcome to Docker», con la etiqueta PERSONAL. Para las clases no hace falta cuenta en este momento: pulsamos `Skip`, arriba a la derecha. La cuenta la creamos más adelante, en esta misma demo.

Tras el arranque aparece la pestaña `Containers`, vacía. Abajo a la izquierda debe leerse **Engine running**: el motor está en marcha y ya podemos usar Docker. Si todavía muestra otro mensaje, esperamos unos segundos.

#### Paso 12: comprobar Docker desde la terminal

Abrimos un `cmd` normal, sin administrador, y ejecutamos:

```bash
docker version
```

```bash
docker run hello-world
```

Salida esperada de `docker version` (abreviada):

<pre>
C:\Users\Mananas>docker version
Client:
 Version:           29.9.2
 API version:       1.56
 OS/Arch:           windows/amd64
 Context:           desktop-linux
 ...

Server: Docker Desktop 4.96.3 (244472)
 Engine:
  Version:          29.9.2
  API version:      1.56 (minimum version 1.40)
  OS/Arch:          linux/amd64
  ...
</pre>

Aparecen los dos bloques que explicábamos al principio: `Client`, el comando, que es de Windows (`windows/amd64`), y `Server`, el motor, que es de Linux (`linux/amd64`) porque vive en la máquina que crea Docker Desktop. Si el bloque `Server` diera un error, el motor no estaría respondiendo: habría que abrir Docker Desktop y esperar a «Engine running».

`docker run hello-world` crea y arranca un contenedor a partir de la imagen `hello-world`, una imagen mínima que solo escribe un mensaje. Si la imagen no está en el equipo, Docker la descarga primero de **Docker Hub**, el servicio público donde se publican imágenes. Por eso la primera vez necesita Internet y, antes del mensaje, aparecen líneas de descarga.

Salida esperada:

<pre>
C:\Users\Mananas>docker run hello-world

Hello from Docker!
This message shows that your installation appears to be working correctly.

To generate this message, Docker took the following steps:
 1. The Docker client contacted the Docker daemon.
 2. The Docker daemon pulled the "hello-world" image from the Docker Hub.
    (amd64)
 3. The Docker daemon created a new container from that image which runs the
    executable that produces the output you are currently reading.
 4. The Docker daemon streamed that output to the Docker client, which sent it
    to your terminal.
...
</pre>

Los cuatro pasos que describe el propio mensaje son el recorrido completo: el cliente habla con el motor (*daemon* es el nombre clásico del motor), el motor descarga la imagen de Docker Hub, crea un contenedor con ella y devuelve su salida al cliente. Que aparezca confirma que el cliente, el motor, la descarga de imágenes y la ejecución funcionan de extremo a extremo.

#### Pasos 13 y 14: cuenta de Docker y `docker login`

Descargar imágenes públicas no necesita cuenta. Publicar imágenes propias en Docker Hub, que haremos en S16-1, sí. Por eso la creamos ahora, para que nadie se quede sin ella más adelante.

En `https://hub.docker.com/signup` la web redirige a la pantalla **Sign in**. En el recuadro **Don't have an account?** pulsamos `Sign Up`. En **Create your account**, pestaña `Personal`, rellenamos:

- **Email**: el correo de cada alumno. El registro es con correo, no con Google ni con GitHub.
- **Username**: de 4 a 30 letras y dígitos. Lo escribimos en minúsculas, porque irá dentro del nombre de nuestras imágenes (S16-1).
- **Password**: una contraseña propia, que cada alumno guarda donde guarde sus claves.

La casilla de novedades se deja sin marcar. Después del registro, la web pide abrir «Docker Desktop.exe» para iniciar la sesión. Es seguro, porque la petición viene de la página oficial de Docker; la aceptamos, sin marcar la opción de permitirlo siempre si el equipo es compartido. El botón `Sign in` de Docker Desktop pasa a mostrar el nombre de usuario.

Para que también la terminal tenga la sesión iniciada, ejecutamos en un `cmd`:

```bash
docker login
```

`docker login` identifica a la terminal ante Docker Hub y guarda las credenciales para los comandos que las necesiten, como la publicación de imágenes. Al terminar, la terminal escribe `Login Succeeded`. La guía no tiene pantallazo de estos dos pasos: ambos funcionaron en el equipo de prueba, pero no se capturaron.

### Conviene saber

- **Instalación por usuario y Jenkins.** Docker queda ligado al usuario de Windows que lo instala. El servicio de Jenkins corre con otra cuenta (S13-1), así que, si en alguna sesión Jenkins tuviera que ejecutar comandos de Docker, podría haber problemas. No se ha comprobado. Si apareciera, habría que desinstalar y reinstalar con **All-users installation**.
- **Licencia.** Docker Desktop es gratuito para educación y para empresas pequeñas; las grandes necesitan una suscripción. Conviene confirmar el uso con el centro.
- **Primera descarga.** La primera descarga de una imagen tarda. Si todo el grupo la hace a la vez, conviene avisar para que nadie crea que se ha quedado colgado.

---

## Demo 2: Ciclo de vida de un contenedor

En la Demo 1 ejecutamos `hello-world`, un contenedor que escribe un mensaje y termina. Ahora ejecutamos uno que se queda en marcha: `nginx`, un **servidor web**. Es el mismo concepto que Tomcat en S06-1: un programa que escucha en un puerto, recibe peticiones y devuelve páginas. La imagen `nginx` ya lo trae instalado y configurado, y no hay que instalar nada en Windows.

Un contenedor tiene su propia red, separada de la del equipo. Un servidor que escucha en el puerto 80 dentro del contenedor no es alcanzable desde el navegador de Windows hasta que se **publica** ese puerto: se conecta un puerto del equipo con un puerto del contenedor. Eso es lo que hace la opción `-p`.

<pre>
navegador  →  localhost:8081 (el equipo)  →  puerto 80 (el contenedor nginx)
</pre>

### Crear y arrancar el contenedor

Abrimos un `cmd` y ejecutamos:

```bash
docker run -d -p 8081:80 --name web nginx
```

Cada parte del comando tiene un significado:

- `docker run`: crea un contenedor a partir de una imagen y lo arranca.
- `-d` (*detached*): lo deja funcionando en segundo plano. Sin esta opción, la terminal queda ocupada mostrando la salida del contenedor hasta que lo paramos con `Ctrl+C`.
- `-p 8081:80`: publica el puerto 80 del contenedor en el puerto 8081 del equipo. **El primer número es siempre el del equipo y el segundo el del contenedor.** Elegimos el 8081 porque el 8080 lo ocupa Jenkins.
- `--name web`: le da un nombre propio. Sin él, Docker inventa uno aleatorio.
- `nginx`: la imagen que se usa.

La imagen `nginx` no está en el equipo, así que Docker la descarga de Docker Hub antes de crear el contenedor. Cada línea `Pull complete` es una capa de la imagen; las imágenes se construyen por capas, y se verán con detalle en S16-1. Al final Docker escribe el identificador largo del contenedor.

Salida esperada (abreviada; los identificadores cambian de un equipo a otro):

<pre>
C:\Users\Mananas>docker run -d -p 8081:80 --name web nginx
Unable to find image 'nginx:latest' locally
latest: Pulling from library/nginx
8334177aa35b: Pull complete
9a2c3eb3312e: Pull complete
...
Digest: sha256:4c41e2d0...
Status: Downloaded newer image for nginx:latest
e42008bb822c...
</pre>

El nombre `nginx:latest` tiene dos partes: la imagen (`nginx`) y su etiqueta (`latest`), que identifica una versión. Si no se indica etiqueta, Docker usa `latest`. Las etiquetas se explican en S16-1.

### Listar el contenedor

```bash
docker ps
```

`docker ps` lista los contenedores que están en marcha.

<pre>
C:\Users\Mananas>docker ps
CONTAINER ID   IMAGE     COMMAND                  CREATED          STATUS          PORTS                                         NAMES
e42008bb822c   nginx     "/docker-entrypoint.…"   16 seconds ago   Up 15 seconds   0.0.0.0:8081->80/tcp, [::]:8081->80/tcp       web
</pre>

Las columnas son: el identificador corto del contenedor, la imagen de la que viene, el comando que ejecuta por dentro, cuándo se creó, su estado (`Up`: en marcha), los puertos publicados y su nombre. En `PORTS`, `0.0.0.0:8081->80/tcp` se lee «cualquier dirección del equipo, puerto 8081, redirigido al puerto 80 del contenedor, protocolo TCP»; la segunda entrada, `[::]`, es lo mismo para IPv6.

### Abrir la página

En el navegador escribimos `http://localhost:8081`. Aparece la página «Welcome to nginx!». La URL es la misma estructura de S06-1: protocolo, `localhost` (este mismo ordenador) y el puerto, que ahora es el que hemos publicado.

### Ver los registros

```bash
docker logs web
```

`docker logs` muestra lo que el programa del contenedor ha escrito en su salida. Como el contenedor está en segundo plano, es la forma de ver qué pasa dentro. Con la página ya abierta, el registro incluye una línea por cada petición recibida, con esta forma:

<pre>
... "GET / HTTP/1.1" 200 ...
</pre>

Los puntos suspensivos sustituyen lo que cambia de un equipo a otro: la dirección de quien pide, la fecha y hora y los datos del navegador. Lo que queda es la petición (`GET /`: el verbo GET de S06-1 pidiendo la ruta `/`) y el código de respuesta, `200`, «todo bien». Según el navegador, puede aparecer también una petición a `/favicon.ico` con código `404`: el navegador pide por su cuenta el icono de la pestaña y nginx no tiene ninguno. No es un fallo.

Refrescamos la página con `F5` y volvemos a ejecutar `docker logs web`: aparece una línea nueva por cada petición.

### Detener y arrancar de nuevo

```bash
docker stop web
```

`docker stop` pide al programa que termine y, si no lo hace en unos segundos (diez por defecto), lo fuerza. Docker escribe el nombre del contenedor. Si refrescamos el navegador, la página ya no responde: el contenedor no está en marcha y el puerto 8081 ya no lleva a ningún sitio.

`docker ps` ya no lo lista, porque `ps` solo muestra los contenedores en marcha. Con `-a` (*all*) muestra todos:

```bash
docker ps -a
```

<pre>
C:\Users\Mananas>docker ps -a
CONTAINER ID   IMAGE     COMMAND                  CREATED         STATUS                      PORTS     NAMES
e42008bb822c   nginx     "/docker-entrypoint.…"   3 minutes ago   Exited (0) 12 seconds ago             web
</pre>

El contenedor sigue existiendo, con el estado `Exited`: ha terminado, pero no está borrado. Un contenedor pasa por tres estados que vamos a ver en esta demo: **Created** (creado, no arrancado), **Up** (en marcha) y **Exited** (terminado).

```bash
docker start web
```

`docker start` arranca un contenedor que ya existe. No crea nada nuevo: es el mismo contenedor, con el mismo nombre y la misma configuración de puertos. Refrescamos el navegador y la página vuelve. La diferencia con `docker run` es esta: `run` crea un contenedor nuevo cada vez que se ejecuta (y por eso repetirlo con `--name web` daría un error de nombre en uso); `start` revive uno existente.

### Borrar el contenedor

Intentamos borrarlo mientras está en marcha:

```bash
docker rm web
```

Docker lo rechaza, porque no se puede borrar un contenedor en marcha:

<pre>
Error response from daemon: cannot remove container "/web": container is running: stop the container before removing or force remove
</pre>

Lo detenemos y lo borramos:

```bash
docker stop web
```

```bash
docker rm web
```

`docker rm` borra el contenedor. Comprobamos con `docker ps -a` que la lista queda vacía. Un contenedor borrado no deja nada atrás en el equipo: su sistema de ficheros y sus datos desaparecen con él.

Lo que sí se conserva es la imagen. Con `docker images` vemos que `nginx` sigue descargada:

```bash
docker images
```

Aparece una línea por imagen, con su nombre y etiqueta (`nginx:latest`), su identificador y su tamaño. Esa es la razón de que volver a ejecutar `docker run ... nginx` ya no descargue nada y arranque en un segundo: la plantilla sigue en el equipo, y solo se crea un contenedor nuevo a partir de ella.

### Cuando el puerto está ocupado

Jenkins arranca solo con Windows y escucha en el 8080. Probamos a publicar otro contenedor en ese puerto:

```bash
docker run -d -p 8080:80 --name web2 nginx
```

Salida esperada:

<pre>
C:\Users\Mananas>docker run -d -p 8080:80 --name web2 nginx
94afa190e0eb6da50324fb4fc01c3c4976ab12a9c8d63172479e979a44bb1f70
docker: Error response from daemon: ports are not available: exposing port TCP 0.0.0.0:8080 -> 127.0.0.1:0: listen tcp 0.0.0.0:8080: bind: Only one usage of each socket address (protocol/network address/port) is normally permitted.

Run 'docker run --help' for more information
</pre>

El mensaje largo dice, en lo esencial, que el puerto 8080 no está disponible porque otro programa ya lo usa: `Only one usage of each socket address` es la forma en que Windows dice que un puerto solo puede tener un dueño. Ese otro programa es Jenkins. El mismo conflicto aparecería con PostgreSQL (5432) o con MongoDB (27017).

Antes del error, Docker imprimió un identificador largo: el contenedor `web2` sí se creó, pero no llegó a arrancar. Lo comprobamos:

```bash
docker ps -a
```

`web2` aparece con el estado `Created`. Sigue ocupando el nombre `web2`, así que hay que borrarlo antes de repetir el comando:

```bash
docker rm web2
```

La solución del conflicto es publicar un puerto distinto del equipo. El puerto de dentro del contenedor no cambia: nginx sigue escuchando en el 80, y solo cambia el número de la izquierda.

```bash
docker run -d -p 8082:80 --name web2 nginx
```

Esta vez arranca. Abrimos `http://localhost:8082` para comprobarlo. Para dejar el equipo limpio borramos el contenedor con un solo comando:

```bash
docker rm -f web2
```

`-f` (*force*) detiene el contenedor si está en marcha y lo borra, todo en un paso. Lo detiene de golpe, sin esperar a que el programa termine con calma como hace `docker stop`, así que con contenedores cuyos datos importan se prefiere `stop` primero. Para contenedores de prueba como estos, es lo que usaremos a partir de ahora para limpiar.

### Resumen de comandos

| Comando | Qué hace |
|---|---|
| `docker run` | Crea un contenedor a partir de una imagen y lo arranca |
| `docker ps` | Lista los contenedores en marcha (`-a`: todos) |
| `docker logs nombre` | Muestra lo que ha escrito el programa del contenedor |
| `docker stop nombre` | Detiene el contenedor sin borrarlo |
| `docker start nombre` | Arranca un contenedor que ya existe |
| `docker rm nombre` | Borra un contenedor detenido (`-f`: también si está en marcha) |
| `docker images` | Lista las imágenes descargadas |

---

## Demo 3: Una base de datos sin instalar nada

En S07 instalamos PostgreSQL con un instalador, elegimos una contraseña, un puerto y una carpeta, y quedó como un servicio de Windows. Ahora obtenemos el mismo servidor en pocos segundos, sin instalador y sin tocar Windows, con un solo comando. La imagen `postgres` contiene el servidor ya configurado; el contenedor es el servidor en marcha.

Hay dos detalles propios de esta imagen:

- **La contraseña se pasa con una variable de entorno.** Una variable de entorno (S07) es un valor con nombre que el sistema entrega al programa cuando arranca. La opción `-e NOMBRE=valor` de `docker run` define una dentro del contenedor, y la imagen `postgres` lee `POSTGRES_PASSWORD` la primera vez que arranca para crear el usuario `postgres` con esa contraseña. Sin ella, el contenedor se detiene con un error.
- **El puerto del equipo tiene que ser distinto del 5432.** El PostgreSQL instalado en S07 ya escucha en el 5432. Publicamos el del contenedor en el **5433**, y por dentro sigue siendo el 5432.

### Ejecutar PostgreSQL

```bash
docker run -d --name postgres-demo -e POSTGRES_PASSWORD=demo-docker -p 5433:5432 postgres:17
```

- `-e POSTGRES_PASSWORD=demo-docker`: define la contraseña del usuario `postgres`. Es una contraseña de prueba para un contenedor de usar y tirar, que vamos a borrar en esta misma demo; no es la del PostgreSQL de S07, y no hay que reutilizar aquí una contraseña real. El comando queda guardado en el historial de la terminal, y por eso las contraseñas de verdad no se escriben así: en S16-2 las sacaremos a un fichero `.env`.
- `-p 5433:5432`: puerto 5433 del equipo, puerto 5432 del contenedor.
- `postgres:17`: la imagen `postgres` en la etiqueta `17`, es decir, PostgreSQL 17. Fijar la versión hace que todos los equipos usen la misma. Sin etiqueta, Docker usaría `latest`.

La primera vez, Docker descarga la imagen (unos cientos de megas), igual que hizo con `nginx`. Comprobamos:

```bash
docker ps
```

<pre>
C:\Users\Mananas>docker ps
CONTAINER ID   IMAGE         COMMAND                  CREATED          STATUS          PORTS                                         NAMES
...            postgres:17   "docker-entrypoint.s…"   20 seconds ago   Up 19 seconds   0.0.0.0:5433->5432/tcp, [::]:5433->5432/tcp   postgres-demo
</pre>

`Up` significa que el contenedor está en marcha, no que PostgreSQL esté listo: en el primer arranque la imagen crea la base de datos y eso tarda unos segundos, y durante ese tiempo rechaza las conexiones. Miramos los registros hasta que aparece la línea de que ya acepta conexiones:

```bash
docker logs postgres-demo
```

<pre>
...
PostgreSQL init process complete; ready for start up.

... LOG:  starting PostgreSQL 17...
... LOG:  listening on IPv4 address "0.0.0.0", port 5432
... LOG:  database system is ready to accept connections
</pre>

La línea que buscamos es `database system is ready to accept connections`. Si pgAdmin se conecta antes y falla, es lo mismo que vimos en S07 con `Connection refused`: esperamos y reintentamos.

### Conectar desde pgAdmin

pgAdmin ya muestra el servidor local de S07 (puerto 5432). Añadimos el del contenedor como un segundo servidor: clic derecho sobre `Servers`, `Register` > `Server...`.

En la pestaña `General`:

- **Name**: `Docker`

En la pestaña `Connection`:

- **Host name/address**: `localhost`
- **Port**: `5433`
- **Maintenance database**: `postgres`
- **Username**: `postgres`
- **Password**: `demo-docker`

Pulsamos `Save`. El servidor `Docker` aparece junto al local. Desde pgAdmin los dos son iguales: lo único que los distingue es el puerto. Es un PostgreSQL de verdad, y las herramientas que ya conocemos funcionan con él.

La imagen trae ya una base de datos llamada `postgres`. En S07 creamos una base por proyecto, pero aquí no hace falta: la usamos directamente. Desplegamos `Docker` > `Databases`, clic derecho sobre `postgres` > `Query Tool`, y ejecutamos con ▶:

```sql
create table nota (
    id bigint generated by default as identity primary key,
    texto varchar(100) not null
);

insert into nota (texto) values ('Creada dentro de un contenedor');

select * from nota;
```

Es el SQL de S07: una tabla con una clave primaria generada por la base de datos (`generated by default as identity`) y una columna de texto obligatoria. En la pestaña `Data Output` aparece la fila insertada:

<pre>
 id |             texto
----+--------------------------------
  1 | Creada dentro de un contenedor
(1 row)
</pre>

### Entrar en el contenedor

Hay otra forma de hablar con la base de datos, sin pgAdmin y sin usar el puerto: ejecutar un programa dentro del contenedor. La imagen `postgres` incluye `psql`, el cliente de línea de comandos de PostgreSQL.

```bash
docker exec -it postgres-demo psql -U postgres
```

`docker exec` ejecuta un comando dentro de un contenedor que ya está en marcha; no crea ningún contenedor nuevo. Sus partes son:

- `-i` mantiene abierta la entrada del contenedor, y `-t` le asigna una terminal. Juntas, `-it`, permiten una sesión interactiva en la que escribimos y vemos la respuesta.
- `postgres-demo`: el contenedor donde se ejecuta.
- `psql -U postgres`: el comando que se ejecuta dentro, que abre una sesión como el usuario `postgres`.

No pide contraseña, porque la conexión se hace desde dentro del propio contenedor. Aparece el indicador `postgres=#`. Probamos dos órdenes:

```sql
\dt
```

```sql
select * from nota;
```

<pre>
postgres=# \dt
        List of relations
 Schema | Name | Type  |  Owner
--------+------+-------+----------
 public | nota | table | postgres
(1 row)

postgres=# select * from nota;
 id |             texto
----+--------------------------------
  1 | Creada dentro de un contenedor
(1 row)
</pre>

`\dt` es una orden propia de `psql` que lista las tablas. Salimos con `\q`.

### Borrar el contenedor y recrearlo

Borramos el contenedor y su base de datos:

```bash
docker rm -f postgres-demo
```

Lo volvemos a crear con exactamente el mismo comando:

```bash
docker run -d --name postgres-demo -e POSTGRES_PASSWORD=demo-docker -p 5433:5432 postgres:17
```

Ahora no hay descarga: la imagen ya está en el equipo, y el contenedor arranca en unos segundos. Esperamos otra vez a la línea `ready to accept connections` en `docker logs postgres-demo`. En pgAdmin pulsamos sobre el servidor `Docker`; como su conexión se perdió con el contenedor anterior, puede pedir de nuevo la contraseña (`demo-docker`). Desplegamos `Databases` > `postgres` > `Schemas` > `public` > `Tables` y pulsamos `Refresh`: **la tabla `nota` ya no está**.

El sistema de ficheros de un contenedor desaparece con él, y los datos de PostgreSQL vivían dentro. El contenedor nuevo parte de la imagen, que está limpia, así que su base de datos está vacía. Es la diferencia con el PostgreSQL de S07, que guarda sus datos en una carpeta de Windows y los conserva entre ejecuciones. Para una base de datos de verdad esto es inaceptable, y la solución son los **volúmenes**, que guardan los datos fuera del contenedor. Se trabajan en S16-2 con Docker Compose.

### Limpiar

Dejamos el equipo limpio:

```bash
docker rm -f postgres-demo
```

Con `docker ps -a` comprobamos que no queda ningún contenedor. Con `docker images` vemos que las imágenes `postgres`, `nginx` y `hello-world` siguen descargadas: ocupan espacio en disco aunque no haya contenedores, y se borran con un comando que veremos en S16-1.
