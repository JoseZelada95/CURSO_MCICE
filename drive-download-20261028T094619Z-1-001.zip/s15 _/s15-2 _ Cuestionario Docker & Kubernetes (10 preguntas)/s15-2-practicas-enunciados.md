# S15-2 Prácticas

## Objetivos

Se repite con puertos, nombres y bases de datos propios lo visto en las demos: ejecutar contenedores, leer su estado y sus registros, resolver los errores de puertos y nombres, y hacer funcionar una base de datos sin instalarla. Cada práctica trabaja con una imagen y con un puerto elegidos por cada persona, de modo que la sintaxis de `docker run` se fija escribiéndola y no copiándola.

Docker Desktop tiene que estar en marcha (**Engine running**) en todas las prácticas. Al empezar conviene comprobar con `docker ps -a` que no quedan contenedores de las demos: si queda alguno, se borra con `docker rm -f` antes de seguir.

Los puertos que ya están ocupados en el equipo, y que no se pueden publicar, son el 8080 (Jenkins), el 5432 (PostgreSQL) y el 27017 (MongoDB).

---

## Práctica 1: Servidor web en un contenedor

Se ejecuta un contenedor de `nginx` en un puerto elegido por cada persona, se comprueba su página en el navegador, se consultan los registros de las peticiones y se provocan a propósito dos errores frecuentes para aprender a reconocerlos.

**Pasos**

1. Elegimos un puerto libre para publicar `nginx`: un número entre 1024 y 65535 que no sea el 8080 ni el 8081 (el de la demo). Lo anotamos.
2. Ejecutamos un contenedor de `nginx` en segundo plano, con el nombre `web-practica` y el puerto elegido publicado en el puerto 80 del contenedor.
3. Comprobamos con `docker ps` que el contenedor está en marcha y que la columna `PORTS` muestra el puerto elegido.
4. Abrimos la página en el navegador y comprobamos que aparece «Welcome to nginx!».
5. Refrescamos la página tres veces con `F5`, consultamos los registros del contenedor y localizamos las líneas de las peticiones. Anotamos el código de respuesta de cada una.
6. Provocamos el primer error: repetimos exactamente el mismo comando del paso 2. Anotamos el mensaje y explicamos qué lo causa.
7. Provocamos el segundo error: ejecutamos otro contenedor de `nginx` con otro nombre y el mismo puerto del equipo. Anotamos el mensaje y comprobamos con `docker ps -a` en qué estado ha quedado ese segundo contenedor.
8. Borramos el contenedor del paso 7, detenemos y borramos `web-practica` y comprobamos con `docker ps -a` que no queda ninguno.

**Pistas**

- Un `docker run` de este tipo necesita cuatro cosas: la opción para ejecutarlo en segundo plano, la opción de publicar el puerto en la forma `puertoDelEquipo:puertoDelContenedor`, la opción de dar nombre y la imagen. `nginx` escucha en el puerto 80 dentro del contenedor.
- Si la página no carga, hay que mirar `PORTS` en `docker ps` y comprobar que el número de la izquierda es el mismo que se escribe en el navegador. Un puerto escrito al revés (`80:8082` en lugar de `8082:80`) normalmente no da ningún error de Docker, pero la página no carga.
- En los registros, no todas las peticiones tienen por qué dar el mismo código: el navegador puede preguntar si la página ha cambiado en lugar de pedirla otra vez.
- Un contenedor creado que no ha llegado a arrancar no aparece en `docker ps`, pero sí en `docker ps -a`.
- El nombre de un contenedor es único. Mientras exista, aunque esté parado, no se puede reutilizar.

---

## Práctica 2: Ciclo de vida completo

Se recorren los estados de un contenedor separando la creación de la ejecución, y se anota qué estado muestra Docker y si responde el navegador tras cada comando.

**Pasos**

1. Elegimos un puerto del equipo libre (distinto del 8080). Con `docker create`, creamos sin arrancarlo un contenedor de `nginx` llamado `ciclo` con ese puerto publicado. Anotamos lo que escribe el comando.
2. Ejecutamos `docker ps` y después `docker ps -a`. Anotamos si el contenedor aparece en cada caso y qué muestra la columna `STATUS`.
3. Intentamos abrir la página en el navegador. Explicamos por qué no responde.
4. Arrancamos el contenedor y comprobamos con `docker ps -a` su estado. Abrimos la página.
5. Detenemos el contenedor y comprobamos su estado.
6. Reiniciamos el contenedor con `docker restart` y comprobamos su estado.
7. Intentamos borrar el contenedor mientras está en marcha. Anotamos el mensaje.
8. Detenemos el contenedor, lo borramos y comprobamos con `docker ps -a` que no queda.
9. Completamos la tabla con lo observado.
10. Ampliación: creamos con `docker create` un contenedor llamado `ciclo2` publicado en el puerto 8080 y lo arrancamos. Anotamos qué comando falla, con qué mensaje, y en qué estado queda el contenedor. Lo borramos al terminar.

| Paso | Comando | `STATUS` en `docker ps -a` | ¿Responde el navegador? |
|---|---|---|---|
| 1 | `create` | | |
| 4 | `start` | | |
| 5 | `stop` | | |
| 6 | `restart` | | |
| 7 | `rm` (en marcha) | | |
| 8 | `stop` y `rm` | | |

**Pistas**

- `docker create` acepta las mismas opciones que `docker run` para el nombre y los puertos, pero no admite `-d` porque no arranca nada.
- `docker create` escribe el identificador largo del contenedor y nada más. El estado `Created` significa que el contenedor existe pero no ha arrancado nunca.
- `docker restart` hace lo mismo que `stop` seguido de `start`, y también funciona con un contenedor que ya está detenido.
- `docker rm` solo borra contenedores detenidos, salvo que se use la opción `-f`. En esta práctica no se usa `-f` hasta que haga falta.
- En la ampliación, lo importante es en qué momento Docker intenta usar el puerto: al crear el contenedor o al arrancarlo.

---

## Práctica 3: MongoDB en un contenedor

Se ejecuta MongoDB en un contenedor sin instalar nada, publicado en un puerto distinto del que ocupa el servicio local, y se comprueba con `mongosh` y con Compass que es un servidor independiente.

**Pasos**

1. Comprobamos que el MongoDB instalado en S11-2 sigue en marcha con `mongosh` y listamos sus bases de datos con `show dbs`. Salimos de `mongosh`.
2. Ejecutamos un contenedor con la imagen `mongo` en la etiqueta `8`, en segundo plano, con el nombre `mongo-practica`. El puerto de MongoDB dentro del contenedor es el 27017; lo publicamos en el puerto 27018 del equipo, porque el 27017 lo ocupa el servicio local.
3. Comprobamos con `docker ps` que está en marcha y con `docker logs` que el servidor espera conexiones.
4. Nos conectamos con `mongosh` al puerto 27018.
5. Cambiamos a una base de datos llamada `practica`, insertamos en una colección `notas` un documento con los campos `titulo`, `texto` e `importante`, y lo consultamos.
6. Abrimos Compass, creamos una conexión a `mongodb://localhost:27018` y comprobamos que aparece la base de datos `practica` con su documento.
7. Volvemos a conectarnos al MongoDB local (puerto 27017) y comprobamos que su lista de bases de datos no incluye `practica`.
8. Borramos el contenedor. Comprobamos con `docker ps -a` que no queda ninguno y con `docker images` que la imagen `mongo` sigue descargada.

**Pistas**

- La imagen `mongo` no necesita variables de entorno para arrancar.
- La primera descarga de la imagen tarda: son varios cientos de megas.
- `mongosh` acepta una cadena de conexión como argumento. Es la misma forma de S12-1 (`mongodb://servidor:puerto`), con el puerto publicado.
- Los registros de MongoDB están en formato JSON. La línea que indica que el servidor está listo contiene el mensaje `Waiting for connections`.
- La imagen `mongo` incluye `mongosh`. Con `docker exec -it` se puede abrir `mongosh` dentro del contenedor, sin usar el puerto 27018. Es una alternativa para el paso 4.
- Un contenedor y el servicio local son dos servidores distintos: lo que se guarda en uno no existe en el otro. Por eso el paso 7 es distinto de la comprobación del paso 6.
