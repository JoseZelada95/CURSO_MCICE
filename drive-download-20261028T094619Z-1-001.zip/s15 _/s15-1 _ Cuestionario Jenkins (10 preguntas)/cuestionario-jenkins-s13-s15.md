# Cuestionario tipo test · IFCD0014 · Jenkins (S13-1 a S15-1)

**Curso:** IFCD0014 – Desarrollo de Aplicaciones con Spring e Hibernate (26/2138)
**Nivel:** fácil · **Preguntas:** 10, en el orden en que se imparte el temario · **Formato:** 4 opciones, solo una correcta, con explicación de la correcta y de cada incorrecta.

Al final hay una tabla con las respuestas.

---

## S13-1 · Integración continua e instalación de Jenkins

### Pregunta 1 (S13-1 · Integración continua)

¿Qué es la integración continua?

**A)** Subir el código a GitHub una sola vez, cuando el proyecto está terminado.

**B)** Construir y probar el proyecto de forma automática, en un equipo aparte, cada vez que cambia el código, para avisar pronto si algo falla.

**C)** Escribir las pruebas antes de escribir el código.

**D)** Dejar de usar Git y compartir el código entre las personas del equipo por correo.

**Respuesta correcta: B.**

**B (correcta):** integrar es juntar en un mismo proyecto los cambios de todas las personas del equipo. La integración continua (en inglés, *continuous integration*, abreviado CI) consiste en hacerlo con mucha frecuencia y, cada vez que el proyecto cambia, descargarlo, construirlo (`mvn clean package`) y ejecutar las pruebas de JUnit de forma automática, sin que nadie tenga que acordarse. Si algo falla, el aviso llega a los pocos minutos, cuando el cambio que lo causó todavía está fresco. El programa que ejecuta todo esto es un servidor de integración continua, y Jenkins es el más extendido.

**A:** es lo contrario. Juntar los cambios solo al final es justo cuando aparecen los problemas, igual que cuatro personas que cocinan un plato cada una en su casa y descubren en la mesa que hay cuatro postres y ningún plato principal.

**C:** eso es otra práctica, el desarrollo guiado por pruebas (TDD), que trata del orden en que se escriben las pruebas y el código, no de automatizar la construcción.

**D:** la integración continua se apoya en Git, no lo sustituye. Cada cambio se envía al repositorio con `git push`, y es el servidor el que se entera, lo descarga y lo construye.

---

### Pregunta 2 (S13-1 · Job y build)

En Jenkins, ¿qué diferencia hay entre un *job* y un *build*?

**A)** Son dos nombres del mismo concepto: en las versiones antiguas, el build se llamaba job.

**B)** El build es la descripción del trabajo que hay que hacer y el job es el resultado de ejecutarlo.

**C)** El job es el programa que se instala en el equipo y el build es la carpeta donde ese programa guarda sus datos.

**D)** El job es la descripción del trabajo (la receta) y cada build es el resultado de una ejecución concreta de ese job, con su número (`#1`, `#2`, `#3`…), su salida de consola y su estado.

**Respuesta correcta: D.**

**D (correcta):** un job describe qué debe hacer Jenkins, por ejemplo «descargar este repositorio y construirlo con Maven». Cada vez que se lanza, Jenkins crea un build con su número, su registro de lo ocurrido (la salida de consola) y su resultado, que puede ser verde (éxito) o rojo (fallo). Es como una receta y cada vez que se cocina: la receta es el job y cada plato es un build.

**A:** no son lo mismo. Lo que sí ocurre es que la documentación antigua llama también *project* al job, pero el build nunca ha sido el job.

**B:** está invertida. La descripción es el job y el resultado es el build.

**C:** el programa que se instala es el controlador (el proceso central de Jenkins), y la carpeta donde guarda su configuración, sus jobs y sus plugins es la carpeta de datos (`JENKINS_HOME`). Ninguno de los dos es un build.

---

### Pregunta 3 (S13-1 · Servicio de Windows)

Jenkins se instala en Windows con el instalador `.msi`, que lo deja como servicio de Windows. ¿Qué ventaja tiene eso?

**A)** Windows lo arranca solo al encender el equipo y sigue funcionando sin ninguna ventana abierta ni sesión iniciada.

**B)** No hace falta desbloquearlo la primera vez: se entra directamente sin contraseña.

**C)** Ya no hace falta tener Java instalado en el equipo.

**D)** Se maneja desde la consola de comandos, sin necesidad de abrir el navegador.

**Respuesta correcta: A.**

**A (correcta):** un servicio de Windows es un programa que Windows arranca por su cuenta y que no depende de ninguna ventana. Se comprueba en la consola de servicios (`services.msc`), donde Jenkins aparece con estado «En ejecución» y tipo de inicio «Automático». Es distinto de arrancar Jenkins desde una terminal, donde al cerrar la terminal se para.

**B:** en una instalación nueva Jenkins no deja entrar a nadie sin demostrar que tiene acceso al equipo. Genera una contraseña inicial de administrador y la guarda en un fichero llamado `initialAdminPassword`; la pantalla «Unlock Jenkins» indica la ruta de ese fichero.

**C:** Jenkins es una aplicación escrita en Java y necesita Java 21 o posterior para ejecutarse. Por eso se comprueba `java -version` antes de instalar.

**D:** Jenkins se maneja desde una página web, en `http://localhost:8080`. `localhost` es el nombre que designa a este mismo ordenador y `8080` es el puerto (el número de la «puerta» por la que el programa recibe conexiones).

---

## S13-2 · Primer job con Git y Maven

### Pregunta 4 (S13-2 · Herramientas globales)

En `Administrar Jenkins > Tools` se declaran el JDK y Maven con un nombre, por ejemplo `jdk-21` y `maven-3.9`. ¿Para qué sirve?

**A)** Para que Jenkins pueda guardar el usuario y el token de GitHub.

**B)** Para que Jenkins pueda arrancar como servicio de Windows.

**C)** Para que los jobs elijan esas herramientas por su nombre, sin depender de lo que el servicio encuentre en su `PATH`.

**D)** Para cambiar el puerto `8080` por otro.

**Respuesta correcta: C.**

**C (correcta):** Jenkins no trae Maven ni un JDK para construir proyectos, y un servicio no ve el entorno de la sesión del usuario: parte de uno propio, con su `PATH` (la lista de carpetas donde Windows busca los programas cuando escribimos su nombre). Declarar las herramientas una sola vez, con un nombre, hace que cada job use la misma versión y que, si el JDK cambia de carpeta, se cambie en un solo sitio.

**A:** el usuario y el token se guardan como una credencial, en `Administrar Jenkins > Credentials`. Jenkins las guarda cifradas y los jobs las usan por su nombre, sin que nadie vea el valor.

**B:** el Java con el que se ejecuta Jenkins se elige en el instalador (pantalla «Select Java home directory») y es una decisión distinta. El JDK de `Tools` es el que se usa para construir el proyecto, y pueden ser el mismo o no.

**D:** el puerto se eligió en el instalador (pantalla «Port selection»). `Tools` solo trata de las herramientas con las que se construye.

---

## S14-1 · Pipeline como código

### Pregunta 5 (S14-1 · Jenkinsfile)

¿Qué es un `Jenkinsfile` y dónde se guarda normalmente?

**A)** Un fichero donde Jenkins guarda las contraseñas; se guarda en la carpeta `secrets`.

**B)** Un informe en XML con los resultados de las pruebas; lo genera Maven en la carpeta `target`.

**C)** Un programa que amplía las capacidades de Jenkins; se descarga desde la página de plugins.

**D)** Un fichero de texto que describe el pipeline (etapas y pasos); se guarda en el repositorio, en la raíz del proyecto, junto al `pom.xml`.

**Respuesta correcta: D.**

**D (correcta):** un pipeline («cadena de montaje») es la secuencia de etapas por las que pasa el código: compilar, probar, empaquetar. El `Jenkinsfile` es el fichero donde se escribe, con una estructura fija: `pipeline`, `stages`, `stage` y `steps`. Se llama exactamente así, con la J mayúscula y sin extensión. Al guardarlo en el repositorio, se versiona como cualquier otra clase: cambia a la vez que el proyecto y cada construcción queda asociada a una versión concreta del pipeline.

**A:** las credenciales las guarda Jenkins cifradas en su carpeta de datos, con las claves de la carpeta `secrets`, que nunca se copia ni se comparte. Un `Jenkinsfile` no guarda secretos: se sube al repositorio y quedarían a la vista.

**B:** los informes XML de las pruebas se llaman `TEST-*.xml` y están en `target/surefire-reports`. Son los que lee el paso `junit` de Jenkins.

**C:** eso es un plugin, una extensión de Jenkins que se instala desde `Administrar Jenkins > Plugins`.

---

### Pregunta 6 (S14-1 · `post` y `always`)

En el `Jenkinsfile`, el paso `junit` va dentro de `post { always { ... } }` de la etapa `Probar`. ¿Por qué?

**A)** Para que Maven ejecute las pruebas dos veces y así asegurarse de que funcionan.

**B)** Para que el informe de pruebas se publique siempre, también cuando una prueba falla y la etapa termina en rojo.

**C)** Para que el informe solo se publique cuando todas las pruebas pasan.

**D)** Para que el JAR se guarde dentro de Jenkins al terminar la construcción.

**Respuesta correcta: B.**

**B (correcta):** el bloque `post` define qué hacer cuando termina una etapa, según cómo haya terminado, y la condición `always` significa «siempre». Si `junit` fuera un paso más de la etapa, al fallar `mvn test` Jenkins abandonaría la etapa en ese mismo momento y el informe no se publicaría, justo cuando más falta hace. Con `always`, el informe se publica con éxito o con fallo.

**A:** las pruebas se ejecutan una sola vez, con `mvn -B test`. `junit` no las ejecuta: solo lee los informes XML que Maven ya ha dejado en `target/surefire-reports`.

**C:** es justo lo contrario de lo que se busca. Sin `always`, el informe solo aparecería en las construcciones en verde, que son las que menos lo necesitan.

**D:** guardar el JAR lo hace `archiveArtifacts`, en la etapa `Empaquetar`.

---

### Pregunta 7 (S14-1 · Poll SCM)

¿Qué hace la opción `Poll SCM` de un job, con una programación como `H/2 * * * *`?

**A)** Espera a que GitHub le envíe un aviso cada vez que llega un `push`.

**B)** Construye el proyecto cada dos minutos, haya cambios o no.

**C)** Cada cierto tiempo (aquí, cada dos minutos) pregunta al repositorio si hay commits nuevos y construye solo si los hay.

**D)** Descarga a su carpeta el JAR de cada construcción anterior.

**Respuesta correcta: C.**

**C (correcta):** SCM son las siglas de *Source Code Management*, la gestión del código fuente, es decir, Git. El sondeo (*polling*) es como mirar el buzón cada dos minutos en lugar de esperar a que llame el cartero. La programación usa la sintaxis de cron, con cinco campos (`minuto hora día-del-mes mes día-de-la-semana`): `H/2` significa «cada 2 minutos», y la `H` hace que Jenkins elija el minuto exacto dentro de cada intervalo.

**A:** eso describe un *webhook*. Para usarlo, el servidor de Jenkins tiene que ser accesible desde Internet, y el del aula no lo es, por eso se usa el sondeo.

**B:** no construye siempre. Si en esos dos minutos no ha llegado ningún commit nuevo, no se lanza ninguna construcción.

**D:** guardar el JAR es tarea de `archiveArtifacts`, y el sondeo no descarga nada: solo comprueba si hay cambios.

---

## S14-2 · Avisos y seguimiento del historial

### Pregunta 8 (S14-2 · Condición `fixed`)

En un bloque `post` al nivel de `pipeline`, ¿cuándo se ejecuta el aviso de la condición `fixed`?

**A)** Cuando esta construcción termina bien y la anterior no había terminado bien: es decir, cuando el proyecto se recupera.

**B)** Siempre que la construcción termina en verde.

**C)** Cuando la construcción falla por segunda vez seguida.

**D)** Cuando se corrige el `Jenkinsfile` con Replay.

**Respuesta correcta: A.**

**A (correcta):** `fixed` avisa de una recuperación, el paso de rojo a verde. Es como un corte de luz: nos enteramos de que se va y de que vuelve, y nadie nos avisa cada minuto de que sigue habiendo luz. Por eso `fixed` no se repite en los verdes siguientes. Una construcción que se recupera cumple a la vez `fixed` y `success`, así que salen los dos avisos.

**B:** eso es `success`, que se ejecuta en cada construcción que termina en verde (*Stable*).

**C:** el fallo de una construcción lo trata `failure`, que se ejecuta cada vez que la construcción termina en rojo, sea la primera vez o la quinta.

**D:** Replay es otra herramienta: permite editar el `Jenkinsfile` de una construcción ya hecha y volver a ejecutarla sin tocar el repositorio. No tiene relación con `fixed`.

---

## S15-1 · Parámetros y cobertura

### Pregunta 9 (S15-1 · Parámetros y `when`)

El `Jenkinsfile` declara un parámetro `EMPAQUETAR` (una casilla) y la etapa `Empaquetar` lleva `when { expression { return params.EMPAQUETAR } }`. ¿Qué ocurre si la casilla se lanza desmarcada?

**A)** La etapa falla y la construcción termina en rojo.

**B)** Jenkins vuelve a preguntar por la casilla antes de continuar.

**C)** Jenkins borra la etapa del `Jenkinsfile` del repositorio.

**D)** Jenkins omite la etapa: no se ejecuta, no da ningún error y la construcción puede terminar en verde.

**Respuesta correcta: D.**

**D (correcta):** un parámetro es una pregunta que Jenkins hace justo antes de empezar la construcción; quien la lanza contesta (con `Build with Parameters`) y el pipeline lee la respuesta con `params.NOMBRE`. Un `booleanParam` se muestra como una casilla: marcada es `true` y sin marcar es `false`. La condición `when` funciona como un portero: si la expresión da `false`, la etapa se omite (*skipped*) y la construcción sigue con lo siguiente. Una etapa omitida no es una etapa fallida: nadie ha pedido que se ejecute.

**A:** fallar significa que ha habido un error, y aquí no lo hay. Omitir una etapa es una decisión, no un fallo.

**B:** la pregunta se hace una sola vez, al lanzar la construcción. Después el pipeline ya tiene la respuesta.

**C:** el `Jenkinsfile` no cambia nunca. Esa es la idea de los parámetros: el fichero se queda igual en el repositorio y lo que cambia es lo que hace en cada ejecución.

---

### Pregunta 10 (S15-1 · Cobertura)

¿Qué mide la cobertura de las pruebas, la que muestra JaCoCo?

**A)** El número de pruebas que han pasado en verde.

**B)** El porcentaje del código que se ejecuta mientras corren las pruebas.

**C)** El tiempo que tarda Maven en ejecutar todas las pruebas.

**D)** El número de personas del equipo que han escrito pruebas.

**Respuesta correcta: B.**

**B (correcta):** es como revisar una casa de diez habitaciones y abrir solo dos: de las otras ocho no sabemos nada. Una línea cubierta es la que se ejecuta al menos una vez durante las pruebas; una línea sin cubrir es la que ninguna prueba ejecuta. Una línea sin cubrir no está mal: está sin comprobar, y si alguien la rompe, ninguna prueba lo notará. Quien mide es JaCoCo, que ejecuta Maven con su plugin; Jenkins solo publica el informe con su plugin Coverage.

**A:** eso es el resultado de las pruebas, que publica el paso `junit`: cuántas pasan y cuáles fallan. Que las seis pruebas pasen en verde no dice cuánto código comprueban.

**C:** el tiempo de ejecución se ve en el registro de Maven y en la vista de etapas de Jenkins, y es una medida distinta.

**D:** la cobertura no habla de personas. Mide qué código recorren las pruebas, no quién las ha escrito ni si son buenas.

---

## Tabla de respuestas

| Nº | Sesión | Resp. |
|---|---|---|
| 1 | S13-1 | B |
| 2 | S13-1 | D |
| 3 | S13-1 | A |
| 4 | S13-2 | C |
| 5 | S14-1 | D |
| 6 | S14-1 | B |
| 7 | S14-1 | C |
| 8 | S14-2 | A |
| 9 | S15-1 | D |
| 10 | S15-1 | B |
