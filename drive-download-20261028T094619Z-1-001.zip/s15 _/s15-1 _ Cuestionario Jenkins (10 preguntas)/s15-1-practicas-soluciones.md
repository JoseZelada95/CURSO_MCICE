# S15-1 Soluciones de las prácticas

Las soluciones de las Prácticas 1 y 2 son el código del zip `s15-1-practicas.zip`. La de la Práctica 3 es orientativa y no tiene zip, porque cada grupo tiene su proyecto.

---

## Práctica 1: Parámetro de pruebas y etapa condicionada en contactos

Partimos del `Jenkinsfile` de la Demo 1 y hacemos tres cambios. Primero, el bloque `parameters` pasa a tener `EJECUTAR_PRUEBAS` (marcada por defecto, igual que en la demo) y `MOSTRAR_ENTORNO` (sin marcar). Segundo, la etapa `Empaquetar` pierde su `when`, porque ahora se ejecuta siempre. Tercero, aparece al principio una etapa nueva, `Entorno`, que solo se ejecuta si se marca `MOSTRAR_ENTORNO`. El resto (`tools`, `Compilar`, `Probar` con su `junit` y el `post` final) no cambia.

La clave de la práctica es la etapa `Entorno`. Es una etapa de diagnóstico: cuando algo falla en Jenkins y no sabemos si es culpa del código o de la máquina, ver qué Java y qué Maven está usando la construcción lo aclara. Como casi nunca hace falta, la dejamos apagada por defecto y se enciende solo cuando se pide.

```groovy
/*
 * S15-1 Práctica 1: Parámetro de pruebas y etapa condicionada en contactos
 *
 * Objetivo: que el pipeline de contactos pregunte si se ejecutan las pruebas y si se muestra
 * la información del entorno, y que cada respuesta cambie lo que hace la construcción.
 *
 * Aplica las técnicas de S15-1:
 *   1. Bloque parameters con dos booleanParam y sus valores por defecto
 *   2. Lectura de un parámetro con params dentro de un comando (-DskipTests)
 *   3. Etapa condicionada con when y expression
 *
 * Concepto clave: los parámetros no cambian el fichero, cambian lo que el fichero hace en cada
 * ejecución. Una etapa omitida no es una etapa fallida.
 */
pipeline {
    agent any

    // Los nombres deben coincidir letra por letra con los de Manage Jenkins > Tools (S13-2).
    tools {
        jdk 'jdk-21'
        maven 'maven-3.9'
    }

    // EJECUTAR_PRUEBAS trae la casilla marcada: por defecto se prueba.
    // MOSTRAR_ENTORNO trae la casilla sin marcar: la información del entorno solo se ve si se pide.
    parameters {
        booleanParam(name: 'EJECUTAR_PRUEBAS', defaultValue: true, description: 'Marcar para ejecutar las pruebas. Desmarcar para saltarlas.')
        booleanParam(name: 'MOSTRAR_ENTORNO', defaultValue: false, description: 'Marcar para mostrar las versiones de Java y de Maven que usa la construccion.')
    }

    stages {

        // La etapa solo se ejecuta si MOSTRAR_ENTORNO está marcado. Si no, Jenkins la omite.
        // La ponemos la primera porque no depende de nada y sirve para diagnosticar.
        stage('Entorno') {
            when {
                expression { return params.MOSTRAR_ENTORNO }
            }
            steps {
                bat 'java -version'
                bat 'mvn -version'
            }
        }

        stage('Compilar') {
            steps {
                bat 'mvn -B clean compile'
            }
        }

        stage('Probar') {
            steps {
                // skipTests es lo contrario de ejecutar: negamos el valor del parámetro con !.
                bat "mvn -B test -DskipTests=${!params.EJECUTAR_PRUEBAS}"
            }
            post {
                // El informe se publica siempre, también cuando las pruebas fallan.
                always {
                    junit testResults: 'target/surefire-reports/*.xml', allowEmptyResults: true
                }
            }
        }

        stage('Empaquetar') {
            steps {
                bat 'mvn -B package -DskipTests'
                archiveArtifacts artifacts: 'target/*.jar'
            }
        }
    }

    // post fuera de stages: se evalúa al terminar el pipeline entero.
    post {
        failure {
            echo "FALLO: la construccion ${env.BUILD_NUMBER} de ${env.JOB_NAME} ha fallado. Revisar la etapa en rojo."
        }
        success {
            echo "OK: la construccion ${env.BUILD_NUMBER} de ${env.JOB_NAME} ha terminado bien."
        }
        fixed {
            echo "RECUPERADA: ${env.JOB_NAME} vuelve a funcionar desde la construccion ${env.BUILD_NUMBER}."
        }
    }
}
```

**Qué debe salir**

Las tres construcciones de la tabla del enunciado, con lo que escribe Maven (comprobado en local):

| Construcción | EJECUTAR_PRUEBAS | MOSTRAR_ENTORNO | ¿Líneas `Tests run:`? | ¿Versiones de Java y Maven? |
|---|---|---|---|---|
| Por defecto | marcada | sin marcar | Sí: `Tests run: 6, Failures: 0, Errors: 0, Skipped: 0` | No: la etapa `Entorno` está omitida |
| Sin pruebas | sin marcar | sin marcar | No: `Tests are skipped.` | No |
| Con entorno | marcada | marcada | Sí | Sí, antes de `Compilar` |

Con las pruebas ejecutadas, el fragmento de Maven es este:

<pre>
[INFO] --- surefire:3.5.6:test (default-test) @ contactos ---
[INFO] Using auto detected provider org.apache.maven.surefire.junitplatform.JUnitPlatformProvider
[INFO] Running com.curso.AplicacionTests
[INFO] Tests run: 1, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 1.581 s -- in com.curso.AplicacionTests
[INFO] Running com.curso.model.ContactoTests
[INFO] Tests run: 5, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 0.019 s -- in com.curso.model.ContactoTests
[INFO] Tests run: 6, Failures: 0, Errors: 0, Skipped: 0
[INFO] BUILD SUCCESS
</pre>

Con las pruebas saltadas:

<pre>
[INFO] --- surefire:3.5.6:test (default-test) @ contactos ---
[INFO] Tests are skipped.
[INFO] BUILD SUCCESS
</pre>

Y los dos comandos de la etapa `Entorno` existen y funcionan en `cmd`. Con `mvn -version` se ve qué Maven y qué Java usa la construcción (el ejemplo es de nuestra comprobación en Linux; en el aula saldrán las versiones y las rutas de Windows):

<pre>
Apache Maven 3.9.11 (3e54c93a704957b63ee3494413a2b544fd3d825b)
Maven home: /opt/maven
Java version: 21.0.12.1, vendor: Ubuntu, runtime: /usr/lib/jvm/java-21-openjdk-amd64
</pre>

Lo que no hemos podido comprobar es cómo escribe Jenkins estas salidas ni cómo muestra la etapa `Entorno` omitida.

**Decisiones tomadas**

- **`MOSTRAR_ENTORNO` empieza sin marcar.** Un valor por defecto debe ser lo que queremos que ocurra casi siempre. Mostrar versiones en cada construcción llenaría la consola de ruido; mostrarlas solo cuando se pide es lo útil. Con `EJECUTAR_PRUEBAS` es al revés: casi siempre se prueba, así que va marcado.
- **`Entorno` es la primera etapa.** No depende de nada, y si la compilación falla queremos haber visto antes con qué herramientas se intentó.
- **Se elimina `EMPAQUETAR`.** El enunciado pide dos parámetros y cada uno hace una cosa distinta: uno cambia un comando (`-DskipTests`) y el otro decide si existe una etapa. Con los dos mecanismos distintos en la misma práctica, se practican a la vez los dos usos de `params`.
- **Se niega con `!`.** Preguntamos en positivo ("ejecutar") porque la casilla se entiende a la primera, y traducimos a lo que entiende Maven (`skipTests`) con la negación.
- **`allowEmptyResults: true` en `junit`.** Sin pruebas no hay informes, y no queremos que el aviso de que no hay informes convierta en fallo una construcción que se pidió sin pruebas.

---

## Práctica 2: Cobertura de contactos

Esta solución es la de la Práctica 1 más tres cosas: JaCoCo en el `pom.xml`, el fichero `lombok.config` y el paso `recordCoverage` en el `post` de `Probar`. El `pom.xml` y el `lombok.config` son los mismos de la Demo 2.

El bloque que se añade al `pom.xml`, justo después de `spring-boot-maven-plugin` y dentro de `<plugins>`:

```xml
			<plugin>
				<groupId>org.jacoco</groupId>
				<artifactId>jacoco-maven-plugin</artifactId>
				<version>0.8.16</version>
				<executions>
					<execution>
						<goals>
							<goal>prepare-agent</goal>
						</goals>
					</execution>
					<execution>
						<id>informe</id>
						<phase>test</phase>
						<goals>
							<goal>report</goal>
						</goals>
					</execution>
				</executions>
			</plugin>
```

El `lombok.config`, en la raíz, junto al `pom.xml`:

```
# S15-1 Demo 2: configuración de Lombok del proyecto contactos.
#
# config.stopBubbling = true: Lombok busca ficheros lombok.config en la carpeta del código fuente
# y en todas las carpetas superiores. Con esta línea la búsqueda termina aquí, en la raíz del proyecto,
# y no se mezcla con ninguna configuración de carpetas de fuera.
config.stopBubbling = true

# lombok.addLombokGeneratedAnnotation = true: Lombok marca con @lombok.Generated todo el código que
# genera (getters, setters, constructores). JaCoCo ignora el código marcado así y no lo cuenta como
# código sin probar. Desde Lombok 1.18.34 ya es el comportamiento por defecto; escribirlo deja la
# decisión a la vista y no depende de la versión de Lombok.
lombok.addLombokGeneratedAnnotation = true
```

Y el `Jenkinsfile` completo:

```groovy
/*
 * S15-1 Práctica 2: Cobertura de contactos
 *
 * Objetivo: publicar en Jenkins la cobertura de las pruebas de contactos para localizar
 * qué clase tiene poca cobertura y qué líneas no recorre ninguna prueba.
 *
 * Aplica las técnicas de S15-1:
 *   1. JaCoCo en el pom.xml (el informe lo genera Maven al ejecutar las pruebas)
 *   2. recordCoverage con el parser JACOCO dentro de post y always
 *   3. Los parámetros de la Práctica 1, sin cambios
 *
 * Concepto clave: la cobertura no dice si las pruebas son buenas, dice qué código ejecutan.
 * Una línea sin recorrer es una pregunta: ¿merece una prueba?
 */
pipeline {
    agent any

    // Los nombres deben coincidir letra por letra con los de Manage Jenkins > Tools (S13-2).
    tools {
        jdk 'jdk-21'
        maven 'maven-3.9'
    }

    parameters {
        booleanParam(name: 'EJECUTAR_PRUEBAS', defaultValue: true, description: 'Marcar para ejecutar las pruebas. Desmarcar para saltarlas.')
        booleanParam(name: 'MOSTRAR_ENTORNO', defaultValue: false, description: 'Marcar para mostrar las versiones de Java y de Maven que usa la construccion.')
    }

    stages {

        stage('Entorno') {
            when {
                expression { return params.MOSTRAR_ENTORNO }
            }
            steps {
                bat 'java -version'
                bat 'mvn -version'
            }
        }

        stage('Compilar') {
            steps {
                bat 'mvn -B clean compile'
            }
        }

        stage('Probar') {
            steps {
                // Con las pruebas activadas, el agente de JaCoCo (declarado en el pom.xml)
                // anota qué líneas se ejecutan y Maven escribe target/site/jacoco/jacoco.xml.
                // Con las pruebas saltadas no hay ejecución que medir y no se genera informe.
                bat "mvn -B test -DskipTests=${!params.EJECUTAR_PRUEBAS}"
            }
            post {
                always {
                    junit testResults: 'target/surefire-reports/*.xml', allowEmptyResults: true

                    // Publica la cobertura leyendo el informe XML de JaCoCo.
                    recordCoverage(tools: [[parser: 'JACOCO']])
                }
            }
        }

        stage('Empaquetar') {
            steps {
                bat 'mvn -B package -DskipTests'
                archiveArtifacts artifacts: 'target/*.jar'
            }
        }
    }

    // post fuera de stages: se evalúa al terminar el pipeline entero.
    post {
        failure {
            echo "FALLO: la construccion ${env.BUILD_NUMBER} de ${env.JOB_NAME} ha fallado. Revisar la etapa en rojo."
        }
        success {
            echo "OK: la construccion ${env.BUILD_NUMBER} de ${env.JOB_NAME} ha terminado bien."
        }
        fixed {
            echo "RECUPERADA: ${env.JOB_NAME} vuelve a funcionar desde la construccion ${env.BUILD_NUMBER}."
        }
    }
}
```

**Qué debe salir**

Con las seis pruebas, el informe de JaCoCo (Maven 3.9.11 y JaCoCo 0.8.16 reales sobre `contactos`) es este:

<pre>
[INFO] --- jacoco:0.8.16:prepare-agent (default) @ contactos ---
[INFO] Tests run: 1, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 2.805 s -- in com.curso.AplicacionTests
[INFO] Tests run: 5, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 0.060 s -- in com.curso.model.ContactoTests
[INFO] Tests run: 6, Failures: 0, Errors: 0, Skipped: 0
[INFO] --- jacoco:0.8.16:report (informe) @ contactos ---
[INFO] Loading execution data file /ruta/contactos/target/jacoco.exec
[INFO] Analyzed bundle 'contactos' with 2 classes
[INFO] BUILD SUCCESS
</pre>

<pre>
Element           Missed Instructions   Cov.   Missed Branches   Cov.   Missed Lines   Lines   Missed Methods   Methods
Total             5 of 47               89%    1 of 6            83%    2              10      1                5
com.curso         5 of 8                37%    0 of 0            n/a    2              3       1                2
com.curso.model   0 of 39               100%   1 of 6            83%    0              7       0                3
</pre>

Las tres preguntas del enunciado:

1. **La clase con menos cobertura es `Aplicacion`**, con el 37 % de las instrucciones y 1 de 3 líneas cubiertas.
2. **Las líneas sin cubrir son la 16 y la 17**, las del cuerpo de `main()`: la llamada a `SpringApplication.run(...)` y la llave que cierra el método. La línea 13, la declaración de la clase, sí está cubierta. Ninguna prueba llama a `main()`: `contextLoads` arranca la aplicación a través de `@SpringBootTest`, no por el método principal.
3. **La línea amarilla es la 65 de `Contacto`**, en el método `emailValido()`:

<pre>
65  return email.contains("@") && email.contains(".") && !email.contains(" ");
    1 of 6 branches missed.
</pre>

   Se ejecuta (la llaman dos de las pruebas), pero falta un camino: ninguna prueba comprueba un correo **sin arroba**. Las pruebas existentes cubren un correo correcto, uno sin punto y uno con espacio, pero en todas la primera condición, `email.contains("@")`, da `true`: nunca se prueba el caso en que da `false`.

Si lanzamos la construcción con `EJECUTAR_PRUEBAS` sin marcar, Maven no ejecuta pruebas y JaCoCo avisa de que no tiene datos (comprobado en local):

<pre>
[INFO] --- jacoco:0.8.16:prepare-agent (default) @ contactos ---
[INFO] --- surefire:3.5.6:test (default-test) @ contactos ---
[INFO] Tests are skipped.
[INFO] --- jacoco:0.8.16:report (informe) @ contactos ---
[INFO] Skipping JaCoCo execution due to missing execution data file.
[INFO] BUILD SUCCESS
</pre>

No se genera `jacoco.xml`. Qué hace `recordCoverage` en ese caso no está documentado ni lo hemos comprobado: es lo que el alumno anota al mirar su construcción.

**Ampliación: cubrir la línea amarilla**

Se añade a `ContactoTests` una prueba con un correo sin arroba. Va al final de la clase, antes de la llave que la cierra, con el mismo estilo que las otras:

```java
    // Comprueba que un correo sin arroba no es válido.
    @Test
    void emailSinArrobaNoEsValido() {
        assertFalse(new Contacto("Lucía Pérez", "lucia.example.com", "600123456").emailValido());
    }
```

Este fragmento es opcional y **no está en el zip**: lo hemos ejecutado con Maven (siete pruebas, `BUILD SUCCESS`) pero no forma parte del código entregado. Con él, `Contacto` pasa a 6 de 6 ramas cubiertas y la línea 65 deja de ser amarilla; `Aplicacion` no cambia, porque la prueba no tiene nada que ver con `main()`.

**Decisiones tomadas**

- **Publicar dentro de `post { always }`.** La cobertura se publica junto a `junit`, con la misma condición. Si una prueba falla, el informe de cobertura no existe (Maven se detiene antes de `report`), pero el intento no cuesta nada y no oculta el fallo.
- **`report` en la fase `test`.** Así `mvn -B test` ya produce el informe, sin una etapa aparte ni un comando extra. Sin indicar fase, `report` se ejecuta en `verify` (comprobado): la etapa `Probar`, que solo llega a `test`, no lo generaría.
- **`lombok.config` explícito.** Con la versión de Lombok de Spring Boot 4.1.1 no haría falta, porque la marca de código generado ya es la opción por defecto. Pero deja la decisión por escrito en el proyecto y lo protege de una versión más antigua de Lombok (comprobado: con `false`, `Contacto` baja al 82 % por tres métodos que Lombok escribió).
- **La clase menos cubierta no es la más importante.** `Aplicacion` tiene el porcentaje más bajo, pero su `main()` nadie lo prueba y no pasa nada. La línea amarilla de `Contacto` tiene un porcentaje alto y es, sin embargo, el hallazgo útil: una condición real de la lógica de negocio sin comprobar. Leer la cobertura es mirar las líneas, no solo la cifra.

---

## Práctica 3: Parámetros y cobertura en el proyecto del grupo

Esta solución es **orientativa**: es una plantilla que cada grupo adapta a su proyecto. Parte del `Jenkinsfile` de S14-2 (compilar, probar, empaquetar y `post`) y añade tres parámetros, el cálculo de las rutas cuando el `pom.xml` está en una subcarpeta y la publicación de la cobertura. Para que quede corto, la plantilla tiene solo `Compilar` y `Probar`; el grupo conserva su etapa `Empaquetar`.

```groovy
/*
 * S15-1 Práctica 3 (solución orientativa): parámetros y cobertura en el Jenkinsfile del grupo
 *
 * Objetivo: añadir al pipeline del proyecto del grupo un parámetro para las pruebas, un parámetro
 * para excluir una clase de pruebas y la publicación de la cobertura de JaCoCo.
 *
 * Aplica las técnicas de S15-1:
 *   1. booleanParam y stringParam leídos con params
 *   2. Exclusión de una clase de pruebas con "-Dtest=!NombreTests" (JaCoCo solo mide lo que se ejecuta)
 *   3. recordCoverage con pattern cuando el pom.xml está en una subcarpeta (-f)
 *
 * Concepto clave: es una plantilla. Cada grupo cambia SUBCARPETA, EXCLUIR_PRUEBAS y los nombres
 * de sus herramientas según su proyecto. No se entrega en zip: no existe un proyecto común.
 */
pipeline {
    agent any

    tools {
        jdk 'jdk-21'
        maven 'maven-3.9'
    }

    // Si el pom.xml está en la raíz del repositorio, SUBCARPETA se queda vacío.
    // Si está en una subcarpeta (por ejemplo app), SUBCARPETA vale app.
    environment {
        POM = "${params.SUBCARPETA ? params.SUBCARPETA + '/pom.xml' : 'pom.xml'}"
        INFORME = "${params.SUBCARPETA ? params.SUBCARPETA + '/' : ''}target/site/jacoco/jacoco.xml"
        PRUEBAS = "${params.SUBCARPETA ? params.SUBCARPETA + '/' : ''}target/surefire-reports/*.xml"
    }

    parameters {
        booleanParam(name: 'EJECUTAR_PRUEBAS', defaultValue: true, description: 'Marcar para ejecutar las pruebas. Desmarcar para saltarlas.')
        string(name: 'EXCLUIR_PRUEBAS', defaultValue: '', description: 'Clase de pruebas a excluir, por ejemplo AplicacionTests. Vacio: no se excluye ninguna.')
        string(name: 'SUBCARPETA', defaultValue: '', description: 'Carpeta del pom.xml dentro del repositorio. Vacio: el pom.xml esta en la raiz.')
    }

    stages {

        stage('Compilar') {
            steps {
                bat "mvn -B -f ${env.POM} clean compile"
            }
        }

        stage('Probar') {
            steps {
                script {
                    // Si hay una clase que excluir, se añade -Dtest=!Clase. Si no, no se añade nada.
                    def excluir = params.EXCLUIR_PRUEBAS?.trim() ? "\"-Dtest=!${params.EXCLUIR_PRUEBAS.trim()}\"" : ''
                    bat "mvn -B -f ${env.POM} test ${excluir} -DskipTests=${!params.EJECUTAR_PRUEBAS}"
                }
            }
            post {
                always {
                    junit testResults: env.PRUEBAS, allowEmptyResults: true
                    recordCoverage(tools: [[parser: 'JACOCO', pattern: env.INFORME]])
                }
            }
        }
    }

    post {
        failure {
            echo "FALLO: la construccion ${env.BUILD_NUMBER} de ${env.JOB_NAME} ha fallado."
        }
        success {
            echo "OK: la construccion ${env.BUILD_NUMBER} de ${env.JOB_NAME} ha terminado bien."
        }
        fixed {
            echo "RECUPERADA: ${env.JOB_NAME} vuelve a funcionar desde la construccion ${env.BUILD_NUMBER}."
        }
    }
}
```

**Cómo funciona**

- **Tres parámetros.** `EJECUTAR_PRUEBAS` es booleano. `EXCLUIR_PRUEBAS` y `SUBCARPETA` son de texto (`string`) y por defecto van vacíos: sin exclusión, y con el `pom.xml` en la raíz.
- **Rutas calculadas.** El bloque `environment` define tres variables: la ruta del `pom.xml`, la del informe de cobertura y la de los informes de pruebas. Si `SUBCARPETA` tiene texto, lo añaden delante; si está vacío, quedan como en un proyecto normal. Es una condición de una línea: `params.SUBCARPETA ? ... : ...` quiere decir "si tiene texto, esto; si no, esto otro".
- **Un bloque `script` en `Probar`.** El texto de la exclusión depende de un parámetro (puede existir o no), y para construir un texto con una condición hace falta una variable (`def excluir`), que dentro de `steps` solo se puede escribir en un bloque `script`. El resto del `Jenkinsfile` no lo necesita. `?.trim()` quita los espacios sobrantes y tolera que el parámetro no tenga valor.
- **`"-Dtest=!Clase"`.** Excluye esa clase de pruebas; Maven ejecuta las demás. Se escribe entre comillas dobles porque en `cmd` el signo `!` puede interpretarse (S14-1). Desde Groovy las comillas dobles se escapan con `\"`.
- **`-f ${env.POM}`.** Indica a Maven qué `pom.xml` usar. Va en cada comando de Maven.
- **Cobertura con ruta.** `recordCoverage(tools: [[parser: 'JACOCO', pattern: env.INFORME]])` añade `pattern`, la ruta del informe, relativa al espacio de trabajo. Con la subcarpeta `app` es `app/target/site/jacoco/jacoco.xml`.

**Qué hemos comprobado**

La construcción de las cadenas, con Groovy, para cuatro combinaciones de parámetros (el comando que recibiría `bat` y la ruta del informe):

<pre>
compilar: mvn -B -f pom.xml clean compile
probar  : mvn -B -f pom.xml test  -DskipTests=false
informe : target/site/jacoco/jacoco.xml
--
compilar: mvn -B -f pom.xml clean compile
probar  : mvn -B -f pom.xml test "-Dtest=!AplicacionTests" -DskipTests=false
informe : target/site/jacoco/jacoco.xml
--
compilar: mvn -B -f app/pom.xml clean compile
probar  : mvn -B -f app/pom.xml test  -DskipTests=false
informe : app/target/site/jacoco/jacoco.xml
--
compilar: mvn -B -f app/pom.xml clean compile
probar  : mvn -B -f app/pom.xml test "-Dtest=!AplicacionTests" -DskipTests=true
informe : app/target/site/jacoco/jacoco.xml
</pre>

(El tercer caso tiene `EXCLUIR_PRUEBAS` con solo espacios y no añade exclusión.) Y con Maven real sobre `contactos`:

- **La exclusión cambia la cobertura.** Con `mvn -B test "-Dtest=!AplicacionTests" -DskipTests=false` se ejecutan 5 pruebas (`BUILD SUCCESS`) y la cobertura es: `Aplicacion` 0 de 8 instrucciones y 0 de 3 líneas (0 %), `Contacto` 39 de 39 instrucciones y 7 de 7 líneas (100 %). Antes, con las seis pruebas, `Aplicacion` estaba al 37 %. La única diferencia es la clase de pruebas excluida: `contextLoads` era la que creaba un objeto de `Aplicacion`. JaCoCo solo mide lo que se ejecuta: una clase excluida no desaparece, hace que el código que solo ella recorría quede sin cubrir.
- **La subcarpeta.** Con el proyecto copiado en `repo/app/`, `mvn -B -f app/pom.xml clean test` ejecuta las 6 pruebas y deja el informe en `app/target/site/jacoco/jacoco.xml`; en la raíz del repositorio no se crea `target`.

**Decisiones tomadas**

- **`EXCLUIR_PRUEBAS` por defecto, vacío; pero cada grupo puede cambiarlo.** Una construcción lanzada por el sondeo no pasa por el formulario y usa el valor por defecto. Si el grupo sabe que `AplicacionTests` o sus pruebas con base de datos fallan siempre en Jenkins (S14-1: la variable con la contraseña no existe para el servicio), conviene poner esa clase como `defaultValue` para que lo automático funcione.
- **Solo una clase.** La plantilla excluye una clase. Para varias, Maven admite una lista (`"-Dtest=!AplicacionTests,!*RepositoryTests"`, S14-1) y el grupo edita la línea del `Jenkinsfile`; poner varias clases en el parámetro sin más no funcionaría, porque el `!` solo se añade al principio.
- **Rutas con `environment` y no repetidas.** Escribir `app/` en cada comando es fácil de olvidar en uno. Calcularlo una vez evita que `junit` busque en una carpeta y Maven escriba en otra.
- **Valores vacíos válidos.** Un grupo con el `pom.xml` en la raíz no tiene que tocar `SUBCARPETA`.
- **Qué mirar en el resultado.** La cobertura de un proyecto de grupo suele salir baja. La pregunta del enunciado distingue dos causas: pruebas excluidas (se pueden recuperar si se arregla su problema con Jenkins) y pruebas que nadie ha escrito (trabajo pendiente). Esa lista es el punto de partida del trabajo de pruebas del final del curso.

**Qué no hemos comprobado**: el `Jenkinsfile` se ha validado con el analizador de Groovy (4.0.24 y 2.4.21), pero no se ha ejecutado en Jenkins. En concreto, que `params` sea accesible desde `environment`, que `script` y `def` funcionen como se espera en un pipeline declarativo, que `env.POM` y `env.INFORME` se resuelvan en `junit` y `recordCoverage`, y que `pattern` admita una ruta relativa a la subcarpeta.

---

## Problemas frecuentes

- **El grupo no ve la cobertura que esperaba.** Primero se comprueba que Maven genera `jacoco.xml` en local con el mismo comando que usa el `Jenkinsfile`. Si no se genera allí, tampoco en Jenkins.
- **`jacoco.xml` no se encuentra.** El informe está en la subcarpeta del `pom.xml` y la ruta no la lleva.
- **`junit` no encuentra informes de pruebas.** Mismo problema con `target/surefire-reports`.
- **El comando de exclusión falla en `cmd`.** Faltan las comillas dobles alrededor de `-Dtest=!Clase`.
- **La exclusión no tiene efecto.** El nombre de la clase de pruebas tiene que coincidir con el del fichero de pruebas, sin `.java`.
- **La etapa `Entorno` (P1) aparece sin salida.** Si `MOSTRAR_ENTORNO` está sin marcar, está omitida y no escribe nada. No es un fallo.
- **El plugin Coverage no está.** `recordCoverage` no existe como paso. Se instala como en la Demo 2.
- **Se cambia `lombok.config` y la cobertura no cambia.** Falta `mvn -B clean test` con `clean`.
- **Hay comillas curvas en el fichero.** Vienen de pegar texto desde un documento. Groovy no las reconoce.

---

## Qué está verificado y qué no

**Verificado** (Maven 3.9.11, JDK 21.0.12, Surefire 3.5.6, JaCoCo 0.8.16, Lombok 1.18.46; `contactos` real):

- Los `Jenkinsfile` de las Prácticas 1 y 2 (zip) y el orientativo de la Práctica 3 pasan Groovy 4.0.24 y 2.4.21, y la comprobación estructural propia. El código del zip y el de este documento son el mismo (los bloques se han generado a partir de los ficheros).
- Las salidas de Maven con y sin pruebas, las cifras del informe de JaCoCo, las líneas 16, 17 y 65, la ausencia de informe con las pruebas saltadas, `-Dtest=!AplicacionTests` con su efecto sobre la cobertura, `-f app/pom.xml` con su ruta de informe y la prueba de ampliación (siete pruebas, seis de seis ramas).
- La construcción de las cadenas del `Jenkinsfile` de la Práctica 3 para cuatro combinaciones de parámetros.
- Que `java -version` y `mvn -version` existen y funcionan (los comandos de la etapa `Entorno`).

**No verificado (requiere Jenkins real)**: las pantallas y los menús de Jenkins, el formulario de `Build with Parameters`, la etapa omitida en la vista de etapas, el informe de cobertura dentro de Jenkins, `recordCoverage` sin informe, las salidas de `java -version` y `mvn -version` dentro de la consola de Jenkins, el comportamiento del `Jenkinsfile` de la Práctica 3 y el proyecto de cada grupo.
