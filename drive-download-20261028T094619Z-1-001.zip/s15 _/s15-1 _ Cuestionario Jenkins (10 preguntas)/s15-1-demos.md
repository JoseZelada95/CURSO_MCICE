# S15-1 Demos

## Objetivos

Un pipeline que hace siempre lo mismo es un buen comienzo, pero un equipo necesita más. A veces hay que decidir algo en el momento de lanzar la construcción: si se ejecutan las pruebas, si se empaqueta el JAR. Los **parámetros** lo permiten: Jenkins pregunta antes de empezar y el pipeline lee la respuesta. La condición `when` hace que una etapa solo se ejecute si se cumple una condición, y así el mismo `Jenkinsfile` produce resultados distintos según quién lo lanza y con qué opciones, sin editar el fichero.

La segunda mitad de la parte añade una medida que el verde o el rojo no dan: la **cobertura**, el porcentaje del código que recorren las pruebas. Jenkins es pequeño de fábrica y crece con **plugins**, así que instalamos uno, añadimos JaCoCo al `pom.xml` de `contactos` y leemos el informe: qué porcentaje tiene cada clase y qué líneas no toca ninguna prueba. Por el camino aparece un detalle de Lombok que conviene conocer, porque cambia de dónde sale la cifra. Cerramos con una explicación breve de cómo un pipeline usa por su identificador la credencial que creamos en S13-2, sin escribir nunca el secreto en el `Jenkinsfile`.

Al terminar esta parte los alumnos son capaces de:
- Declarar parámetros con un bloque `parameters` y `booleanParam`, y leerlos en el pipeline con `params`.
- Condicionar una etapa con `when` y `expression`, y explicar qué es una etapa omitida y en qué se diferencia de una etapa fallida.
- Lanzar una construcción con `Build with Parameters` y comparar las consolas de dos ejecuciones con valores distintos.
- Instalar un plugin desde la página de plugins de Jenkins y comprobar qué ha añadido.
- Añadir JaCoCo al `pom.xml`, publicar la cobertura con `recordCoverage` y leer el porcentaje por clase.
- Localizar las líneas que ninguna prueba recorre.
- Explicar por qué el código que genera Lombok no cuenta como código sin probar y qué hace `lombok.config`.
- Explicar cómo usa un pipeline una credencial por su ID sin que el secreto aparezca en el fichero.

---

## El material de esta parte

Esta parte no crea ningún proyecto nuevo. Trabajamos con `contactos`, el proyecto de S11-1 que Jenkins construye desde S13-2: la clase `Contacto` con Lombok, `ContactoTests` con cinco pruebas y `AplicacionTests` con `contextLoads`, seis pruebas en total y sin base de datos. El zip `s15-1-demos.zip` lo incluye en la carpeta `contactos`, exactamente como quedó en S14-2 (comprobado: ningún fichero cambia). Las carpetas `demo1-parametros` y `demo2-cobertura` contienen solo los ficheros que cambian en cada demo; los copiamos sobre el proyecto.

<pre>
s15-1-demos/
├── cambios/
│   └── lombok-config-antes.txt
├── contactos/
│   ├── src/
│   ├── .gitattributes
│   ├── .gitignore
│   ├── Jenkinsfile
│   └── pom.xml
├── demo1-parametros/
│   └── Jenkinsfile
└── demo2-cobertura/
    ├── Jenkinsfile
    ├── lombok.config
    └── pom.xml
</pre>

La carpeta `cambios` no es código del proyecto: es una ficha de texto con el experimento de `lombok.config` de la Demo 2, paso por paso. Lleva extensión `.txt` para que no se confunda con código ni se suba al repositorio.

El repositorio es el de siempre, `https://github.com/JD-CFTIC/contactos.git` (privado, con el token de S11-1), en la rama `main`. Cada alumno usa el suyo. No hay ramas nuevas, ni webhooks, ni servidor de correo.

### Antes de empezar

Comprobamos cinco cosas, porque las demos se ven tal como se cuentan aquí solo si se cumplen:

1. Jenkins responde en `http://localhost:8080`. Si no responde, desde un `cmd` de administrador: `sc query Jenkins` y, si está parado, `net start Jenkins`.
2. El job `contactos` es el de S14-1 y S14-2: tipo `Pipeline`, `Pipeline script from SCM` con Git, `Branch Specifier` `*/main` y `Script Path` `Jenkinsfile`. El sondeo (`Poll SCM`, `H/2 * * * *`) puede estar activado o no: en esta parte lanzamos las construcciones a mano, porque necesitamos elegir los valores.
3. La última construcción del job está en verde.
4. La copia local de `contactos` en IntelliJ está al día (`git pull`) y `git status` dice `nothing to commit, working tree clean`.
5. En la terminal de IntelliJ (`Alt+F12`) funcionan `java -version` (Java 21) y `mvn -version`. Las comprobaciones locales de la Demo 2 usan Maven desde ahí.

Una aclaración sobre los números. En los ejemplos las construcciones tienen números concretos (la 12, la 13...) para poder seguir la historia. Los de cada alumno serán otros, porque dependen de cuántas construcciones lleve su job. Lo mismo pasa con los tiempos que escribe Maven: los de este documento son de una ejecución concreta.

---

## Demo 1: Parámetros y etapa condicionada

### Qué es un parámetro

Pensemos en una cafetería. La receta del café es siempre la misma, pero antes de prepararlo el camarero pregunta: "¿con leche?", "¿para llevar?". La respuesta no cambia la receta, cambia lo que sale de ella. Un **parámetro** de Jenkins es exactamente eso: una pregunta que Jenkins hace justo antes de empezar la construcción. Quien la lanza contesta, y el pipeline lee la respuesta y se comporta en consecuencia.

Hasta ahora nuestro `Jenkinsfile` no preguntaba nada. Hacía siempre lo mismo: compilar, probar y empaquetar. Si un día queríamos construir sin ejecutar las pruebas, había que editar el fichero, hacer commit y esperar. Con parámetros, el fichero no se toca: se contesta una casilla.

### El bloque parameters y booleanParam

Los parámetros se declaran en un bloque llamado `parameters`, dentro de `pipeline`, al mismo nivel que `tools` y `stages`. Solo puede aparecer una vez. Dentro, cada pregunta es una línea. Hay varios tipos de parámetro (texto, lista de opciones, contraseña...); hoy usamos el más sencillo, `booleanParam`.

Un **booleano** es un valor que solo puede ser `true` (verdadero) o `false` (falso). Lo conocemos de Java desde `assertTrue` y `assertFalse` (S02-2). En Jenkins, un `booleanParam` se muestra como una **casilla**: marcada es `true`, sin marcar es `false`. Tiene tres datos:

- `name`: el nombre del parámetro. Es el nombre con el que el pipeline lo lee, y por convención se escribe en mayúsculas con guiones bajos (`EJECUTAR_PRUEBAS`).
- `defaultValue`: el valor **por defecto**, el que trae la casilla si nadie la toca. Es importante elegirlo bien, porque es lo que ocurre cuando alguien lanza la construcción sin pensar: en nuestro caso, `true` en los dos parámetros, de modo que por defecto se prueba y se empaqueta, como hasta ahora.
- `description`: el texto de ayuda que Jenkins muestra junto a la casilla. Lo escribimos sin tildes, igual que los `echo` (S14-1), por prudencia con la codificación de Windows.

### Leer la respuesta: params

Para leer la respuesta, el pipeline escribe `params.` seguido del nombre: `params.EJECUTAR_PRUEBAS`. `params` es el "tablón de respuestas" de la construcción: contiene lo que se contestó a cada pregunta. Recordemos `env.` de S14-2: allí leíamos variables que prepara Jenkins por su cuenta (`env.JOB_NAME`, `env.BUILD_NUMBER`). Con `params.` leemos algo distinto: lo que ha contestado una persona.

Hay un detalle que cuida el código. Nosotros preguntamos en positivo ("¿ejecutar las pruebas?"), porque así se entiende la casilla, pero Maven entiende la propiedad `skipTests` (S03-2), que es justo la pregunta contraria: "¿saltar las pruebas?". Para pasar de una a otra negamos el valor con el signo `!` (lo vimos en S11-1): `!true` es `false` y `!false` es `true`. Así, casilla marcada produce `-DskipTests=false` (Maven ejecuta las pruebas) y casilla sin marcar produce `-DskipTests=true` (Maven las salta). Además, el comando va entre comillas dobles, para que `${...}` se sustituya por su valor (S14-2).

### La condición when y las etapas omitidas

El segundo parámetro, `EMPAQUETAR`, no se lee dentro de un comando sino en la **cabecera de una etapa**. Una etapa puede llevar un bloque `when`, que es como el portero de una sala: comprueba una condición y, si no se cumple, la etapa no se ejecuta y el recorrido continúa con la siguiente. Dentro de `when` hay varias formas de escribir la condición; usamos `expression`, que contiene un trozo de código en Groovy (el lenguaje del `Jenkinsfile`) que tiene que dar `true` o `false`. `return` es la palabra que devuelve ese valor. Si da `true`, la etapa se ejecuta; si da `false`, Jenkins la **omite**.

Una etapa omitida (en inglés, *skipped*) no es una etapa fallida. No hay error, no se pone nada en rojo y la construcción puede terminar en verde. Simplemente esa etapa no se ha ejecutado, y en la consola no hay ninguna salida de ella. Esta diferencia es la que más desconcierta al principio: ver que "falta" el empaquetado no significa que haya fallado, significa que alguien decidió no pedirlo.

### El código, pieza a pieza

Partimos del `Jenkinsfile` de S14-2 (el de `contactos`), que no cambia en su estructura (`agent`, `tools`, `Compilar` y el `post` final; solo hemos acortado algunos comentarios). Hay tres piezas nuevas. La primera es el bloque `parameters`, justo después de `tools`:

```groovy
    // parameters declara las preguntas que Jenkins hace al lanzar la construcción.
    // Solo puede aparecer una vez, dentro de pipeline.
    // booleanParam es un parámetro de tipo sí o no (casilla marcada o sin marcar):
    //   name         = el nombre con el que el pipeline lo lee (params.EJECUTAR_PRUEBAS)
    //   defaultValue = el valor que trae la casilla si nadie la toca
    //   description  = el texto de ayuda que Jenkins muestra junto a la casilla (sin tildes, por prudencia)
    parameters {
        booleanParam(name: 'EJECUTAR_PRUEBAS', defaultValue: true, description: 'Marcar para ejecutar las pruebas. Desmarcar para saltarlas.')
        booleanParam(name: 'EMPAQUETAR', defaultValue: true, description: 'Marcar para generar y guardar el JAR. Desmarcar para omitir la etapa Empaquetar.')
    }
```

La segunda está en la etapa `Probar`: el comando de Maven lee el parámetro con `params` y lo niega. El `post` con `junit` de esa etapa se queda como estaba, solo cambia la última línea de `steps`:

```groovy
                // params.EJECUTAR_PRUEBAS vale true o false. Maven entiende la propiedad skipTests
                // (saltar pruebas), que es justo lo contrario: skipTests=false significa "ejecutarlas".
                // El signo ! delante de params niega el valor: !true es false y !false es true.
                //   EJECUTAR_PRUEBAS marcado   →  -DskipTests=false  →  Maven ejecuta las pruebas
                //   EJECUTAR_PRUEBAS desmarcado →  -DskipTests=true   →  Maven dice "Tests are skipped."
                // Comillas dobles para que ${...} se sustituya por su valor (S14-2).
                bat "mvn -B test -DskipTests=${!params.EJECUTAR_PRUEBAS}"
```

La tercera es la etapa `Empaquetar`, que gana un bloque `when` antes de `steps`:

```groovy
        stage('Empaquetar') {
            // when decide si la etapa se ejecuta. expression evalúa una expresión de Groovy:
            // si devuelve true, la etapa se ejecuta; si devuelve false, Jenkins la omite
            // y la marca como omitida (skipped) en la vista de etapas, sin dar error.
            when {
                expression { return params.EMPAQUETAR }
            }
            steps {
                // Las pruebas ya se ejecutaron en la etapa anterior (o se decidió saltarlas),
                // así que aquí no se repiten.
                bat 'mvn -B package -DskipTests'
                // Guarda el JAR dentro de Jenkins, asociado a esta construcción.
                archiveArtifacts artifacts: 'target/*.jar'
            }
        }
```

Y este es el `Jenkinsfile` completo, idéntico al de la carpeta `demo1-parametros` del zip:

```groovy
/*
 * S15-1 Demo 1: Parámetros y etapa condicionada
 *
 * Objetivo: que quien lanza la construcción decida si se ejecutan las pruebas y si se empaqueta
 * el JAR, sin editar el Jenkinsfile.
 *
 * Lo que hace este ejemplo:
 *   - Parte del Jenkinsfile de S14-2 Demo 1 (compilar, probar, empaquetar y avisos con post)
 *   - Declara dos parámetros booleanos con un bloque parameters
 *   - Lee EJECUTAR_PRUEBAS con params dentro del comando de la etapa Probar
 *   - Condiciona la etapa Empaquetar con when: solo se ejecuta si EMPAQUETAR está marcado
 *
 * Concepto clave: un parámetro es una pregunta que Jenkins hace antes de empezar la construcción;
 * el pipeline lee la respuesta con params.NOMBRE y la misma descripción produce resultados distintos.
 */
pipeline {

    // Cualquier agente disponible: en el aula, el propio Jenkins.
    agent any

    // Los nombres entre comillas son los de Manage Jenkins > Tools (S13-2) y deben
    // coincidir letra por letra con ellos.
    tools {
        jdk 'jdk-21'
        maven 'maven-3.9'
    }

    // parameters declara las preguntas que Jenkins hace al lanzar la construcción.
    // Solo puede aparecer una vez, dentro de pipeline.
    // booleanParam es un parámetro de tipo sí o no (casilla marcada o sin marcar):
    //   name         = el nombre con el que el pipeline lo lee (params.EJECUTAR_PRUEBAS)
    //   defaultValue = el valor que trae la casilla si nadie la toca
    //   description  = el texto de ayuda que Jenkins muestra junto a la casilla (sin tildes, por prudencia)
    parameters {
        booleanParam(name: 'EJECUTAR_PRUEBAS', defaultValue: true, description: 'Marcar para ejecutar las pruebas. Desmarcar para saltarlas.')
        booleanParam(name: 'EMPAQUETAR', defaultValue: true, description: 'Marcar para generar y guardar el JAR. Desmarcar para omitir la etapa Empaquetar.')
    }

    stages {

        stage('Compilar') {
            steps {
                // clean borra target/ antes de empezar: así no quedan informes de una construcción anterior.
                bat 'mvn -B clean compile'
            }
        }

        stage('Probar') {
            steps {
                // params.EJECUTAR_PRUEBAS vale true o false. Maven entiende la propiedad skipTests
                // (saltar pruebas), que es justo lo contrario: skipTests=false significa "ejecutarlas".
                // El signo ! delante de params niega el valor: !true es false y !false es true.
                //   EJECUTAR_PRUEBAS marcado   →  -DskipTests=false  →  Maven ejecuta las pruebas
                //   EJECUTAR_PRUEBAS desmarcado →  -DskipTests=true   →  Maven dice "Tests are skipped."
                // Comillas dobles para que ${...} se sustituya por su valor (S14-2).
                bat "mvn -B test -DskipTests=${!params.EJECUTAR_PRUEBAS}"
            }
            post {
                // El informe se publica siempre, también cuando las pruebas fallan (S14-1).
                // Si las pruebas se han saltado no hay informe, y allowEmptyResults evita un segundo error.
                always {
                    junit testResults: 'target/surefire-reports/*.xml', allowEmptyResults: true
                }
            }
        }

        stage('Empaquetar') {
            // when decide si la etapa se ejecuta. expression evalúa una expresión de Groovy:
            // si devuelve true, la etapa se ejecuta; si devuelve false, Jenkins la omite
            // y la marca como omitida (skipped) en la vista de etapas, sin dar error.
            when {
                expression { return params.EMPAQUETAR }
            }
            steps {
                // Las pruebas ya se ejecutaron en la etapa anterior (o se decidió saltarlas),
                // así que aquí no se repiten.
                bat 'mvn -B package -DskipTests'
                // Guarda el JAR dentro de Jenkins, asociado a esta construcción.
                archiveArtifacts artifacts: 'target/*.jar'
            }
        }
    }

    // post fuera de stages: se evalúa una sola vez, cuando termina todo el pipeline (S14-2).
    post {

        // failure: se ejecuta solo si la construcción ha terminado en rojo.
        failure {
            echo "FALLO: la construccion ${env.BUILD_NUMBER} de ${env.JOB_NAME} ha fallado. Revisar la etapa en rojo."
        }

        // success: se ejecuta solo si la construcción ha terminado en verde.
        success {
            echo "OK: la construccion ${env.BUILD_NUMBER} de ${env.JOB_NAME} ha terminado bien."
        }

        // fixed: esta construcción termina bien y la anterior no.
        fixed {
            echo "RECUPERADA: ${env.JOB_NAME} vuelve a funcionar desde la construccion ${env.BUILD_NUMBER}."
        }
    }
}
```

### Antes de subirlo: qué debe pasar en Maven

Antes de llevar el fichero a Jenkins comprobamos en nuestro ordenador qué hace Maven con cada valor del parámetro. Es lo que ejecutará Jenkins por dentro. En la terminal de IntelliJ (`Alt+F12`), en la raíz de `contactos`:

```bash
mvn -B clean compile
mvn -B test -DskipTests=false
```

El segundo comando es el que genera Jenkins con la casilla marcada. Salida esperada (hemos dejado solo las líneas que importan):

<pre>
[INFO] --- surefire:3.5.6:test (default-test) @ contactos ---
[INFO] Using auto detected provider org.apache.maven.surefire.junitplatform.JUnitPlatformProvider
[INFO] Running com.curso.AplicacionTests
[INFO] Tests run: 1, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 1.581 s -- in com.curso.AplicacionTests
[INFO] Running com.curso.model.ContactoTests
[INFO] Tests run: 5, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 0.019 s -- in com.curso.model.ContactoTests
[INFO] Tests run: 6, Failures: 0, Errors: 0, Skipped: 0
[INFO] BUILD SUCCESS
</pre>

Seis pruebas, ninguna falla, y en `target/surefire-reports` quedan los informes que lee `junit`:

<pre>
TEST-com.curso.AplicacionTests.xml
TEST-com.curso.model.ContactoTests.xml
com.curso.AplicacionTests.txt
com.curso.model.ContactoTests.txt
</pre>

Ahora el mismo comando con la casilla sin marcar:

```bash
mvn -B clean test -DskipTests=true
```

Salida esperada:

<pre>
[INFO] --- surefire:3.5.6:test (default-test) @ contactos ---
[INFO] Tests are skipped.
[INFO] BUILD SUCCESS
</pre>

Maven no falla: ejecuta el objetivo de pruebas, dice que se salta y termina en `BUILD SUCCESS`. Y en `target` no hay carpeta `surefire-reports`, porque no se ha ejecutado ninguna prueba y por tanto no hay informes que publicar. Por eso el `junit` de `Probar` lleva `allowEmptyResults: true` (S14-1): sin ello, una construcción sin pruebas daría un segundo error por no encontrar informes. El contenido de `target` tras esta ejecución:

<pre>
classes
generated-sources
generated-test-sources
maven-status
test-classes
</pre>

Por último, la etapa `Empaquetar` cuando sí se ejecuta:

```bash
mvn -B package -DskipTests
```

<pre>
[INFO] --- surefire:3.5.6:test (default-test) @ contactos ---
[INFO] Tests are skipped.
[INFO] Building jar: /ruta/contactos/target/contactos-0.0.1-SNAPSHOT.jar
[INFO] --- spring-boot:4.1.1:repackage (repackage) @ contactos ---
[INFO] Replacing main artifact /ruta/contactos/target/contactos-0.0.1-SNAPSHOT.jar with repackaged archive, adding nested dependencies in BOOT-INF/.
[INFO] The original artifact has been renamed to /ruta/contactos/target/contactos-0.0.1-SNAPSHOT.jar.original
[INFO] BUILD SUCCESS
</pre>

Maven construye el JAR y lo reempaqueta con Spring Boot, que deja el original como `.jar.original` (S05-1). Los tamaños de los dos ficheros:

<pre>
9105192 target/contactos-0.0.1-SNAPSHOT.jar
3722 target/contactos-0.0.1-SNAPSHOT.jar.original
</pre>

El patrón `target/*.jar` de `archiveArtifacts` recoge el primero y no el segundo, porque este termina en `.original`.

### Paso 1: subir el Jenkinsfile

1. En IntelliJ abrimos `contactos` y, en el panel `Project` (`Alt+1`), hacemos doble clic en `Jenkinsfile`, que está en la raíz, junto a `pom.xml`.
2. Seleccionamos todo el contenido (`Ctrl+A`) y pegamos el `Jenkinsfile` completo de arriba.
3. En la terminal de IntelliJ (`Alt+F12`) ejecutamos:

```bash
git add Jenkinsfile
git commit -m "Anade parametros al Jenkinsfile"
git push
```

   El mensaje del commit va sin tildes, por la consola de Windows (S14-2).

### Paso 2: la primera construcción después de añadir los parámetros

Hay una particularidad. El job de Jenkins no conoce los parámetros hasta que ha ejecutado, al menos una vez, un `Jenkinsfile` que los declare: la definición vive en el fichero, no en la configuración del job. Por eso la primera construcción tras añadir `parameters` es especial.

1. En Jenkins abrimos el job `contactos` y pulsamos `Build Now` (*Construir ahora*).
2. Esperamos a que termine y, en esta construcción, **no sacamos conclusiones sobre los valores de los parámetros**: no hemos comprobado qué contienen `params.EJECUTAR_PRUEBAS` y `params.EMPAQUETAR` en esta primera ejecución, y su resultado no nos sirve para comparar. Su función es que Jenkins lea el fichero y aprenda las preguntas.
3. Volvemos a la página del job y la recargamos (`F5`). Si todo ha ido bien, en el menú de la izquierda `Build Now` se ha convertido en `Build with Parameters` (*Construir con parámetros*).

Esta secuencia (la primera construcción, el cambio del botón) es lo que describe la documentación habitual de Jenkins, pero **no la hemos comprobado en el aula**: los nombres exactos del botón y del menú pueden variar, y el idioma en que aparecen también.

### Paso 3: primera ejecución comparable, con los valores por defecto

1. En el menú del job pulsamos `Build with Parameters`. Jenkins muestra un formulario con las dos casillas, `EJECUTAR_PRUEBAS` y `EMPAQUETAR`, cada una con el texto de su `description`, y las dos marcadas, porque `defaultValue` es `true`.
2. No tocamos nada y pulsamos `Build` (*Construir*).
3. Cuando termina (la 13 en nuestro ejemplo), abrimos la construcción y entramos en `Console Output` (*Salida de consola*).

Lo que esperamos ver, en este orden: la compilación; las seis pruebas con `Tests run: 6, Failures: 0, Errors: 0, Skipped: 0`; la etapa de empaquetado con `Building jar` y `Replacing main artifact`; y el aviso final `OK: la construccion 13 de contactos ha terminado bien.` (S14-2). Jenkins escribe además sus propias líneas alrededor, y el formato exacto con el que muestra cada comando no lo hemos comprobado. En la página de la construcción debe aparecer el JAR como artefacto guardado.

### Paso 4: segunda ejecución, con valores distintos

1. Pulsamos `Build with Parameters` otra vez.
2. Desmarcamos `EJECUTAR_PRUEBAS` y dejamos `EMPAQUETAR` marcada. Pulsamos `Build`.
3. Abrimos la consola de la nueva construcción (la 14).

Ahora Maven recibe `-DskipTests=true`. Lo que esperamos: el objetivo de pruebas dice `Tests are skipped.`, no hay ninguna línea `Tests run:`, la construcción sigue y empaqueta, y termina con el mismo aviso `OK`. En la página de la construcción no habrá resultado de pruebas (`junit` no encontró informes y `allowEmptyResults` lo permitió).

### Paso 5: una tercera, sin empaquetar

1. `Build with Parameters`. Marcamos `EJECUTAR_PRUEBAS` y desmarcamos `EMPAQUETAR`. `Build`.
2. Abrimos la consola de la construcción 15.

Lo que esperamos: las pruebas se ejecutan, la etapa `Empaquetar` **no escribe nada** (no hay ninguna salida de `package`) y la construcción termina en verde. Esa etapa está omitida. En la vista de etapas aparecerá, según la documentación, como omitida y no como fallida; **no lo hemos comprobado con un Jenkins real**, ni el texto ni el color con los que se muestra.

### Comparar las consolas

Con las tres construcciones delante, lo que cambia es solo lo que cada una preguntó:

| Construcción | EJECUTAR_PRUEBAS | EMPAQUETAR | Qué escribe la consola | Resultado |
|---|---|---|---|---|
| 13 | marcada | marcada | `Tests run: 6`, `Building jar` | Verde, con JAR |
| 14 | sin marcar | marcada | `Tests are skipped.`, `Building jar` | Verde, con JAR y sin resultado de pruebas |
| 15 | marcada | sin marcar | `Tests run: 6`, sin salida de empaquetado | Verde, sin JAR |

Es el mismo `Jenkinsfile` en las tres. Esa es la idea de fondo: la descripción del pipeline se queda en el repositorio y las decisiones de cada ejecución se toman al lanzarla. Las salidas de Maven de cada fila salen de ejecuciones reales (arriba); lo que no hemos podido comprobar es cómo las presenta Jenkins.

### Qué pasa cuando la construcción la lanza el sondeo

Si el job tiene activado `Poll SCM` (S14-1), un commit nuevo lanza una construcción **sin que nadie conteste el formulario**. Se supone que en ese caso se usan los valores por defecto (`true` y `true`), de modo que las construcciones automáticas hacen lo de siempre. **Esto no lo hemos comprobado**; conviene mirar la consola de la primera construcción automática para confirmarlo. Es una razón más para elegir bien los `defaultValue`.

### Resumen de la demo

- `parameters` declara las preguntas; `booleanParam` es una casilla con `name`, `defaultValue` y `description`.
- `params.NOMBRE` lee la respuesta. Se puede usar dentro de un comando (con comillas dobles) o en la cabecera de una etapa.
- `when { expression { return ... } }` decide si una etapa se ejecuta. Si no, se omite sin error.
- La primera construcción tras añadir parámetros solo sirve para que Jenkins los conozca.

---

## Demo 2: Plugin y cobertura con JaCoCo

### Qué es la cobertura

Imaginemos que revisamos una casa antes de comprarla y solo abrimos dos de las diez habitaciones. Si en esas dos no hay humedades, sabemos que esas dos están bien; de las otras ocho no sabemos nada. Con las pruebas pasa lo mismo. Que las seis pruebas de `contactos` pasen en verde nos dice que lo que comprueban funciona, pero no cuánto del código comprueban. La **cobertura** responde a esa pregunta: de todas las líneas del programa, qué porcentaje se ejecutan mientras corren las pruebas.

Una línea **cubierta** es una línea que se ha ejecutado al menos una vez durante las pruebas. Una línea **sin cubrir** es una que ninguna prueba ha llegado a ejecutar. Una línea sin cubrir no está mal: está sin comprobar. Si mañana alguien la rompe, ninguna prueba lo notará. Por eso mirar las líneas rojas es la forma más directa de entender por qué se escribe una prueba nueva.

### Quién hace qué: JaCoCo, Maven y Jenkins

Intervienen tres piezas y conviene no confundirlas:

- **JaCoCo** (*Java Code Coverage*) es la herramienta que mide. Se engancha a la ejecución de las pruebas, anota qué instrucciones se ejecutan y escribe informes.
- **Maven** es quien la ejecuta, a través del plugin `jacoco-maven-plugin` declarado en el `pom.xml`. Un **plugin de Maven** es una pieza que añade tareas a Maven (S03-2: `maven-jar-plugin`, `exec-maven-plugin`).
- **Jenkins** no mide nada. Con un plugin suyo lee el informe que Maven ya ha dejado en el espacio de trabajo y lo muestra en la página de la construcción.

Es importante entender que Jenkins y Maven tienen cada uno sus plugins, y que no son lo mismo: uno es una extensión de Jenkins (se instala desde la web de Jenkins) y otro es una extensión de Maven (se declara en el `pom.xml`). Esta demo usa uno de cada.

### Instalar el plugin de Jenkins

Un **plugin** de Jenkins es una extensión que añade capacidades (S13-1: Git, publicar pruebas). Jenkins se instala con lo básico y crece con ellos. El que necesitamos se llama **Coverage**. Según su página (https://plugins.jenkins.io/coverage/), su identificador es `coverage`, necesita Jenkins 2.555.3 o posterior (el nuestro es el 2.580.1) y añade al pipeline el paso `recordCoverage`. La documentación indica además que `publishCoverage` es el paso del plugin anterior de cobertura, no de este: nosotros usamos `recordCoverage`.

Pasos (los nombres de menús siguen la documentación; **no hemos comprobado** estas pantallas en el aula):

1. En Jenkins entramos en `Administrar Jenkins` (*Manage Jenkins*) y abrimos `Plugins`.
2. Miramos primero la pestaña de plugins instalados (`Installed plugins`) y buscamos `Coverage`. Si ya está, no hay que instalar nada.
3. Si no está, abrimos `Available plugins` (*Plugins disponibles*), escribimos `Coverage` en el buscador, marcamos el resultado que se llama **Coverage** y pulsamos `Install` (*Instalar*). En la lista pueden aparecer otros plugins con "JaCoCo" o "Cobertura" en el nombre; el que usamos es Coverage, el que ofrece `recordCoverage`.
4. Jenkins descarga el plugin y sus dependencias (necesita Internet, como al descargar Maven en S13-2). Si ofrece reiniciar, lo hacemos cuando no haya ninguna construcción en marcha.
5. Comprobamos que ha quedado instalado: vuelve a aparecer en `Installed plugins`.

### JaCoCo en el pom.xml

Ahora la parte de Maven. Abrimos el `pom.xml` de `contactos`. Al final tiene un bloque `<build>` con un `<plugin>`, el `spring-boot-maven-plugin`. Añadimos justo después de él, dentro de `<plugins>`, el de JaCoCo:

```xml
			<plugin>
				<groupId>org.jacoco</groupId>
				<artifactId>jacoco-maven-plugin</artifactId>
				<version>0.8.16</version>
				<executions>
					<execution>
						<goals>
							<goal>prepare-agent</goal>
						</goals>
					</execution>
					<execution>
						<id>informe</id>
						<phase>test</phase>
						<goals>
							<goal>report</goal>
						</goals>
					</execution>
				</executions>
			</plugin>
```

Lo explicamos línea a línea:

- `groupId` y `artifactId` identifican el plugin en Maven Central, igual que una dependencia (S02-1).
- `version` es `0.8.16`. La hemos comprobado en Maven Central: es una versión reciente y funciona con Java 21 (la ejecución real de abajo es con JDK 21). JaCoCo tiene que entender el formato de las clases compiladas de cada versión de Java, así que una versión antigua de JaCoCo no sirve con un Java nuevo y la versión importa.
- `executions` lista cuándo se ejecuta el plugin. Un plugin de Maven ofrece varios **goals** (tareas); aquí usamos dos.
- `prepare-agent` es el primero. Prepara el **agente** de JaCoCo: un programa que se engancha a la JVM que ejecuta las pruebas y va anotando qué instrucciones se ejecutan. No lleva `phase` porque ya trae una por defecto, anterior a las pruebas; es imprescindible que vaya antes, porque tiene que estar enganchado cuando las pruebas corran. El resultado lo guarda en `target/jacoco.exec`.
- `report` es el segundo. Lee `target/jacoco.exec` y genera los informes en `target/site/jacoco`. Lleva `<phase>test</phase>`: una **fase** (S03-2) es un paso del ciclo de vida de Maven, y `test` es aquella en la que se ejecutan las pruebas. El informe se genera cuando Maven llega a esa fase, después de que Surefire haya ejecutado las pruebas. Sin la línea de fase, `report` se ejecutaría en `verify`, una fase posterior a `package`: `mvn test` no generaría el informe (lo hemos comprobado quitando esa línea) y haría falta `mvn verify`.
- `id` (`informe`) es el nombre de esa ejecución. Aparece en la salida de Maven entre paréntesis y permite distinguir las dos ejecuciones del mismo plugin.

Después de guardar el `pom.xml`, IntelliJ avisa de que ha cambiado: pulsamos `Load Maven Changes` (el icono `m` del editor, o `Ctrl+Shift+O`) para que lo lea (S06-1).

### Probar en local, antes de Jenkins

Siempre probamos primero en nuestro ordenador: si Maven no genera el informe, Jenkins tampoco lo encontrará. En la terminal de IntelliJ:

```bash
mvn -B clean test
```

Salida esperada (solo las líneas que importan; el resto es lo de siempre):

<pre>
[INFO] --- jacoco:0.8.16:prepare-agent (default) @ contactos ---
[INFO] Tests run: 1, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 2.805 s -- in com.curso.AplicacionTests
[INFO] Tests run: 5, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 0.060 s -- in com.curso.model.ContactoTests
[INFO] Tests run: 6, Failures: 0, Errors: 0, Skipped: 0
[INFO] --- jacoco:0.8.16:report (informe) @ contactos ---
[INFO] Loading execution data file /ruta/contactos/target/jacoco.exec
[INFO] Analyzed bundle 'contactos' with 2 classes
[INFO] BUILD SUCCESS
</pre>

Dos cosas que mirar. La línea `prepare-agent` aparece antes de las pruebas y la de `report` después. Y `Analyzed bundle 'contactos' with 2 classes`: JaCoCo ha encontrado las dos clases del proyecto, `Aplicacion` y `Contacto`. Los ficheros que deja en `target/site/jacoco`:

<pre>
com.curso
com.curso.model
index.html
jacoco-resources
jacoco-sessions.html
jacoco.csv
jacoco.xml
</pre>

`jacoco.xml` es el que lee Jenkins. `index.html` es el que nos interesa abrir ahora, para ver cómo es un informe de cobertura antes de verlo dentro de Jenkins.

### Leer el informe

En el panel `Project` abrimos `target/site/jacoco/index.html` (clic derecho > `Open In > Browser`). Es una tabla con una fila por paquete, y dentro de cada paquete una por clase. Las columnas que importan:

- **Missed Instructions** y **Cov.**: cuántas instrucciones no se han ejecutado y qué porcentaje se ha ejecutado. Una instrucción es cada orden elemental del código compilado (el `.class`), no cada línea del `.java`.
- **Missed Branches** y **Cov.**: una **rama** es cada camino posible en una decisión. Un `if` tiene dos ramas (se cumple, no se cumple). `&&` también añade ramas, una por cada condición.
- **Missed** y **Lines**: cuántas líneas sin ejecutar y cuántas hay en total. **Methods** y **Classes**, igual.

Lo que muestra nuestro `contactos`, con las seis pruebas:

<pre>
Element           Missed Instructions   Cov.   Missed Branches   Cov.   Missed Lines   Lines   Missed Methods   Methods
Total             5 of 47               89%    1 of 6            83%    2              10      1                5
com.curso         5 of 8                37%    0 of 0            n/a    2              3       1                2
com.curso.model   0 of 39               100%   1 of 6            83%    0              7       0                3
</pre>

(La tabla de JaCoCo está en inglés y con barras de color; aquí la hemos pasado a texto.) Las dos filas de paquete se leen así:

- `com.curso.model`, que tiene `Contacto`, está al 100 % de instrucciones y de líneas, pero al 83 % de ramas: falta una de las seis.
- `com.curso`, que tiene `Aplicacion`, está al 37 %.

El porcentaje por clase es el de la fila de la clase dentro del paquete: al hacer clic en `com.curso` aparece `Aplicacion` con el 37 %. Y haciendo clic en la clase y luego en su fichero `.java` se ve el código con las líneas pintadas:

- **Verde**: línea cubierta.
- **Rojo**: línea sin cubrir. Ninguna prueba la ha ejecutado.
- **Amarillo**: línea cubierta solo en parte. Una decisión en la que se ha probado un camino y no el otro.

En `Aplicacion.java`, las líneas de `main()` están en rojo:

<pre>
13  fc   public class Aplicacion {
16  nc       SpringApplication.run(Aplicacion.class, args);
17  nc   }
</pre>

(`fc` es verde y `nc` es rojo en el HTML de JaCoCo.) La línea 13 (la declaración de la clase) cuenta como cubierta porque Spring crea un objeto de `Aplicacion` al arrancar en `contextLoads`, pero las pruebas nunca llaman a `main()`: el contexto lo arranca `@SpringBootTest`, no el método principal. Es una línea sin cubrir "legítima": nadie suele probar `main()`, y se acepta que quede así. Pero es información, no un error.

En `Contacto.java` casi todo es verde. La excepción es la línea 65, la que valida el correo, en amarillo:

<pre>
65  pc   return email.contains("@") && email.contains(".") && !email.contains(" ");
        1 of 6 branches missed.
</pre>

Esta es la información valiosa. La línea se ejecuta (la llaman `emailCorrectoEsValido` y `emailSinPuntoOConEspaciosNoEsValido`), pero hay un camino que nadie recorre: ninguna prueba comprueba un correo **sin arroba**. Si alguien quitara por error la condición `email.contains("@")`, las seis pruebas seguirían en verde. La cobertura lo ha detectado sin que lo hayamos buscado.

### Un detalle de Lombok

Una nota para quien prepare la clase: el guion de planificación suponía que la cobertura de `Contacto` baja por el código de Lombok. Lo hemos medido con el proyecto real y, con la versión de Lombok que fija Spring Boot 4.1.1, **no baja**; por eso esta sección enseña por qué y cómo provocar la bajada para entenderla. Mirando la cifra de `Contacto` (100 % de instrucciones y de métodos) cabe preguntarse algo. `Contacto` usa Lombok (S11-1): sus tres getters, sus tres setters y su constructor vacío **no están escritos en el `.java`**, los genera Lombok al compilar. Y ninguna de nuestras pruebas llama a `setNombre()` ni al constructor vacío. ¿Cómo es posible que estén al 100 %?

Aquí está la sorpresa y es la razón de esta sección. Desde la versión 1.18.34 de Lombok (la de nuestro proyecto es la 1.18.46, la que fija Spring Boot 4.1.1), cada método que genera lleva por defecto una anotación llamada `@lombok.Generated`. Y desde la versión 0.8.3, JaCoCo ignora el código que lleva una anotación con ese nombre en su informe. Así que **en nuestro proyecto, tal y como está, el código generado ya no cuenta**. Lo podemos comprobar con `javap` (S11-1), que lista lo que hay dentro de la clase compilada:

```bash
javap -p -v -cp target/classes com.curso.model.Contacto | findstr /c:"lombok.Generated"
```

Salida esperada: siete líneas `lombok.Generated`, una por cada método generado (tres getters, tres setters y el constructor vacío). Hemos comprobado la salida en Linux con `grep`; el comando con `findstr` de Windows **no lo hemos probado**.

Pero esta marca depende de la versión de Lombok: en versiones antiguas no existía, y por eso era un problema muy frecuente que la cobertura saliera baja por código que nadie ha escrito. Para ver qué pasa cuando la marca no está, y para fijar una decisión por escrito en el proyecto, existe el fichero `lombok.config`.

### lombok.config: el antes y el después

`lombok.config` es un fichero de texto en la raíz del proyecto, junto al `pom.xml`, donde se configura Lombok. Cada línea tiene la forma `clave = valor` y `#` abre un comentario. Hay dos claves que nos interesan:

- `lombok.addLombokGeneratedAnnotation`: si vale `true`, Lombok marca con `@lombok.Generated` todo lo que genera (y JaCoCo lo ignora). Si vale `false`, no marca nada.
- `config.stopBubbling`: Lombok busca ficheros `lombok.config` en la carpeta del código y en todas las carpetas superiores, y los combina. Con `config.stopBubbling = true` la búsqueda termina en este fichero y no se mezcla con ninguna configuración de carpetas de fuera.

Hacemos un experimento en dos tiempos, que es la ficha `cambios/lombok-config-antes.txt` del zip. Primero provocamos el "antes", que es lo que verían las versiones antiguas de Lombok:

1. En el panel `Project`, clic derecho sobre `contactos` > `New > File`, nombre `lombok.config`.
2. Escribimos:

```
config.stopBubbling = true
lombok.addLombokGeneratedAnnotation = false
```

3. En la terminal: `mvn -B clean test`. El `clean` es imprescindible: sin él Maven no recompilaría y veríamos el resultado anterior (S04-1).

Ahora Lombok no marca el código y JaCoCo lo cuenta. En el informe, `Contacto` baja:

<pre>
Element                              Cov.   Missed Instructions
Contacto                             82%    11 of 63
  setNombre(String)                  0%
  setTelefono(String)                0%
  Contacto()                         0%
  (los demás métodos)                100%
</pre>

`Contacto` ha pasado del 100 % al 82 % de instrucciones, tiene 3 de sus 10 métodos sin cubrir (`setNombre`, `setTelefono` y el constructor vacío) y el total del proyecto baja del 89 % al 77 %. La razón se confirma con `javap`: ahora no sale ningún `lombok.Generated`. Es decir, la cobertura ha bajado por **código que nadie ha escrito**, y cualquiera que mirase la cifra pensaría que hay tres métodos de `Contacto` sin probar cuando en realidad son piezas de Lombok.

Segundo tiempo, el "después". Cambiamos `false` por `true` (es la configuración que lleva el zip, en `demo2-cobertura/lombok.config`, con comentarios):

```
# S15-1 Demo 2: configuración de Lombok del proyecto contactos.
#
# config.stopBubbling = true: Lombok busca ficheros lombok.config en la carpeta del código fuente
# y en todas las carpetas superiores. Con esta línea la búsqueda termina aquí, en la raíz del proyecto,
# y no se mezcla con ninguna configuración de carpetas de fuera.
config.stopBubbling = true

# lombok.addLombokGeneratedAnnotation = true: Lombok marca con @lombok.Generated todo el código que
# genera (getters, setters, constructores). JaCoCo ignora el código marcado así y no lo cuenta como
# código sin probar. Desde Lombok 1.18.34 ya es el comportamiento por defecto; escribirlo deja la
# decisión a la vista y no depende de la versión de Lombok.
lombok.addLombokGeneratedAnnotation = true
```

Guardamos y repetimos `mvn -B clean test`. `Contacto` vuelve a: instrucciones 100 %, 0 líneas sin cubrir de 7, 0 métodos sin cubrir de 3, y `javap` vuelve a mostrar las siete líneas `lombok.Generated`. Los números de las tres situaciones, medidos con Maven y JaCoCo reales sobre el `contactos` real:

| Situación | Contacto (instrucciones) | Contacto (métodos sin cubrir) | Total del proyecto |
|---|---|---|---|
| Sin `lombok.config` (Lombok 1.18.46 marca por defecto) | 100 % | 0 de 3 | 89 % |
| `lombok.addLombokGeneratedAnnotation = false` ("antes") | 82 % | 3 de 10 | 77 % |
| `lombok.addLombokGeneratedAnnotation = true` ("después") | 100 % | 0 de 3 | 89 % |

Una consecuencia: con Lombok 1.18.46 la tercera fila es igual que la primera, porque `true` es ya el valor por defecto. Entonces, ¿para qué dejamos el fichero? Por dos razones. Una, que escribir el valor deja la decisión **a la vista** de quien lea el proyecto y no depende de qué versión de Lombok se use mañana. Otra, que el proyecto tiene que seguir funcionando igual si alguien baja la versión de Lombok o si el fichero se copia a un proyecto más antiguo. Dejamos, pues, el fichero definitivo con `true` y los comentarios.

Para que el fichero entre en el repositorio:

```bash
git add lombok.config pom.xml
git commit -m "Anade JaCoCo y lombok.config"
```

(Más abajo hacemos el `push` junto con el `Jenkinsfile`.)

### El Jenkinsfile con recordCoverage

El `Jenkinsfile` de la Demo 2 es el de la Demo 1 con una línea nueva en el `post` de la etapa `Probar`. La añadimos ahí, junto a `junit`, porque las dos cosas publican resultados de las pruebas y las dos deben ejecutarse siempre (`always`):

```groovy
            post {
                always {
                    // Publica los resultados de las pruebas (S13-2 y S14-1).
                    junit testResults: 'target/surefire-reports/*.xml', allowEmptyResults: true

                    // recordCoverage publica la cobertura. tools indica de qué herramienta es el informe:
                    // parser 'JACOCO' le dice que el formato es el de JaCoCo. Sin indicar pattern, el plugin
                    // busca en el espacio de trabajo **/jacoco.xml, que es donde lo deja Maven.
                    recordCoverage(tools: [[parser: 'JACOCO']])
                }
            }
```

`recordCoverage` es el paso del plugin Coverage. Lo explicamos:

- `tools: [[parser: 'JACOCO']]` le dice de qué herramienta es el informe. `tools` es una lista, y cada elemento va entre corchetes con el `parser`, que indica el formato del fichero. De ahí los dobles corchetes: uno por la lista y otro por cada herramienta. `JACOCO` es el formato del informe XML de JaCoCo. Otros formatos que admite, por ejemplo, son JUnit o Cobertura; no los usamos.
- No indicamos dónde está el fichero. Según la documentación del plugin, si no se indica un `pattern`, para JaCoCo busca `**/jacoco.xml` (y `**/jacocoTestReport.xml`) en el espacio de trabajo. `**/` significa "en cualquier carpeta" (S13-2), así que encuentra `target/site/jacoco/jacoco.xml` donde lo deja Maven. En la Práctica 3 veremos qué pasa cuando el proyecto está en una subcarpeta y hay que indicarlo.
- `recordCoverage` **no mide nada**: lee el fichero que Maven ya ha generado. Si Maven no lo genera, no hay nada que leer.

Este es el `Jenkinsfile` completo, idéntico al de la carpeta `demo2-cobertura` del zip:

```groovy
/*
 * S15-1 Demo 2: Cobertura de las pruebas con JaCoCo
 *
 * Objetivo: que cada construcción publique en Jenkins qué porcentaje del código recorren las pruebas.
 *
 * Lo que hace este ejemplo:
 *   - Parte del Jenkinsfile de la Demo 1 (parámetros, etapa condicionada y avisos con post)
 *   - Añade en la etapa Probar el paso recordCoverage, que lee el informe XML de JaCoCo
 *   - El informe lo genera Maven al ejecutar las pruebas, gracias al plugin jacoco-maven-plugin del pom.xml
 *
 * Concepto clave: JaCoCo mide en Maven y Jenkins publica el resultado. recordCoverage no mide nada
 * por sí mismo: solo lee el fichero que Maven ya ha generado.
 */
pipeline {

    // Cualquier agente disponible: en el aula, el propio Jenkins.
    agent any

    // Los nombres entre comillas son los de Manage Jenkins > Tools (S13-2) y deben
    // coincidir letra por letra con ellos.
    tools {
        jdk 'jdk-21'
        maven 'maven-3.9'
    }

    // Los mismos dos parámetros de la Demo 1 (S15-1).
    parameters {
        booleanParam(name: 'EJECUTAR_PRUEBAS', defaultValue: true, description: 'Marcar para ejecutar las pruebas. Desmarcar para saltarlas.')
        booleanParam(name: 'EMPAQUETAR', defaultValue: true, description: 'Marcar para generar y guardar el JAR. Desmarcar para omitir la etapa Empaquetar.')
    }

    stages {

        stage('Compilar') {
            steps {
                // clean borra target/ antes de empezar: así no quedan informes de una construcción anterior.
                bat 'mvn -B clean compile'
            }
        }

        stage('Probar') {
            steps {
                // Si EJECUTAR_PRUEBAS está marcado, Maven ejecuta las pruebas con el agente de JaCoCo
                // activado (lo declara el pom.xml) y deja el informe en target/site/jacoco/jacoco.xml.
                bat "mvn -B test -DskipTests=${!params.EJECUTAR_PRUEBAS}"
            }
            post {
                always {
                    // Publica los resultados de las pruebas (S13-2 y S14-1).
                    junit testResults: 'target/surefire-reports/*.xml', allowEmptyResults: true

                    // recordCoverage publica la cobertura. tools indica de qué herramienta es el informe:
                    // parser 'JACOCO' le dice que el formato es el de JaCoCo. Sin indicar pattern, el plugin
                    // busca en el espacio de trabajo **/jacoco.xml, que es donde lo deja Maven.
                    recordCoverage(tools: [[parser: 'JACOCO']])
                }
            }
        }

        stage('Empaquetar') {
            when {
                expression { return params.EMPAQUETAR }
            }
            steps {
                bat 'mvn -B package -DskipTests'
                archiveArtifacts artifacts: 'target/*.jar'
            }
        }
    }

    // post fuera de stages: se evalúa una sola vez, cuando termina todo el pipeline (S14-2).
    post {

        // failure: se ejecuta solo si la construcción ha terminado en rojo.
        failure {
            echo "FALLO: la construccion ${env.BUILD_NUMBER} de ${env.JOB_NAME} ha fallado. Revisar la etapa en rojo."
        }

        // success: se ejecuta solo si la construcción ha terminado en verde.
        success {
            echo "OK: la construccion ${env.BUILD_NUMBER} de ${env.JOB_NAME} ha terminado bien."
        }

        // fixed: esta construcción termina bien y la anterior no.
        fixed {
            echo "RECUPERADA: ${env.JOB_NAME} vuelve a funcionar desde la construccion ${env.BUILD_NUMBER}."
        }
    }
}
```

### Paso a paso en Jenkins

1. Con el plugin instalado, volvemos a IntelliJ y abrimos el `Jenkinsfile` de `contactos`. `Ctrl+A` y pegamos el completo de arriba.
2. En la terminal:

```bash
git add Jenkinsfile
git commit -m "Anade recordCoverage al Jenkinsfile"
git push
```

   El `push` envía también el commit del `pom.xml` y de `lombok.config` hecho antes.

3. En Jenkins abrimos el job `contactos`, pulsamos `Build with Parameters` y dejamos las dos casillas marcadas. `Build`.
4. Cuando termina (la 16 en el ejemplo), miramos la consola. Esperamos, dentro de la etapa `Probar`, las mismas líneas que en local (`jacoco:0.8.16:prepare-agent`, `Tests run: 6` y `jacoco:0.8.16:report`) y, al final de la etapa, algún mensaje del plugin al leer el informe. **El texto de esos mensajes no lo hemos comprobado.**
5. En la página de la construcción buscamos el resultado de la cobertura. Según la documentación del plugin, aparece en el menú de la construcción (algo como `Coverage Report`) y muestra un resumen con porcentajes y, por cada clase, la cobertura de líneas y de ramas; desde cada clase se puede abrir el código con las líneas coloreadas. **Nada de esto lo hemos visto en un Jenkins real**: ni los nombres de los menús, ni el aspecto, ni qué métricas muestra por defecto.

Lo que sí sabemos con certeza es el contenido: las cifras serán las del informe de JaCoCo de arriba, porque es el fichero que lee el plugin. `Contacto`, al 100 % de líneas y 83 % de ramas, y `Aplicacion`, con `main()` sin cubrir.

### Dos casos que conviene conocer

**Pruebas saltadas.** Si lanzamos la construcción con `EJECUTAR_PRUEBAS` sin marcar, Maven no ejecuta pruebas y por tanto JaCoCo no tiene nada que medir. Lo comprobamos en local:

```bash
mvn -B clean test -DskipTests=true
```

<pre>
[INFO] --- jacoco:0.8.16:prepare-agent (default) @ contactos ---
[INFO] --- surefire:3.5.6:test (default-test) @ contactos ---
[INFO] Tests are skipped.
[INFO] --- jacoco:0.8.16:report (informe) @ contactos ---
[INFO] Skipping JaCoCo execution due to missing execution data file.
[INFO] BUILD SUCCESS
</pre>

La construcción termina bien, pero no se genera `jacoco.xml`: no existe la carpeta `target/site`. Qué hace entonces `recordCoverage` al no encontrar el fichero (si avisa, si falla, si lo ignora) **no está documentado y no lo hemos comprobado**. Hay que lanzar una construcción así y mirar, antes de fiarse de la cifra.

**Una prueba falla.** Si una prueba falla, Maven termina con `BUILD FAILURE` en la fase de pruebas y no llega a la de `report`, así que tampoco hay informe en ese caso (lo hemos comprobado rompiendo `emailValido()`). Como `recordCoverage` también está en `always`, Jenkins lo intentará y no encontrará nada. La cobertura de una construcción roja no existe: primero se arregla la prueba.

### Resumen de la demo

- JaCoCo (Maven) mide; el plugin Coverage (Jenkins) publica. El puente es `target/site/jacoco/jacoco.xml`.
- `prepare-agent` va antes de las pruebas y `report` en la fase `test`. Sin pruebas ejecutadas no hay informe.
- Una línea roja nadie la ejecuta; una amarilla se ejecuta pero deja un camino sin probar. En `contactos`, la línea 65 de `Contacto` es la amarilla.
- Lombok marca su código con `@lombok.Generated` y JaCoCo lo ignora. `lombok.config` lo deja por escrito y permite ver qué pasa sin la marca.

---

## Las credenciales de Jenkins en un pipeline (explicación breve)

En S13-2 creamos en Jenkins una credencial de tipo `Username with password` con nuestro usuario de GitHub y el token (S11-1), y la usamos en el job con su `ID`. No hay práctica ni demo de esta parte; solo cerramos la idea: un pipeline puede usar esa misma credencial **sin que el secreto aparezca nunca en el `Jenkinsfile`**.

Es importante porque el `Jenkinsfile` se sube al repositorio. Un token escrito ahí lo vería todo el que pueda leer el repositorio, y aunque se borre después sigue en el historial de Git (S11-1). Con una credencial, el fichero solo contiene el `ID`, que es un nombre, y Jenkins entrega el valor al pipeline en el momento de usarlo, desde su almacén cifrado.

El paso se llama `withCredentials` y trabaja así: abre un bloque, crea dentro unas variables con el usuario y la contraseña de la credencial, y las retira al cerrarlo. Un ejemplo, con un identificador de relleno (`ID-DE-TU-CREDENCIAL`; cada uno usa el que puso en S13-2):

```groovy
        stage('Ejemplo de credencial') {
            steps {
                // credentialsId es el ID de la credencial creada en S13-2.
                // usernameVariable y passwordVariable son los nombres de las variables que Jenkins
                // crea mientras dura el bloque: una con el usuario y otra con el token.
                withCredentials([usernamePassword(credentialsId: 'ID-DE-TU-CREDENCIAL',
                                                  usernameVariable: 'GITHUB_USUARIO',
                                                  passwordVariable: 'GITHUB_TOKEN')]) {
                    // Comillas simples: Groovy no sustituye nada y el secreto no se interpola en el
                    // texto del script. En cmd las variables de entorno se leen con %NOMBRE%.
                    // Aquí solo mostramos el usuario; el token no se escribe nunca.
                    bat 'echo Usuario: %GITHUB_USUARIO%'
                }
            }
        }
```

Este fragmento es solo de referencia y **no está verificado**: no lo hemos ejecutado en un Jenkins real, y su sintaxis no se ha comprobado con el analizador de Groovy como el resto de los `Jenkinsfile` de esta parte. Dos ideas que sí conviene retener. Primera, las comillas simples en `bat`: con comillas dobles, Groovy sustituiría el secreto en el propio texto del script antes de ejecutarlo. Segunda, Jenkins enmascara en la consola los valores de las credenciales (los sustituye por asteriscos), pero eso es una ayuda y no una garantía: un comando que escriba el token a un fichero o lo transforme puede dejarlo a la vista. Nunca se imprime.

---

## Problemas frecuentes

- **El botón sigue siendo `Build Now` y no hay formulario.** Jenkins no ha ejecutado todavía un `Jenkinsfile` con `parameters`. Hay que subir el fichero, lanzar una construcción con `Build Now` y recargar la página.
- **La primera construcción tras añadir parámetros no se comporta como esperábamos.** Es la que enseña las preguntas a Jenkins; no la usamos para comparar. Lanzamos otra con `Build with Parameters`.
- **El `Jenkinsfile` falla con un error de sintaxis al añadir `parameters`.** Suele ser un parámetro mal escrito (`boleanParam`) o una llave sin cerrar. La sangría no importa en Groovy, las llaves sí. Si el texto de `description` lleva comillas simples dentro, hay que evitarlas o usar comillas dobles. El texto exacto del error de Jenkins no lo hemos comprobado.
- **La etapa `Empaquetar` no aparece, o sale diferente.** Si la casilla `EMPAQUETAR` estaba desmarcada es lo esperado. No es un fallo.
- **Las pruebas se saltan aunque la casilla estaba marcada.** Comprobamos que el comando lleva `${!params.EJECUTAR_PRUEBAS}` con el `!` y entre comillas dobles. Con comillas simples saldría escrito `-DskipTests=${!params.EJECUTAR_PRUEBAS}` tal cual (S14-2).
- **`recordCoverage` no existe como paso.** El plugin Coverage no está instalado o Jenkins no se ha reiniciado después de instalarlo. Se comprueba en `Administrar Jenkins > Plugins > Installed plugins`.
- **No hay informe de cobertura.** Casi siempre es que Maven no ha generado `jacoco.xml`: las pruebas se saltaron, una falló o `report` no está en el `pom.xml`. Se mira la consola de Maven buscando `jacoco:0.8.16:report` y el mensaje `Skipping JaCoCo execution due to missing execution data file`. Se repite `mvn -B clean test` en local.
- **El informe sale en blanco o con 0 %.** El agente no estaba enganchado: falta `prepare-agent` o va después de las pruebas. Lo comprobamos en la salida de Maven: la línea `prepare-agent` tiene que ir antes de las pruebas.
- **La cobertura de `Contacto` es mucho más baja de lo esperado.** Probablemente el código de Lombok se está contando. Se revisa `lombok.config` (la clave tiene que ser `lombok.addLombokGeneratedAnnotation = true`) y se hace `mvn -B clean test`. Sin `clean`, Maven no recompila y el resultado antiguo sigue ahí.
- **Después de cambiar `lombok.config` la cifra no cambia.** Falta `clean`: Maven reutiliza las clases ya compiladas, que se compilaron con la configuración anterior (S04-1).
- **`Load Maven Changes` no se pulsa y IntelliJ subraya `jacoco` en rojo.** Es solo el IDE: Maven lo entiende igualmente desde la terminal.
- **Fallo al descargar `jacoco-maven-plugin`.** Maven necesita Internet para bajarlo la primera vez, igual que cualquier plugin (S02-1). Se vuelve a intentar con conexión.
- **Las comillas son curvas.** Se han pegado desde un documento. Groovy no las reconoce. Se sustituyen por comillas rectas (S14-1).
- **Las letras con tilde salen deformadas en la consola.** Los `echo` y los mensajes de commit van sin tildes (S14-2).

---

## Qué está verificado y qué no

**Verificado** (Maven 3.9.11, JDK 21.0.12, Surefire 3.5.6, JaCoCo 0.8.16, Lombok 1.18.46 con Spring Boot 4.1.1; `contactos` real, idéntico al de S14-2):

- Los cuatro `Jenkinsfile` de las demos y las prácticas con zip, más el orientativo de la Práctica 3, pasan el analizador de Groovy 4.0.24 y el de Groovy 2.4.21. Jenkins ejecuta los pipelines con su propio intérprete, así que no sustituye a su comprobación. Una comprobación estructural propia (directivas, condiciones de `post`, parámetros declarados, llaves y comillas) los da por buenos y detecta seis ficheros erróneos hechos a propósito.
- La interpolación de `${!params.EJECUTAR_PRUEBAS}` con Groovy: `true` produce `-DskipTests=false` y `false` produce `-DskipTests=true`.
- Con Maven real: `mvn -B test -DskipTests=false` (seis pruebas), `-DskipTests=true` (`Tests are skipped.`, sin carpeta `surefire-reports`) y `package -DskipTests` (JAR de 9105192 bytes y `.jar.original` de 3722). Las salidas de este documento salen de esas ejecuciones.
- Con Maven real: `jacoco-maven-plugin` 0.8.16 con `prepare-agent` y `report` en la fase `test` (sin la línea `<phase>`, `report` solo se ejecuta con `mvn verify`), el orden de los plugins, los ficheros de `target/site/jacoco`, la tabla de porcentajes, las líneas pintadas de `Aplicacion` y `Contacto` (la 65 en amarillo, `1 of 6 branches missed`) y la ruta `target/site/jacoco/jacoco.xml`.
- Las tres situaciones de `lombok.config` (sin fichero, `false` y `true`) y sus cifras, y las siete marcas `lombok.Generated` que muestra `javap` en la clase compilada con `true` (y ninguna con `false`). El fichero con comentarios del zip da los mismos resultados que sin ellos.
- Las ejecuciones con pruebas saltadas (`Skipping JaCoCo execution due to missing execution data file`, sin `jacoco.xml`) y con una prueba rota (`BUILD FAILURE`, sin informe).
- El proyecto del zip, con el `pom.xml` y el `lombok.config` de `demo2-cobertura` copiados encima, compila y pasa las seis pruebas.

**Según la documentación, sin comprobar en Jenkins**: que el plugin Coverage se identifica como `coverage`, necesita Jenkins 2.555.3 o posterior y ofrece `recordCoverage(tools: [[parser: 'JACOCO']])`; que sin `pattern` busca `**/jacoco.xml`; y que `publishCoverage` es del plugin anterior.

**No verificado (requiere Jenkins real)**:

- Los nombres de los menús y botones: `Administrar Jenkins > Plugins`, `Available plugins`, `Build with Parameters`, `Console Output`, el menú de cobertura de la construcción.
- La instalación del plugin Coverage y si ofrece reiniciar.
- Cómo se presenta una etapa omitida en la vista de etapas.
- Qué valores tienen los parámetros en la primera construcción tras añadir `parameters`, y que el botón cambie de `Build Now` a `Build with Parameters` tras ella.
- Qué valores usa una construcción lanzada por el sondeo.
- El informe de cobertura dentro de Jenkins: resumen, porcentajes por clase, código coloreado y las métricas que muestra por defecto.
- Qué hace `recordCoverage` cuando no encuentra `jacoco.xml`.
- Las líneas que Jenkins escribe alrededor de cada comando en la consola.
- El fragmento de `withCredentials`: ni su ejecución ni su sintaxis con Groovy.
- El comando `javap ... | findstr` en Windows (se probó con `grep` en Linux).
- Que los nombres `jdk-21` y `maven-3.9` coincidan con los de cada equipo (son los supuestos de S13-2).

**Fuentes** consultadas para los datos que no dependen de nuestras ejecuciones:
- Plugin Coverage de Jenkins: https://plugins.jenkins.io/coverage/ y https://github.com/jenkinsci/coverage-plugin
- Registro de cambios de Lombok: https://projectlombok.org/changelog
- Registro de cambios de JaCoCo: https://www.jacoco.org/jacoco/trunk/doc/changes.html

---

## Conceptos que se añaden a conceptos-introducidos.md

Las filas siguientes se añaden al final de `conceptos-introducidos.md` sin tocar las existentes. Incluyen las de las prácticas de esta parte.

| Parámetro de Jenkins, bloque `parameters` y `booleanParam` | S15-1 | Completo: un parámetro es una pregunta que Jenkins hace justo antes de empezar la construcción y que el pipeline lee; el `Jenkinsfile` no cambia, cambia lo que hace en cada ejecución (ejemplo de la cafetería: la receta es la misma, el camarero pregunta "¿con leche?"). Se declara en un bloque `parameters` dentro de `pipeline`, una sola vez. `booleanParam(name, defaultValue, description)` es una casilla: marcada `true`, sin marcar `false`; `name` es el nombre con el que se lee (mayúsculas con guiones bajos), `defaultValue` el valor si nadie la toca (importante elegirlo bien) y `description` la ayuda junto a la casilla (sin tildes). Existen otros tipos; en la Práctica 3 se usa `string` (texto con valor por defecto) |
| `params` | S15-1 | Completo: `params.NOMBRE` lee la respuesta a un parámetro. Se diferencia de `env.` (S14-2): `env` son variables que prepara Jenkins, `params` lo que ha contestado una persona. Se puede usar dentro de un comando entre comillas dobles (`${...}`, S14-2) o en la cabecera de una etapa |
| Negar un parámetro: `-DskipTests=${!params.EJECUTAR_PRUEBAS}` | S15-1 | Completo: se pregunta en positivo ("¿ejecutar las pruebas?") pero Maven entiende `skipTests` (S03-2), la pregunta contraria; el signo `!` (S11-1) niega el valor. Marcada produce `-DskipTests=false` y sin marcar `-DskipTests=true`. Comprobado con Groovy y con Maven: con `true` salen seis pruebas; con `false`, `Tests are skipped.`, `BUILD SUCCESS` y sin carpeta `surefire-reports` (por eso `allowEmptyResults: true` en `junit`, S14-1) |
| `when` y `expression`; etapa omitida frente a etapa fallida | S15-1 | Completo: `when` en la cabecera de una etapa es el portero que decide si se ejecuta; `expression { return params.X }` contiene código Groovy que da `true` o `false`. Si da `false`, Jenkins omite la etapa (*skipped*): no hay error, no se pone nada en rojo, la construcción puede terminar en verde y la consola no tiene ninguna salida de esa etapa. Omitida no es fallida. Cómo se muestra una etapa omitida en la vista de etapas no está verificado |
| `Build with Parameters` y primera construcción tras añadir `parameters` | S15-1 | Completo; **no verificado en Jenkins real**: el job no conoce los parámetros hasta que ha ejecutado un `Jenkinsfile` que los declare, así que la primera construcción tras añadirlos (`Build Now`) solo sirve para registrarlos y no se usa para comparar (no se afirma qué valores tienen `params` en ella); después el botón cambia a `Build with Parameters`, que muestra un formulario con las casillas en su valor por defecto. Los nombres exactos del botón y el idioma no están comprobados |
| Construcciones lanzadas por el sondeo con parámetros | S15-1 | Introducido; **no verificado**: una construcción lanzada por `Poll SCM` no pasa por el formulario y se supone que usa los valores por defecto (`defaultValue`), por lo que conviene elegirlos para que lo automático haga lo habitual |
| Plugin de Jenkins: instalar Coverage | S15-1 | Completo; **no verificado en Jenkins real**: un plugin es una extensión que añade capacidades a Jenkins; no es lo mismo que un plugin de Maven (extensión de Maven, se declara en el `pom.xml`). Ruta según la documentación: `Administrar Jenkins > Plugins`, comprobar en `Installed plugins` y, si falta, `Available plugins`, buscar `Coverage`, `Install` y reiniciar si lo ofrece. Según su página: id `coverage`, Jenkins 2.555.3 o posterior (el aula tiene 2.580.1) y paso `recordCoverage`; `publishCoverage` es del plugin anterior |
| Cobertura; línea cubierta, sin cubrir y parcial; rama | S15-1 | Completo: porcentaje del código que se ejecuta mientras corren las pruebas (ejemplo de la casa de diez habitaciones de las que solo se abren dos). Verde en el informe = línea cubierta; rojo = ninguna prueba la ejecuta; amarillo = se ejecuta pero deja un camino sin probar. Una rama es cada camino de una decisión (`if`, `&&`). Una línea sin cubrir no está mal, está sin comprobar: la cobertura mide qué ejecutan las pruebas, no si son buenas |
| JaCoCo y `jacoco-maven-plugin` (`prepare-agent`, `report`) | S15-1 | Completo: JaCoCo mide, Maven lo ejecuta con su plugin y Jenkins solo publica el resultado. Plugin `org.jacoco:jacoco-maven-plugin` versión `0.8.16` (comprobada en Maven Central; funciona con JDK 21). `prepare-agent` engancha el agente a la JVM de las pruebas y guarda `target/jacoco.exec`; tiene que ir antes de las pruebas. `report` (con `<phase>test</phase>` y un `id`, `informe`) lee ese fichero y escribe `target/site/jacoco`: `index.html`, `jacoco.csv`, `jacoco.xml` y una carpeta por paquete. Salida de Maven: `jacoco:0.8.16:prepare-agent (default)`, `jacoco:0.8.16:report (informe)` y `Analyzed bundle 'contactos' with 2 classes`. Se añade en `<build><plugins>` tras `spring-boot-maven-plugin` y se pulsa `Load Maven Changes` |
| Informe de JaCoCo: columnas y cifras de `contactos` | S15-1 | Completo: `index.html` tiene una fila por paquete y, dentro, por clase; columnas `Missed Instructions`/`Cov.`, `Missed Branches`/`Cov.`, `Missed`/`Lines` y `Missed`/`Methods`. Medido con las seis pruebas: total 89 % de instrucciones (5 de 47 sin cubrir) y 83 % de ramas (1 de 6); `Aplicacion` 37 % (`main()` sin cubrir: líneas 16 y 17 en rojo, la 13 en verde); `Contacto` 100 % de instrucciones, líneas y métodos y 83 % de ramas (línea 65, `emailValido()`, en amarillo: `1 of 6 branches missed`, ninguna prueba comprueba un correo sin arroba). JaCoCo trunca los porcentajes (37,5 se muestra 37) |
| `recordCoverage(tools: [[parser: 'JACOCO']])` | S15-1 | Completo; **no verificado en Jenkins real**: paso del plugin Coverage que lee el informe XML de JaCoCo y lo publica; no mide nada. `tools` es una lista de herramientas (de ahí los dobles corchetes) y `parser: 'JACOCO'` da el formato. Sin `pattern`, según la documentación, busca `**/jacoco.xml` y `**/jacocoTestReport.xml` en el espacio de trabajo; con un proyecto en subcarpeta se indica `pattern`. Va en el `post` de `Probar` con `always`, junto a `junit` |
| Cobertura con pruebas saltadas o rotas | S15-1 | Completo: con `-DskipTests=true` Maven termina en `BUILD SUCCESS` pero JaCoCo avisa `Skipping JaCoCo execution due to missing execution data file` y no hay `jacoco.xml` ni carpeta `target/site`; con una prueba rota, `BUILD FAILURE` y tampoco hay informe. Qué hace `recordCoverage` sin fichero no está documentado ni comprobado. JaCoCo solo mide lo que se ejecuta: con `"-Dtest=!AplicacionTests"` (S14-1) `Aplicacion` baja a 0 % de líneas y `Contacto` se queda en 100 % |
| Lombok y cobertura: `@lombok.Generated` y `lombok.config` | S15-1 | Completo: desde Lombok 1.18.34 todo el código que genera lleva `@lombok.Generated` por defecto y desde JaCoCo 0.8.3 se ignora el código marcado con una anotación cuyo nombre contenga `Generated`; con Lombok 1.18.46 (Spring Boot 4.1.1) la cobertura de `Contacto` ya sale al 100 % sin configurar nada (comprobado con `javap -p -v`: siete `lombok.Generated`). `lombok.config` en la raíz, junto a `pom.xml`: `config.stopBubbling = true` termina la búsqueda de configuraciones en carpetas superiores y `lombok.addLombokGeneratedAnnotation = true` deja la marca por escrito, sin depender de la versión. Experimento con `false` y `mvn -B clean test` (el `clean` es imprescindible): `Contacto` baja al 82 % de instrucciones, con `setNombre`, `setTelefono` y el constructor vacío en 0 % (3 de 10 métodos sin cubrir) y el total al 77 %; con `true` vuelve al 100 % y al 89 %. El guion suponía que la cobertura bajaba por Lombok; se reformuló al medirlo |
| Credencial de Jenkins usada por su ID en un pipeline: `withCredentials` | S15-1 | Introducido (explicación breve, sin práctica); **no verificado**: el `Jenkinsfile` se sube al repositorio y un secreto escrito queda en el historial, por lo que solo contiene el ID de la credencial de S13-2. `withCredentials([usernamePassword(credentialsId: '...', usernameVariable: '...', passwordVariable: '...')]) { ... }` crea las variables mientras dura el bloque; en `bat`, comillas simples (Groovy no interpola el secreto) y `%VARIABLE%` en `cmd`. Jenkins enmascara los valores en la consola, pero es una ayuda y no una garantía: el token nunca se imprime |
| Práctica 1: parámetro de pruebas y etapa condicionada | S15-1 | Completo (solución): `Jenkinsfile` de `contactos` con `EJECUTAR_PRUEBAS` (`true`) y `MOSTRAR_ENTORNO` (`false`), y una primera etapa `Entorno` con `when` que ejecuta `java -version` y `mvn -version`; se lanza con y sin ellos y se comparan las consolas. Verificado con Groovy y Maven (los dos comandos existen); la salida dentro de Jenkins no |
| Práctica 2: cobertura de `contactos` | S15-1 | Completo (solución): Práctica 1 más JaCoCo en el `pom.xml`, `lombok.config` y `recordCoverage`. La clase con menos cobertura es `Aplicacion` (37 %; líneas 16 y 17 de `main()`); la línea más instructiva es la 65 de `Contacto` (amarilla). Ampliación: una prueba de un correo sin arroba lleva `Contacto` a 6 de 6 ramas con siete pruebas (comprobado) y `Aplicacion` no cambia |
| Práctica 3: parámetros y cobertura en el proyecto del grupo | S15-1 | Completo (solución orientativa, sin zip): `Jenkinsfile` del grupo con `EJECUTAR_PRUEBAS` (`booleanParam`) y `EXCLUIR_PRUEBAS` y `SUBCARPETA` (`string`), que construyen `-f subcarpeta/pom.xml`, `"-Dtest=!NombreTests"`, las rutas de `junit` y el `pattern` de `recordCoverage` con la subcarpeta. Comprobado con Maven: `-f app/pom.xml` deja el informe en `app/target/site/jacoco/jacoco.xml`. Un proyecto de grupo suele salir con poca cobertura: ese dato es el punto de partida del trabajo de pruebas |
| Proyecto `contactos` y repositorio en S15-1 | S15-1 | Reutilizado de S11-1 y S14-2 sin cambios en el código Java ni en las pruebas (comprobado: la carpeta `contactos` del zip es idéntica a la de `s14-2-demos.zip`). La Demo 2 solo añade al `pom.xml` el plugin de JaCoCo y el fichero `lombok.config`. Mismo repositorio (https://github.com/JD-CFTIC/contactos.git, cada alumno el suyo), rama `main`. Secuencia de ejemplo con construcciones 12 a 16 |
| Pantallas y datos de Jenkins de S15-1: verificado y no verificado | S15-1 | Nota para chats posteriores. **Verificado** (Maven 3.9.11, JDK 21, Surefire 3.5.6, JaCoCo 0.8.16, Lombok 1.18.46, `contactos` real): salidas de `mvn` con y sin `-DskipTests`, informe de JaCoCo y sus cifras, las tres situaciones de `lombok.config`, `javap`, pruebas saltadas y rotas, `-Dtest=!`, `-f subcarpeta/pom.xml`, sintaxis Groovy (4.0.24 y 2.4.21) y estructura de los `Jenkinsfile`. **Según la documentación**: id, versión mínima y paso del plugin Coverage. **No verificado (requiere Jenkins real)**: menús y botones, instalación del plugin, `Build with Parameters` y la primera construcción, valores en construcciones del sondeo, etapa omitida en la vista de etapas, el informe de cobertura dentro de Jenkins, `recordCoverage` sin fichero, `withCredentials`, y `javap ... \| findstr` en Windows |
