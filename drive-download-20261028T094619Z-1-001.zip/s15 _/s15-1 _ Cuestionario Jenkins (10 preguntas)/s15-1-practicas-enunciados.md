# S15-1 Prácticas

## Objetivos

En las demos hemos hecho que un pipeline pregunte antes de empezar, que una etapa solo se ejecute si se pide y que Jenkins publique la cobertura de las pruebas. En estas prácticas lo hacemos nosotros: primero con `contactos`, donde todo está comprobado y los resultados se pueden contrastar, y después con el proyecto del grupo, donde cada grupo se encuentra los problemas particulares de su código.

Todas las prácticas se lanzan desde Jenkins y se comprueban en la consola de la construcción. Para cada una se anota qué ha hecho cada construcción, porque la forma de aprender aquí es comparar: el mismo `Jenkinsfile`, lanzado con valores distintos, produce resultados distintos.

Se trabaja en el repositorio de siempre, `https://github.com/JD-CFTIC/contactos.git` (el de cada alumno), en la rama `main`. Los textos de `echo`, los comandos `bat` y los mensajes de commit se escriben sin tildes ni eñes.

---

## Práctica 1: Parámetro de pruebas y etapa condicionada en contactos

**Enunciado**

El `Jenkinsfile` de `contactos` queda con dos parámetros y una etapa condicionada. Se parte del `Jenkinsfile` que dejó la Demo 1 en el repositorio y se modifica así:

- Un parámetro `EJECUTAR_PRUEBAS` que decide si Maven ejecuta las pruebas. Por defecto, marcado.
- Un parámetro `MOSTRAR_ENTORNO` que decide si se muestra la información del entorno. Por defecto, sin marcar.
- Una etapa `Entorno`, la primera de todas, que solo se ejecuta si `MOSTRAR_ENTORNO` está marcado y que muestra la versión de Java y la de Maven que usa la construcción.
- La etapa `Empaquetar` vuelve a ejecutarse siempre: el parámetro `EMPAQUETAR` de la demo y su condición se eliminan.

Se lanza la construcción tres veces con valores distintos y se comparan las consolas.

**Pasos**

1. Abrimos el `Jenkinsfile` de `contactos` en IntelliJ. En el bloque `parameters` dejamos los dos parámetros de este enunciado, con los valores por defecto indicados y un texto de ayuda sin tildes.
2. Quitamos de la etapa `Empaquetar` la condición de la demo, para que se ejecute siempre.
3. Añadimos al principio de `stages` la etapa `Entorno`, con su condición y dos pasos `bat`: uno que muestre la versión de Java y otro la de Maven.
4. Antes de subir nada, ejecutamos en la terminal de IntelliJ los dos comandos de la etapa `Entorno` y comprobamos que funcionan.
5. Hacemos commit y push con un mensaje sin tildes.
6. En Jenkins, `Build Now`. Esta primera construcción solo sirve para que Jenkins conozca los parámetros nuevos: no se usa para comparar. Recargamos la página del job y comprobamos que ahora aparece `Build with Parameters`.
7. Lanzamos tres construcciones con `Build with Parameters`:
   1. Con los valores por defecto.
   2. Con `EJECUTAR_PRUEBAS` sin marcar.
   3. Con `EJECUTAR_PRUEBAS` marcado y `MOSTRAR_ENTORNO` marcado.
8. En la consola de cada una buscamos tres cosas: si hay líneas `Tests run:`, si aparece `Tests are skipped.`, y si aparecen las versiones de Java y de Maven.
9. Completamos esta tabla en el cuaderno:

| Construcción | EJECUTAR_PRUEBAS | MOSTRAR_ENTORNO | ¿Líneas `Tests run:`? | ¿Versiones de Java y Maven? |
|---|---|---|---|---|
| Por defecto | | | | |
| Sin pruebas | | | | |
| Con entorno | | | | |

**Pistas**

- `booleanParam` lleva tres datos: `name`, `defaultValue` y `description`. Los nombres se escriben en mayúsculas y con guion bajo, y se leen luego con `params.` delante.
- Maven entiende `skipTests`, que es lo contrario de "ejecutar". Hay que negar el valor del parámetro.
- La condición de una etapa va en un bloque `when` dentro de la propia etapa, antes de `steps`. Con `expression` se escribe una expresión de Groovy que devuelve `true` o `false`.
- Para comprobar las versiones en local, `java -version` y `mvn -version` se ejecutan tal cual en `cmd`.
- Una etapa omitida no está en rojo: no hay error. Si dudamos de si se ejecutó, miramos si hay salida suya en la consola.

---

## Práctica 2: Cobertura de contactos

**Enunciado**

Se publica en Jenkins la cobertura de las pruebas de `contactos`. Con el informe delante se responde a tres preguntas: qué clase tiene menos cobertura, qué líneas de esa clase no recorre ninguna prueba y si hay alguna línea que se ejecuta solo en parte.

Se parte del `Jenkinsfile` de la Práctica 1. Si el proyecto ya tiene JaCoCo y `lombok.config` por haber seguido la Demo 2, se comprueba que están; si no, se añaden como en la demo.

**Pasos**

1. Comprobamos que el plugin Coverage está instalado en `Administrar Jenkins > Plugins`. Si falta, lo instalamos como en la Demo 2.
2. En el `pom.xml`, añadimos `jacoco-maven-plugin` con la versión `0.8.16`, con las dos ejecuciones de la demo: el agente antes de las pruebas y el informe en la fase `test`.
3. Creamos en la raíz el fichero `lombok.config` de la demo.
4. En la terminal de IntelliJ ejecutamos `mvn -B clean test` y comprobamos que existe `target/site/jacoco/jacoco.xml`. Abrimos `target/site/jacoco/index.html` en el navegador.
5. Añadimos al `Jenkinsfile` el paso que publica la cobertura, en el mismo sitio donde se publican las pruebas.
6. Commit con mensaje sin tildes y push.
7. En Jenkins, `Build with Parameters` con los valores por defecto. Abrimos el informe de cobertura de la construcción.
8. Respondemos, mirando el informe (el de Jenkins y, si no lo encontramos, el `index.html` local):
   1. ¿Qué clase tiene menos cobertura y qué porcentaje?
   2. ¿Qué números de línea de esa clase no recorre ninguna prueba?
   3. ¿Hay alguna clase con una línea en amarillo (cubierta solo en parte)? ¿Cuál es el número de línea y qué camino falta?
9. Lanzamos otra construcción con `EJECUTAR_PRUEBAS` sin marcar y anotamos qué ocurre con la cobertura.

**Ampliación (opcional)**

Se escribe una prueba que cubra el camino que falta en la línea amarilla, se sube y se comprueba, con el informe, que la rama pasa a estar cubierta.

**Pistas**

- `prepare-agent` tiene que ejecutarse antes de las pruebas. `report` va en la fase `test`, que es en la que Maven ejecuta las pruebas.
- Hay que repetir `mvn -B clean test` con `clean` cada vez que se cambie `lombok.config` o el `pom.xml`, para que Maven no reutilice clases compiladas con la configuración anterior.
- `recordCoverage` lee el informe de JaCoCo; el formato se indica con `parser`. Si no se indica ruta, busca `jacoco.xml` en el espacio de trabajo.
- Abrir un fichero `.java` desde el informe de JaCoCo muestra el código con las líneas coloreadas: verde cubierta, rojo sin cubrir, amarillo cubierta en parte.
- Una rama es cada camino de una decisión. Una línea con `&&` o con `if` puede tener varias.
- Lo que no se mide, no se publica: si Maven no ejecuta las pruebas, JaCoCo no tiene nada que contar.

---

## Práctica 3: Parámetros y cobertura en el proyecto del grupo

**Enunciado**

Cada grupo añade al `Jenkinsfile` de su proyecto un parámetro para las pruebas y la publicación de la cobertura, y comprueba el resultado con el código de su proyecto. Esta práctica no tiene zip: cada proyecto es distinto. El `Jenkinsfile` del grupo ya existe desde S14-2 y se mejora.

Se pide:

1. Un parámetro booleano que decide si se ejecutan las pruebas.
2. Un parámetro de texto con el nombre de una clase de pruebas que se excluye de la ejecución (vacío: no se excluye ninguna). Esto sirve para dejar fuera las pruebas que necesitan la base de datos y que no funcionan en Jenkins (se anotaron en S14-2).
3. JaCoCo en el `pom.xml` del proyecto y la publicación de la cobertura en el `Jenkinsfile`.
4. Si el `pom.xml` no está en la raíz del repositorio, que todas las rutas (Maven, informes de pruebas e informe de cobertura) tengan en cuenta la subcarpeta.

**Pasos**

1. Elegimos quién del grupo trabaja con el `Jenkinsfile`; los demás revisan. Hacemos `git pull` antes de empezar y `git pull` antes de cada `push`.
2. Comprobamos dónde está el `pom.xml` del proyecto: en la raíz o en una subcarpeta.
3. Añadimos JaCoCo al `pom.xml` y, si el proyecto usa Lombok, el fichero `lombok.config`. Comprobamos en local que `mvn -B clean test` genera `jacoco.xml`. Si hay subcarpeta, el comando es el de la parte de S14-2 con `-f`.
4. Añadimos los parámetros al `Jenkinsfile` y los usamos en la etapa de pruebas.
5. Añadimos la publicación de la cobertura, con la ruta correcta si hay subcarpeta.
6. Commit, push y `Build Now` (para registrar los parámetros). Después, construcciones con `Build with Parameters`:
   1. Con los valores por defecto.
   2. Excluyendo una clase de pruebas.
7. Anotamos, para cada construcción, cuántas pruebas se ejecutaron y la cobertura de las tres clases con menos cobertura.
8. Respondemos como grupo: ¿qué clases no están cubiertas por ninguna prueba? ¿Cuáles lo están solo en parte? ¿Qué parte de la baja cobertura se debe a las pruebas que hemos excluido y qué parte a pruebas que nadie ha escrito?

**Pistas**

- Para un parámetro de texto, `string` con `name`, `defaultValue` y `description`.
- La exclusión se escribe `"-Dtest=!NombreTests"`, con las comillas dobles para que `cmd` no interprete el signo `!`.
- JaCoCo solo mide lo que se ejecuta. Si se excluye una clase de pruebas, el código que solo esa clase recorría pasa a aparecer como sin cubrir.
- Con el `pom.xml` en una subcarpeta, Maven se invoca con `-f subcarpeta/pom.xml`, y los informes (`target/...`) quedan dentro de esa subcarpeta, así que las rutas de `junit` y de la cobertura también la llevan.
- Si en el `Jenkinsfile` hay que construir un texto en función de un parámetro, Groovy lo permite fuera de los pasos con un bloque `script`; una `environment` también puede calcular valores.
- La cobertura de un proyecto propio suele ser baja. No es un fallo de la herramienta ni del grupo: es el punto de partida del trabajo de pruebas.

---

## Problemas frecuentes

- **No aparece `Build with Parameters`.** Jenkins no ha ejecutado todavía un `Jenkinsfile` con `parameters`. Se lanza `Build Now` una vez y se recarga la página.
- **El `Jenkinsfile` da un error de sintaxis nada más lanzarse.** Una llave sin cerrar, un nombre mal escrito (`boleanParam`) o comillas curvas pegadas desde un documento. Se corrige y se vuelve a subir.
- **Las pruebas se ejecutan aunque se desmarcó la casilla (o al revés).** Se comprueba que el comando lleva el `!` delante del parámetro y está entre comillas dobles.
- **No hay informe de cobertura.** Se mira la consola de Maven: tiene que aparecer `jacoco:0.8.16:report`. Si las pruebas se saltaron, falló alguna o el `pom.xml` no tiene el plugin, no se genera `jacoco.xml`.
- **El informe sale al 0 %.** El agente de JaCoCo no estaba enganchado a las pruebas o las pruebas no se ejecutaron.
- **En el proyecto del grupo no se encuentra `jacoco.xml`.** Se está buscando en la raíz y el informe está dentro de la subcarpeta del `pom.xml`: hay que indicar la ruta.
- **Se hace `push` y Git lo rechaza.** Otro miembro del grupo ha subido cambios. Se hace `git pull` y se repite el `push` (S11-1).
- **Se cambia `lombok.config` o el `pom.xml` y la cifra no cambia.** Falta `clean` en el comando de Maven.

---

## Qué está verificado y qué no

**Verificado** con Maven 3.9.11, JDK 21.0.12, JaCoCo 0.8.16 y `contactos` real: todos los comandos de Maven, las salidas y las cifras a las que remiten estos enunciados, y la sintaxis de los `Jenkinsfile` de las soluciones con Groovy 4.0.24 y 2.4.21.

**No verificado (requiere Jenkins real)**: cómo muestra Jenkins los parámetros, las etapas omitidas y el informe de cobertura; los nombres exactos de menús y botones; la primera construcción tras añadir parámetros; el comportamiento de `recordCoverage` cuando no hay informe; y el proyecto de cada grupo, que no hemos visto: sus rutas, su Lombok y sus pruebas pueden dar problemas que aquí no se contemplan.
