# S11-2 Prácticas

## Objetivos

Se aplica lo aprendido en las demos con un proyecto nuevo, `contactos-api`: una API REST de contactos guardados en PostgreSQL. En la primera práctica se construye la API y se prueba desde Swagger. En la segunda se documenta con anotaciones. En la tercera se le añade validación y se comprueban las respuestas 400. La cuarta práctica lleva Swagger, la documentación y la validación a la API del proyecto de cada grupo.

Las tres primeras prácticas son acumulativas: cada una parte del estado en que dejó el proyecto la anterior. Al final de cada una se hace un commit con un mensaje que explique qué cambia, igual que en S11-1.

Antes de la siguiente sesión, cada persona instala MongoDB en su equipo siguiendo la última sección de `s11-2-demos.md`.

---

## Práctica 1: API de contactos con Swagger

Se crea el proyecto `contactos-api` con una tabla de PostgreSQL, una entidad, un repositorio y un controlador con cuatro operaciones, y se prueban todas desde Swagger.

**Pasos**

1. Creamos un proyecto nuevo con `File > New > Project` y, en el panel izquierdo, `Generators > Spring Boot`. Name `contactos-api`, Type `Maven`, Language `Java`, Group `com.curso`, Artifact `contactos-api`, Package name `com.curso`, JDK `21`, Java `21`, Packaging `Jar` y Configuration `Properties`. En la segunda pantalla dejamos Spring Boot `4.1.1` y marcamos `Spring Web`, `Spring Data JPA`, `PostgreSQL Driver` y `Lombok`. Hacemos clic en `Create`.
2. Renombramos con `Shift+F6` las clases que genera el asistente: la principal pasa a llamarse `Aplicacion` y la de `src/test/java`, `AplicacionTests`.
3. Creamos en PostgreSQL la base de datos `contactos`. Guardamos en `sql/01-crear-contacto.sql` (carpeta `sql` en la raíz del proyecto) el script que borra la tabla `contacto` si existe, la crea y le inserta dos filas de ejemplo, una de ellas sin teléfono. La tabla tiene estas columnas:

   | Columna | Tipo | Reglas |
   |---|---|---|
   | `id` | `bigint` | clave primaria, generada automáticamente |
   | `nombre` | `varchar(100)` | obligatoria |
   | `email` | `varchar(150)` | obligatoria |
   | `telefono` | `varchar(15)` | opcional |

   Ejecutamos el script contra la base de datos `contactos`.
4. Configuramos `application.properties`: nombre de la aplicación `contactos-api`, conexión a la base de datos `contactos` con el usuario `postgres` y la contraseña leída de la variable de entorno `POSTGRES_PASSWORD` (que definimos en la configuración de ejecución, como en las sesiones anteriores) y `spring.jpa.hibernate.ddl-auto=validate`.
5. Creamos los paquetes `com.curso.model`, `com.curso.repository` y `com.curso.controller`. En el primero escribimos la entidad `Contacto`, con un campo por cada columna y el constructor vacío, los getters y los setters generados con Lombok. En el segundo, `ContactoRepository`, un repositorio de Spring Data JPA. En el tercero, `ContactoController`, bajo la ruta `/api/contactos`, con cuatro operaciones:
   - Listar todos los contactos, ordenados por nombre.
   - Obtener un contacto por su id. Devuelve 404 si no existe.
   - Crear un contacto. Devuelve 201 con el contacto guardado, ya con su id.
   - Borrar un contacto por su id. Devuelve 204 si lo borra y 404 si no existe.
6. Añadimos al `pom.xml` la dependencia de Swagger (`springdoc-openapi-starter-webmvc-ui`, versión `3.1.1`) y pulsamos **Load Maven Changes**.
7. Arrancamos la aplicación, abrimos `http://localhost:8080/swagger-ui.html` y probamos las cuatro operaciones: listar, obtener el contacto 1, crear uno nuevo, obtener un id que no existe (`99`) y borrar el contacto recién creado. Anotamos el código que devuelve cada una.
8. Hacemos un commit con el proyecto completo. Creamos antes el repositorio (`git init -b main`) y comprobamos con `git status` que `.idea` y `target` no aparecen.

**Pistas**

- Si el asistente de IntelliJ no muestra `Spring Web`, está dentro de la categoría `Web`; `Spring Data JPA` y `PostgreSQL Driver` están en `SQL`; `Lombok`, en `Developer Tools`.
- La clave primaria generada automáticamente se escribe en la tabla con `generated always as identity` y, en la entidad, con `@GeneratedValue(strategy = GenerationType.IDENTITY)`.
- Al crear, conviene poner el id a `null` antes de guardar (`setId(null)`): así, aunque el cliente envíe un `id`, `save()` hace siempre un alta y no modifica una fila existente.
- Para el 404 de las dos operaciones por id se usan las mismas ideas de S09: `findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build())` para obtener, y `existsById()` antes de `deleteById()` para borrar.
- Si la aplicación no arranca con un error de validación del esquema, la tabla o alguna columna de la base de datos no coincide con la entidad: comparar los nombres y los tipos.
- Los cuerpos de ejemplo de Swagger traen `0` en el `id` y `string` en los textos. Se sustituyen por valores reales antes de pulsar `Execute`.

---

## Práctica 2: Documentar la API

Se describe la API de contactos con anotaciones de Swagger, de forma que la página de documentación se entienda sin leer el código.

**Pasos**

1. Partimos del proyecto de la práctica anterior, con la aplicación parada y el árbol de trabajo limpio (`git status`).
2. En la clase `Aplicacion`, definimos la información general: título `API de contactos`, versión `1.0` y una descripción de una frase.
3. En `ContactoController`, agrupamos las operaciones bajo la etiqueta `Contactos`, con una descripción, y añadimos a cada operación un resumen y una descripción.
4. Describimos las respuestas de cada operación con los códigos que realmente puede devolver: `200` para listar y para obtener, `404` para obtener y borrar, `201` para crear y `204` para borrar. Las respuestas de error no deben anunciar un cuerpo.
5. En la entidad `Contacto`, describimos la clase y cada campo, con un valor de ejemplo. El `id` se marca como campo de solo lectura.
6. Arrancamos la aplicación y comprobamos en la página de Swagger que: el título y la descripción son los nuestros; las operaciones aparecen bajo `Contactos`; el `DELETE` muestra dos respuestas (204 y 404); y el cuerpo de ejemplo del `POST` no incluye el `id` y trae los valores que escribimos.
7. Comprobamos también en `http://localhost:8080/v3/api-docs` que la información general aparece en el JSON.
8. Hacemos un commit con los cambios.

**Pistas**

- Las anotaciones se importan del paquete `io.swagger.v3.oas.annotations` (y sus subpaquetes `info`, `tags`, `media` y `responses`). Si IntelliJ ofrece varias clases con el mismo nombre, hay que elegir la de ese paquete.
- La información general lleva `@OpenAPIDefinition` con un `@Info` dentro.
- `@Operation` tiene los atributos `summary` (una línea) y `description` (el detalle).
- Varias `@ApiResponse` en un mismo método se agrupan con `@ApiResponses({ ... })`.
- Para que una respuesta no anuncie cuerpo se usa el atributo `content = @Content`, vacío.
- Para marcar el `id` como solo lectura, `@Schema` tiene el atributo `accessMode` con el valor `Schema.AccessMode.READ_ONLY`.
- Si los cambios no se ven al recargar la página, comprobar que la aplicación se ha reiniciado: la documentación se genera al arrancar.

---

## Práctica 3: Validar los contactos

Se añaden reglas de validación a la entidad `Contacto` y se comprueba desde Swagger que los datos incorrectos reciben un 400 con un mensaje claro.

**Pasos**

1. Partimos del proyecto de la práctica anterior, con la aplicación parada. Antes de validar, creamos un contacto con un cuerpo vacío (`{}`) desde Swagger y anotamos qué código devuelve y por qué.
2. Añadimos al `pom.xml` la dependencia `spring-boot-starter-validation` y pulsamos **Load Maven Changes**.
3. Declaramos las reglas en la entidad `Contacto`, cada una con un mensaje en español:
   - `nombre`: obligatorio, con un máximo de 100 caracteres.
   - `email`: obligatorio, con formato de correo válido y un máximo de 150 caracteres.
   - `telefono`: opcional, con un máximo de 15 caracteres.
4. Activamos la validación en la operación de crear.
5. Configuramos `application.properties` para que la respuesta de error incluya el mensaje y la lista de errores de validación.
6. Arrancamos la aplicación y probamos desde Swagger la creación con estos cuerpos, anotando el código y el mensaje de cada respuesta:
   - Un nombre vacío (`""`).
   - Un nombre de solo espacios (`"   "`).
   - Un teléfono de 16 caracteres.
   - Un nombre vacío y un correo `ana` a la vez.
   - Los correos `ana`, `ana@` y `ana@x`. Comprobamos cuáles se rechazan y cuáles se aceptan.
   - Un contacto correcto, con teléfono y sin teléfono.
7. Abrimos `http://localhost:8080/v3/api-docs` y localizamos en el esquema de `Contacto` qué campos aparecen como obligatorios y cuáles llevan longitud máxima.
8. Hacemos un commit con los cambios.

**Pistas**

- `@NotBlank` rechaza `null`, la cadena vacía y la formada solo por espacios. `@NotNull` solo rechaza `null`.
- `@Email` comprueba el formato del correo, pero con una regla bastante permisiva. Qué direcciones acepta se averigua probando, no suponiendo.
- `@Size(max = 15)` no rechaza `null`. Por eso un teléfono ausente es válido, que es lo que queremos.
- `@Valid` va delante de `@RequestBody`, en el parámetro del método.
- Las dos propiedades que se necesitan empiezan por `spring.web.error.` y terminan en `include-message` e `include-binding-errors`, ambas con el valor `always`.
- Las longitudes máximas deben coincidir con las de las columnas de la tabla.

---

## Práctica 4: Swagger y validación en el proyecto del grupo

Se aplica lo mismo a la API del proyecto de cada grupo.

**Pasos**

1. Acordamos en el grupo quién añade los cambios y en qué rama o momento, para no pisarnos. Antes de empezar, cada integrante actualiza su copia con `git pull`.
2. Añadimos Swagger al proyecto del grupo y comprobamos que la página de documentación lista todas sus operaciones.
3. Documentamos la API: información general, etiqueta por controlador, resumen de cada operación, respuestas con los códigos reales y descripción y ejemplo de los campos de las entidades.
4. Elegimos al menos dos entidades del proyecto y les añadimos reglas de validación coherentes con su tabla en la base de datos: campos obligatorios, longitudes máximas y, si procede, formato.
5. Probamos desde Swagger las operaciones de creación con datos correctos y con datos incorrectos, y comprobamos que la API responde con 400 y un mensaje que dice qué hay que corregir.
6. Hacemos un commit con un mensaje claro y lo enviamos al repositorio del grupo (`git push`).

**Pistas**

- Si una operación del proyecto devuelve algo distinto de lo que Swagger anuncia por defecto, se describe con `@ApiResponse`.
- Las reglas de validación se deciden mirando el script SQL de cada tabla: lo que la base de datos exige (`not null`, longitud de `varchar`) es lo que la validación debe comprobar antes.
- Si el proyecto ya devuelve errores propios (por ejemplo, un 404 con un mensaje), la validación convive con ellos: solo actúa sobre los parámetros marcados con `@Valid`.
