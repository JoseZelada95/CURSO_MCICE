# S11-2 Demos

## Objetivos

Una API solo es útil si quien la consume sabe qué rutas ofrece, qué datos espera y qué responde. En las sesiones anteriores esa información vivía en la cabeza de quien escribió el controlador y se probaba con Postman. En esta parte la API se documenta a sí misma: una página web, generada a partir del propio código, que lista cada operación y permite probarla sin salir del navegador.

La API también tiene que defenderse de los datos incorrectos. Una tarea sin título no debería llegar a la base de datos, donde el fallo sería un 500 difícil de interpretar. La validación declara las reglas con anotaciones sobre la clase y hace que la API responda con un 400 y un mensaje claro.

Trabajamos sobre el proyecto `tareas` de S11-1, el que ya usa Lombok y está en un repositorio de Git. Cada demo termina con un commit, para seguir el hábito de guardar cada cambio con un mensaje claro. Al final del documento hay una sección para instalar MongoDB, que se usa en la parte siguiente.

Al terminar esta parte los alumnos son capaces de:

- Añadir Swagger a una API de Spring Boot, abrir su página de documentación y probar desde ella cada operación.  
- Describir la API con `@OpenAPIDefinition`, `@Tag`, `@Operation`, `@ApiResponse` y `@Schema`.  
- Declarar reglas de validación con `@NotBlank` y `@Size`, activarlas con `@Valid` y leer la respuesta 400\.  
- Instalar MongoDB en su equipo y comprobar que funciona con `mongosh`.

---

## Demo 1: Swagger sobre la API de tareas

Cuando alguien necesita usar una API, lo primero que busca es su documentación: qué rutas hay, qué verbo usa cada una, qué datos se envían y qué se recibe. Escribirla a mano tiene un problema: se queda anticuada en cuanto el código cambia.

Hay cuatro nombres que conviene distinguir:

- **OpenAPI** es una especificación: un formato (JSON o YAML) estándar para describir una API REST. Es el "idioma" de la documentación.  
- **Swagger** es el nombre de un conjunto de herramientas construidas alrededor de OpenAPI. **Swagger UI** es la que nos interesa: una página web que lee una descripción OpenAPI y la muestra de forma interactiva.  
- **springdoc** es la librería que usamos nosotros. Lee los controladores de Spring MVC al arrancar la aplicación, genera la descripción OpenAPI a partir de ellos y publica Swagger UI.

El resultado es una documentación que se mantiene viva: si el código cambia, la página cambia, porque se genera de nuevo cada vez que la aplicación arranca.

El código de esta parte está en `s11-2-demos.zip`, dentro de la carpeta `tareas`. Contiene el proyecto en su estado final de la Demo 3\. Las clases y los ficheros que cambian se copian de ahí, o se escriben siguiendo el documento. Los demás (`TareaRepository`, `AplicacionTests`, el script SQL) son los de S11-1, sin cambios.

### Añadir el borrado

En S11-1 la API tenía dos operaciones, `GET` y `POST`. Para probar una API de verdad conviene que tenga también un `DELETE`. Abrimos el proyecto `tareas` de S11-1 en IntelliJ (`File > Open`) y, en `TareaController`, añadimos el método `eliminar`. Es el mismo procedimiento de S09: `existsById()` comprueba si hay una fila con ese id, y `deleteById()` la borra.

```java
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        // existsById() devuelve true si hay una fila con ese id. Lo comprobamos antes de borrar
        // para poder distinguir "borrada" (204) de "no existía" (404).
        if (!tareaRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        tareaRepository.deleteById(id);
        // 204 = hecho y sin cuerpo.
        return ResponseEntity.noContent().build();
    }
```

&nbsp;

IntelliJ subraya en rojo `DeleteMapping`, `PathVariable` y `ResponseEntity` porque no están importadas. Con el cursor sobre cada una, `Alt+Enter` y `Import class` las añade. Las rutas son `org.springframework.web.bind.annotation.DeleteMapping`, `org.springframework.web.bind.annotation.PathVariable` y `org.springframework.http.ResponseEntity`.

### La dependencia

Swagger se añade al `pom.xml` como cualquier otra librería. Dentro de `<dependencies>`, después de la dependencia `spring-boot-starter-webmvc`, añadimos:

```xml
		<dependency>
			<groupId>org.springdoc</groupId>
			<artifactId>springdoc-openapi-starter-webmvc-ui</artifactId>
			<version>3.1.1</version>
		</dependency>
```

&nbsp;

El nombre `springdoc-openapi-starter-webmvc-ui` se lee por partes: es el *starter* de springdoc para Spring **MVC** (el que usamos, frente a WebFlux) que incluye la interfaz (**ui**) de Swagger. A diferencia de las librerías que hemos usado hasta ahora, esta sí lleva `<version>`: el POM padre de Spring Boot no la gestiona, y hay que indicar una versión compatible con la de Spring Boot. La serie 3 de springdoc es la que corresponde a Spring Boot 4, y `3.1.1` es la que hemos usado para preparar esta parte.

Pulsamos **Load Maven Changes** (el icono `m` que aparece en el editor, o `Ctrl+Shift+O`) para que IntelliJ descargue la librería. No hace falta ninguna anotación ni ninguna clase de configuración: con la dependencia en el classpath, Spring Boot detecta springdoc al arrancar y publica la documentación.

### Abrir la página de documentación

Arrancamos `Aplicacion` con ▶ (con la variable de entorno `POSTGRES_PASSWORD` ya definida en su configuración de ejecución, como en S11-1). Springdoc publica dos direcciones nuevas:

- `http://localhost:8080/swagger-ui.html`: la página interactiva. Redirige a `http://localhost:8080/swagger-ui/index.html`.  
- `http://localhost:8080/v3/api-docs`: la descripción OpenAPI en JSON, de la que se alimenta la página. Es lo que leería una herramienta, no una persona.

Abrimos la primera en el navegador. La página muestra el título de la API, las operaciones agrupadas por el nombre del controlador y, al final, una sección `Schemas` con las clases que viajan en las peticiones y las respuestas. Cada operación aparece en una fila con el color de su verbo (`GET` azul, `POST` verde, `DELETE` rojo), su ruta y, al hacer clic, un panel con sus parámetros y sus respuestas posibles.

Un resumen de lo que describe `/v3/api-docs` para nuestra API (el JSON real es más largo, con los esquemas y los tipos):

<pre>
{
  "info": {
    "title": "OpenAPI definition",
    "version": "v0"
  },
  "paths": {
    "/api/tareas": {
      "get": {
        "tags": [
          "tarea-controller"
        ],
        "operationId": "listar",
        "responses": [
          "200"
        ]
      },
      "post": {
        "tags": [
          "tarea-controller"
        ],
        "operationId": "crear",
        "responses": [
          "201"
        ]
      }
    },
    "/api/tareas/{id}": {
      "delete": {
        "tags": [
          "tarea-controller"
        ],
        "operationId": "eliminar",
        "responses": [
          "200"
        ]
      }
    }
  }
}
</pre>

&nbsp;

Hay tres operaciones, las tres de `TareaController`, y la documentación las ha encontrado sola.

### Probar las operaciones desde la página

Probar desde la página sustituye a Postman para las comprobaciones rápidas. El procedimiento es el mismo en cada operación:

1. Hacemos clic en la fila de la operación para abrirla.  
2. Hacemos clic en `Try it out`. Los campos se vuelven editables.  
3. Rellenamos lo que haga falta (el cuerpo, el id).  
4. Hacemos clic en `Execute`. La página envía la petición y muestra debajo la respuesta del servidor: el código (`Code`) y el cuerpo (`Response body`).

**Listar.** En `GET /api/tareas`, `Try it out` y `Execute`. La respuesta es un 200 con la lista de tareas: primero las pendientes y, dentro de cada grupo, por título (el orden de S11-1).

**Crear.** En `POST /api/tareas`, `Try it out`. El cuadro de texto del cuerpo trae un ejemplo con valores de relleno (`string`, `0`, `true`). Lo sustituimos por:

```json
{
  "titulo": "Documentar la API",
  "descripcion": "Añadir Swagger"
}
```

&nbsp;

`Execute`. Respuesta esperada:

<pre>
HTTP/1.1 201 
Content-Type: application/json
Content-Length: 88
Date: Tue, 20 Oct 2026 06:10:53 GMT

{"titulo":"Documentar la API","descripcion":"Añadir Swagger","completada":false,"id":4}
</pre>

&nbsp;

El código es 201 (creada) y el cuerpo trae la tarea con el `id` que le ha dado la base de datos. Esa respuesta es el contrato de la operación.

**Borrar.** En `DELETE /api/tareas/{id}`, `Try it out`, escribimos en el campo `id` el que acaba de devolver la creación (aquí, `4`) y `Execute`:

<pre>
HTTP/1.1 204 
Date: Tue, 20 Oct 2026 06:10:54 GMT
</pre>

&nbsp;

204 quiere decir hecho y sin cuerpo. Si repetimos el borrado con un id que no existe, por ejemplo `99`:

<pre>
HTTP/1.1 404 
Content-Length: 0
Date: Tue, 20 Oct 2026 06:10:54 GMT
</pre>

&nbsp;

### Lo que la documentación todavía no dice

La documentación generada sin ayuda es correcta pero fría. Si miramos con atención la página, falta mucho de lo que necesitaría quien consume la API:

- El título es genérico: `OpenAPI definition`, versión `v0`.  
- Las operaciones están agrupadas bajo `tarea-controller`, el nombre de la clase convertido en etiqueta.  
- Ninguna operación tiene una descripción en lenguaje claro.  
- La operación `DELETE` aparece con una única respuesta `200`, porque springdoc deduce los códigos de la firma del método y no puede saber que el método devuelve 204 o 404\.

Eso lo corregimos en la Demo 2\. Guardamos el cambio de esta demo en Git, desde la terminal de IntelliJ (`Alt+F12`):

```sh
git add .
git commit -m "Añadir el borrado de tareas y Swagger"
```

&nbsp;

---

## Demo 2: Describir la API con anotaciones

Las anotaciones de Swagger no cambian lo que hace el código: añaden información que la página muestra. Se escriben junto al método o el campo que describen, así que la documentación se actualiza en el mismo momento en que se cambia el código. Todas proceden de la librería que ya hemos añadido, y viven en el paquete `io.swagger.v3.oas.annotations`.

### Datos generales: @OpenAPIDefinition

Para cambiar el título, la versión y la descripción de la cabecera, añadimos a la clase `Aplicacion` la anotación `@OpenAPIDefinition` con un `@Info`. Es la clase completa, tal como queda en el zip:

```java
package com.curso;

// SpringApplication y @SpringBootApplication proceden de Spring Boot. Maven las ha
// descargado con los starters declarados en el pom.xml: no hay que buscarlas a mano.
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// Estas anotaciones proceden de springdoc-openapi (Swagger), que Maven ha descargado con
// springdoc-openapi-starter-webmvc-ui. Describen la API completa en la cabecera de la página.
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;

/**
 * S11-2 Demo 2: Clase principal con la descripción general de la API
 *
 * Objetivo: dar a la página de Swagger un título, una versión y una descripción propios.
 *
 * Lo que hace este ejemplo:
 *   - Arranca la aplicación de tareas, igual que en S11-1
 *   - Declara con @OpenAPIDefinition los datos generales de la API
 *
 * Concepto clave: sin esta anotación Swagger pone el título genérico "OpenAPI definition".
 * Con ella, quien abre la página sabe a qué API pertenece y en qué versión está.
 */
// @SpringBootApplication marca la clase de arranque: Spring escanea su paquete (com.curso)
// y los subpaquetes (model, repository, controller) y crea los beans que encuentra.
@SpringBootApplication
// @OpenAPIDefinition con @Info rellena la cabecera de la página de documentación.
@OpenAPIDefinition(info = @Info(
        title = "API de tareas",
        version = "1.0",
        description = "API REST para consultar, crear y borrar tareas, guardadas en PostgreSQL"))
public class Aplicacion {

    // main() es el punto de entrada del programa. SpringApplication.run() crea el contenedor,
    // lo arranca y deja el servidor esperando peticiones.
    public static void main(String[] args) {
        SpringApplication.run(Aplicacion.class, args);
    }

}
```

&nbsp;

`@Info` tiene un atributo por cada dato de la cabecera: `title`, `version` y `description`. Al volver a arrancar, `/v3/api-docs` muestra:

<pre>
{
  "title": "API de tareas",
  "description": "API REST para consultar, crear y borrar tareas, guardadas en PostgreSQL",
  "version": "1.0"
}
</pre>

&nbsp;

### Agrupar y describir las operaciones: @Tag y @Operation

En `TareaController`, `@Tag` se pone sobre la clase y sustituye el nombre `tarea-controller` por el que queramos, con una descripción:

```java
@Tag(name = "Tareas", description = "Consulta, alta y borrado de tareas")
public class TareaController {
```

&nbsp;

`@Operation` se pone sobre cada método. Tiene dos textos: `summary`, una línea corta que aparece en la fila de la operación, y `description`, el detalle que aparece al abrirla. Por ejemplo, en `listar()`:

```java
    @Operation(summary = "Lista las tareas",
            description = "Devuelve todas las tareas: primero las pendientes y, dentro de cada grupo, ordenadas por título.")
```

&nbsp;

### Describir las respuestas: @ApiResponse y @ApiResponses

`@ApiResponse` describe un código de respuesta: `responseCode` es el código (como texto) y `description` dice cuándo se devuelve. Cuando un método puede devolver varios, se agrupan con `@ApiResponses`. Así corregimos el `DELETE`, que antes mostraba un único 200:

```java
    @Operation(summary = "Borra una tarea", description = "Borra la tarea con el id indicado.")
    @ApiResponses({
            @ApiResponse(responseCode = "204", description = "Tarea borrada"),
            @ApiResponse(responseCode = "404", description = "No existe ninguna tarea con ese id", content = @Content)
    })
    @DeleteMapping("/{id}")
```

&nbsp;

El atributo `content = @Content` merece una explicación. Para cada respuesta, Swagger anuncia por defecto que el cuerpo es el tipo que devuelve el método (aquí, una `Tarea`). Un 404 o un 400 no devuelven ninguna tarea, y mostrarlo así confunde. `@Content` vacío le dice que esa respuesta no trae un cuerpo con esa forma. `@Content` es otra clase de Swagger y hay que importarla (`io.swagger.v3.oas.annotations.media.Content`).

En `crear()` se describen el 201 y el 400, y en `listar()` el 200 con una sola `@ApiResponse`, sin `@ApiResponses`. El controlador completo, con la validación de la Demo 3, está más abajo.

### Describir los datos: @Schema

`@Schema` describe una clase o un campo, y es lo que aparece en la sección `Schemas` y en el ejemplo del cuerpo de las peticiones. Sobre la clase da la descripción de la entidad; sobre cada campo, su descripción y un valor de ejemplo:

```java
@Schema(description = "Tarea de una lista de tareas pendientes")
public class Tarea {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Identificador de la tarea, generado por la base de datos", example = "4",
            accessMode = Schema.AccessMode.READ_ONLY)
    private Long id;

    @Schema(description = "Título breve de la tarea", example = "Documentar la API")
    private String titulo;
```

&nbsp;

`example` es el valor que Swagger pone en el cuerpo de ejemplo en lugar del `string` de relleno, de modo que quien prueba la API tiene un cuerpo válido a un clic. `accessMode = READ_ONLY` marca un campo que solo se lee: el `id` lo genera la base de datos, así que no aparece en el ejemplo de la petición de alta.

Al recargar la página, el título y la descripción de la cabecera son los nuestros, las operaciones están bajo `Tareas` con su resumen, el `DELETE` anuncia sus dos respuestas y el cuerpo de ejemplo del `POST` trae valores con sentido. La documentación ya se entiende sin preguntar a quien escribió el código.

Guardamos el cambio:

```sh
git add .
git commit -m "Describir la API de tareas con anotaciones de Swagger"
```

&nbsp;

---

## Demo 3: Validación con @Valid

Si en Swagger enviamos un `POST` con un cuerpo vacío (`{}`), la tarea llega al repositorio sin título. La base de datos tiene la columna `titulo` con `not null`, así que la rechaza, y lo que recibe el cliente es esto:

<pre>
HTTP/1.1 500 
Content-Type: application/json
Transfer-Encoding: chunked
Date: Tue, 20 Oct 2026 06:16:09 GMT
Connection: close

{"timestamp":"2026-10-20T06:16:09.049Z","status":500,"error":"Internal Server Error","path":"/api/tareas"}
</pre>

&nbsp;

Un 500 y ningún motivo. El fallo no es del servidor sino de quien envió el dato, pero la API lo comunica como si lo fuera, y el mensaje real (`null value in column "titulo"... violates not-null constraint`) solo está en el log del servidor. La **validación** corrige eso: comprueba los datos al entrar en el método del controlador, antes de tocar la base de datos, y responde con un 400 que dice qué campo falla.

### La dependencia

La validación se hace con **Jakarta Bean Validation**, el estándar de Java para declarar reglas con anotaciones. Spring Boot lo empaqueta en un starter. Después de la dependencia de springdoc, añadimos:

```xml
		<dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-starter-validation</artifactId>
		</dependency>
```

&nbsp;

Esta sí lleva la versión gestionada por Spring Boot, así que no se escribe `<version>`. **Load Maven Changes** otra vez.

### Las reglas en la entidad

Las reglas se declaran sobre los campos de `Tarea`:

```java
    @NotBlank(message = "El título es obligatorio")
    @Size(max = 100, message = "El título admite como máximo 100 caracteres")
    @Schema(description = "Título breve de la tarea", example = "Documentar la API")
    private String titulo;

    @Size(max = 255, message = "La descripción admite como máximo 255 caracteres")
    @Schema(description = "Detalle opcional de la tarea", example = "Añadir Swagger y describir cada operación")
    private String descripcion;
```

&nbsp;

- **`@NotBlank`** exige que el texto no sea `null`, ni esté vacío, ni tenga solo espacios. Hay otras dos parecidas que no hacen lo mismo: `@NotNull` solo rechaza `null` (admite `""`), y `@NotEmpty` rechaza `null` y `""` (pero admite `"   "`). Para un texto que debe tener contenido, `@NotBlank` es la correcta.  
- **`@Size(max = 100)`** limita la longitud del texto. Debe coincidir con la de la columna (`varchar(100)`): así el rechazo ocurre en la validación y no en la base de datos.  
- **`message`** es el texto que recibirá quien envíe el dato incorrecto. Sin él, Spring usa un mensaje genérico en inglés.  
- La descripción no lleva `@NotBlank` porque es opcional: la columna admite `null`. Solo se limita su longitud.

Estos atributos viven en la clase, no en un método. Se escriben una vez y valen para cada operación que reciba una `Tarea`.

### Activar la validación: @Valid

Las anotaciones por sí solas no comprueban nada. Se activan en el parámetro del método del controlador con `@Valid`:

```java
    public Tarea crear(@Valid @RequestBody Tarea tarea) {
```

&nbsp;

`@Valid` pide a Spring que, antes de ejecutar el método, compruebe las reglas del objeto que acaba de construir con el JSON. Si alguna falla, el método no se ejecuta y Spring responde con un 400\. `Valid` procede de `jakarta.validation.Valid` (hay que importarla).

### Ver los errores en la respuesta

Por defecto, la respuesta de error de Spring Boot trae solo el estado y la ruta: `{"timestamp": ..., "status": 400, "error": "Bad Request", "path": "/api/tareas"}`. Dos propiedades en `application.properties` hacen que añada el motivo y la lista de errores de validación:

```properties
# Cuando una petición es rechazada, la respuesta de error de Spring Boot solo trae el estado
# (400) y la ruta. Con estas dos propiedades añade también un mensaje y la lista de errores
# de validación (qué campo falló y por qué), para que quien consume la API sepa qué corregir.
spring.web.error.include-message=always
spring.web.error.include-binding-errors=always
```

&nbsp;

Las añadimos al final del fichero. Arrancamos otra vez y, en Swagger, probamos el `POST` con un título vacío:

```json
{
  "titulo": ""
}
```

&nbsp;

Respuesta:

<pre>
{"timestamp":"2026-10-20T06:10:54.223Z","status":400,"error":"Bad Request","message":"Validation failed for object='tarea'. Error count: 1","errors":[{"objectName":"tarea","field":"titulo","rejectedValue":"","codes":["NotBlank.tarea.titulo","NotBlank.titulo","NotBlank.java.lang.String","NotBlank"],"arguments":[{"arguments":null,"code":"titulo","codes":["tarea.titulo","titulo"],"defaultMessage":"titulo"}],"bindingFailure":false,"code":"NotBlank","defaultMessage":"El título es obligatorio"}],"path":"/api/tareas"}
</pre>

&nbsp;

Es larga, pero solo hay que leer cuatro cosas: `status` (400), `message` (resume cuántos errores hay), y, dentro de `errors`, el `field` que falla (`titulo`) y el `defaultMessage`, que es el texto que escribimos en `message` (`El título es obligatorio`). El resto de campos (`codes`, `arguments`...) son detalle interno de Spring.

Con un título de 101 caracteres, la regla que falla es la de longitud:

<pre>
{"timestamp":"2026-10-20T06:10:54.236Z","status":400,"error":"Bad Request","message":"Validation failed for object='tarea'. Error count: 1","errors":[{"objectName":"tarea","field":"titulo","rejectedValue":"xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx","codes":["Size.tarea.titulo","Size.titulo","Size.java.lang.String","Size"],"arguments":[{"arguments":null,"code":"titulo","codes":["tarea.titulo","titulo"],"defaultMessage":"titulo"},100,0],"bindingFailure":false,"code":"Size","defaultMessage":"El título admite como máximo 100 caracteres"}],"path":"/api/tareas"}
</pre>

&nbsp;

Cuando falla más de una regla, `errors` trae un elemento por cada una.

Swagger también ha leído las reglas, sin que tengamos que repetirlas. En el esquema de `Tarea` que publica `/v3/api-docs` aparece `titulo` como obligatorio (`required`) y con `maxLength` en el título y en la descripción:

<pre>
{
  "Tarea": {
    "type": "object",
    "description": "Tarea de una lista de tareas pendientes",
    "properties": {
      "id": {
        "type": "integer",
        "format": "int64",
        "description": "Identificador de la tarea, generado por la base de datos",
        "example": 4,
        "readOnly": true
      },
      "titulo": {
        "type": "string",
        "description": "Título breve de la tarea",
        "example": "Documentar la API",
        "maxLength": 100,
        "minLength": 0
      },
      "descripcion": {
        "type": "string",
        "description": "Detalle opcional de la tarea",
        "example": "Añadir Swagger y describir cada operación",
        "maxLength": 255,
        "minLength": 0
      },
      "completada": {
        "type": "boolean",
        "description": "true si la tarea está terminada",
        "example": false
      }
    },
    "required": [
      "titulo"
    ]
  }
}
</pre>

&nbsp;

La sección `Schemas` de la página muestra lo mismo: un asterisco rojo junto a `titulo` y la longitud máxima de cada campo. Quien consume la API conoce las reglas antes de equivocarse.

### El código completo

Las tres clases quedan así (son las del zip). La entidad:

```java
package com.curso.model;

// Importamos las anotaciones de JPA (Jakarta Persistence), el estándar de Java para
// guardar objetos en bases de datos. Maven las ha descargado al declarar
// spring-boot-starter-data-jpa en el pom.xml: no hay que buscarlas ni instalarlas a mano.
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

// Importamos las anotaciones de validación (Jakarta Bean Validation). Maven las ha descargado
// al declarar spring-boot-starter-validation en el pom.xml. Describen las reglas que debe
// cumplir cada campo; se comprueban cuando el controlador recibe la tarea con @Valid.
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

// Importamos @Schema de Swagger. Maven la ha descargado con springdoc-openapi-starter-webmvc-ui.
// Sirve para describir la entidad y sus campos en la página de documentación.
import io.swagger.v3.oas.annotations.media.Schema;

// Importamos las anotaciones de Lombok. Maven ha descargado la librería al declarar
// org.projectlombok:lombok en el pom.xml. Lombok las lee al compilar y escribe por nosotros
// el código repetitivo, que queda dentro del .class pero no aparece en el .java.
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * S11-2 Demo 3: Entidad Tarea documentada y validada
 *
 * Objetivo: describir en la propia entidad qué es cada campo y qué datos se aceptan.
 *
 * Lo que hace este ejemplo:
 *   - Declara la entidad Tarea sobre la tabla tarea de PostgreSQL, con Lombok como en S11-1
 *   - Describe la entidad y cada campo con @Schema, para la página de Swagger
 *   - Exige un título con texto y limita la longitud de título y descripción
 *
 * Concepto clave: las reglas de validación viven en la clase. Se escriben una vez y se aplican
 * en cada operación que recibe una Tarea, y Swagger las muestra como parte de la documentación.
 */
@Entity
// @Schema sobre la clase da la descripción de la entidad en la sección Schemas de Swagger.
@Schema(description = "Tarea de una lista de tareas pendientes")
@Getter
@Setter
@NoArgsConstructor
public class Tarea {

    // @Id marca la clave primaria; @GeneratedValue con IDENTITY hace que la genere
    // la base de datos (columna autoincremental). Es Long y no long porque una tarea
    // nueva todavía no tiene id y vale null hasta que se guarda.
    // accessMode = READ_ONLY indica a Swagger que el id solo se lee: lo genera la base de datos
    // y no aparece en el ejemplo de la petición de alta.
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Identificador de la tarea, generado por la base de datos", example = "4",
            accessMode = Schema.AccessMode.READ_ONLY)
    private Long id;

    // @NotBlank exige que el título no sea null, ni esté vacío, ni tenga solo espacios.
    // @Size(max = 100) limita la longitud, igual que el varchar(100) de la tabla.
    // El texto de message es el que recibe quien envía un título incorrecto.
    @NotBlank(message = "El título es obligatorio")
    @Size(max = 100, message = "El título admite como máximo 100 caracteres")
    @Schema(description = "Título breve de la tarea", example = "Documentar la API")
    private String titulo;

    // Aquí no usamos @NotBlank porque la descripción es opcional (la columna admite null).
    // Solo limitamos su longitud, igual que el varchar(255) de la tabla.
    @Size(max = 255, message = "La descripción admite como máximo 255 caracteres")
    @Schema(description = "Detalle opcional de la tarea", example = "Añadir Swagger y describir cada operación")
    private String descripcion;

    // Un boolean no puede ser null, así que no necesita reglas de validación.
    @Schema(description = "true si la tarea está terminada", example = "false")
    private boolean completada;

    // Este constructor sí lo escribimos nosotros: Lombok no sabe qué campos queremos recibir.
    // @AllArgsConstructor incluiría también el id y completada, que no debemos indicar al crear una tarea.
    public Tarea(String titulo, String descripcion) {
        this.titulo = titulo;
        this.descripcion = descripcion;
    }

    // toString() devuelve el texto con el que se imprime la tarea;
    // @Override avisa al compilador de que reescribimos el método heredado de Object.
    // Lombok tiene @ToString, pero lo escribimos nosotros para decidir qué campos se imprimen.
    @Override
    public String toString() {
        return "Tarea{id=" + id + ", titulo='" + titulo + "', completada=" + completada + "}";
    }
}
```

&nbsp;

El controlador:

```java
package com.curso.controller;

import java.util.List;

// Sort procede de Spring Data e indica por qué campos se ordena una consulta.
// HttpStatus enumera los códigos de estado de HTTP y ResponseEntity representa la respuesta
// completa (estado y cuerpo). Ambas proceden de Spring, que Maven trae con los starters del pom.xml.
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

// @Valid procede de Jakarta Bean Validation, que Maven ha descargado al declarar
// spring-boot-starter-validation en el pom.xml. Pide a Spring que compruebe las reglas
// de la clase antes de ejecutar el método.
import jakarta.validation.Valid;

// Estas anotaciones proceden de Spring MVC, que Maven trae con spring-boot-starter-webmvc.
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.curso.model.Tarea;
import com.curso.repository.TareaRepository;

// Estas anotaciones proceden de springdoc-openapi (Swagger), que Maven ha descargado con
// springdoc-openapi-starter-webmvc-ui. Describen el controlador y sus operaciones para la
// página de documentación; no cambian lo que hace el código.
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

// RequiredArgsConstructor procede de Lombok, que Maven ha descargado con el pom.xml.
import lombok.RequiredArgsConstructor;

/**
 * S11-2 Demo 3: Controlador REST de tareas documentado y validado
 *
 * Objetivo: ofrecer la lista, el alta y el borrado de tareas como API REST, con su documentación
 * en Swagger y rechazando los datos incorrectos con un 400.
 *
 * Lo que hace este ejemplo:
 *   - GET /api/tareas devuelve todas las tareas en JSON
 *   - POST /api/tareas valida la tarea recibida, la guarda y devuelve 201
 *   - DELETE /api/tareas/{id} borra la tarea y devuelve 204, o 404 si no existe
 *   - Describe cada operación y cada código de respuesta con anotaciones de Swagger
 *
 * Concepto clave: la documentación y la validación se declaran con anotaciones. El código de
 * cada método sigue siendo el mismo; las anotaciones añaden descripción y reglas.
 */
@RestController
@RequestMapping("/api/tareas")
@RequiredArgsConstructor
// @Tag agrupa las operaciones del controlador bajo un nombre en la página de Swagger.
@Tag(name = "Tareas", description = "Consulta, alta y borrado de tareas")
public class TareaController {

    // final = el campo se asigna una sola vez, en el constructor que genera Lombok.
    private final TareaRepository tareaRepository;

    /**
     * Devuelve todas las tareas: primero las pendientes y, dentro de cada grupo, por título.
     *
     * Ejemplo:
     *   GET /api/tareas  →  [{"titulo":"Cerrar la sesión", ..., "id":3}, {"titulo":"Compartir el proyecto", ..., "id":4}, ...]
     */
    // @Operation da el resumen (una línea) y la descripción (más detalle) de la operación.
    // @ApiResponse describe uno de los códigos que puede devolver.
    @Operation(summary = "Lista las tareas",
            description = "Devuelve todas las tareas: primero las pendientes y, dentro de cada grupo, ordenadas por título.")
    @ApiResponse(responseCode = "200", description = "Lista de tareas, vacía si no hay ninguna")
    @GetMapping
    public List<Tarea> listar() {
        // findAll(Sort) devuelve todas las filas de la tabla tarea ordenadas por los campos indicados.
        return tareaRepository.findAll(Sort.by("completada", "titulo"));
    }

    /**
     * Guarda una tarea nueva.
     *
     * Ejemplo:
     *   POST /api/tareas  {"titulo": "Comprar café"}  →  201 y la tarea con su id
     *   POST /api/tareas  {"titulo": ""}              →  400 (el título es obligatorio)
     */
    // @ApiResponses agrupa varias @ApiResponse cuando una operación puede devolver más de un código.
    // content = @Content (vacío) indica que esa respuesta no devuelve una tarea, para que Swagger no la anuncie.
    @Operation(summary = "Crea una tarea",
            description = "Guarda una tarea nueva. El id lo genera la base de datos y el título es obligatorio.")
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "Tarea creada, con su id"),
            @ApiResponse(responseCode = "400", description = "Datos no válidos: título vacío o campos demasiado largos", content = @Content)
    })
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    // @Valid hace que Spring compruebe las reglas de Tarea (@NotBlank, @Size) antes de entrar
    // en el método. Si alguna falla, el método no se ejecuta y Spring responde con un 400.
    public Tarea crear(@Valid @RequestBody Tarea tarea) {
        // Anulamos el id recibido: save() inserta si el id es null y actualiza si existe,
        // y aquí queremos que siempre cree una tarea nueva.
        tarea.setId(null);
        return tareaRepository.save(tarea);
    }

    /**
     * Borra una tarea por su id.
     *
     * Ejemplo:
     *   DELETE /api/tareas/3   →  204 (borrada, sin cuerpo)
     *   DELETE /api/tareas/99  →  404 (no existe)
     */
    @Operation(summary = "Borra una tarea", description = "Borra la tarea con el id indicado.")
    @ApiResponses({
            @ApiResponse(responseCode = "204", description = "Tarea borrada"),
            @ApiResponse(responseCode = "404", description = "No existe ninguna tarea con ese id", content = @Content)
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        // existsById() devuelve true si hay una fila con ese id. Lo comprobamos antes de borrar
        // para poder distinguir "borrada" (204) de "no existía" (404).
        if (!tareaRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        tareaRepository.deleteById(id);
        // 204 = hecho y sin cuerpo.
        return ResponseEntity.noContent().build();
    }
}
```

&nbsp;

Y el `application.properties` completo:

```properties
# Nombre de la aplicación: aparece entre corchetes en cada línea del log.
spring.application.name=tareas

# Conexión a PostgreSQL: dirección de la base de datos tareas, usuario y contraseña.
# La contraseña no se escribe aquí porque este fichero se guarda en el repositorio:
# se lee de la variable de entorno POSTGRES_PASSWORD.
spring.datasource.url=jdbc:postgresql://localhost:5432/tareas
spring.datasource.username=postgres
spring.datasource.password=${POSTGRES_PASSWORD}

# validate: Hibernate no toca las tablas (las crea el script SQL), solo comprueba al arrancar
# que cada entidad coincide con su tabla.
spring.jpa.hibernate.ddl-auto=validate

# Desactiva la sesión de Hibernate abierta durante la vista (como en las sesiones anteriores).
spring.jpa.open-in-view=false

# Escribe en la consola cada sentencia SQL que genera Hibernate.
spring.jpa.show-sql=true

# Cuando una petición es rechazada, la respuesta de error de Spring Boot solo trae el estado
# (400) y la ruta. Con estas dos propiedades añade también un mensaje y la lista de errores
# de validación (qué campo falló y por qué), para que quien consume la API sepa qué corregir.
spring.web.error.include-message=always
spring.web.error.include-binding-errors=always
```

&nbsp;

Guardamos el cambio y lo enviamos al repositorio remoto de S11-1:

```sh
git add .
git commit -m "Validar las tareas con Bean Validation"
git push
```

&nbsp;

---

## Instalar MongoDB

La parte siguiente trabaja con MongoDB. Para que esa sesión se dedique a usarlo y no a instalarlo, cada persona lo instala ahora en su equipo. MongoDB es una base de datos distinta de las que hemos usado: no guarda tablas y filas, sino documentos con forma de JSON. Hace falta el servidor (el programa que guarda los datos y queda funcionando en segundo plano, como PostgreSQL) y la consola `mongosh`, desde la que se le hacen consultas.

La edición gratuita se llama **MongoDB Community**. Funciona en Windows 11 (64 bits) y escucha por defecto en `localhost`, puerto `27017`.

### Instalar el servidor

1. Abrimos `https://www.mongodb.com/try/download/community` en el navegador.  
2. Elegimos **Version**: la más reciente que ofrezca la página; **Platform**: `Windows`; **Package**: `msi`. Hacemos clic en `Download`.  
3. Abrimos el fichero descargado (en `Descargas`) con doble clic. Windows pide confirmar con `Sí`.  
4. En el asistente: `Next`, aceptamos la licencia y `Next`.  
5. **Setup Type**: `Complete`.  
6. **Service Configuration**: dejamos marcada **Install MongoD as a Service** y todo lo que viene por defecto (**Run the service as Network Service user**, nombre del servicio `MongoDB` y las carpetas de datos y de registro que propone). Con esto MongoDB arranca solo con Windows. Hacemos clic en `Next`.  
7. **Install MongoDB Compass**: la dejamos marcada. Compass es una aplicación gráfica para explorar los datos, que podemos usar o no. `Next` e `Install`.  
8. Al terminar, `Finish`.

Para comprobar que el servidor está en marcha, abrimos los servicios de Windows (`Win+R`, escribimos `services.msc` y Enter) y buscamos el servicio `MongoDB`: su estado debe ser **En ejecución**.

### Instalar mongosh

El instalador anterior no incluye la consola `mongosh`: se instala aparte.

1. Abrimos `https://www.mongodb.com/try/download/shell`.  
2. Elegimos **Platform**: `Windows` y **Package**: `msi`, y hacemos clic en `Download`.  
3. Ejecutamos el instalador con las opciones por defecto.

### Comprobar que funciona

Abrimos una terminal **nueva** (para que reconozca el programa recién instalado) y escribimos:

```sh
mongosh --version
```

&nbsp;

Debe mostrar un número de versión. Si responde que `mongosh` no se reconoce como un comando, hay que añadir la carpeta donde se instaló al `PATH` de Windows (el instalador suele hacerlo; si no, se puede reinstalar marcando esa opción) o cerrar y volver a abrir la terminal.

Para conectarnos al servidor:

```sh
mongosh
```

&nbsp;

Sin argumentos, `mongosh` se conecta a `mongodb:// 127.0.0.1: 27017`, el servidor local. Aparece un texto de bienvenida y el indicador cambia a `test>`. Escribimos:

db.runCommand({ ping: 1 })

&nbsp;

Respuesta esperada:

<pre>
{ ok: 1 }
</pre>

&nbsp;

`ok: 1` quiere decir que el servidor responde. Salimos con `exit`. Si `mongosh` tarda y termina con un error de conexión (`ECONNREFUSED`), el servicio no está en marcha: se arranca desde la consola de servicios (clic derecho sobre `MongoDB` y `Iniciar`).