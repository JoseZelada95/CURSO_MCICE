# S11-1 Prácticas

## Objetivos

Se aplica lo aprendido en las demos con un proyecto propio. Las dos primeras prácticas trabajan sobre un proyecto nuevo y pequeño, `contactos`: una agenda de contactos con una sola clase, sin base de datos, para que la atención se dedique a Git. En la primera se versiona el proyecto desde cero con la línea de comandos y se envía a un repositorio remoto propio. En la segunda se repite el recorrido completo desde IntelliJ. La tercera práctica lleva el proyecto de cada grupo a un repositorio remoto compartido, con acceso para todos los integrantes, y provoca a propósito un conflicto para resolverlo.

En todas las prácticas los mensajes de commit explican qué cambia, en una frase corta. Y en `cmd` el texto de los mensajes se escribe con comillas dobles.

---

## Práctica 1: Repositorio de contactos

Se crea el proyecto `contactos` con Spring Boot y Lombok, se escribe la clase `Contacto`, se versiona el proyecto desde cero con la línea de comandos, con tres commits y un historial legible, y se envía a un repositorio remoto propio.

**Pasos**

1. Creamos un proyecto nuevo con `File > New > Project` y, en el panel izquierdo, `Generators > Spring Boot`. Name `contactos`, Type `Maven`, Language `Java`, Group `com.curso`, Artifact `contactos`, Package name `com.curso`, JDK `21`, Java `21`, Packaging `Jar` y Configuration `Properties`. En la segunda pantalla dejamos Spring Boot `4.1.1` y marcamos como única dependencia `Lombok` (dentro de `Developer Tools`). Hacemos clic en `Create`.
2. Renombramos las clases que genera el asistente con `Shift+F6`: la principal pasa a llamarse `Aplicacion` y la de `src/test/java`, `AplicacionTests`.
3. Comprobamos en la terminal de IntelliJ (`Alt+F12`) que Git está instalado y que el nombre, el correo, el nombre de la rama principal y la forma de hacer `pull` están configurados.
4. Creamos el repositorio en la carpeta del proyecto y consultamos el estado. Comprobamos que `.idea`, `target` y `HELP.md` no aparecen entre los ficheros sin seguimiento, y explicamos por qué.
5. Preparamos todo el proyecto y hacemos el primer commit, con un mensaje que diga que es el proyecto generado.
6. Creamos el paquete `com.curso.model` (clic derecho sobre `src/main/java`, `New > Package`) y dentro la clase `Contacto`, con tres campos de tipo `String`: `nombre`, `email` y `telefono`. Usamos Lombok para generar los getters, los setters y el constructor vacío, y escribimos a mano un constructor que reciba los tres datos.
7. Consultamos el estado, preparamos solo la carpeta `src` y hacemos el segundo commit.
8. Creamos el paquete `com.curso.model` en `src/test/java` (clic derecho sobre `src/test/java`, `New > Package`) y dentro la clase `ContactoTests`, con dos tests: uno que compruebe que el constructor guarda los tres datos y que los getters los devuelven, y otro que compruebe que `setEmail()` cambia el correo.
9. Ejecutamos los tests con ▶ junto al nombre de la clase y comprobamos que pasan. Hacemos el tercer commit.
10. Consultamos el historial con una línea por commit y comprobamos que aparecen los tres, del más reciente al más antiguo.
11. Creamos en GitHub un repositorio nuevo, privado y **vacío** (sin README, sin `.gitignore` y sin licencia) llamado `contactos`. Disponemos de un token de acceso personal clásico con el alcance `repo` (el de la Demo 3 si no ha caducado, o uno nuevo).
12. Enlazamos el repositorio local con el remoto y enviamos la rama principal dejándola enlazada con la del remoto. Comprobamos con el estado que la rama local coincide con `origin/main` y, en GitHub, que aparecen los tres commits y que `target` y `.idea` no están.

**Pistas**

- En el generador, `Lombok` está en la categoría `Developer Tools`. Si no se marca, el `pom.xml` no tendrá la dependencia y las anotaciones no se reconocen. Se puede añadir a mano después, con `<optional>true</optional>` y sin `<version>`, y pulsando **Load Maven Changes**.
- Si IntelliJ subraya en rojo `getNombre()` pero el proyecto compila, falta activar el procesamiento de anotaciones: `File > Settings > Build, Execution, Deployment > Compiler > Annotation Processors`, **Enable annotation processing**.
- Las anotaciones de Lombok que se necesitan son `@Getter`, `@Setter` y `@NoArgsConstructor`.
- Con `git add .` se prepara todo lo que no está ignorado; con `git add src` solo la carpeta indicada. Conviene ejecutar `git status` antes de cada commit para saber exactamente qué va a entrar.
- Un buen mensaje de commit describe el cambio, no el trabajo: "Añadir la clase Contacto" dice más que "cambios" o "segundo commit".
- Si el comando `git commit` se queda esperando en una pantalla de texto, es que faltó la opción `-m` y Git está pidiendo el mensaje en un editor.
- El ▶ junto al nombre de una clase de tests ejecuta todos sus tests; junto a un método, solo ese.
- La dirección del repositorio remoto se copia desde la página que muestra GitHub al crearlo, en la pestaña `HTTPS`. Si `git push` responde que la rama `main` no existe, el repositorio se creó con otro nombre de rama: `git branch` muestra cuál es.
- En las credenciales, el usuario es el nombre de la cuenta de GitHub y la contraseña es el token.

---

## Práctica 2: Flujo completo en IntelliJ

Se realiza desde IntelliJ un ciclo completo sobre `contactos`: dos cambios con su comparación y su commit, consulta del historial y envío al remoto. La terminal se usa solo para comprobar al final.

**Pasos**

1. Partimos del proyecto de la práctica anterior, con el árbol de trabajo limpio y enlazado con el remoto.
2. Añadimos a `Contacto` un método `resumen()` que devuelva el nombre y, entre paréntesis, el correo y el teléfono separados por una coma y un espacio. Por ejemplo, `Lucía Pérez (lucia@example.com, 600123456)`. Añadimos a `ContactoTests` un test que compruebe ese resultado.
3. Abrimos la ventana de commit (`Alt+0`) y revisamos la comparación de cada fichero (`Ctrl+D`): identificamos qué líneas son nuevas en cada uno. Hacemos el commit desde ahí, con un mensaje que explique el cambio.
4. Añadimos a `Contacto` un método `emailValido()` que devuelva `true` si el correo tiene una arroba, tiene un punto y no tiene ningún espacio. Añadimos a `ContactoTests` dos tests: uno que compruebe que un correo correcto es válido y otro que compruebe que un correo sin punto o con un espacio no lo es.
5. Ejecutamos todos los tests de la clase con ▶, revisamos otra vez la comparación y hacemos el segundo commit desde la ventana de commit.
6. Abrimos la ventana de Git (`Alt+9`, pestaña `Log`) y comprobamos que aparecen los cinco commits. Seleccionamos el commit del primer cambio y abrimos la comparación de uno de sus ficheros.
7. En la terminal de IntelliJ, consultamos el estado y comprobamos qué dice sobre la relación con `origin/main`.
8. Enviamos los dos commits al remoto desde IntelliJ, sin usar la terminal, con el menú `Git`. Comprobamos en GitHub que aparecen y, en la terminal, que el estado vuelve a decir que la rama coincide con `origin/main`.

**Pistas**

- En un `boolean`, la condición `&&` exige que se cumplan las dos a la vez, y `!` niega una condición. El método `contains()` de `String` devuelve `true` si el texto contiene la cadena indicada.
- Un test con `assertTrue` o `assertFalse` comprueba directamente el valor `boolean` que devuelve el método. `assertEquals` compara dos valores.
- En la ventana de commit solo entran en el commit los ficheros con la casilla marcada. Si un fichero no debe entrar, se desmarca.
- Si el menú `Git` pide credenciales al enviar y no las recuerda, el usuario es el de la cuenta de GitHub y la contraseña es el token.
- Antes de enviar, el cuadro de diálogo de envío lista los commits que se van a subir. Conviene leerlos: deben ser los dos que acabamos de hacer.

---

## Práctica 3: Repositorio compartido del grupo

Cada grupo crea un repositorio remoto para su proyecto, sube el código que ya tiene (el CRUD y la API de las sesiones anteriores), da acceso al resto de integrantes y comprueba que todos pueden clonar, cambiar y enviar cambios. Después dos integrantes cambian a propósito la misma línea de un fichero y resuelven el conflicto.

Esta práctica se hace en grupo. Los pasos 1 a 6 los realiza una persona del grupo (la que será dueña del repositorio); los pasos 7 a 12, todos los integrantes.

**Pasos**

1. Una persona crea en GitHub un repositorio nuevo, privado y **vacío** (sin README, sin `.gitignore` y sin licencia), con el nombre del proyecto del grupo.
2. En la carpeta del proyecto del grupo, comprobamos que existe el fichero `.gitignore` y que `application.properties` no contiene ninguna contraseña (la de la base de datos debe leerse de la variable de entorno `POSTGRES_PASSWORD`). Si algo no está bien, se corrige antes de continuar.
3. Creamos en la raíz del proyecto un fichero `README.md` con el nombre del proyecto, una frase que lo describa y una sección `Autores` que contenga una sola línea de lista con el texto `Pendiente de completar`.
4. Creamos el repositorio local, preparamos todo el proyecto y hacemos el primer commit. Comprobamos con el estado que `target` y `.idea` no entran.
5. Creamos un token de acceso personal clásico, con el alcance `repo` y una caducidad corta, y lo guardamos en un lugar seguro. Enlazamos el repositorio local con el remoto y enviamos la rama principal dejándola enlazada.
6. Añadimos al resto de integrantes como colaboradores del repositorio desde su página de GitHub (`Settings > Collaborators`) y les indicamos la dirección del repositorio. Cada integrante tiene que aceptar la invitación, que llega a su correo o a sus notificaciones de GitHub.
7. Cada integrante crea su propio token de acceso personal con el alcance `repo`.
8. Cada integrante clona el repositorio en una carpeta propia, abre el proyecto en IntelliJ y comprueba que compila. Para ejecutar la aplicación necesita definir la variable de entorno `POSTGRES_PASSWORD` en su propio IntelliJ y tener creada la base de datos en su PostgreSQL.
9. Dos integrantes, a los que llamamos A y B, provocan el conflicto. Cada uno, en su copia y **sin traer cambios del remoto**, sustituye en el `README.md` la línea `Pendiente de completar` por su propio nombre, y hace commit.
10. A envía su cambio al remoto: debe funcionar. B intenta enviar el suyo: Git lo rechaza. B anota el motivo que da el mensaje.
11. B trae los cambios del remoto y comprueba que Git informa de un conflicto en `README.md`. B lo resuelve con el editor de conflictos de IntelliJ, de forma que la lista de autores contenga los nombres de A y de B y no quede ninguna marca, hace el commit que cierra la fusión y envía el resultado.
12. El resto de integrantes, por turnos, trae los cambios del remoto, añade su nombre a la lista de autores, hace commit y lo envía. Cuando todos han terminado, cada integrante trae los últimos cambios y comprueba que su `README.md` tiene el nombre de todos. Se revisa en GitHub el historial de commits: debe aparecer al menos uno de cada integrante.

**Pistas**

- Si `git status` responde `fatal: not a git repository`, el proyecto todavía no tiene repositorio y hay que crearlo con `git init`.
- El nombre de la rama inicial de un repositorio nuevo puede ser `master` en vez de `main` si no se ha configurado. `git branch` muestra cuál es; con `git branch -M main` se renombra.
- Si Git informa de que `origin` ya existe, ya hay un remoto configurado: `git remote -v` lo muestra y `git remote set-url origin <url>` lo cambia.
- Las credenciales: el usuario es el nombre de la cuenta de GitHub y la contraseña es el token. Si el sistema recordó antes una contraseña antigua, `Authentication failed` indica que hay que borrar la credencial guardada: en Windows, `Administrador de credenciales > Credenciales de Windows`, la entrada de `github.com`.
- Si `git pull` se niega a continuar y habla de `divergent branches` y de cómo reconciliarlas, falta la configuración `git config --global pull.rebase false`.
- Un envío rechazado con `fetch first` o `non-fast-forward` no es un fallo: otra persona envió antes. Se resuelve con `git pull` y, después, `git push` otra vez. Lo normal es que el `pull` funcione solo; si produce un conflicto, se resuelve como en el paso 11.
- En un conflicto, las dos versiones están en el fichero separadas por `<<<<<<<`, `=======` y `>>>>>>>`. En el editor de IntelliJ, el panel de la izquierda es la versión propia, el de la derecha la que llega del remoto y el del centro el resultado.
- Un repositorio privado no se ve en GitHub para quien no ha aceptado la invitación: responde con un error 404, no con un mensaje de permisos.
- No se sube nunca ningún token ni contraseña al repositorio: ni en el código, ni en `application.properties`, ni en el `README.md`.
