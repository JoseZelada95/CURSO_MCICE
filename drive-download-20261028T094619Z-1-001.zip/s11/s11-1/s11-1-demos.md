# S11-1 Demos

## Objetivos

En esta parte aprendemos a guardar y compartir el código de un proyecto con Git. Trabajamos sobre un proyecto nuevo y sencillo, `tareas`: una API REST de tareas guardada en PostgreSQL, con la misma estructura de controlador, repositorio y entidad que ya conocemos de las sesiones anteriores. Así la atención se dedica a la herramienta y no al dominio.

Vemos Git con lo básico, que es lo que se usa cada día en un equipo: guardar el trabajo en una serie de instantáneas, enviarlo a una copia compartida, traer lo que han hecho los demás y resolver el choque cuando dos personas tocan la misma línea. Lo vemos dos veces con los mismos conceptos. Primero en la línea de comandos, que es lo que ejecutan después las herramientas de integración continua y lo que permite entender qué ocurre de verdad. Después en IntelliJ, que es como se trabaja a diario. Haber visto antes los comandos hace que cada botón del IDE tenga sentido y permite diagnosticar el problema cuando algo no sale como se espera. Todo el trabajo se hace sobre una sola línea de desarrollo, la rama principal, que es suficiente para lo que el curso necesita de Git.

El proyecto usa además Lombok, una librería que escribe durante la compilación el código repetitivo de las clases (getters, setters y constructores) a partir de anotaciones. Hasta ahora ese código se escribía a mano para entender qué contiene; desde aquí se genera, que es como se trabaja en un proyecto real. Lombok aparece en la Demo 1, en el momento en que lo necesitamos, y sirve además para tener un cambio real y con sentido que guardar en el historial.

Al terminar esta parte los alumnos son capaces de:
- Configurar Git y crear un repositorio local con `git init`.
- Guardar el trabajo con `git add` y `git commit`, y consultar el historial con `git status`, `git diff` y `git log`.
- Decidir con un `.gitignore` qué ficheros no deben entrar en el repositorio.
- Usar Lombok (`@Getter`, `@Setter`, `@NoArgsConstructor` y `@RequiredArgsConstructor`) y explicar las precauciones con las entidades.
- Hacer lo mismo desde IntelliJ: ventana de commit, comparación de versiones e historial.
- Enlazar un repositorio local con uno remoto y usar `git push`, `git clone` y `git pull`, autenticándose con un token de acceso personal.
- Resolver con el editor de IntelliJ el conflicto que aparece cuando dos copias cambian la misma línea.

---

## Demo 1: Repositorio local con la línea de comandos

Imaginemos que escribimos un informe y, antes de cada cambio importante, guardamos una copia con otro nombre: `informe_v1`, `informe_v2`, `informe_definitivo`, `informe_definitivo_ahora_sí`. Funciona, pero no sabemos qué cambió entre una copia y otra, ni quién lo cambió, ni por qué, y si dos personas editan a la vez cada una acaba con su propia versión.

Un **sistema de control de versiones** resuelve ese problema. Guarda el historial completo de un proyecto como una serie de **instantáneas**, cada una con un mensaje que explica qué cambió y quién lo hizo, y permite volver a cualquiera de ellas. **Git** es el sistema de control de versiones que usa casi todo el desarrollo de software. Es una herramienta de línea de comandos que se instala una vez en el ordenador y funciona sin conexión a Internet: el historial vive en una carpeta del propio proyecto.

El conjunto formado por el proyecto y su historial se llama **repositorio**. Cada instantánea del historial se llama **commit**. En esta demo creamos un repositorio sobre el proyecto `tareas` y lo construimos paso a paso, con tres commits.

### Comprobar que Git está instalado y configurarlo

Abrimos una terminal (en Windows, `cmd`) y escribimos:

```bash
git --version
```

Salida esperada (el número de versión puede ser otro):

<pre>
git version 2.43.0
</pre>

Si la terminal responde que `git` no se reconoce como un comando, Git no está instalado. Lo descargamos de `git-scm.com` (en Windows, `Git for Windows`), ejecutamos el instalador aceptando todas las opciones que propone y volvemos a abrir la terminal y IntelliJ para que reconozcan el nuevo programa.

Antes del primer commit, Git necesita saber quién firma los cambios. Cada commit guarda el nombre y el correo de su autor, y así el historial responde a la pregunta "quién cambió esto". Lo configuramos una sola vez por ordenador con la opción `--global`, que significa "para todos los repositorios de este usuario". Aprovechamos para dejar otras dos opciones que vamos a necesitar:

```bash
git config --global user.name "Ana García"
git config --global user.email "ana.garcia@example.com"
git config --global init.defaultBranch main
git config --global pull.rebase false
```

Cada alumno escribe su propio nombre y su correo. Las dos últimas líneas son iguales para todos:

- `init.defaultBranch main` da nombre a la línea de trabajo principal de los repositorios nuevos. Una **rama** es una línea de trabajo del historial; en esta parte solo usamos la principal, y queremos que se llame `main`, que es el nombre que GitHub da a la principal de los repositorios nuevos. Si no lo configuramos, Git usa el nombre que traiga su instalación (en el aula es `master`) y los nombres de nuestro ordenador y de GitHub no coincidirían.
- `pull.rebase false` decide qué hace Git cuando, al traer los cambios de otra copia del repositorio con `git pull` (lo vemos en la Demo 3), las dos copias han avanzado cada una por su lado. Sin esta opción, Git se niega a continuar y pide elegir cómo juntarlas. Con `false` las junta fusionándolas, que es lo que explicamos en esta parte.

Los comandos no muestran ninguna salida cuando funcionan. Para comprobar lo guardado, escribimos `git config --global --list`:

<pre>
user.name=Ana García
user.email=ana.garcia@example.com
init.defaultbranch=main
pull.rebase=false
</pre>

En `cmd`, el texto de un mensaje se escribe entre comillas dobles, como en todos los ejemplos de este documento. Las comillas simples no funcionan en esa terminal.

### Crear el proyecto

Creamos el proyecto con el generador de Spring Boot, igual que en S06-1. Vamos a `File > New > Project`. En el panel izquierdo, dentro de `Generators`, seleccionamos `Spring Boot`.

Rellenamos los campos:

- **Name**: `tareas`.
- **Location**: la carpeta donde guardamos los proyectos del curso.
- **Type**: `Maven`.
- **Language**: `Java`.
- **Group**: `com.curso`.
- **Artifact**: `tareas`.
- **Package name**: `com.curso`. El generador lo recalcula cada vez que cambiamos otro campo, así que lo revisamos al final.
- **JDK**: `21`.
- **Java**: `21`.
- **Packaging**: `Jar`.
- **Configuration**: `Properties`.

Hacemos clic en `Next`. En la segunda pantalla dejamos la versión de Spring Boot `4.1.1` y marcamos tres dependencias: `Spring Data JPA`, `Spring Web` y `PostgreSQL Driver`. No marcamos `Lombok`: lo añadimos a mano más adelante para ver el cambio en el historial. Hacemos clic en `Create`.

IntelliJ crea el proyecto y descarga las librerías. Cuando termina, renombramos la clase principal, que el generador llama `TareasApplication`: la seleccionamos en `src/main/java/com/curso`, pulsamos `Shift+F6`, escribimos `Aplicacion` y pulsamos Enter. Hacemos lo mismo con la clase de `src/test/java/com/curso`, que pasa de `TareasApplicationTests` a `AplicacionTests`. Si IntelliJ pregunta si quiere renombrar también los tests y las referencias, aceptamos.

El proyecto generado es el punto de partida de la historia: lo que vamos a guardar en el primer commit. Contiene el `pom.xml`, la clase `Aplicacion`, el test `AplicacionTests`, un `application.properties` con una única línea (`spring.application.name=tareas`) y varios ficheros que Spring Boot añade para ayudar:

- `.gitignore`: la lista de lo que Git no debe guardar. Lo explicamos en la sección siguiente.
- `.gitattributes`: le dice a Git cómo tratar los saltos de línea de ciertos ficheros. Windows y Linux marcan el final de línea de forma distinta, y este fichero evita que el script `mvnw` se estropee al cambiar de sistema.
- `mvnw`, `mvnw.cmd` y `.mvn`: el Maven Wrapper (S05-1). No lo usamos, pero forma parte de lo que genera Spring Boot y se guarda con el proyecto.
- `HELP.md`: un fichero de ayuda que no usamos. Lo ignora el `.gitignore`.

El código de esta demo está en `s11-1-demos.zip`, dentro de la carpeta `tareas`. Contiene el proyecto en su estado final de la Demo 1, sin la carpeta `.git` (el repositorio lo crea cada uno). Las clases y los ficheros que vamos añadiendo en cada paso se copian de ahí. Las clases `Aplicacion` y `AplicacionTests` del zip llevan comentarios didácticos; no hace falta copiarlas, porque las que genera el asistente funcionan igual.

### Crear el repositorio

Abrimos la terminal de IntelliJ: `View > Tool Windows > Terminal` (atajo `Alt+F12`). Se abre dentro de la carpeta del proyecto, que es donde queremos el repositorio. Escribimos:

```bash
git init
```

Salida esperada:

<pre>
Initialized empty Git repository in /ruta/tareas/.git/
</pre>

`git init` convierte la carpeta en un repositorio creando dentro una carpeta oculta llamada `.git`. Ahí es donde Git guarda todo el historial. Si algún día queremos que la carpeta deje de ser un repositorio, basta con borrar `.git`; el proyecto no cambia. Ni el código ni la compilación saben que `.git` existe.

### Ver el estado

El comando que más se usa en Git es el que pregunta "¿cómo estamos?":

```bash
git status
```

Salida esperada:

<pre>
On branch main

No commits yet

Untracked files:
  (use "git add &lt;file&gt;..." to include in what will be committed)
	.gitattributes
	.gitignore
	.mvn/
	mvnw
	mvnw.cmd
	pom.xml
	src/

nothing added to commit but untracked files present (use "git add" to track)
</pre>

Se lee así: estamos en la rama `main`, todavía no hay ningún commit, y hay ficheros **sin seguimiento** (*untracked*): Git los ve en la carpeta, pero aún no los ha incluido en el repositorio. Fíjate en lo que no aparece: `.idea/`, `target/` o `HELP.md`. Existen en el disco, pero el `.gitignore` le dice a Git que los ignore. Es el momento de ver por qué.

### El .gitignore

En un repositorio solo debe ir lo que no se puede reconstruir: el código fuente y los ficheros de configuración del proyecto. Todo lo que se genera solo, no. La carpeta `target/` contiene lo que Maven produce al compilar (se vuelve a crear con un comando) y `.idea/` contiene la configuración personal de IntelliJ de cada persona, que no tiene por qué coincidir con la de otra. Si estuvieran en el repositorio, cada compilación los cambiaría y llenaría de ruido el historial. Y hay otra razón más importante: la contraseña de la base de datos no está en ningún fichero del proyecto, vive en la variable de entorno `POSTGRES_PASSWORD` (S07), precisamente para que no llegue nunca al repositorio.

El fichero `.gitignore` lista, un patrón por línea, lo que Git debe ignorar. El que genera Spring Boot contiene, entre otros, estas líneas:

<pre>
HELP.md
target/
.mvn/wrapper/maven-wrapper.jar

### IntelliJ IDEA ###
.idea
*.iws
*.iml
*.ipr
</pre>

Una línea que acaba en `/` ignora una carpeta entera; `*.iml` ignora cualquier fichero que termine en `.iml`; las líneas que empiezan por `#` son comentarios. No hay que escribir nada: el fichero ya viene hecho, y lo único que hay que saber es que existe y para qué sirve.

### El primer commit: add y commit

Guardar una instantánea en Git son dos pasos, y la analogía de la fotografía de grupo ayuda. Primero se coloca delante de la cámara a quienes saldrán en la foto; después se hace la foto.

- `git add` coloca los ficheros en el **área de preparación** (*staging area*): la lista de lo que irá en el próximo commit. Permite elegir exactamente qué entra en la instantánea, sin obligar a guardar todo lo que se ha tocado.
- `git commit` hace la foto: guarda en el historial lo que hay en el área de preparación, con un mensaje.

Preparamos todo con `git add .`, donde el punto significa "la carpeta actual y todo lo que contiene" (salvo lo que el `.gitignore` ignora):

```bash
git add .
git status
```

Salida esperada del segundo comando (`git add` no muestra nada):

<pre>
On branch main

No commits yet

Changes to be committed:
  (use "git rm --cached &lt;file&gt;..." to unstage)
	new file:   .gitattributes
	new file:   .gitignore
	new file:   .mvn/wrapper/maven-wrapper.properties
	new file:   mvnw
	new file:   mvnw.cmd
	new file:   pom.xml
	new file:   src/main/java/com/curso/Aplicacion.java
	new file:   src/main/resources/application.properties
	new file:   src/test/java/com/curso/AplicacionTests.java
</pre>

Ahora los ficheros están en `Changes to be committed`: preparados. Si en Windows aparecen avisos del tipo `LF will be replaced by CRLF`, son normales y no hay que hacer nada: Git avisa de que cambiará el tipo de salto de línea al guardar o recuperar el fichero.

Hacemos la instantánea. La opción `-m` (*message*) escribe el mensaje del commit, que debe explicar **qué cambia**, en pocas palabras:

```bash
git commit -m "Proyecto inicial generado con Spring Boot"
```

Salida esperada:

<pre>
[main (root-commit) 7f1731e] Proyecto inicial generado con Spring Boot
 9 files changed, 617 insertions(+)
 create mode 100644 .gitattributes
 create mode 100644 .gitignore
 create mode 100644 .mvn/wrapper/maven-wrapper.properties
 create mode 100755 mvnw
 create mode 100644 mvnw.cmd
 create mode 100644 pom.xml
 create mode 100644 src/main/java/com/curso/Aplicacion.java
 create mode 100644 src/main/resources/application.properties
 create mode 100644 src/test/java/com/curso/AplicacionTests.java
</pre>

La primera línea trae el nombre de la rama, la marca `root-commit` (el primero de la historia), un código de siete caracteres (`7f1731e`) y el mensaje. Ese código es el **identificador** del commit: Git lo calcula a partir del contenido, así que cada commit tiene el suyo y no se repite. El tuyo será distinto del de este documento, al igual que el número de ficheros y de líneas si el generador ha cambiado.

### Consultar el historial: log

```bash
git log --oneline
```

Salida esperada:

<pre>
7f1731e (HEAD -&gt; main) Proyecto inicial generado con Spring Boot
</pre>

`git log` muestra el historial, del commit más reciente al más antiguo; `--oneline` lo resume en una línea por commit. Entre paréntesis, `HEAD -> main` significa "estamos situados en la rama `main`". **HEAD** es el marcador de "dónde estoy" dentro del historial.

### Segundo commit: Lombok y las clases de la aplicación

Ahora añadimos las tres clases de la aplicación: la entidad `Tarea`, su repositorio y el controlador. Si las escribiéramos como en las sesiones anteriores, la entidad tendría unas 90 líneas, y casi todas serían siempre iguales: el constructor vacío, un getter y un setter por campo. El controlador tendría un constructor que solo recibe el repositorio y lo guarda en un campo. Ese código hay que escribirlo, leerlo y mantenerlo, y no dice nada del dominio.

**Lombok** es una librería que escribe ese código por nosotros durante la compilación. Se usa mediante **anotaciones**: etiquetas que empiezan por `@` y que Lombok lee al compilar para generar el código correspondiente, que queda dentro del fichero `.class` pero no aparece en el `.java`. El comportamiento de la clase no cambia; solo cambia lo que tenemos que escribir y leer. En la carpeta `referencia` del zip están las versiones sin Lombok de `Tarea` y de `TareaController` (con extensión `.txt` para que no se compilen), por si queremos compararlas con las que usamos.

#### La dependencia

Lombok se añade al `pom.xml` como cualquier otra librería. Dentro de `<dependencies>`, después de la dependencia `spring-boot-starter-webmvc`, añadimos:

```xml
		<dependency>
			<groupId>org.projectlombok</groupId>
			<artifactId>lombok</artifactId>
			<optional>true</optional>
		</dependency>
```

Dos detalles. No hay `<version>`: el POM padre de Spring Boot (`spring-boot-starter-parent`, S05-1) ya fija la versión de Lombok, igual que la del resto de librerías que gestiona. Y `<optional>true</optional>` indica que Lombok solo se necesita para compilar este proyecto y no debe pasar como dependencia a quien use el proyecto como librería. En un JAR de Spring Boot no hace falta ninguna configuración adicional: Lombok trabaja en la compilación y no viaja en la aplicación.

Pulsamos **Load Maven Changes** (el icono `m` que aparece en el editor, o `Ctrl+Shift+O`) para que IntelliJ descargue la librería.

#### El procesamiento de anotaciones de IntelliJ

Maven compila el proyecto con Lombok sin ningún ajuste, pero el editor de IntelliJ necesita dos cosas para reconocer los métodos que Lombok genera. Si falta alguna, el código compila pero IntelliJ subraya en rojo las llamadas a `getTitulo()` o `setId()` porque no ve esos métodos en el `.java`.

- El plugin **Lombok**, que viene incluido en IntelliJ y activado por defecto.
- El **procesamiento de anotaciones**. Vamos a `File > Settings` (atajo `Ctrl+Alt+S`), `Build, Execution, Deployment > Compiler > Annotation Processors` y marcamos **Enable annotation processing**. Hacemos clic en `Apply` y en `OK`. Si IntelliJ muestra un aviso al abrir el proyecto con el texto "Annotation processing is disabled", se activa desde el propio aviso.

Un **procesador de anotaciones** es un programa que el compilador ejecuta mientras compila para leer las anotaciones y generar código. Lombok es uno.

#### Código: Tarea.java

Creamos los paquetes `com.curso.model`, `com.curso.repository` y `com.curso.controller` (clic derecho sobre `src/main/java`, `New > Package`) y, dentro de `com.curso.model`, la clase `Tarea` (clic derecho sobre el paquete, `New > Java Class`). Su contenido es el de `src/main/java/com/curso/model` del zip:

```java
package com.curso.model;

// Importamos las anotaciones de JPA (Jakarta Persistence), el estándar de Java para
// guardar objetos en bases de datos. Maven las ha descargado al declarar
// spring-boot-starter-data-jpa en el pom.xml: no hay que buscarlas ni instalarlas a mano.
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

// Importamos las anotaciones de Lombok. Maven ha descargado la librería al declarar
// org.projectlombok:lombok en el pom.xml. Lombok las lee al compilar y escribe por nosotros
// el código repetitivo, que queda dentro del .class pero no aparece en el .java.
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * S11-1 Demo 1: Entidad Tarea con Lombok
 *
 * Objetivo: quitar de la entidad el código repetitivo (constructor vacío, getters y setters)
 * y dejar solo lo que dice qué es una tarea.
 *
 * Lo que hace este ejemplo:
 *   - Declara la entidad Tarea sobre la tabla tarea de PostgreSQL
 *   - Pide a Lombok el constructor vacío, los getters y los setters con tres anotaciones
 *
 * Concepto clave: Lombok genera ese código al compilar. El comportamiento no cambia,
 * pero la clase se lee de un vistazo y Git muestra los cambios reales de cada commit.
 */
@Entity
// @Getter escribe un getter por cada campo: getId(), getTitulo(), getDescripcion()
// y isCompletada() (en un boolean, Java usa el prefijo is).
@Getter
// @Setter escribe un setter por cada campo: setId(), setTitulo(), setDescripcion()
// y setCompletada().
@Setter
// @NoArgsConstructor escribe el constructor sin argumentos que Hibernate necesita.
@NoArgsConstructor
public class Tarea {

    // @Id marca la clave primaria; @GeneratedValue con IDENTITY hace que la genere
    // la base de datos (columna autoincremental). Es Long y no long porque una tarea
    // nueva todavía no tiene id y vale null hasta que se guarda.
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Sin más anotaciones, cada campo se corresponde con la columna del mismo nombre.
    private String titulo;
    private String descripcion;
    private boolean completada;

    // Este constructor sí lo escribimos nosotros: Lombok no sabe qué campos queremos recibir.
    // @AllArgsConstructor incluiría también el id y completada, que no debemos indicar al crear una tarea.
    public Tarea(String titulo, String descripcion) {
        this.titulo = titulo;
        this.descripcion = descripcion;
    }

    // toString() devuelve el texto con el que se imprime la tarea;
    // @Override avisa al compilador de que reescribimos el método heredado de Object.
    // Lombok tiene @ToString, pero lo escribimos nosotros para decidir qué campos se imprimen.
    @Override
    public String toString() {
        return "Tarea{id=" + id + ", titulo='" + titulo + "', completada=" + completada + "}";
    }
}
```

Hay cuatro puntos que conviene entender, porque marcan dónde se usa Lombok y dónde no:

- **`@Getter` y `@Setter`** puestos sobre la clase se aplican a todos los campos. Se pueden poner también sobre un solo campo.
- **`@NoArgsConstructor`** genera el constructor vacío que Hibernate necesita (S06-1). Como la clase tiene otro constructor escrito a mano, Java no crearía uno vacío por su cuenta: sin esta anotación Hibernate fallaría.
- **El constructor de dos parámetros** se mantiene a mano. Lombok ofrece `@AllArgsConstructor`, que recibiría los cuatro campos, pero no queremos que se pueda indicar el `id` ni `completada` al crear una tarea nueva.
- **Evitamos `@Data` en las entidades.** Es una anotación de Lombok que reúne `@Getter`, `@Setter` y además genera `equals()`, `hashCode()` y `toString()` con todos los campos. En una entidad JPA da problemas: con relaciones entre entidades, el `toString()` de cada una imprime a la otra y se produce un bucle infinito (lo vimos en S08-1), y `equals()` y `hashCode()` basados en todos los campos cambian cuando cambia cualquier dato. Por eso en las entidades se usan las anotaciones sueltas.

Lombok tiene también `@ToString`; aquí lo dejamos escrito a mano para decidir qué campos se imprimen.

#### Código: TareaRepository.java

`TareaRepository` no usa Lombok; es la interfaz vacía de S06-1. La creamos en `com.curso.repository` (`New > Java Class`, y en el desplegable que aparece elegimos `Interface`):

```java
package com.curso.repository;

// JpaRepository procede de Spring Data JPA, que Maven trae con spring-boot-starter-data-jpa.
import org.springframework.data.jpa.repository.JpaRepository;

// Importamos la entidad que gestiona este repositorio.
import com.curso.model.Tarea;

/**
 * S11-1 Demo 1: Repositorio de tareas
 *
 * Objetivo: disponer de las operaciones de guardar, buscar y borrar tareas sin escribirlas.
 *
 * Lo que hace este ejemplo:
 *   - Declara una interfaz vacía que extiende JpaRepository
 *   - Hereda save(), findAll(), findById(), count() y deleteById()
 *
 * Concepto clave: el repositorio se declara, no se escribe. Spring Data genera
 * en memoria la clase que implementa la interfaz al arrancar la aplicación.
 */
// JpaRepository<Tarea, Long> = entidad que gestiona (Tarea) y tipo de su clave primaria (Long).
public interface TareaRepository extends JpaRepository<Tarea, Long> {
}
```

#### Código: TareaController.java

El controlador ofrece dos operaciones: `GET /api/tareas` devuelve todas las tareas y `POST /api/tareas` guarda una nueva. Es la misma estructura de `@RestController` y `@RequestMapping` de S09. La novedad está en el constructor: sin Lombok sería este.

```java
    // final = el campo se asigna una sola vez, en el constructor.
    private final TareaRepository tareaRepository;

    // Constructor de inyección: Spring lo llama al crear el controlador y le entrega
    // el repositorio. Con un único constructor no hace falta anotarlo.
    public TareaController(TareaRepository tareaRepository) {
        this.tareaRepository = tareaRepository;
    }
```

Con Lombok, esas líneas se reducen a la anotación `@RequiredArgsConstructor`, que escribe un constructor con un parámetro por cada campo `final` de la clase. Es el constructor de inyección de S06-1: lo escribe Lombok y Spring lo usa igual que antes. Creamos la clase en `com.curso.controller` con este contenido:

```java
package com.curso.controller;

import java.util.List;

// Estas anotaciones y la clase ResponseStatus proceden de Spring MVC, que Maven trae
// con spring-boot-starter-webmvc. HttpStatus enumera los códigos de estado de HTTP.
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.curso.model.Tarea;
import com.curso.repository.TareaRepository;

// RequiredArgsConstructor procede de Lombok, que Maven ha descargado con el pom.xml.
import lombok.RequiredArgsConstructor;

/**
 * S11-1 Demo 1: Controlador REST de tareas con Lombok
 *
 * Objetivo: ofrecer la lista de tareas y el alta de una tarea nueva como API REST,
 * sin escribir el constructor de inyección.
 *
 * Lo que hace este ejemplo:
 *   - GET /api/tareas devuelve todas las tareas en JSON
 *   - POST /api/tareas guarda la tarea recibida y devuelve 201
 *
 * Concepto clave: @RequiredArgsConstructor escribe el constructor que recibe los campos final.
 * Spring lo usa para inyectar el repositorio igual que antes.
 */
@RestController
@RequestMapping("/api/tareas")
// @RequiredArgsConstructor escribe un constructor con un parámetro por cada campo final
// (aquí, tareaRepository). Es el constructor que antes escribíamos a mano.
@RequiredArgsConstructor
public class TareaController {

    // final = el campo se asigna una sola vez, en el constructor que genera Lombok.
    private final TareaRepository tareaRepository;

    /**
     * Devuelve todas las tareas.
     *
     * Ejemplo:
     *   GET /api/tareas  →  [{"titulo":"Preparar la demo de Git", ..., "id":1}, ...]
     */
    @GetMapping
    public List<Tarea> listar() {
        // findAll() devuelve todas las filas de la tabla tarea, sin ningún orden concreto.
        return tareaRepository.findAll();
    }

    /**
     * Guarda una tarea nueva.
     *
     * Ejemplo:
     *   POST /api/tareas  {"titulo": "Comprar café"}  →  201 y la tarea con su id
     */
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Tarea crear(@RequestBody Tarea tarea) {
        // Anulamos el id recibido: save() inserta si el id es null y actualiza si existe,
        // y aquí queremos que siempre cree una tarea nueva.
        tarea.setId(null);
        return tareaRepository.save(tarea);
    }
}
```

#### Comprobar que Lombok ha escrito el código

Compilamos el proyecto con `Build > Build Project` (`Ctrl+F9`). Para comprobar que los métodos existen dentro del `.class` aunque no estén en el `.java`, usamos `javap`, una herramienta del JDK que lista el contenido de una clase compilada. La opción `-p` incluye también lo privado:

```bash
javap -p -cp target/classes com.curso.model.Tarea
```

Salida esperada:

<pre>
Compiled from "Tarea.java"
public class com.curso.model.Tarea {
  private java.lang.Long id;
  private java.lang.String titulo;
  private java.lang.String descripcion;
  private boolean completada;
  public com.curso.model.Tarea(java.lang.String, java.lang.String);
  public java.lang.String toString();
  public java.lang.Long getId();
  public java.lang.String getTitulo();
  public java.lang.String getDescripcion();
  public boolean isCompletada();
  public void setId(java.lang.Long);
  public void setTitulo(java.lang.String);
  public void setDescripcion(java.lang.String);
  public void setCompletada(boolean);
  public com.curso.model.Tarea();
}
</pre>

Los cuatro getters, los cuatro setters y el constructor vacío están en el `.class` sin que estén escritos en el `.java`. Lo mismo ocurre con el controlador:

```bash
javap -p -cp target/classes com.curso.controller.TareaController
```

<pre>
Compiled from "TareaController.java"
public class com.curso.controller.TareaController {
  private final com.curso.repository.TareaRepository tareaRepository;
  public java.util.List&lt;com.curso.model.Tarea&gt; listar();
  public com.curso.model.Tarea crear(com.curso.model.Tarea);
  public com.curso.controller.TareaController(com.curso.repository.TareaRepository);
}
</pre>

El constructor `TareaController(TareaRepository)` es el que escribe `@RequiredArgsConstructor`.

#### Qué ha cambiado: status, diff y commit

Volvemos a Git. Preguntamos por el estado:

```bash
git status
```

Salida esperada:

<pre>
On branch main
Changes not staged for commit:
  (use "git add &lt;file&gt;..." to update what will be committed)
  (use "git restore &lt;file&gt;..." to discard changes in working directory)
	modified:   pom.xml

Untracked files:
  (use "git add &lt;file&gt;..." to include in what will be committed)
	src/main/java/com/curso/controller/
	src/main/java/com/curso/model/
	src/main/java/com/curso/repository/

no changes added to commit (use "git add" and/or "git commit -a")
</pre>

Aparecen dos clases de cambios. El `pom.xml` está **modificado** (*modified*): Git lo conoce y ha cambiado desde el último commit. Las carpetas de las tres clases son nuevas y siguen **sin seguimiento**, como al principio. Con `git diff` vemos exactamente qué líneas cambiaron en los ficheros que Git ya conoce:

```bash
git diff pom.xml
```

<pre>
diff --git a/pom.xml b/pom.xml
index c919e70..031fa26 100644
--- a/pom.xml
+++ b/pom.xml
@@ -38,6 +38,11 @@
 			&lt;groupId&gt;org.springframework.boot&lt;/groupId&gt;
 			&lt;artifactId&gt;spring-boot-starter-webmvc&lt;/artifactId&gt;
 		&lt;/dependency&gt;
+		&lt;dependency&gt;
+			&lt;groupId&gt;org.projectlombok&lt;/groupId&gt;
+			&lt;artifactId&gt;lombok&lt;/artifactId&gt;
+			&lt;optional&gt;true&lt;/optional&gt;
+		&lt;/dependency&gt;
 
 		&lt;dependency&gt;
 			&lt;groupId&gt;org.postgresql&lt;/groupId&gt;
</pre>

Se lee así: las líneas con `+` son las que se han añadido y las que llevan `-` (que aquí no hay) serían las eliminadas; las que no llevan marca son contexto, para situar el cambio. La línea `@@ -38,6 +38,11 @@` indica dónde está el cambio dentro del fichero. Tener esa diferencia a la vista es lo que hace útil un historial.

Preparamos todo y hacemos el commit. Con `git add .` se preparan el fichero modificado y las carpetas nuevas:

```bash
git add .
git commit -m "Añadir Lombok y las clases de la aplicación"
```

Salida esperada del `commit`:

<pre>
[main 9be3c46] Añadir Lombok y las clases de la aplicación
 4 files changed, 166 insertions(+)
 create mode 100644 src/main/java/com/curso/controller/TareaController.java
 create mode 100644 src/main/java/com/curso/model/Tarea.java
 create mode 100644 src/main/java/com/curso/repository/TareaRepository.java
</pre>

### Tercer commit: la base de datos y la conexión

El proyecto aún no puede arrancar: faltan la tabla `tarea` y los datos de conexión. Es el mismo procedimiento de S07.

1. En pgAdmin creamos una base de datos llamada `tareas` (`Servers` > servidor > clic derecho sobre `Databases` > `Create` > `Database...`, campo **Database** `tareas`, `Save`).
2. Abrimos en ella la `Query Tool` (clic derecho sobre `tareas` > `Query Tool`), abrimos el fichero `sql/01-crear-tarea.sql` del zip (icono de carpeta de la barra de la `Query Tool`) y lo ejecutamos con ▶. El script borra la tabla `tarea` si existe, la crea y le inserta tres tareas, así que se puede repetir las veces que haga falta.
3. Copiamos la carpeta `sql` a la raíz del proyecto, junto al `pom.xml`. La guardamos con el proyecto porque el script describe cómo es la base de datos que necesita la aplicación.
4. Sustituimos el contenido de `src/main/resources/application.properties` por el del zip. Los comentarios explican cada propiedad; la contraseña no se escribe, se lee de la variable de entorno `POSTGRES_PASSWORD`:

```properties
# Nombre de la aplicación: aparece entre corchetes en cada línea del log.
spring.application.name=tareas

# Conexión a PostgreSQL: dirección de la base de datos tareas, usuario y contraseña.
# La contraseña no se escribe aquí porque este fichero se guarda en el repositorio:
# se lee de la variable de entorno POSTGRES_PASSWORD.
spring.datasource.url=jdbc:postgresql://localhost:5432/tareas
spring.datasource.username=postgres
spring.datasource.password=${POSTGRES_PASSWORD}

# validate: Hibernate no toca las tablas (las crea el script SQL), solo comprueba al arrancar
# que cada entidad coincide con su tabla.
spring.jpa.hibernate.ddl-auto=validate

# Desactiva la sesión de Hibernate abierta durante la vista (como en las sesiones anteriores).
spring.jpa.open-in-view=false

# Escribe en la consola cada sentencia SQL que genera Hibernate.
spring.jpa.show-sql=true
```

5. Definimos la variable de entorno en la configuración de ejecución, como en S07: ▶ junto al `main()` de `Aplicacion` y después `Edit Configurations…`, `Environment variables` con `POSTGRES_PASSWORD=` y la contraseña del usuario `postgres`.

Arrancamos con ▶ y abrimos `http://localhost:8080/api/tareas` en el navegador.

Salida esperada en el navegador:

<pre>
[{"titulo":"Preparar la demo de Git","descripcion":"Crear el repositorio local del proyecto","completada":true,"id":1},{"titulo":"Practicar los commits","descripcion":"Hacer cambios pequeños con mensajes claros","completada":false,"id":2},{"titulo":"Cerrar la sesión","descripcion":"Subir el proyecto a un repositorio remoto","completada":false,"id":3},{"titulo":"Compartir el proyecto","descripcion":"Dar acceso al resto del grupo","completada":false,"id":4}]
</pre>

La aplicación funciona con la entidad y el controlador de Lombok. Paramos la aplicación con ■ y guardamos el cambio. La opción `--short` de `git status` da una versión resumida: `M` es modificado y `??` es "sin seguimiento".

```bash
git status --short
```

<pre>
 M src/main/resources/application.properties
?? sql/
</pre>

```bash
git add sql src
git commit -m "Añadir el script SQL y la conexión a PostgreSQL"
```

<pre>
[main 60f7613] Añadir el script SQL y la conexión a PostgreSQL
 2 files changed, 44 insertions(+)
 create mode 100644 sql/01-crear-tarea.sql
</pre>

Terminamos mirando el historial completo:

```bash
git log --oneline
```

<pre>
60f7613 (HEAD -&gt; main) Añadir el script SQL y la conexión a PostgreSQL
9be3c46 Añadir Lombok y las clases de la aplicación
7f1731e Proyecto inicial generado con Spring Boot
</pre>

Tres instantáneas, cada una con un mensaje que cuenta qué ocurrió. Sin la opción `--oneline`, `git log` muestra además el autor y la fecha de cada commit. El número que acompaña a `-1` limita la salida al último commit:

```bash
git log -1
```

<pre>
commit 60f76132162131dcde0d7b7510dfcd4d0c88c482 (HEAD -&gt; main)
Author: Ana García &lt;ana.garcia@example.com&gt;
Date:   Tue Oct 20 07:48:12 2026 +0200

    Añadir el script SQL y la conexión a PostgreSQL
</pre>

Aquí vemos el identificador completo, que son 40 caracteres de los que `--oneline` muestra los siete primeros; el nombre y el correo configurados al principio; y la fecha. Esa es la razón de configurar el nombre antes del primer commit.

---

## Demo 2: Git en IntelliJ

Todo lo que hemos hecho en la terminal se puede hacer desde IntelliJ, y a diario es más cómodo. La interfaz no inventa nada nuevo: cada botón ejecuta un comando de los que ya hemos visto. Repetimos el flujo con dos cambios nuevos y vemos cómo IntelliJ los muestra y los guarda.

IntelliJ detecta de forma automática que la carpeta del proyecto es un repositorio, porque contiene `.git`. Si no lo hiciera, `VCS > Enable Version Control Integration…` (en versiones recientes, `Git > Enable Version Control Integration…`), seleccionar `Git` y `OK` lo activan.

### El aspecto de IntelliJ con Git

- **La ventana de commit** (`Commit`, a la izquierda; atajo `Alt+0`) lista los ficheros cambiados desde el último commit. Es el equivalente de `git status` y `git add` a la vez: cada fichero tiene una casilla y solo los marcados entran en el commit.
- **La ventana de Git** (`Git`, abajo; atajo `Alt+9`, pestaña `Log`) muestra el historial, el equivalente de `git log`.
- **Los colores de los ficheros** en el panel del proyecto indican su estado: verde para ficheros nuevos, azul para los modificados, y rojo o gris para los desconocidos o ignorados.
- **El nombre de la rama** (`main`) aparece en la barra de herramientas, junto al nombre del proyecto. Solo lo miramos: trabajamos siempre sobre la principal.

### Primer cambio: ordenar la lista

Ahora mismo `listar()` devuelve las tareas en el orden en que PostgreSQL las encuentre, que no está garantizado. Lo cambiamos para que las ordene por `id`. Abrimos `TareaController.java` y hacemos dos cambios.

El primero, en los `import`: añadimos la clase `Sort`, de Spring Data, que describe por qué campos se ordena una consulta.

```java
// Sort procede de Spring Data e indica por qué campos se ordena una consulta.
import org.springframework.data.domain.Sort;
```

El segundo, dentro de `listar()`: sustituimos las dos líneas del cuerpo por estas:

```java
        // findAll(Sort) devuelve todas las filas de la tabla tarea ordenadas por los campos indicados.
        return tareaRepository.findAll(Sort.by("id"));
```

`Sort.by("id")` ordena por el campo `id` de menor a mayor. Abrimos la ventana de commit (`Alt+0`). El fichero `TareaController.java` aparece en la lista, en azul, con su casilla marcada. Si hacemos doble clic sobre él (o pulsamos `Ctrl+D`), IntelliJ abre una comparación con dos columnas: a la izquierda la versión del último commit y a la derecha la actual, con las líneas cambiadas resaltadas. Es el equivalente visual de `git diff`, que en la terminal daría esto:

<pre>
diff --git a/src/main/java/com/curso/controller/TareaController.java b/src/main/java/com/curso/controller/TareaController.java
index 6830491..e46e25d 100644
--- a/src/main/java/com/curso/controller/TareaController.java
+++ b/src/main/java/com/curso/controller/TareaController.java
@@ -4,6 +4,8 @@ import java.util.List;
 
 // Estas anotaciones y la clase ResponseStatus proceden de Spring MVC, que Maven trae
 // con spring-boot-starter-webmvc. HttpStatus enumera los códigos de estado de HTTP.
+// Sort procede de Spring Data e indica por qué campos se ordena una consulta.
+import org.springframework.data.domain.Sort;
 import org.springframework.http.HttpStatus;
 import org.springframework.web.bind.annotation.GetMapping;
 import org.springframework.web.bind.annotation.PostMapping;
@@ -49,8 +51,8 @@ public class TareaController {
      */
     @GetMapping
     public List&lt;Tarea&gt; listar() {
-        // findAll() devuelve todas las filas de la tabla tarea, sin ningún orden concreto.
-        return tareaRepository.findAll();
+        // findAll(Sort) devuelve todas las filas de la tabla tarea ordenadas por los campos indicados.
+        return tareaRepository.findAll(Sort.by("id"));
     }
 
     /**
</pre>

Escribimos el mensaje `Listar las tareas ordenadas por id` en el campo de abajo y hacemos clic en `Commit`. Equivale a `git add` y `git commit -m`.

### Segundo cambio: una tarea más

Abrimos `sql/01-crear-tarea.sql`. En la sentencia `insert`, la última fila (`Cerrar la sesión`) termina en `;`. Para añadir una fila debajo, esa pasa a terminar en coma y la nueva lleva el punto y coma. Dejamos las dos últimas filas así:

```sql
    ('Cerrar la sesión', 'Subir el proyecto a un repositorio remoto', false),
    ('Compartir el proyecto', 'Dar acceso al resto del grupo', false);
```

Fíjate en la puntuación: solo la última fila termina en punto y coma. Con `Alt+0` y `Ctrl+D` vemos la comparación, que enseña justo ese detalle: la línea de `Cerrar la sesión` aparece cambiada (el `;` pasa a ser una coma) y la fila nueva aparece añadida. Hacemos el commit con el mensaje `Añadir la tarea de compartir el proyecto`.

No hace falta ejecutar el script otra vez: el fichero guarda cómo se crea la base de datos, y nuestra base actual no cambia hasta que lo ejecutemos.

### El historial

Abrimos la ventana de Git (`Alt+9`, pestaña `Log`). Aparece la lista de commits, del más reciente al más antiguo, con el mensaje, el autor y la fecha. Al hacer clic sobre un commit, el panel de la derecha muestra los ficheros que cambió, y un doble clic sobre uno de ellos abre la misma comparación de dos columnas que usamos antes de hacer el commit. Es el equivalente de `git log` y de `git diff` sobre un commit antiguo.

Lo que muestra la ventana es lo mismo que la terminal. En la terminal de IntelliJ (`Alt+F12`), que siempre está a un atajo de distancia, lo comprobamos:

```bash
git log --oneline
```

<pre>
7b2bd1e (HEAD -&gt; main) Añadir la tarea de compartir el proyecto
e5fbbef Listar las tareas ordenadas por id
60f7613 Añadir el script SQL y la conexión a PostgreSQL
9be3c46 Añadir Lombok y las clases de la aplicación
7f1731e Proyecto inicial generado con Spring Boot
</pre>

Mismo resultado, otra interfaz: la terminal enseña qué ocurre; IntelliJ lo hace más cómodo, y se pueden mezclar según convenga. Cuando algo no sale como se espera en el IDE, `git status` y `git log` dicen qué ha pasado de verdad.

Como cierre, para ver quién cambió cada línea de un fichero abierto, clic derecho sobre el margen izquierdo del editor y `Annotate with Git Blame`.

---

## Demo 3: Repositorio remoto, token y conflicto

Hasta ahora todo el historial vive en un solo ordenador. Para trabajar en equipo, necesitamos una copia en un sitio al que todos tengan acceso. Un **repositorio remoto** es esa copia: un repositorio alojado en un servidor. **GitHub** es el servicio de alojamiento más usado; ofrece repositorios remotos gratuitos, y es el que usamos en el curso. Cada persona o grupo tiene su propia cuenta.

El remoto es la copia compartida, y hay dos movimientos que lo mantienen sincronizado: **`push`** (enviar tus commits al remoto) y **`pull`** (traer al ordenador los commits que otros han enviado). Para tener una copia del repositorio en otro ordenador por primera vez, se usa **`clone`**.

### Crear el repositorio vacío en GitHub

Iniciamos sesión en `github.com`. Hacemos clic en el signo `+` de la esquina superior derecha y después en `New repository`. Rellenamos:

- **Repository name**: `tareas`.
- **Private** seleccionado. Un repositorio privado solo lo ven las personas a las que se da acceso.
- **Add a README file**, **Add .gitignore** y **Choose a license**: sin marcar. Queremos el repositorio **vacío**: ya tenemos un `.gitignore` en el proyecto, y un repositorio con ficheros propios tendría un historial distinto del nuestro y chocaría con él al enviar.

Hacemos clic en `Create repository`. GitHub muestra una página con instrucciones. De ahí copiamos la dirección del repositorio, que tiene esta forma (se muestra con el botón de copiar junto a la dirección de la pestaña `HTTPS`):

<pre>
https://github.com/usuario/tareas.git
</pre>

`usuario` es el nombre de la cuenta de GitHub de quien lo crea.

### Enlazar el repositorio local con el remoto

Desde la terminal de IntelliJ, en la carpeta del proyecto, escribimos (con la dirección copiada):

```bash
git remote add origin https://github.com/usuario/tareas.git
git remote -v
```

El primer comando no muestra nada. Registra un remoto con un nombre y una dirección; el nombre `origin` es el convenio para "el repositorio del que vengo". El segundo lista los remotos configurados (`-v`, *verbose*):

<pre>
origin	https://github.com/usuario/tareas.git (fetch)
origin	https://github.com/usuario/tareas.git (push)
</pre>

Aparece dos veces porque el mismo remoto se usa para traer (`fetch`) y para enviar (`push`).

### El token de acceso personal

Antes de enviar nada, GitHub tiene que saber que somos quien decimos ser. Los servicios de alojamiento ya no aceptan la contraseña de la cuenta cuando se trabaja con Git por HTTPS: exigen un **token de acceso personal**. Un token es un texto largo y aleatorio que hace de contraseña específica para Git: tiene fecha de caducidad, solo da los permisos que le damos y se puede revocar sin cambiar la contraseña de la cuenta. Es el punto en el que más gente se atasca la primera vez, así que vamos despacio. Ese mismo token lo usará Jenkins más adelante para leer el repositorio.

Lo creamos en GitHub:

1. Clic en la foto de perfil (arriba a la derecha), `Settings`.
2. En el menú de la izquierda, hasta abajo, `Developer settings`.
3. `Personal access tokens` > `Tokens (classic)`.
4. `Generate new token` > `Generate new token (classic)`. GitHub puede pedir la contraseña de la cuenta.
5. **Note**: `curso-tareas` (un nombre para reconocer el token).
6. **Expiration**: `30 days`.
7. **Select scopes**: marcamos `repo`, que da acceso a los repositorios, incluidos los privados.
8. Clic en `Generate token`.

GitHub muestra el token (empieza por `ghp_`) **una sola vez**. Lo copiamos en ese momento y lo guardamos en un lugar seguro, como un gestor de contraseñas: si cerramos la página, no se puede volver a ver y habría que generar otro. Un token es una contraseña: no se escribe en el código, no se guarda en el repositorio, no se pega en un chat ni se envía por correo. Si se filtra, se revoca desde la misma página (`Delete`).

GitHub ofrece también tokens de tipo *fine-grained* (de permisos más detallados), pero para repositorios de los que somos colaboradores y no propietarios tienen limitaciones. En el curso usamos el token clásico.

### Enviar los cambios: push

Enviamos la rama `main` al remoto. El comando lleva dos datos, `origin` (a qué remoto) y `main` (qué rama):

```bash
git push origin main
```

Al ejecutarlo por primera vez, el sistema pide las credenciales de GitHub. En Windows, el instalador de Git incluye el **Git Credential Manager**, un programa que gestiona las credenciales y las recuerda para no volver a pedirlas. Lo que aparece depende de la versión:

- Una ventana de GitHub con una opción para usar el **token** (en la pestaña `Token`): se pega el token ahí.
- O una petición en la propia terminal. En ese caso, `Username` es el nombre de la cuenta de GitHub y `Password` es el **token**, no la contraseña de la cuenta. Al pegar el token en la terminal no se ve ningún carácter, como en cualquier contraseña: se pega y se pulsa Enter.

Salida esperada:

<pre>
Enumerating objects: 37, done.
Counting objects: 100% (37/37), done.
Delta compression using up to 8 threads
Compressing objects: 100% (27/27), done.
Writing objects: 100% (37/37), 11.24 KiB | 3.74 MiB/s, done.
Total 37 (delta 5), reused 0 (delta 0), pack-reused 0
remote: Resolving deltas: 100% (5/5), done.
To https://github.com/usuario/tareas.git
 * [new branch]      main -> main
</pre>

Las líneas que empiezan por `remote:` las escribe GitHub y pueden variar, y los números de objetos también. Lo importante está al final: `main -> main` indica que la rama local se ha enviado a la rama del remoto. Si el token es incorrecto o ha caducado, el error es `remote: Invalid username or token` o `Authentication failed`: se genera otro token. Actualizamos la página del repositorio en GitHub: aparecen los ficheros y todos los commits con sus mensajes. El `.gitignore` ha cumplido su función: ni `target/` ni `.idea/` están ahí.

### Enlazar la rama con la del remoto: push -u

Hacemos un cambio más, para ver qué ocurre con el siguiente envío. Todo repositorio de GitHub debería tener un `README.md`, un fichero en formato Markdown en la raíz que explica de qué trata el proyecto y cómo ponerlo en marcha; es lo primero que se ve al abrirlo. Lo creamos en la raíz del proyecto (clic derecho sobre el proyecto, `New > File`, nombre `README.md`) con este contenido:

```markdown
# Tareas

API REST de tareas con Spring Boot, Spring Data JPA y PostgreSQL.

## Puesta en marcha

1. Crear la base de datos `tareas` y ejecutar el script `sql/01-crear-tarea.sql`.
2. Definir la variable de entorno `POSTGRES_PASSWORD` con la contraseña del usuario `postgres`.
3. Arrancar `Aplicacion` y abrir `http://localhost:8080/api/tareas`.
```

Lo guardamos como commit y probamos a enviarlo escribiendo solo `git push`:

```bash
git add README.md
git commit -m "Añadir el README del proyecto"
git push
```

<pre>
[main 9bf70c1] Añadir el README del proyecto
 1 file changed, 9 insertions(+)
 create mode 100644 README.md
fatal: The current branch main has no upstream branch.
To push the current branch and set the remote as upstream, use

    git push --set-upstream origin main

To have this happen automatically for branches without a tracking
upstream, see 'push.autoSetupRemote' in 'git help config'.
</pre>

Git se niega. En el primer `push` le indicamos a mano a qué rama del remoto enviar, pero Git no guardó esa relación: la rama `main` de nuestro ordenador todavía no sabe cuál es su rama gemela del remoto, y sin saberlo no puede decidir adónde ir cuando escribimos `git push` a secas. El propio mensaje trae la solución. La opción `-u` (*set upstream*) hace dos cosas a la vez: envía los commits y deja registrado que `main` de este ordenador sigue a `main` del remoto, de modo que a partir de ahora basta con escribir `git push` y `git pull`:

```bash
git push -u origin main
```

<pre>
To https://github.com/usuario/tareas.git
   7b2bd1e..9bf70c1  main -&gt; main
branch 'main' set up to track 'origin/main'.
</pre>

La última línea, `set up to track`, confirma que quedan enlazadas. Solo hay que hacerlo una vez por rama. Comprobamos el estado:

```bash
git status
```

<pre>
On branch main
Your branch is up to date with 'origin/main'.

nothing to commit, working tree clean
</pre>

`up to date with 'origin/main'` quiere decir que la rama local y la del remoto coinciden. `origin/main` es la copia local de lo que Git sabe que hay en el remoto. Antes del `-u`, ese mismo comando no mencionaba el remoto.

### Clonar el repositorio en otra carpeta

Para simular a otra persona, o a la misma en otro ordenador, clonamos el repositorio en una carpeta distinta. Nos situamos fuera del proyecto, en una carpeta vacía de nuestra elección, y ejecutamos:

```bash
git clone https://github.com/usuario/tareas.git tareas-copia
```

<pre>
Cloning into 'tareas-copia'...
remote: Enumerating objects: 40, done.
remote: Counting objects: 100% (40/40), done.
remote: Compressing objects: 100% (30/30), done.
remote: Total 40 (delta 6), reused 40 (delta 6), pack-reused 0 (from 0)
Receiving objects: 100% (40/40), 12.01 KiB | 4.00 MiB/s, done.
Resolving deltas: 100% (6/6), done.
</pre>

`clone` descarga todo el historial, crea una carpeta con los ficheros de la rama principal y deja ya configurado el remoto `origin` y la rama enlazada, así que no hace falta `-u`. El último dato del comando, `tareas-copia`, es el nombre de la carpeta nueva; sin él, Git usaría el nombre del repositorio (`tareas`) y chocaría con el proyecto original. Como el repositorio es privado, vuelve a pedir credenciales si el Credential Manager no las recuerda.

Ahora tenemos dos copias del mismo repositorio: el proyecto original (`tareas`), abierto en IntelliJ, y la copia (`tareas-copia`). Para trabajar en la copia desde la terminal, entramos en ella con `cd tareas-copia`. Hacemos un cambio desde ahí: añadimos al final del `README.md`, tras una línea en blanco, estas líneas (con cualquier editor de texto sirve):

```markdown
## Autores

- Ana García
```

Hacemos commit y lo enviamos. Aquí `git push` no necesita argumentos, porque `clone` ya dejó enlazada la rama:

```bash
git add README.md
git commit -m "Añadir los autores al README"
git push
```

<pre>
[main 3a2a0c4] Añadir los autores al README
 1 file changed, 4 insertions(+)
Enumerating objects: 5, done.
Counting objects: 100% (5/5), done.
Delta compression using up to 8 threads
Compressing objects: 100% (3/3), done.
Writing objects: 100% (3/3), 338 bytes | 338.00 KiB/s, done.
Total 3 (delta 2), reused 0 (delta 0), pack-reused 0
To https://github.com/usuario/tareas.git
   9bf70c1..3a2a0c4  main -&gt; main
</pre>

### Traer los cambios: pull

El proyecto original no sabe nada de ese commit. Volvemos a su terminal (la de IntelliJ) y traemos lo nuevo del remoto:

```bash
git pull
```

<pre>
From https://github.com/usuario/tareas
   9bf70c1..3a2a0c4  main       -&gt; origin/main
Updating 9bf70c1..3a2a0c4
Fast-forward
 README.md | 4 ++++
 1 file changed, 4 insertions(+)
</pre>

`pull` hace dos cosas seguidas: descarga los commits nuevos del remoto (`fetch`) y los incorpora a la rama actual (`merge`, fusionar). Aquí la incorporación es trivial: el proyecto original no había avanzado por su lado, así que a Git le basta con mover la rama al último commit (`Fast-forward`, avance rápido), sin crear ningún commit nuevo.

El ciclo de trabajo en equipo se resume en esto: `pull` para traer lo de los demás, cambios y `commit` en el ordenador propio, y `push` para compartirlos. Mientras cada persona toca ficheros o líneas distintas, funciona sin sobresaltos. Falta ver qué pasa cuando no es así.

### Dos copias cambian la misma línea

Ahora hacemos que las dos copias cambien **la misma línea** sin haberse traído antes lo que hizo la otra, que es lo que pasa en un equipo cuando dos personas trabajan a la vez. Las dos modifican el orden en que `listar()` devuelve las tareas.

En la **copia** (`tareas-copia`), con cualquier editor de texto, abrimos `src/main/java/com/curso/controller/TareaController.java` y cambiamos la línea de `Sort`: queremos las tareas pendientes primero.

```java
        return tareaRepository.findAll(Sort.by("completada"));
```

(`completada` vale `false` en las pendientes y `true` en las terminadas, y `false` se ordena antes que `true`.) Hacemos commit y lo enviamos, y todo va bien:

```bash
git add src
git commit -m "Listar primero las tareas pendientes"
git push
```

<pre>
[main e926653] Listar primero las tareas pendientes
 1 file changed, 1 insertion(+), 1 deletion(-)
To https://github.com/usuario/tareas.git
   3a2a0c4..e926653  main -&gt; main
</pre>

En el **proyecto original**, en IntelliJ y sin hacer `pull` antes, cambiamos la misma línea de `TareaController.java` para ordenar por título:

```java
        return tareaRepository.findAll(Sort.by("titulo"));
```

Lo guardamos como commit desde la ventana de commit (`Alt+0`) con el mensaje `Listar las tareas ordenadas por título`. En la terminal intentamos enviarlo:

```bash
git push
```

<pre>
To https://github.com/usuario/tareas.git
 ! [rejected]        main -&gt; main (fetch first)
error: failed to push some refs to 'https://github.com/usuario/tareas.git'
hint: Updates were rejected because the remote contains work that you do not
hint: have locally. This is usually caused by another repository pushing to
hint: the same ref. If you want to integrate the remote changes, use
hint: 'git pull' before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
</pre>

Git rechaza el envío. `rejected` y `fetch first` significan que el remoto tiene commits que nosotros no tenemos, y Git no deja enviar nada que pudiera pisar trabajo ajeno. No es un fallo: es la protección que impide perder cambios. La solución es la que dice el mensaje: traer primero lo del remoto.

```bash
git pull
```

<pre>
From https://github.com/usuario/tareas
   3a2a0c4..e926653  main       -&gt; origin/main
Auto-merging src/main/java/com/curso/controller/TareaController.java
CONFLICT (content): Merge conflict in src/main/java/com/curso/controller/TareaController.java
Automatic merge failed; fix conflicts and then commit the result.
</pre>

Esta vez no hay avance rápido. Las dos copias han avanzado por su lado, y Git intenta **fusionar** los dos caminos. Como cada uno cambió una línea distinta, lo haría solo; pero aquí los dos cambiaron la misma, y Git no puede decidir cuál vale: eso es un **conflicto** (`CONFLICT (content)`). No es un error sino un caso normal del trabajo compartido. Git deja la fusión a medias y espera a que una persona decida el resultado. Lo vemos con el estado:

```bash
git status
```

<pre>
On branch main
Your branch and 'origin/main' have diverged,
and have 1 and 1 different commits each, respectively.
  (use "git pull" if you want to integrate the remote branch with yours)

You have unmerged paths.
  (fix conflicts and run "git commit")
  (use "git merge --abort" to abort the merge)

Unmerged paths:
  (use "git add &lt;file&gt;..." to mark resolution)
	both modified:   src/main/java/com/curso/controller/TareaController.java

no changes added to commit (use "git add" and/or "git commit -a")
</pre>

El fichero aparece como `both modified` (modificado en las dos copias). Si abrimos `TareaController.java`, Git ha escrito dentro del fichero las dos versiones, separadas por unas marcas:

<pre>
&lt;&lt;&lt;&lt;&lt;&lt;&lt; HEAD
        return tareaRepository.findAll(Sort.by("titulo"));
=======
        return tareaRepository.findAll(Sort.by("completada"));
&gt;&gt;&gt;&gt;&gt;&gt;&gt; e9266535c309c329c6903d5b68307ecee09776c0
</pre>

- `<<<<<<< HEAD` abre el conflicto. Lo que hay hasta el `=======` es **nuestra** versión (la del commit en el que estamos situados, `HEAD`).
- `=======` separa las dos versiones.
- `>>>>>>>` cierra el conflicto. Lo que hay entre el `=======` y esta línea es la versión que llega del remoto, con el identificador del commit (aquí, `e926653...`; el tuyo será otro).

Un conflicto se resuelve decidiendo qué queda, que puede ser una de las versiones, la otra o una combinación de las dos, y borrando las tres líneas de marcas. Mientras queden marcas el código no compila. Aquí las dos versiones son correctas y las queremos las dos: pendientes primero y, dentro de cada grupo, por título.

### Resolver el conflicto con el editor de IntelliJ

Podemos editar las marcas a mano, pero IntelliJ ofrece un editor que lo hace más cómodo. IntelliJ detecta que hay una fusión pendiente. Abrimos `Git > Resolve Conflicts…` (también aparece un aviso con el enlace `Resolve` en la esquina inferior derecha). Se abre la ventana `Conflicts`, que lista los ficheros afectados: `TareaController.java`. Tiene tres botones: `Accept Yours` (conserva solo nuestra versión), `Accept Theirs` (conserva solo la que llega del remoto) y `Merge…` (abre el editor de conflictos). Los dos primeros son atajos que descartan la otra versión sin avisar; aquí queremos una combinación, así que hacemos clic en `Merge…`.

El **editor de conflictos** muestra tres paneles:

- el de la izquierda tiene nuestra versión (la que teníamos en el proyecto original),
- el de la derecha tiene la versión que llega del remoto (la de la copia),
- el del centro es el **resultado**: lo que quedará en el fichero. Es un panel que se puede editar.

Los fragmentos en conflicto aparecen resaltados en los tres paneles. Entre los paneles hay flechas (`>>` y `<<`) que copian un fragmento de un lado al resultado. Sirven cuando queremos quedarnos con una de las dos versiones. En nuestro caso ninguna de las dos es la solución completa, así que editamos directamente el panel central hasta que la línea quede así:

```java
        return tareaRepository.findAll(Sort.by("completada", "titulo"));
```

`Sort.by("completada", "titulo")` ordena por varios campos: primero por `completada` y, entre las tareas con el mismo valor, por `titulo`. Hacemos clic en `Apply` (abajo) para guardar el resultado. IntelliJ hace el equivalente a `git add` del fichero. Comprobamos que no quedan marcas en el fichero y vemos el estado:

```bash
git status
```

<pre>
On branch main
Your branch and 'origin/main' have diverged,
and have 1 and 1 different commits each, respectively.
  (use "git pull" if you want to integrate the remote branch with yours)

All conflicts fixed but you are still merging.
  (use "git commit" to conclude merge)

Changes to be committed:
	modified:   src/main/java/com/curso/controller/TareaController.java
</pre>

`All conflicts fixed but you are still merging` significa que falta el último paso: el commit que cierra la fusión. Abrimos la ventana de commit (`Alt+0`), que trae el mensaje `Merge branch 'main' of https://github.com/usuario/tareas` ya escrito (lo deja Git). Podemos conservarlo o cambiarlo por uno que explique la decisión, como `Fusionar los dos órdenes: pendientes primero y por título`. Pulsamos `Commit`. En la terminal, la fusión se cierra con `git add` del fichero y `git commit -m "mensaje"`; para abandonarla sin resolver nada, se usa `git merge --abort`.

Por último, enviamos el resultado:

```bash
git push
```

<pre>
To https://github.com/usuario/tareas.git
   e926653..a54f61f  main -&gt; main
</pre>

Y miramos el historial:

```bash
git log --oneline
```

<pre>
a54f61f (HEAD -&gt; main, origin/main) Merge branch 'main' of https://github.com/usuario/tareas
71971ad Listar las tareas ordenadas por título
e926653 Listar primero las tareas pendientes
3a2a0c4 Añadir los autores al README
9bf70c1 Añadir el README del proyecto
7b2bd1e Añadir la tarea de compartir el proyecto
e5fbbef Listar las tareas ordenadas por id
60f7613 Añadir el script SQL y la conexión a PostgreSQL
9be3c46 Añadir Lombok y las clases de la aplicación
7f1731e Proyecto inicial generado con Spring Boot
</pre>

Los dos cambios están en el historial, y el commit de fusión (`Merge branch 'main'...`) recuerda que dos caminos se juntaron. Arrancamos la aplicación (después de ejecutar otra vez `sql/01-crear-tarea.sql` en pgAdmin, para que la base tenga también la cuarta tarea) y abrimos `http://localhost:8080/api/tareas`: las tareas pendientes salen primero y ordenadas por título, y la terminada, al final.

<pre>
[{"titulo":"Cerrar la sesión","descripcion":"Subir el proyecto a un repositorio remoto","completada":false,"id":3},{"titulo":"Compartir el proyecto","descripcion":"Dar acceso al resto del grupo","completada":false,"id":4},{"titulo":"Practicar los commits","descripcion":"Hacer cambios pequeños con mensajes claros","completada":false,"id":2},{"titulo":"Preparar la demo de Git","descripcion":"Crear el repositorio local del proyecto","completada":true,"id":1}]
</pre>

La copia (`tareas-copia`) se queda atrás con un solo `git pull`. Ya no la usamos más.

IntelliJ hace lo mismo con `Git > Push…` (`Ctrl+Shift+K`) y `Git > Pull…` (también `Git > Update Project…`), y con `Git > Manage Remotes…` se ve y se edita la lista de remotos. Si el `pull` se hace desde ahí, el conflicto abre directamente la ventana `Conflicts`. Para abrir un repositorio existente, `File > New > Project from Version Control…`, con la dirección del repositorio en el campo `URL`, hace el equivalente a `git clone`.

El repositorio remoto es también el punto de partida de la integración continua: Jenkins no construye carpetas de un ordenador, construye el código de un repositorio.

---

## Resumen de comandos

| Comando | Para qué sirve |
|---|---|
| `git config --global user.name "…"` y `user.email "…"` | Indica el autor que firma los commits |
| `git config --global init.defaultBranch main` | Da el nombre `main` a la rama principal de los repositorios nuevos |
| `git config --global pull.rebase false` | Hace que `pull` junte las dos copias fusionándolas |
| `git init` | Convierte la carpeta en un repositorio |
| `git status` | Muestra qué ha cambiado y qué está preparado |
| `git add <ruta>` | Prepara ficheros para el próximo commit |
| `git commit -m "mensaje"` | Guarda lo preparado como una instantánea |
| `git diff` | Muestra las líneas que han cambiado |
| `git log --oneline` | Muestra el historial, un commit por línea |
| `git remote add origin <url>` | Enlaza el repositorio con un remoto |
| `git push origin main` | Envía la rama al remoto |
| `git push -u origin main` | Envía la rama al remoto y la enlaza con la remota |
| `git push` | Envía los commits de la rama enlazada |
| `git clone <url> <carpeta>` | Descarga una copia de un repositorio remoto |
| `git pull` | Trae los cambios del remoto y los fusiona |
| `git merge --abort` | Cancela una fusión con conflicto |
