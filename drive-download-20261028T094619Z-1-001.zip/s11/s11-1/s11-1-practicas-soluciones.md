# S11-1 Soluciones

## Práctica 1: Repositorio de contactos

La solución crea el proyecto con el generador de Spring Boot, comprueba y configura Git, construye un historial de tres commits (el proyecto tal como lo genera el asistente, la clase `Contacto` y sus tests) y envía el resultado a un repositorio remoto propio. Cada commit contiene un solo tipo de cambio, de modo que el historial se lee como la historia de cómo se construyó el proyecto.

El proyecto completo está en `s11-1-practicas.zip`, en la carpeta `contactos`. El zip contiene el estado final de las dos primeras prácticas (con `resumen()` y `emailValido()`); en esta práctica la clase y los tests tienen solo lo que se indica abajo.

### Crear el proyecto

El único cambio respecto a la Demo 1 es la dependencia: en la segunda pantalla del generador marcamos `Lombok` (en `Developer Tools`) y ninguna otra. El `pom.xml` generado queda con tres dependencias: `spring-boot-starter`, `lombok` (con `<optional>true</optional>` y sin versión) y `spring-boot-starter-test` (con scope `test`). Después de crearlo, renombramos con `Shift+F6` las clases `ContactosApplication` y `ContactosApplicationTests` a `Aplicacion` y `AplicacionTests`.

### Comprobar Git y crear el repositorio

En la terminal de IntelliJ (`Alt+F12`):

```bash
git --version
git config --global --list
git init
git status
```

`git config --global --list` debe mostrar `user.name`, `user.email`, `init.defaultbranch=main` y `pull.rebase=false`. Si falta alguna, se configura como en la Demo 1. Salida esperada de `git init` y `git status`:

<pre>
Initialized empty Git repository in /ruta/contactos/.git/
On branch main

No commits yet

Untracked files:
  (use "git add &lt;file&gt;..." to include in what will be committed)
	.gitattributes
	.gitignore
	.mvn/
	mvnw
	mvnw.cmd
	pom.xml
	src/

nothing added to commit but untracked files present (use "git add" to track)
</pre>

`.idea`, `target` y `HELP.md` no aparecen porque el `.gitignore` que genera Spring Boot los ignora.

### Primer commit: el proyecto generado

```bash
git add .
git commit -m "Proyecto inicial generado con Spring Boot"
```

<pre>
[main (root-commit) d4f9b60] Proyecto inicial generado con Spring Boot
 9 files changed, 620 insertions(+)
 create mode 100644 .gitattributes
 create mode 100644 .gitignore
 create mode 100644 .mvn/wrapper/maven-wrapper.properties
 create mode 100755 mvnw
 create mode 100644 mvnw.cmd
 create mode 100644 pom.xml
 create mode 100644 src/main/java/com/curso/Aplicacion.java
 create mode 100644 src/main/resources/application.properties
 create mode 100644 src/test/java/com/curso/AplicacionTests.java
</pre>

### Segundo commit: la clase Contacto

Creamos el paquete `com.curso.model` (clic derecho sobre `src/main/java`, `New > Package`) y dentro la clase `Contacto` (clic derecho sobre el paquete, `New > Java Class`):

```java
package com.curso.model;

// Getter, Setter y NoArgsConstructor proceden de Lombok, que Maven descarga con el pom.xml.
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * S11-1 Práctica 1: Clase Contacto
 *
 * Objetivo: representar a una persona de una agenda de contactos.
 *
 * Lo que hace este ejemplo:
 *   - Guarda el nombre, el correo electrónico y el teléfono del contacto
 *   - Lombok genera los getters, los setters y el constructor vacío
 *
 * Concepto clave: es una clase Java normal, sin JPA. Solo necesitamos un código
 * sencillo al que hacer cambios y guardarlos con Git.
 */
// @Getter y @Setter generan un getter y un setter por cada campo.
// @NoArgsConstructor genera el constructor sin parámetros.
@Getter
@Setter
@NoArgsConstructor
public class Contacto {

    private String nombre;
    private String email;
    private String telefono;

    // Constructor con los tres datos del contacto.
    public Contacto(String nombre, String email, String telefono) {
        this.nombre = nombre;
        this.email = email;
        this.telefono = telefono;
    }

}
```

`@Getter`, `@Setter` y `@NoArgsConstructor` de Lombok generan los getters, los setters y el constructor vacío. El constructor con los tres datos se escribe a mano porque Lombok no sabe qué campos queremos recibir. Es una clase Java normal, sin JPA: no hay base de datos, solo un código sencillo al que hacer cambios y guardarlos con Git.

Antes de hacer el commit miramos qué ha cambiado:

```bash
git status --short
git add src
git commit -m "Añadir la clase Contacto con Lombok"
```

<pre>
?? src/main/java/com/curso/model/
[main e1b3324] Añadir la clase Contacto con Lombok
 1 file changed, 38 insertions(+)
 create mode 100644 src/main/java/com/curso/model/Contacto.java
</pre>

### Tercer commit: los tests

Creamos el paquete `com.curso.model` en `src/test/java` y dentro la clase `ContactoTests`:

```java
package com.curso.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

/**
 * S11-1 Práctica 1: Tests de la clase Contacto
 *
 * Objetivo: comprobar que Contacto guarda y devuelve sus datos y que sus métodos
 * hacen lo esperado.
 */
class ContactoTests {

    // Comprueba que el constructor guarda los datos y que los getters los devuelven.
    @Test
    void guardaLosDatos() {
        Contacto contacto = new Contacto("Lucía Pérez", "lucia@example.com", "600123456");

        assertEquals("Lucía Pérez", contacto.getNombre());
        assertEquals("lucia@example.com", contacto.getEmail());
        assertEquals("600123456", contacto.getTelefono());
    }

    // Comprueba que el setter cambia el valor del campo.
    @Test
    void cambiaElEmail() {
        Contacto contacto = new Contacto("Lucía Pérez", "lucia@example.com", "600123456");

        contacto.setEmail("lucia.perez@example.com");

        assertEquals("lucia.perez@example.com", contacto.getEmail());
    }

}
```

Los dos tests cubren lo que ya hace la clase: que el constructor y los getters guardan y devuelven los datos, y que un setter cambia el valor. Los ejecutamos con ▶ junto al nombre de la clase: los dos pasan. Después:

```bash
git add src
git commit -m "Añadir los tests de Contacto"
git log --oneline
```

<pre>
[main a5ba17d] Añadir los tests de Contacto
 1 file changed, 35 insertions(+)
 create mode 100644 src/test/java/com/curso/model/ContactoTests.java
a5ba17d (HEAD -&gt; main) Añadir los tests de Contacto
e1b3324 Añadir la clase Contacto con Lombok
d4f9b60 Proyecto inicial generado con Spring Boot
</pre>

Tres instantáneas, del commit más reciente al más antiguo. En el historial se ve cómo se construyó el proyecto sin abrir ningún fichero.

### Enviar el proyecto al repositorio remoto

En GitHub: `+` > `New repository`, **Repository name** `contactos`, **Private** seleccionado, y sin marcar `Add a README file`, `Add .gitignore` ni `Choose a license`. Copiamos la dirección de la pestaña `HTTPS` y, en la terminal de IntelliJ:

```bash
git remote add origin https://github.com/usuario/contactos.git
git push -u origin main
```

Como ya conocemos el motivo de `-u` (dejar enlazada la rama local con la del remoto), lo escribimos desde el primer envío. Si el sistema pide credenciales, el usuario es el de la cuenta de GitHub y la contraseña es el token. Salida esperada del `push` (las líneas de progreso que escribe Git variarán):

<pre>
Enumerating objects: 33, done.
Counting objects: 100% (33/33), done.
Delta compression using up to 8 threads
Compressing objects: 100% (22/22), done.
Writing objects: 100% (33/33), 8.12 KiB | 4.06 MiB/s, done.
Total 33 (delta 2), reused 0 (delta 0), pack-reused 0
remote: Resolving deltas: 100% (2/2), done.
To https://github.com/usuario/contactos.git
 * [new branch]      main -&gt; main
branch 'main' set up to track 'origin/main'.
</pre>

Comprobamos con el estado que la rama coincide con la del remoto:

```bash
git status
```

<pre>
On branch main
Your branch is up to date with 'origin/main'.

nothing to commit, working tree clean
</pre>

Al actualizar la página del repositorio en GitHub aparecen los tres commits con sus mensajes y los ficheros del proyecto, y no aparecen `target` ni `.idea`.

**Decisiones tomadas**

- Se hace un commit para el proyecto tal como lo genera el asistente antes de escribir ninguna clase. Así el historial distingue lo que genera la herramienta de lo que escribimos nosotros.
- Código y tests van en commits distintos porque son dos cambios con sentido propio: la clase se puede entender sin los tests, y los tests aportan una segunda lectura.
- Se prepara `src` y no `.` en los commits segundo y tercero para que solo entre lo que se pretende. Con `git status --short` antes de cada commit se comprueba qué entra.
- El mensaje de cada commit nombra el cambio ("Añadir la clase Contacto con Lombok") y no el trabajo ("segundo commit").
- El repositorio remoto se crea vacío y privado. Vacío, para que su historial no choque con el local; privado, porque es un proyecto de práctica. Este repositorio lo usará Jenkins más adelante, en las sesiones de integración continua.

---

## Práctica 2: Flujo completo en IntelliJ

La solución añade dos métodos a `Contacto`, cada uno con sus tests, y hace un commit por método desde la ventana de commit de IntelliJ. Después revisa el historial y envía los dos commits al remoto con el menú `Git`.

Las clases finales son las del zip. Al terminar esta práctica, `Contacto` queda así:

```java
package com.curso.model;

// Getter, Setter y NoArgsConstructor proceden de Lombok, que Maven descarga con el pom.xml.
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * S11-1 Práctica 1: Clase Contacto
 *
 * Objetivo: representar a una persona de una agenda de contactos.
 *
 * Lo que hace este ejemplo:
 *   - Guarda el nombre, el correo electrónico y el teléfono del contacto
 *   - Lombok genera los getters, los setters y el constructor vacío
 *   - Ofrece resumen() y emailValido()
 *
 * Concepto clave: es una clase Java normal, sin JPA. Solo necesitamos un código
 * sencillo al que hacer cambios y guardarlos con Git.
 */
// @Getter y @Setter generan un getter y un setter por cada campo.
// @NoArgsConstructor genera el constructor sin parámetros.
@Getter
@Setter
@NoArgsConstructor
public class Contacto {

    private String nombre;
    private String email;
    private String telefono;

    // Constructor con los tres datos del contacto.
    public Contacto(String nombre, String email, String telefono) {
        this.nombre = nombre;
        this.email = email;
        this.telefono = telefono;
    }

    /**
     * Devuelve el contacto en una sola línea: el nombre y, entre paréntesis, el correo y el teléfono.
     *
     * Ejemplo:
     *   resumen()  →  "Lucía Pérez (lucia@example.com, 600123456)"
     *
     * @return el texto con los tres datos del contacto
     */
    public String resumen() {
        // Concatenamos los tres datos con los separadores que queremos entre ellos.
        return nombre + " (" + email + ", " + telefono + ")";
    }

    /**
     * Comprueba que el correo tiene un aspecto razonable.
     *
     * Ejemplo:
     *   "lucia@example.com"   →  true
     *   "lucia@example"       →  false (no tiene punto)
     *   "lucia @example.com"  →  false (tiene un espacio)
     *
     * @return true si el correo tiene @, tiene punto y no tiene espacios
     */
    public boolean emailValido() {
        // contains() devuelve true si el texto contiene la cadena indicada.
        // El operador && exige que se cumplan las tres condiciones a la vez.
        return email.contains("@") && email.contains(".") && !email.contains(" ");
    }

}
```

Y `ContactoTests`, con los cinco tests:

```java
package com.curso.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * S11-1 Práctica 1: Tests de la clase Contacto
 *
 * Objetivo: comprobar que Contacto guarda y devuelve sus datos y que sus métodos
 * hacen lo esperado.
 */
class ContactoTests {

    // Comprueba que el constructor guarda los datos y que los getters los devuelven.
    @Test
    void guardaLosDatos() {
        Contacto contacto = new Contacto("Lucía Pérez", "lucia@example.com", "600123456");

        assertEquals("Lucía Pérez", contacto.getNombre());
        assertEquals("lucia@example.com", contacto.getEmail());
        assertEquals("600123456", contacto.getTelefono());
    }

    // Comprueba que el setter cambia el valor del campo.
    @Test
    void cambiaElEmail() {
        Contacto contacto = new Contacto("Lucía Pérez", "lucia@example.com", "600123456");

        contacto.setEmail("lucia.perez@example.com");

        assertEquals("lucia.perez@example.com", contacto.getEmail());
    }

    // Comprueba que resumen() une el nombre, el correo y el teléfono.
    @Test
    void resumenIncluyeEmailYTelefono() {
        Contacto contacto = new Contacto("Lucía Pérez", "lucia@example.com", "600123456");

        assertEquals("Lucía Pérez (lucia@example.com, 600123456)", contacto.resumen());
    }

    // Comprueba que un correo correcto es válido.
    @Test
    void emailCorrectoEsValido() {
        Contacto contacto = new Contacto("Lucía Pérez", "lucia@example.com", "600123456");

        assertTrue(contacto.emailValido());
    }

    // Comprueba que un correo sin punto o con espacios no es válido.
    @Test
    void emailSinPuntoOConEspaciosNoEsValido() {
        assertFalse(new Contacto("Lucía Pérez", "lucia@example", "600123456").emailValido());
        assertFalse(new Contacto("Lucía Pérez", "lucia @example.com", "600123456").emailValido());
    }

}
```

### Primer cambio: resumen()

Añadimos a `Contacto` el método `resumen()` (el primero de los dos métodos del código de arriba) y a `ContactoTests` el test `resumenIncluyeEmailYTelefono`. En la ventana de commit (`Alt+0`) aparecen los dos ficheros, en azul y con la casilla marcada. Con `Ctrl+D` sobre cada uno, IntelliJ abre la comparación, y todas las líneas nuevas aparecen resaltadas en verde en la columna derecha. Es lo mismo que mostraría `git diff`:

<pre>
diff --git a/src/main/java/com/curso/model/Contacto.java b/src/main/java/com/curso/model/Contacto.java
index 518853f..fc7dd5c 100644
--- a/src/main/java/com/curso/model/Contacto.java
+++ b/src/main/java/com/curso/model/Contacto.java
@@ -35,4 +35,17 @@ public class Contacto {
         this.telefono = telefono;
     }
 
+    /**
+     * Devuelve el contacto en una sola línea: el nombre y, entre paréntesis, el correo y el teléfono.
+     *
+     * Ejemplo:
+     *   resumen()  →  "Lucía Pérez (lucia@example.com, 600123456)"
+     *
+     * @return el texto con los tres datos del contacto
+     */
+    public String resumen() {
+        // Concatenamos los tres datos con los separadores que queremos entre ellos.
+        return nombre + " (" + email + ", " + telefono + ")";
+    }
+
 }
diff --git a/src/test/java/com/curso/model/ContactoTests.java b/src/test/java/com/curso/model/ContactoTests.java
index a7950f2..57afe02 100644
--- a/src/test/java/com/curso/model/ContactoTests.java
+++ b/src/test/java/com/curso/model/ContactoTests.java
@@ -32,4 +32,12 @@ class ContactoTests {
         assertEquals("lucia.perez@example.com", contacto.getEmail());
     }
 
+    // Comprueba que resumen() une el nombre, el correo y el teléfono.
+    @Test
+    void resumenIncluyeEmailYTelefono() {
+        Contacto contacto = new Contacto("Lucía Pérez", "lucia@example.com", "600123456");
+
+        assertEquals("Lucía Pérez (lucia@example.com, 600123456)", contacto.resumen());
+    }
+
 }
</pre>

Escribimos el mensaje `Añadir el método resumen y su test` y hacemos clic en `Commit`.

### Segundo cambio: emailValido()

Añadimos el método `emailValido()` y sus dos tests (`emailCorrectoEsValido` y `emailSinPuntoOConEspaciosNoEsValido`). El método usa tres condiciones unidas con `&&`, que exige que se cumplan a la vez (con `||` bastaría una y casi cualquier texto pasaría), el operador `!` para negar la de los espacios, y `contains()`, que devuelve `true` si el texto contiene la cadena indicada. Ejecutamos con ▶ junto al nombre de la clase `ContactoTests`: los cinco tests pasan. Revisamos la comparación de los dos ficheros y hacemos el commit con el mensaje `Añadir el método emailValido y sus tests`.

### El historial y el envío

Abrimos la ventana de Git (`Alt+9`, pestaña `Log`): aparecen los cinco commits. Al seleccionar uno, el panel de la derecha lista los ficheros que cambió y un doble clic abre la comparación. En la terminal de IntelliJ comprobamos lo mismo y vemos cómo están respecto al remoto:

```bash
git log --oneline
git status
```

<pre>
83e2d0e (HEAD -&gt; main) Añadir el método emailValido y sus tests
5adf555 Añadir el método resumen y su test
a5ba17d (origin/main) Añadir los tests de Contacto
e1b3324 Añadir la clase Contacto con Lombok
d4f9b60 Proyecto inicial generado con Spring Boot
On branch main
Your branch is ahead of 'origin/main' by 2 commits.
  (use "git push" to publish your local commits)

nothing to commit, working tree clean
</pre>

`origin/main` está dos commits por detrás de `main`: el remoto no tiene todavía los dos últimos. `ahead of 'origin/main' by 2 commits` lo confirma. Enviamos con `Git > Push…` (atajo `Ctrl+Shift+K`). Se abre un diálogo que lista los commits que se van a subir (los dos nuevos) y la rama de destino (`origin/main`). Hacemos clic en `Push`. Si IntelliJ pide credenciales, se usa la cuenta de GitHub y el token. Comprobamos:

```bash
git status
```

<pre>
On branch main
Your branch is up to date with 'origin/main'.

nothing to commit, working tree clean
</pre>

**Decisiones tomadas**

- Un commit por método, con sus tests dentro: cada commit deja el proyecto en un estado que compila y pasa los tests. Así, si un cambio da problemas, se localiza en un commit pequeño.
- La comparación (`Ctrl+D`) se revisa antes de cada commit para comprobar que solo entra lo que se pretende. Es el hábito que evita subir sin querer un cambio olvidado.
- El envío se hace con `Git > Push…` porque su diálogo enseña qué commits van a subir: permite comprobar antes de enviar lo que `git push` envía sin preguntar.

---

## Práctica 3: Repositorio compartido del grupo

La solución sigue el recorrido de la Demo 3, pero con el proyecto del grupo y con varias personas. Una persona (la dueña) prepara y publica el repositorio; el resto lo clona; y dos integrantes provocan un conflicto sobre una línea de `README.md` para resolverlo con el editor de IntelliJ. Los comandos son los de la demo; aquí se ve el recorrido del conflicto con un ejemplo (el proyecto `pedidos` del grupo 3, con Ana García y Luis Martín como integrantes).

### Quien crea el repositorio

1. Crea en GitHub un repositorio privado y vacío con el nombre del proyecto.
2. Comprueba el `.gitignore` y `application.properties`: la contraseña de la base de datos no debe estar escrita en ningún fichero del proyecto; se lee de `${POSTGRES_PASSWORD}`.
3. Crea el `README.md` de la raíz con la lista de autores sin completar:

```markdown
# Pedidos

Proyecto del grupo 3 de IFCD0014.

## Autores

- Pendiente de completar
```

4. Crea el repositorio, hace el primer commit y lo envía:

```bash
git init
git add .
git status
git commit -m "Proyecto inicial del grupo"
git remote add origin https://github.com/grupo3/pedidos.git
git push -u origin main
```

Con `git status` antes del commit comprueba que `target` y `.idea` no aparecen. En el `push`, el usuario es la cuenta de GitHub y la contraseña, el token (creado antes con el alcance `repo` y una caducidad corta). Salida del envío:

<pre>
To https://github.com/grupo3/pedidos.git
 * [new branch]      main -&gt; main
branch 'main' set up to track 'origin/main'.
</pre>

5. En la página del repositorio, `Settings > Collaborators > Add people`, añade a cada integrante. Cada persona recibe una invitación y debe aceptarla; hasta entonces el repositorio privado responde con un error 404.

### Cada integrante

Crea su propio token (`Settings > Developer settings > Personal access tokens > Tokens (classic)`, alcance `repo`) y clona el repositorio con `File > New > Project from Version Control…` en IntelliJ o con `git clone <url>` en la terminal. Abre el proyecto, comprueba que compila (`Build > Build Project`) y, para ejecutarlo, define `POSTGRES_PASSWORD` en su configuración de ejecución y crea su base de datos con el script SQL: ni la variable ni los datos viajan con el repositorio.

### Provocar el conflicto

Ana y Luis tienen cada uno su copia, igual que el repositorio remoto. Sin traer nada del remoto, cada uno sustituye en su `README.md` la línea `Pendiente de completar` por su nombre y hace commit:

```bash
git add README.md
git commit -m "Añadir a Luis Martín como autor"
```

<pre>
[main 81f2e4c] Añadir a Luis Martín como autor
 1 file changed, 1 insertion(+), 1 deletion(-)
</pre>

(Ana hace lo mismo con su nombre: `Añadir a Ana García como autora`.) Ana envía primero y funciona:

```bash
git push
```

<pre>
To https://github.com/grupo3/pedidos.git
   5b426b0..4843a7a  main -&gt; main
</pre>

Luis envía después y Git lo rechaza, porque el remoto tiene un commit que él no tiene:

```bash
git push
```

<pre>
To https://github.com/grupo3/pedidos.git
 ! [rejected]        main -&gt; main (fetch first)
error: failed to push some refs to 'https://github.com/grupo3/pedidos.git'
hint: Updates were rejected because the remote contains work that you do not
hint: have locally. This is usually caused by another repository pushing to
hint: the same ref. If you want to integrate the remote changes, use
hint: 'git pull' before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details.
</pre>

El mensaje dice qué hacer: traer los cambios. Luis ejecuta `git pull`:

<pre>
From https://github.com/grupo3/pedidos
   5b426b0..4843a7a  main       -&gt; origin/main
Auto-merging README.md
CONFLICT (content): Merge conflict in README.md
Automatic merge failed; fix conflicts and then commit the result.
</pre>

Las dos copias cambiaron la misma línea, así que Git no puede decidir y declara un conflicto. En el fichero, las dos versiones están separadas por las marcas:

<pre>
# Pedidos

Proyecto del grupo 3 de IFCD0014.

## Autores

&lt;&lt;&lt;&lt;&lt;&lt;&lt; HEAD
- Luis Martín
=======
- Ana García
&gt;&gt;&gt;&gt;&gt;&gt;&gt; 4843a7ace3f283e69ffd2fc724fe98a2fc7eb32d
</pre>

Encima del `=======` está la versión de Luis (la de su copia) y debajo la de Ana (la que llega del remoto, con el identificador de su commit).

### Resolver el conflicto

En IntelliJ, `Git > Resolve Conflicts…`, `README.md` y `Merge…`. En el editor de tres paneles, el de la izquierda tiene la versión de Luis, el de la derecha la de Ana y el del centro el resultado. Ninguna de las dos es la solución, porque queremos los dos nombres: se edita el panel central hasta que la sección de autores queda así, sin ninguna marca ni la línea `Pendiente de completar`:

```markdown
## Autores

- Ana García
- Luis Martín
```

Luis hace clic en `Apply`, abre la ventana de commit (`Alt+0`), conserva el mensaje que trae (`Merge branch 'main' of ...`) o lo cambia por uno que explique la decisión, y pulsa `Commit`. Ya puede enviar:

```bash
git push
```

<pre>
[main 6488303] Merge branch 'main' of https://github.com/grupo3/pedidos
To https://github.com/grupo3/pedidos.git
   4843a7a..6488303  main -&gt; main
</pre>

Resultado en el historial:

<pre>
6488303 (HEAD -&gt; main, origin/main, origin/HEAD) Merge branch 'main' of https://github.com/grupo3/pedidos
81f2e4c Añadir a Luis Martín como autor
4843a7a Añadir a Ana García como autora
5b426b0 Proyecto inicial del grupo
</pre>

### El resto del grupo

Los demás integrantes, por turnos, hacen `git pull` (o `Git > Pull…`), añaden su nombre a la lista, hacen commit y envían. Si el envío se rechaza porque otra persona se adelantó, repiten `git pull` y `git push`. Como cada una añade una línea nueva en un sitio distinto, lo normal es que el `pull` funcione solo; si la lista se rellena en la misma línea y hay conflicto, se resuelve igual que el de Luis. Al final, todos hacen un último `pull` y comprueban que su `README.md` tiene todos los nombres, y en la pestaña `Commits` de GitHub aparece al menos un commit de cada persona.

**Decisiones tomadas**

- Se crea una persona dueña del repositorio y el resto son colaboradoras: es la forma más sencilla de dar acceso a un grupo pequeño. Las organizaciones de GitHub, con equipos y permisos más finos, son una opción para proyectos mayores que no necesitamos.
- Cada integrante usa su propio token. Un token es una contraseña y no se comparte: si uno se filtra, se revoca sin afectar al resto, y cada commit queda a nombre de su autor.
- El conflicto se provoca con una línea de relleno (`Pendiente de completar`) que todas las personas tienen que cambiar. Así aparece de manera natural y sin riesgo para el código del grupo: un conflicto en un fichero de texto se entiende de un vistazo y quita el miedo a encontrar después uno en el código.
- Los dos nombres se conservan porque las dos versiones eran correctas. Una resolución que descarta una de las dos (`Accept Yours` o `Accept Theirs`) habría borrado a una persona de la lista sin avisar.
- El repositorio del grupo queda listo para que Jenkins lo construya: es lo que se necesita en las sesiones de integración continua.
