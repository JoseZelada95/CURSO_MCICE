# S06-1 Demos

## Objetivos

Esta demo es una guía para construir, paso a paso y desde cero en IntelliJ IDEA, una aplicación web con Spring Boot: una página del navegador que muestra una lista de libros guardados en una base de datos.

Al terminar se habrá:
- Creado un proyecto Spring Boot con el generador de IntelliJ.
- Entendido qué aportan el `parent`, los starters y la autoconfiguración.
- Guardado y leído datos en una base de datos H2 sin escribir SQL.
- Comprobado por qué una aplicación con servidor web no termina sola: Tomcat embebido.
- Consultado las tablas desde el navegador con la consola de H2.
- Entendido el patrón MVC (modelo, vista, controlador) y localizado cada pieza en el proyecto.
- Mostrado los datos en una página HTML con Thymeleaf.


### Antes de empezar

- IntelliJ IDEA abierto.
- JDK 21 instalado (IntelliJ lo detecta solo; lo comprobaremos al crear el proyecto).
- Conexión a Internet: el generador y Maven descargan librerías.
- Un navegador.
- Una carpeta donde guardar el proyecto.

---

## Demo 1: Aplicación web de libros con Spring Boot

La aplicación guarda varios libros en una base de datos y los muestra en una página, en la dirección `http://localhost:8080/libros` pasando por todos los pasos para crear una aplicación web real:
- Un servidor que recibe peticiones.
- Un controlador que las atiende.
- Un repositorio que habla con la base de datos.
- Una plantilla que construye la página.

Se construye en este orden:

| Paso | Qué hacemos | Qué aparece en el proyecto |
|---|---|---|
| 1 | Entender qué es Spring Boot | Nada de código |
| 2 | Crear el proyecto con el generador de IntelliJ | Proyecto base |
| 3 | Recorrer el `pom.xml` | `pom.xml` |
| 4 | Preparar la clase principal | `Aplicacion.java` |
| 5 | Configurar la base de datos | `application.properties` |
| 6 | Declarar la entidad | `Libro.java` |
| 7 | Declarar el repositorio | `LibroRepository.java` |
| 8 | Guardar y leer libros al arrancar | `CargaDatos.java` |
| 9 | Arrancar por primera vez | Salida por consola |
| 10 | Añadir el servidor web | Tomcat embebido |
| 11 | Mirar dentro de la base de datos | Consola de H2 |
| 12 | Atender una petición web | `LibroController.java` |
| 13 | Construir la página | `libros.html` |
| 14 | Probar en el navegador | La página de libros |
| 15 | Una nota sobre los scopes | Nada de código |
| 16 | Cierre | Resumen del recorrido |

---

### Paso 1: Qué es Spring Boot


**Spring** es un **framework**: una estructura de aplicación ya montada, con huecos donde ponemos nuestras clases.
- Una librería es una caja de herramientas: la abrimos cuando queremos y usamos la que necesitamos.
- Un framework es un local ya reformado: la estructura ya está y nosotros colocamos nuestros muebles. Además, es el framework quien decide cuándo llama a nuestro código.

**Dos ideas de Spring que usaremos desde el primer minuto:**
- **Contenedor y bean.** Spring tiene un almacén de objetos llamado **contenedor**. Cada objeto que crea y guarda ahí se llama **bean**. Nosotros no escribimos `new`: pedimos lo que necesitamos y Spring lo entrega. Es como una cocina de restaurante donde el cocinero no va a comprar los ingredientes: se los dejan preparados en la mesa.
- **Inyección por constructor.** Una clase declara en su constructor lo que necesita para trabajar, y Spring se lo entrega al crearla. Es la forma de que los beans se conecten entre sí sin que ninguno cree a los demás.

**Spring Boot** es Spring con tres ayudas añadidas. No sustituye a Spring: lo usa por debajo.
- **El `parent`.** Spring Boot publica un proyecto Maven padre, `spring-boot-starter-parent`, que fija las versiones de todas las librerías habituales de una aplicación Spring. Nuestro `pom.xml` hereda de él y no tenemos que escribir ninguna versión. Es como una lista de la compra con marcas que ya se han probado juntas.
- **Los starters.** Un **starter** es una única dependencia de Maven que trae, por debajo, un paquete completo de librerías para un propósito. Es como comprar el kit de baño completo en lugar de buscar el grifo, el plato de ducha y los tubos por separado. Ejemplos: `spring-boot-starter-data-jpa` (bases de datos) y `spring-boot-starter-webmvc` (aplicaciones web).
- **La autoconfiguración.** Spring Boot mira qué librerías hay en el **classpath** (el conjunto de librerías y carpetas donde Java busca clases) y configura por nosotros lo que normalmente configuraríamos a mano. Es como el hotel que, al ver en tu reserva que viajas con un bebé, prepara una cuna sin que se la pidas. Si ve la base de datos H2, configura una conexión a H2. Si ve el servidor Tomcat, lo arranca. Y si nosotros configuramos algo, Spring Boot cede y usa lo nuestro.

Una forma de verlo: Spring a secas es comprar los muebles y los electrodomésticos sueltos y montar la cocina pieza a pieza. Spring Boot es recibir la cocina ya montada y con los aparatos enchufados. Sigue siendo la misma cocina; solo que se puede empezar a cocinar el primer día.

Al final habremos construido este recorrido, que es el que sigue cada petición que llega a la aplicación:

<pre>
navegador  →  Tomcat (servidor web)  →  controlador  →  repositorio  →  base de datos H2 →
                                              
navegador  ←  página HTML  ←  plantilla Thymeleaf (con los libros)
</pre>

---

### Paso 2: Crear el proyecto con el generador de IntelliJ

IntelliJ incluye un generador de proyectos Spring Boot. Por debajo usa la web `start.spring.io` de Spring, así que necesita Internet. Hace en un minuto lo que a mano llevaría un buen rato: crea la estructura de carpetas, el `pom.xml` con el `parent` y las dependencias que elijamos y la clase principal.

**Primera pantalla: datos del proyecto**

1. Vamos a `File > New > Project`.
2. En el panel izquierdo, dentro de **Generators**, seleccionamos **Spring Boot**.
3. Rellenamos los campos (los dejamos como vengan si no se mencionan):

| Campo | Valor |
|---|---|
| **Name** | `s06-1-demo` |
| **Location** | La carpeta donde guardamos los proyectos |
| **Language** | `Java` |
| **Type** | `Maven` |
| **Group** | `com.curso` |
| **Artifact** | `s06-1-demo` |
| **Package name** | `com.curso` |
| **JDK** | `21` |
| **Java** | `21` |
| **Packaging** | `Jar` |

Qué significa cada campo:
- **Name** y **Location**: cómo se llama la carpeta del proyecto y dónde se guarda.
- **Type: Maven**: la herramienta que compila el proyecto y descarga sus librerías.
- **Group**: identifica a la organización, escrito con el dominio al revés (`com.curso` y no `curso.com`).
- **Artifact**: el nombre del proyecto para Maven. Maven usa este nombre para el fichero que produce al empaquetar.
- **Package name**: el paquete Java donde el generador crea la clase principal. **Lo cambiamos a `com.curso`**: IntelliJ propone `com.curso.s061demo`, que se forma uniendo Group y Artifact sin guiones, y con ese nombre las clases quedarían en otro paquete distinto del que usa la guía. Un **paquete** agrupa clases relacionadas, igual que una carpeta agrupa ficheros.
- **Packaging: Jar**: el tipo de fichero que se genera al empaquetar. Un JAR es un fichero comprimido con las clases compiladas.

4. Pulsamos **Next**.

**Segunda pantalla: versión y dependencias**

5. En **Spring Boot** elegimos `4.1.1`.
6. En el buscador de dependencias escribimos `Spring Data JPA` y la marcamos.
7. Buscamos `H2 Database` y la marcamos.
8. Comprobamos que en el panel derecho (**Added dependencies**) aparecen solo esas dos.
9. Pulsamos **Create**.

Qué hemos elegido:
- **Spring Data JPA**: lo necesario para guardar y leer datos de una base de datos. Lo explicamos en el Paso 3.
- **H2 Database**: una base de datos pequeña escrita en Java que funciona como una librería dentro del propio programa, sin instalar nada.
- No marcamos más dependencias. Las demás (servidor web, consola de H2, Thymeleaf) las añadimos a mano más adelante, para ver qué cambia con cada una.
- Si la lista no ofrece la versión `4.1.1`, elegimos la que venga seleccionada y, después de crear el proyecto, cambiamos el número en el `pom.xml` (lo vemos en el Paso 3).

**Mientras IntelliJ trabaja**
- IntelliJ descarga el proyecto base, lo abre y empieza a descargar las librerías con Maven. La primera vez puede tardar uno o dos minutos. El progreso aparece en la parte inferior, en la ventana **Build**.
- Si IntelliJ pregunta si confiamos en el proyecto, pulsamos **Trust Project**.
- Si pregunta dónde abrirlo, elegimos **New Window**: así cada proyecto queda en su propia ventana y no se mezclan.

**Qué debe verse**
- En el panel **Project** (a la izquierda), la carpeta `s06-1-demo` con estos elementos:
  - `.idea`, `.mvn` y `src`
  - `.gitattributes` y `.gitignore`
  - `HELP.md`, `mvnw`, `mvnw.cmd`
  - `pom.xml`
- IntelliJ abre `HELP.md` en el editor. Es un fichero de ayuda del generador: lo cerramos, no lo usamos.
- En la ventana **Build**, la sincronización termina sin errores en rojo.
- Dentro de `src/main/java`, el paquete `com.curso` con una clase llamada `S061DemoApplication`. La renombramos en el Paso 4.

**Si aparece el aviso "Maven build scripts found"**
- Es una notificación de IntelliJ, con un botón **Load**. Significa que IntelliJ ha encontrado un `pom.xml`, pero todavía no lo ha leído.
- Mientras no pulsemos **Load**, IntelliJ no sabe qué librerías tiene el proyecto y subraya en rojo los `import`.
- Al pulsar **Load**, IntelliJ lee el `pom.xml`, descarga lo que falte y configura el proyecto.
- Esto ocurre sobre todo al **abrir** un proyecto que ya existe. Para abrir uno: `File > Open`, seleccionamos la carpeta que contiene directamente el `pom.xml` (aquí, `s06-1-demo`) y pulsamos **OK**. Si elegimos una carpeta superior que contiene varios proyectos, IntelliJ no sabe cuál es el proyecto Maven.
- Si cerramos la notificación sin pulsar **Load**: panel **Maven** (icono `m` del borde derecho) y pulsamos el icono de recargar, o clic derecho sobre el `pom.xml` y `Maven > Reload project`.

**Si la ventana Build muestra un error en rojo: `Unable to create injector`**
- Es un fallo del arranque de Maven dentro de IntelliJ, no del proyecto. La línea del error dice algo como `No implementation for ArtifactHandlerManager was bound`.
- Primer intento:
  1. Abrimos `Ctrl+Alt+S` y vamos a `Build, Execution, Deployment > Build Tools > Maven`.
  2. En **Maven home path** elegimos `Bundled (Maven 3)`.
  3. Pulsamos **OK**.
  4. En el panel **Maven**, pulsamos el icono de recargar.
- Si sigue fallando, abrimos `.mvn/wrapper/maven-wrapper.properties` y miramos el valor de `distributionUrl`: tiene que apuntar a una versión 3.9 de Maven.

---

### Paso 3: Recorrer el pom.xml

Abrimos `pom.xml` con doble clic. **POM** son las siglas de *Project Object Model*: es el fichero donde Maven lee todo sobre el proyecto, antes de hacer nada. Este es el contenido que debemos ver (puede llevar algún elemento más, como etiquetas vacías `<url/>` o `<licenses>`, o dependencias de test: no importa y no las tocamos):

<pre>
&amp;lt;?xml version="1.0" encoding="UTF-8"?&amp;gt;
&amp;lt;project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd"&amp;gt;
    &amp;lt;modelVersion&amp;gt;4.0.0&amp;lt;/modelVersion&amp;gt;
    &amp;lt;parent&amp;gt;
        &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
        &amp;lt;artifactId&amp;gt;spring-boot-starter-parent&amp;lt;/artifactId&amp;gt;
        &amp;lt;version&amp;gt;4.1.1&amp;lt;/version&amp;gt;
        &amp;lt;relativePath/&amp;gt; &amp;lt;!-- lookup parent from repository --&amp;gt;
    &amp;lt;/parent&amp;gt;
    &amp;lt;groupId&amp;gt;com.curso&amp;lt;/groupId&amp;gt;
    &amp;lt;artifactId&amp;gt;s06-1-demo&amp;lt;/artifactId&amp;gt;
    &amp;lt;version&amp;gt;0.0.1-SNAPSHOT&amp;lt;/version&amp;gt;
    &amp;lt;name&amp;gt;s06-1-demo&amp;lt;/name&amp;gt;
    &amp;lt;description&amp;gt;S06-1 Demo 1: aplicación Spring Boot con Libro, Spring Data JPA, H2 y Thymeleaf&amp;lt;/description&amp;gt;
    &amp;lt;properties&amp;gt;
        &amp;lt;java.version&amp;gt;21&amp;lt;/java.version&amp;gt;
    &amp;lt;/properties&amp;gt;
    &amp;lt;dependencies&amp;gt;
        &amp;lt;dependency&amp;gt;
            &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
            &amp;lt;artifactId&amp;gt;spring-boot-starter-data-jpa&amp;lt;/artifactId&amp;gt;
        &amp;lt;/dependency&amp;gt;
        &amp;lt;dependency&amp;gt;
            &amp;lt;groupId&amp;gt;com.h2database&amp;lt;/groupId&amp;gt;
            &amp;lt;artifactId&amp;gt;h2&amp;lt;/artifactId&amp;gt;
            &amp;lt;scope&amp;gt;runtime&amp;lt;/scope&amp;gt;
        &amp;lt;/dependency&amp;gt;
    &amp;lt;/dependencies&amp;gt;

    &amp;lt;build&amp;gt;
        &amp;lt;plugins&amp;gt;
            &amp;lt;plugin&amp;gt;
                &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
                &amp;lt;artifactId&amp;gt;spring-boot-maven-plugin&amp;lt;/artifactId&amp;gt;
            &amp;lt;/plugin&amp;gt;
        &amp;lt;/plugins&amp;gt;
    &amp;lt;/build&amp;gt;

&amp;lt;/project&amp;gt;
</pre>

Lo revisamos:

- **`<parent>`**: de qué proyecto hereda el nuestro.
  - `spring-boot-starter-parent` es el padre de Spring Boot.
  - `<version>4.1.1</version>` es **la versión de Spring Boot**, y es la única versión que decidimos: con ella Spring Boot elige las versiones de todo lo demás. Con esta versión, Spring Framework 7.0.9, Hibernate 7.4.5.Final y Tomcat 11.0.24, entre otras.
  - `<relativePath/>`, vacío, le dice a Maven que no busque el padre en la carpeta de al lado sino que lo descargue de Maven Central, el repositorio público de librerías Java.
  - El comentario `lookup parent from repository` lo escribe siempre el generador.
  - Si al crear el proyecto no estaba `4.1.1`, cambiamos aquí el número a `4.1.1` y pulsamos **Load Maven Changes**.
- **`<groupId>`, `<artifactId>` y `<version>`**: las coordenadas del proyecto, que es como Maven lo identifica. `0.0.1-SNAPSHOT` es la versión que Spring Boot pone al empezar. **SNAPSHOT** significa "en desarrollo, puede cambiar".
- **`<name>` y `<description>`**: datos descriptivos. No afectan a la compilación.
- **`<properties>`**: `java.version` es la versión de Java del proyecto. El `parent` lee esta propiedad y configura con ella el compilador y la codificación de los ficheros (UTF-8).
- **`<dependencies>`**: las librerías que usa el proyecto. Ninguna lleva `<version>`, porque la fija el `parent`.
  - `spring-boot-starter-data-jpa` es nuestro primer starter. Trae todo lo necesario para trabajar con bases de datos:
    - **Spring Data JPA**, **Hibernate** y el estándar **JPA** (veremos qué hace cada uno en los pasos 6 y 7).
    - **HikariCP**, que gestiona un conjunto de conexiones abiertas a la base de datos.
    - El contenedor de Spring (`spring-context`) y el sistema de registro de mensajes (*logging*) con el que Spring Boot escribe en la consola.
  - `h2` es la base de datos. El scope `runtime` indica que la librería solo hace falta cuando el programa se ejecuta y no cuando se compila: nuestro código nunca importa clases de H2, solo habla con la base de datos a través de Hibernate.
- **`<build>` y `spring-boot-maven-plugin`**: un plugin de Maven que sirve para arrancar la aplicación desde Maven y para empaquetarla en un JAR ejecutable. En esta demo arrancamos con ▶, así que no lo usamos directamente, pero todo proyecto Spring Boot lo lleva.

Un cambio opcional, para que la descripción diga qué es el proyecto. Sustituimos el texto de la etiqueta `<description>` por:

```xml
    <description>S06-1 Demo 1: aplicación Spring Boot con Libro, Spring Data JPA, H2 y Thymeleaf</description>
```

Cada vez que modificamos el `pom.xml`, IntelliJ muestra en la esquina superior derecha del editor un icono con la letra `m` y unas flechas: **Load Maven Changes**. Lo pulsamos (o usamos `Ctrl+Shift+O`) para que Maven descargue lo nuevo.

**Qué debe verse**
- El `pom.xml` abierto, con `<version>4.1.1</version>` dentro de `<parent>`.
- Las dos dependencias, `spring-boot-starter-data-jpa` y `h2`.
- Ningún texto subrayado en rojo.

---

### Paso 4: La clase principal

Todo proyecto Spring Boot tiene una clase principal que lo arranca. El generador ya la ha creado, con un nombre largo (`S061DemoApplication`). La renombramos y escribimos nuestra versión con comentarios.

**Renombrar la clase**
1. En el panel **Project**, abrimos `src/main/java` y el paquete `com.curso`.
2. Hacemos clic sobre `S061DemoApplication` y pulsamos `Shift+F6` (o clic derecho y `Refactor > Rename...`).
3. Escribimos `Aplicacion`.
4. Pulsamos Enter. Si IntelliJ muestra una ventana con otros elementos que se pueden renombrar, la dejamos como viene y pulsamos **Refactor**.

**Escribir el código**
5. Abrimos `Aplicacion.java` con doble clic.
6. Seleccionamos todo el contenido (`Ctrl+A`) y lo sustituimos por este código:

```java
package com.curso;

// Importamos SpringApplication, la clase de Spring Boot que arranca la aplicación.
// Procede de la librería spring-boot, que Maven ha descargado al leer los starters del pom.xml.
// Sin Maven habría que buscar el JAR de Spring Boot y el de cada una de sus dependencias, y añadirlos al classpath a mano.
import org.springframework.boot.SpringApplication;
// Importamos @SpringBootApplication, la anotación que convierte esta clase en el punto de partida de la aplicación.
// Procede de spring-boot-autoconfigure, que llega también de forma transitiva con los starters.
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * S06-1 Demo 1: Clase principal de la aplicación Spring Boot
 *
 * Objetivo: arrancar una aplicación Spring Boot completa desde un método main().
 *
 * Lo que hace este ejemplo:
 *   - Marca la clase con @SpringBootApplication
 *   - Arranca el contenedor de Spring con SpringApplication.run()
 *
 * Concepto clave: en una aplicación Spring Boot el arranque se reduce a una anotación
 * y una llamada. Todo lo demás (servidor web, base de datos, Hibernate) lo configura
 * Spring Boot a partir de las dependencias que declaramos en el pom.xml.
 */
// @SpringBootApplication reúne tres anotaciones en una sola:
//   - @Configuration: esta clase puede declarar beans, como las clases de configuración de S05.
//   - @ComponentScan: Spring busca clases con @Component (y sus estereotipos) en este paquete (com.curso)
//     y en todos sus subpaquetes. Por eso esta clase vive en com.curso: los paquetes model, repository,
//     config y controller cuelgan de él y entran en el escaneo sin ninguna configuración adicional.
//   - @EnableAutoConfiguration: Spring Boot configura por su cuenta lo que encuentra en el classpath.
//     Aquí detecta Tomcat, Hibernate, Spring Data JPA, H2 y Thymeleaf, y los deja listos para usar.
@SpringBootApplication
public class Aplicacion {

    // main() es el punto de entrada de cualquier programa Java: lo ejecutamos con ▶ desde IntelliJ.
    public static void main(String[] args) {
        // SpringApplication.run() crea el contenedor de Spring (el ApplicationContext de S05),
        // aplica la autoconfiguración, crea los beans y arranca Tomcat en el puerto 8080.
        // Recibe la clase de configuración (esta misma, desde donde empieza el escaneo)
        // y los argumentos de la línea de comandos.
        // La aplicación no termina al acabar main(): Tomcat sigue escuchando peticiones
        // hasta que la paramos con el botón de parar de IntelliJ.
        SpringApplication.run(Aplicacion.class, args);
    }
}
```

**Qué significa**
- **`@SpringBootApplication`** es una anotación que reúne tres en una:
  - `@Configuration`: la clase puede declarar beans.
  - `@ComponentScan`: Spring busca, en este paquete y en todos sus subpaquetes, las clases marcadas con `@Component` y las convierte en beans. Por eso la clase está en `com.curso`: todo lo que creemos en `com.curso.model`, `com.curso.controller`, etc. se encontrará sin configurar nada más.
  - `@EnableAutoConfiguration`: activa la autoconfiguración del Paso 1.
- **`SpringApplication.run()`**: crea el contenedor de Spring, aplica la autoconfiguración, crea los beans y, si la aplicación es web, arranca el servidor.
- **`main()`**: el punto de entrada de cualquier programa Java. Es lo que ejecuta el botón ▶.

**Qué debe verse**
- En el panel **Project**, la clase se llama `Aplicacion`.
- El código del bloque anterior, sin subrayados en rojo.
- Todavía no ejecutamos nada.

---

### Paso 5: La configuración de la base de datos

Spring Boot lee automáticamente un fichero llamado `application.properties`, situado en `src/main/resources`. El generador ya lo ha creado, con una sola línea.

1. En el panel **Project**, abrimos `src/main/resources` y hacemos doble clic en `application.properties`.
2. Seleccionamos todo (`Ctrl+A`) y lo sustituimos por:

```properties
# Nombre de la aplicación. Spring Boot lo muestra en el log y lo usan otras herramientas para identificarla.
spring.application.name=s06-1-demo

# URL JDBC de la base de datos H2 en memoria: "jdbc:h2:mem:" indica que vive en memoria
# y "libreria" es su nombre. Fijamos el nombre para poder conectarnos a ella desde la consola de H2.
# Si no lo indicamos, Spring Boot crea la base de datos igualmente, pero con un nombre aleatorio distinto en cada arranque.
spring.datasource.url=jdbc:h2:mem:libreria

# Qué hace Hibernate con las tablas al arrancar y al parar:
# create-drop crea las tablas a partir de las entidades al arrancar y las borra al parar la aplicación.
# Es el comportamiento adecuado con H2 en memoria, donde los datos desaparecen igualmente al terminar.
spring.jpa.hibernate.ddl-auto=create-drop

# Hibernate escribe en la consola cada sentencia SQL que ejecuta, precedida de "Hibernate:".
# Así vemos qué SQL genera Spring Data JPA a partir de nuestro código Java.
spring.jpa.show-sql=true
```

**Qué significa**
- Es un fichero de texto con una propiedad por línea, en formato `clave=valor`. Las líneas que empiezan por `#` son comentarios.
- **`spring.application.name`**: el nombre de la aplicación. Spring Boot lo muestra en los mensajes de arranque.
- **`spring.datasource.url`**: la dirección de la base de datos, escrita como una URL de JDBC.
  - **JDBC** (*Java Database Connectivity*) es el estándar de Java para hablar con bases de datos. Hibernate genera el SQL y lo envía por JDBC.
  - La URL se lee separada por dos puntos: `jdbc` es el protocolo, `h2` la base de datos, `mem` indica que es una base de datos **en memoria**, y `libreria` es su nombre.
  - Una base de datos en memoria es como una pizarra: mientras la aplicación está en marcha podemos escribir y leer en ella, pero al apagarla se borra todo y cada arranque empieza en blanco. Para aprender es ideal.
  - Le ponemos un nombre fijo a propósito: más adelante nos conectaremos a ella desde el navegador y tendremos que escribir exactamente ese nombre.
- **`spring.jpa.hibernate.ddl-auto`**: qué hace Hibernate con las tablas.
  - **DDL** (*Data Definition Language*) son las sentencias de SQL que crean y borran tablas, como `CREATE TABLE`.
  - `create-drop` significa: crear las tablas a partir de nuestras clases al arrancar y borrarlas al parar. Es lo adecuado con una base de datos en memoria.
  - Con una base de datos real, donde los datos deben conservarse, se usa otro valor.
- **`spring.jpa.show-sql`**: Hibernate escribe en la consola cada sentencia SQL que ejecuta, así vemos qué SQL genera nuestro código Java.

Fijémonos en lo que **no** hemos escrito:
- Ni el usuario ni la contraseña de la base de datos.
- Ni el driver.
- Ni cuántas conexiones abrir.
- Ni qué variante de SQL entiende H2.

Spring Boot lo deduce todo del classpath. Eso es la autoconfiguración.

**Qué debe verse**
- `application.properties` con las cuatro propiedades y sus comentarios.
- Todavía no ejecutamos nada.

---

### Paso 6: La entidad Libro

Ya podemos declarar qué datos vamos a guardar. Una **entidad** es una clase Java que Hibernate convierte en una tabla de la base de datos.
- Pensemos en una hoja de cálculo: la hoja es la tabla, cada columna es un campo de la clase y cada fila es un objeto, un libro concreto.
- O en el fichero de fichas de una biblioteca: cada ficha es un libro y todas tienen los mismos apartados.
- **Hibernate** es la librería que hace esa traducción: convierte objetos en filas y filas en objetos. Esto se llama **mapeo objeto-relacional** (ORM).

**Crear el paquete y la clase**
1. Clic derecho sobre `src/main/java`.
2. `New > Package`.
3. Escribimos `com.curso.model` y pulsamos Enter.
4. Clic derecho sobre el paquete `com.curso.model`.
5. `New > Java Class`.
6. Escribimos `Libro` y pulsamos Enter.

Agrupamos las clases en subpaquetes según su papel: `model` (datos), `repository` (acceso a datos), `controller` (peticiones web) y `config` (configuración). Los nombres de los subpaquetes van en inglés, por convención profesional, y los de las clases en español.

**Primer bloque: la clase y sus campos**

7. Abrimos `Libro.java`, seleccionamos todo (`Ctrl+A`) y lo sustituimos por:

```java
package com.curso.model;

// Importamos las anotaciones de JPA (Jakarta Persistence), el estándar de Java para mapear clases a tablas.
// Proceden de jakarta.persistence-api, que Maven ha descargado de forma transitiva con spring-boot-starter-data-jpa.
// No hace falta declararla en el pom.xml: la trae el starter.
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

/**
 * S06-1 Demo 1: Entidad Libro
 *
 * Objetivo: declarar una clase Java que Hibernate convierte en una tabla de la base de datos.
 *
 * Lo que hace este ejemplo:
 *   - Marca la clase con @Entity para que Hibernate la gestione
 *   - Declara la clave primaria con @Id y @GeneratedValue
 *   - Define los datos de un libro: título, autor, año e ISBN
 *
 * Concepto clave: una entidad es una clase Java que se corresponde con una tabla.
 * La clase es la tabla, cada campo es una columna y cada objeto es una fila.
 */
// @Entity le dice a Hibernate que esta clase representa una tabla.
// Sin otras anotaciones, la tabla se llama como la clase ("libro") y cada columna como su campo.
@Entity
public class Libro {

    // @Id marca el campo que es la clave primaria: el valor que identifica cada fila de forma única.
    // @GeneratedValue indica que ese valor no lo escribimos nosotros: lo genera la base de datos.
    // GenerationType.IDENTITY usa una columna autoincremental: el primer libro recibe el id 1, el segundo el 2, etc.
    // El campo es Long (objeto) y no long (primitivo) porque un libro nuevo todavía no tiene id: vale null hasta que se guarda.
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Los campos sin anotar se convierten en columnas con el mismo nombre del campo.
    // Un String se guarda como texto (varchar) y puede ser null.
    private String titulo;
    private String autor;

    // Usamos "anio" y no "año" para evitar la eñe en el nombre de un campo y de una columna.
    // Un int es un primitivo: nunca puede ser null, así que su columna se crea como "not null".
    private int anio;
    private String isbn;
}
```

Qué significa:
- **`@Entity`**: le dice a Hibernate que la clase representa una tabla. Sin más anotaciones, la tabla se llama como la clase y cada columna como su campo. Viene de **Jakarta Persistence** (JPA), el estándar de Java para guardar objetos en bases de datos. El `import` funciona sin tocar el `pom.xml` porque `spring-boot-starter-data-jpa` trajo la librería.
- **`@Id`**: marca la **clave primaria**, el campo cuyo valor identifica cada fila de forma única, como el número de socio en una biblioteca. Toda entidad necesita una.
- **`@GeneratedValue(strategy = GenerationType.IDENTITY)`**: el `id` no lo escribimos nosotros, lo genera la base de datos con una columna autoincremental (el primer libro recibe el 1, el segundo el 2...).
- **`Long` y no `long`**: `long` es un tipo primitivo y nunca puede valer `null`; `Long` es un objeto y sí puede. Un libro nuevo todavía no tiene `id`, así que vale `null` hasta que se guarda.
- **Los demás campos** se convierten en columnas con su mismo nombre. Un `String` es texto y puede ser `null`. Un `int` es primitivo: nunca puede ser `null`, y por eso su columna será `not null`.
- Escribimos `anio` y no `año` para evitar la eñe en el nombre de un campo y de una columna.

**Segundo bloque: los constructores**

8. Pegamos este bloque justo debajo de la línea `private String isbn;` y encima de la llave final `}`:

```java
    // Constructor sin argumentos: Hibernate lo necesita.
    // Cuando lee una fila de la base de datos crea primero un Libro vacío con este constructor
    // y después rellena sus campos. Sin él, no podría reconstruir los objetos.
    public Libro() {
    }

    // Constructor con los datos de un libro: es el que usamos nosotros para crear libros nuevos.
    // No recibe el id: lo asigna la base de datos al guardar.
    public Libro(String titulo, String autor, int anio, String isbn) {
        this.titulo = titulo;
        this.autor = autor;
        this.anio = anio;
        this.isbn = isbn;
    }
```

Qué significa:
- El **constructor** es un bloque especial que Java ejecuta cada vez que se crea un objeto con `new`. Se llama igual que la clase y no tiene tipo de retorno.
- **El constructor vacío** es obligatorio: cuando Hibernate lee una fila, primero crea un `Libro` vacío con este constructor y después rellena sus campos.
- **El constructor con datos** es el que usamos nosotros para crear libros nuevos. No recibe el `id`: lo asigna la base de datos al guardar.
- **`this`** se refiere al propio objeto: `this.titulo = titulo` copia el parámetro en el campo.

**Tercer bloque: los getters y `toString()`**

9. Pegamos este bloque debajo de los constructores y encima de la llave final `}`:

```java
    // Un getter por campo: devuelve el valor para que otras clases puedan leerlo.
    // Thymeleaf los usará más adelante, en esta misma demo, para mostrar los datos en la página.
    public Long getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public int getAnio() {
        return anio;
    }

    public String getIsbn() {
        return isbn;
    }

    // toString() devuelve el texto con el que se imprime el objeto.
    // Sin sobrescribirlo, println() mostraría algo ilegible como com.curso.model.Libro@1b2c3d.
    @Override
    public String toString() {
        return "Libro{id=" + id + ", titulo='" + titulo + "', autor='" + autor
                + "', anio=" + anio + ", isbn='" + isbn + "'}";
    }
```

Qué significa:
- Un **getter** es un método que devuelve el valor de un campo privado. Por convención se llama `get` seguido del nombre del campo con la primera letra en mayúscula. Es la forma de que otras clases lean los datos de un `Libro`. Más adelante veremos quién los usa.
- **`toString()`** devuelve el texto con el que se imprime un objeto. Todas las clases lo heredan de `Object`, pero la versión heredada imprime algo ilegible como `com.curso.model.Libro@1b2c3d`. Lo reescribimos para que muestre los datos.
- **`@Override`** avisa al compilador de que estamos reescribiendo un método heredado y le pide que compruebe que de verdad existe en la clase padre. Si nos equivocamos al escribir el nombre, el compilador da un error en lugar de crear un método distinto sin que nos demos cuenta.

Así queda `Libro.java` completo.

```java
package com.curso.model;

// Importamos las anotaciones de JPA (Jakarta Persistence), el estándar de Java para mapear clases a tablas.
// Proceden de jakarta.persistence-api, que Maven ha descargado de forma transitiva con spring-boot-starter-data-jpa.
// No hace falta declararla en el pom.xml: la trae el starter.
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

/**
 * S06-1 Demo 1: Entidad Libro
 *
 * Objetivo: declarar una clase Java que Hibernate convierte en una tabla de la base de datos.
 *
 * Lo que hace este ejemplo:
 *   - Marca la clase con @Entity para que Hibernate la gestione
 *   - Declara la clave primaria con @Id y @GeneratedValue
 *   - Define los datos de un libro: título, autor, año e ISBN
 *
 * Concepto clave: una entidad es una clase Java que se corresponde con una tabla.
 * La clase es la tabla, cada campo es una columna y cada objeto es una fila.
 */
// @Entity le dice a Hibernate que esta clase representa una tabla.
// Sin otras anotaciones, la tabla se llama como la clase ("libro") y cada columna como su campo.
@Entity
public class Libro {

    // @Id marca el campo que es la clave primaria: el valor que identifica cada fila de forma única.
    // @GeneratedValue indica que ese valor no lo escribimos nosotros: lo genera la base de datos.
    // GenerationType.IDENTITY usa una columna autoincremental: el primer libro recibe el id 1, el segundo el 2, etc.
    // El campo es Long (objeto) y no long (primitivo) porque un libro nuevo todavía no tiene id: vale null hasta que se guarda.
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Los campos sin anotar se convierten en columnas con el mismo nombre del campo.
    // Un String se guarda como texto (varchar) y puede ser null.
    private String titulo;
    private String autor;

    // Usamos "anio" y no "año" para evitar la eñe en el nombre de un campo y de una columna.
    // Un int es un primitivo: nunca puede ser null, así que su columna se crea como "not null".
    private int anio;
    private String isbn;

    // Constructor sin argumentos: Hibernate lo necesita.
    // Cuando lee una fila de la base de datos crea primero un Libro vacío con este constructor
    // y después rellena sus campos. Sin él, no podría reconstruir los objetos.
    public Libro() {
    }

    // Constructor con los datos de un libro: es el que usamos nosotros para crear libros nuevos.
    // No recibe el id: lo asigna la base de datos al guardar.
    public Libro(String titulo, String autor, int anio, String isbn) {
        this.titulo = titulo;
        this.autor = autor;
        this.anio = anio;
        this.isbn = isbn;
    }

    // Un getter por campo: devuelve el valor para que otras clases puedan leerlo.
    // Thymeleaf los usará más adelante, en esta misma demo, para mostrar los datos en la página.
    public Long getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public int getAnio() {
        return anio;
    }

    public String getIsbn() {
        return isbn;
    }

    // toString() devuelve el texto con el que se imprime el objeto.
    // Sin sobrescribirlo, println() mostraría algo ilegible como com.curso.model.Libro@1b2c3d.
    @Override
    public String toString() {
        return "Libro{id=" + id + ", titulo='" + titulo + "', autor='" + autor
                + "', anio=" + anio + ", isbn='" + isbn + "'}";
    }
}
```

**Qué debe verse**
- En el panel **Project**: `com.curso.model` con la clase `Libro`.
- El fichero sin subrayados en rojo.
- Todavía no ejecutamos nada: falta algo que guarde los libros.

---

### Paso 7: El repositorio

Con la entidad declarada, necesitamos algo que la guarde y la lea. Pensemos en una biblioteca: los libros no están sueltos por la sala, hay un almacén, y cuando alguien necesita un libro se lo pide a quien lo gestiona. En el código, ese almacén se llama **repositorio**: la pieza que guarda y busca las entidades de un tipo.

Con Spring Data JPA un repositorio no se escribe: se **declara**.

**Crear el paquete y la interfaz**
1. Clic derecho sobre `src/main/java`, `New > Package`, escribimos `com.curso.repository` y pulsamos Enter.
2. Clic derecho sobre el paquete `com.curso.repository`, `New > Java Class`.
3. Escribimos `LibroRepository`.
4. En la lista que aparece en el cuadro, elegimos **Interface** (en lugar de **Class**) y pulsamos Enter.
5. Abrimos `LibroRepository.java`, seleccionamos todo (`Ctrl+A`) y lo sustituimos por:

```java
package com.curso.repository;

import com.curso.model.Libro;

// Importamos JpaRepository, la interfaz de Spring Data JPA que ya trae las operaciones habituales de acceso a datos.
// Procede de spring-data-jpa, que Maven ha descargado de forma transitiva con spring-boot-starter-data-jpa.
// Sin esta librería tendríamos que escribir a mano el código de Hibernate para guardar y consultar cada entidad.
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * S06-1 Demo 1: Repositorio de libros con Spring Data JPA
 *
 * Objetivo: obtener las operaciones de acceso a datos de Libro sin escribir su implementación.
 *
 * Lo que hace este ejemplo:
 *   - Declara una interfaz que extiende JpaRepository
 *   - Indica con qué entidad trabaja (Libro) y de qué tipo es su clave primaria (Long)
 *
 * Concepto clave: con Spring Data JPA un repositorio es solo una interfaz vacía.
 * Spring crea la clase que la implementa al arrancar y la deja disponible como bean.
 */
// JpaRepository<Libro, Long> recibe dos tipos genéricos: la entidad que gestiona (Libro)
// y el tipo de su clave primaria (Long, el tipo del campo id).
// Al extender la interfaz heredamos, sin escribir nada, métodos como:
//   - save(libro): guarda un libro (INSERT si es nuevo, UPDATE si ya existe)
//   - findAll(): devuelve todos los libros
//   - findById(id): busca un libro por su clave primaria
//   - count(): cuenta cuántos libros hay
//   - deleteById(id): borra un libro por su clave primaria
// No hace falta @Repository ni @Component: Spring Data detecta las interfaces que extienden JpaRepository
// dentro del paquete escaneado y crea un bean por cada una.
public interface LibroRepository extends JpaRepository<Libro, Long> {
}
```

**Qué significa**
- Una **interfaz** es un contrato: declara qué operaciones ofrece, pero no cómo funcionan. Es como la carta de un restaurante: dice qué platos se pueden pedir, no cómo se cocinan; la cocina es otra cosa.
- **`extends`** entre interfaces significa "heredo todo lo que declara la otra". No escribimos ningún método: heredamos todos los de `JpaRepository`.
- **`JpaRepository<Libro, Long>`**: los símbolos `<` y `>` indican con qué tipos trabaja la interfaz, igual que `List<String>` es una lista de textos. Aquí, el primer tipo es la entidad que gestiona (`Libro`) y el segundo el tipo de su clave primaria (`Long`, el tipo del campo `id`).
- Lo que heredamos, sin escribirlo:
  - `save()`: guardar.
  - `findAll()`: obtener todos.
  - `findById()`: buscar por clave primaria.
  - `count()`: contar.
  - `deleteById()`: borrar.
- **¿Quién escribe la clase que lo implementa?** **Spring Data JPA**, una capa de Spring por encima de Hibernate que escribe por nosotros el código repetitivo de guardar, buscar y borrar. Al arrancar, detecta las interfaces que extienden `JpaRepository` dentro del paquete escaneado, genera en memoria una clase que las implementa y la registra como un bean más. Por eso no hace falta `@Repository` ni `@Component`. Es como encargar a un gestor que rellene los formularios: nosotros decimos qué queremos y él hace el papeleo.
- Tres piezas con nombres parecidos, para no confundirlas:
  - **JPA**: el estándar, solo define las reglas, como una norma.
  - **Hibernate**: la librería que cumple esa norma y genera el SQL.
  - **Spring Data JPA**: la capa de Spring que nos ahorra escribir el código repetitivo.

**Qué debe verse**
- En el panel **Project**: `com.curso.repository` con `LibroRepository`. El icono de la clase es el de una interfaz (una `I`).
- Sin subrayados en rojo.

---

### Paso 8: Guardar y leer libros al arrancar

Antes de construir la parte web comprobamos que la base de datos funciona: guardamos libros y los leemos justo al arrancar. Para ejecutar código en ese momento, Spring Boot ofrece **`CommandLineRunner`**: una interfaz con un único método, `run()`, que Spring Boot ejecuta una vez, cuando el contenedor ya está arrancado y todos los beans están listos.

**Crear el paquete y la clase**
1. Clic derecho sobre `src/main/java`, `New > Package`, escribimos `com.curso.config` y pulsamos Enter.
2. Clic derecho sobre `com.curso.config`, `New > Java Class`, escribimos `CargaDatos` y pulsamos Enter.

**Primer bloque: la clase y su dependencia**

3. Abrimos `CargaDatos.java`, seleccionamos todo (`Ctrl+A`) y lo sustituimos por:

```java
package com.curso.config;

import com.curso.model.Libro;
import com.curso.repository.LibroRepository;

// Importamos CommandLineRunner, una interfaz de Spring Boot cuyo método run() se ejecuta una vez
// cuando la aplicación ha terminado de arrancar. Procede de spring-boot, que Maven ha descargado con los starters.
import org.springframework.boot.CommandLineRunner;
// Importamos @Component, la anotación de S05 que convierte una clase en un bean de Spring.
import org.springframework.stereotype.Component;

/**
 * S06-1 Demo 1: Carga de datos de ejemplo
 *
 * Objetivo: guardar y leer libros con el repositorio nada más arrancar la aplicación.
 *
 * Lo que hace este ejemplo:
 *   - Recibe el repositorio por inyección en el constructor
 *   - Cuenta los libros antes y después de guardar
 *   - Guarda cuatro libros y los lista por consola
 *
 * Concepto clave: el repositorio es un bean más. Spring lo inyecta donde se necesita
 * y con una sola llamada a save() Hibernate genera y ejecuta el INSERT.
 */
// @Component hace que Spring cree un bean de esta clase durante el escaneo de com.curso.
// Al implementar CommandLineRunner, Spring Boot llama a su método run() automáticamente
// cuando el contexto ya está arrancado y todos los beans están listos.
@Component
public class CargaDatos implements CommandLineRunner {

    // El repositorio es una dependencia de esta clase: sin él no puede guardar ni leer libros.
    // Es final porque se asigna una sola vez, en el constructor.
    private final LibroRepository libroRepository;

    // Inyección por constructor: al ser el único constructor, Spring lo usa solo
    // y busca en el contenedor un bean de tipo LibroRepository para entregárselo.
    // Ese bean es la clase que Spring Data JPA ha generado a partir de la interfaz.
    public CargaDatos(LibroRepository libroRepository) {
        this.libroRepository = libroRepository;
    }
}
```

IntelliJ subraya `CargaDatos` en rojo. Es lo esperado: la clase dice que cumple la interfaz `CommandLineRunner` y todavía no ha escrito su método.

Qué significa:
- **`implements`**: una clase declara con esta palabra que cumple una interfaz. Queda obligada a escribir todos los métodos de la interfaz, y cada uno lleva `@Override` encima. Si `extends` es "heredo de", `implements` es "me comprometo a cumplir".
- **`@Component`**: Spring crea un bean de esta clase al escanear `com.curso`. Al ser un bean que implementa `CommandLineRunner`, Spring Boot lo encuentra y llama a su `run()`.
- **Inyección por constructor**: la clase declara en su constructor lo que necesita (el repositorio) y Spring se lo entrega. Funciona aunque nosotros no hayamos escrito la clase del repositorio, porque Spring Data JPA la ha registrado como bean.
- **`private final`**: el campo se asigna una sola vez, en el constructor, y ya no puede cambiar.

**Segundo bloque: el método `run()`**

4. Pegamos este bloque debajo del constructor y encima de la llave final `}` de la clase:

```java
    // run() es el método que declara CommandLineRunner y que Spring Boot ejecuta al terminar el arranque.
    // Recibe los argumentos de la línea de comandos con la que se lanzó la aplicación (aquí no los usamos).
    @Override
    public void run(String... args) {
        // count() ejecuta un SELECT count(*) sobre la tabla.
        // Al arrancar, Hibernate acaba de crear la tabla vacía (create-drop), así que no hay ningún libro.
        System.out.println("Libros antes de guardar: " + libroRepository.count());  // → 0

        // save() guarda cada libro: Hibernate genera un INSERT y la base de datos asigna el id.
        // Los ISBN son de ejemplo (inventados): sirven para tener datos con el formato de un ISBN.
        libroRepository.save(new Libro("Don Quijote de la Mancha", "Miguel de Cervantes", 1605, "978-84-000-0001-1"));
        libroRepository.save(new Libro("Cien años de soledad", "Gabriel García Márquez", 1967, "978-84-000-0002-8"));
        libroRepository.save(new Libro("La sombra del viento", "Carlos Ruiz Zafón", 2001, "978-84-000-0003-5"));
        libroRepository.save(new Libro("Rayuela", "Julio Cortázar", 1963, "978-84-000-0004-2"));

        // Volvemos a contar para comprobar que los cuatro INSERT han tenido efecto.
        System.out.println("Libros después de guardar: " + libroRepository.count());  // → 4
    }
```

Qué significa:
- **`String... args`**: los tres puntos significan "cero o más textos". Dentro del método se usa como una lista. Son los argumentos de la línea de comandos con la que se arrancó la aplicación; aquí no los usamos.
- **`count()`**: ejecuta un `SELECT count(*)` sobre la tabla. Al arrancar, Hibernate acaba de crear la tabla vacía, así que da 0.
- **`save()`**: guarda un libro. Hibernate genera un `INSERT` y la base de datos asigna el `id`.
- Los ISBN son inventados, con el formato de un ISBN.

El subrayado rojo de `CargaDatos` desaparece.

**Tercer bloque: leer los libros**

5. Pegamos este bloque **dentro** de `run()`, justo debajo de la línea `System.out.println("Libros después de guardar: " + ...`, y encima de la llave `}` que cierra `run()`:

```java
        // findAll() ejecuta un SELECT de toda la tabla y devuelve una lista de objetos Libro.
        // Hibernate convierte cada fila en un Libro (con el constructor vacío y rellenando los campos).
        // Recorremos la lista con un for-each: en cada vuelta "libro" es un elemento de la lista.
        // println() usa el toString() de Libro, que ya incluye el id asignado por la base de datos.
        System.out.println("Libros guardados:");
        for (Libro libro : libroRepository.findAll()) {
            System.out.println("  " + libro);
        }
```

Qué significa:
- **`findAll()`**: ejecuta un `SELECT` de toda la tabla y devuelve una lista de objetos `Libro`. Hibernate convierte cada fila en un `Libro`.
- **El bucle `for (Libro libro : ...)`** se lee "para cada libro de la lista": en cada vuelta, `libro` es un elemento distinto de la lista.
- **`println()`** imprime cada libro usando el `toString()` que escribimos antes.

Así queda `CargaDatos.java` completo, idéntico al del zip:

```java
package com.curso.config;

import com.curso.model.Libro;
import com.curso.repository.LibroRepository;

// Importamos CommandLineRunner, una interfaz de Spring Boot cuyo método run() se ejecuta una vez
// cuando la aplicación ha terminado de arrancar. Procede de spring-boot, que Maven ha descargado con los starters.
import org.springframework.boot.CommandLineRunner;
// Importamos @Component, la anotación de S05 que convierte una clase en un bean de Spring.
import org.springframework.stereotype.Component;

/**
 * S06-1 Demo 1: Carga de datos de ejemplo
 *
 * Objetivo: guardar y leer libros con el repositorio nada más arrancar la aplicación.
 *
 * Lo que hace este ejemplo:
 *   - Recibe el repositorio por inyección en el constructor
 *   - Cuenta los libros antes y después de guardar
 *   - Guarda cuatro libros y los lista por consola
 *
 * Concepto clave: el repositorio es un bean más. Spring lo inyecta donde se necesita
 * y con una sola llamada a save() Hibernate genera y ejecuta el INSERT.
 */
// @Component hace que Spring cree un bean de esta clase durante el escaneo de com.curso.
// Al implementar CommandLineRunner, Spring Boot llama a su método run() automáticamente
// cuando el contexto ya está arrancado y todos los beans están listos.
@Component
public class CargaDatos implements CommandLineRunner {

    // El repositorio es una dependencia de esta clase: sin él no puede guardar ni leer libros.
    // Es final porque se asigna una sola vez, en el constructor.
    private final LibroRepository libroRepository;

    // Inyección por constructor: al ser el único constructor, Spring lo usa solo
    // y busca en el contenedor un bean de tipo LibroRepository para entregárselo.
    // Ese bean es la clase que Spring Data JPA ha generado a partir de la interfaz.
    public CargaDatos(LibroRepository libroRepository) {
        this.libroRepository = libroRepository;
    }

    // run() es el método que declara CommandLineRunner y que Spring Boot ejecuta al terminar el arranque.
    // Recibe los argumentos de la línea de comandos con la que se lanzó la aplicación (aquí no los usamos).
    @Override
    public void run(String... args) {
        // count() ejecuta un SELECT count(*) sobre la tabla.
        // Al arrancar, Hibernate acaba de crear la tabla vacía (create-drop), así que no hay ningún libro.
        System.out.println("Libros antes de guardar: " + libroRepository.count());  // → 0

        // save() guarda cada libro: Hibernate genera un INSERT y la base de datos asigna el id.
        // Los ISBN son de ejemplo (inventados): sirven para tener datos con el formato de un ISBN.
        libroRepository.save(new Libro("Don Quijote de la Mancha", "Miguel de Cervantes", 1605, "978-84-000-0001-1"));
        libroRepository.save(new Libro("Cien años de soledad", "Gabriel García Márquez", 1967, "978-84-000-0002-8"));
        libroRepository.save(new Libro("La sombra del viento", "Carlos Ruiz Zafón", 2001, "978-84-000-0003-5"));
        libroRepository.save(new Libro("Rayuela", "Julio Cortázar", 1963, "978-84-000-0004-2"));

        // Volvemos a contar para comprobar que los cuatro INSERT han tenido efecto.
        System.out.println("Libros después de guardar: " + libroRepository.count());  // → 4

        // findAll() ejecuta un SELECT de toda la tabla y devuelve una lista de objetos Libro.
        // Hibernate convierte cada fila en un Libro (con el constructor vacío y rellenando los campos).
        // Recorremos la lista con un for-each: en cada vuelta "libro" es un elemento de la lista.
        // println() usa el toString() de Libro, que ya incluye el id asignado por la base de datos.
        System.out.println("Libros guardados:");
        for (Libro libro : libroRepository.findAll()) {
            System.out.println("  " + libro);
        }
    }
}
```

**Qué debe verse**
- En el panel **Project**: `com.curso.config` con `CargaDatos`.
- Sin subrayados en rojo.

---

### Paso 9: Primer arranque

Es el momento de ejecutar. Todavía no hay servidor web: solo el contenedor de Spring, la base de datos y nuestro `CargaDatos`.

1. Abrimos `Aplicacion.java`.
2. Pulsamos el icono ▶ verde que aparece junto a la línea `public static void main` (en el margen izquierdo del editor).
3. Elegimos **Run 'Aplicacion.main()'**.
4. Se abre abajo la ventana **Run** con la salida de la consola.

**Qué debe verse** (los tiempos, el número de proceso y la ruta serán distintos):

<pre>
  .   ____          _            __ _ _
 /\\ / ___'_ __ _ _(_)_ __  __ _ \ \ \ \
( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \
 \\/  ___)| |_)| | | | | || (_| |  ) ) ) )
  '  |____| .__|_| |_|_| |_\__, | / / / /
 =========|_|==============|___/=/_/_/_/

 :: Spring Boot ::                (v4.1.1)

Starting Aplicacion using Java 21 ...
No active profile set, falling back to 1 default profile: "default"
Finished Spring Data repository scanning in 55 ms. Found 1 JPA repository interface.
HHH000001: Hibernate ORM core version 7.4.5.Final
HikariPool-1 - Added connection conn0: url=jdbc:h2:mem:libreria user=SA
HHH10001005: Database info:
	Database JDBC URL [jdbc:h2:mem:libreria]
	Database driver: H2 JDBC Driver
	Database dialect: H2Dialect
	Database version: 2.4.240
Hibernate: drop table if exists libro cascade
Hibernate: create table libro (anio integer not null, id bigint generated by default as identity, autor varchar(255), isbn varchar(255), titulo varchar(255), primary key (id))
Started Aplicacion in 3.53 seconds (process running for 3.958)
Hibernate: select count(*) from libro l1_0
Libros antes de guardar: 0
Hibernate: insert into libro (anio,autor,isbn,titulo,id) values (?,?,?,?,default)
Hibernate: insert into libro (anio,autor,isbn,titulo,id) values (?,?,?,?,default)
Hibernate: insert into libro (anio,autor,isbn,titulo,id) values (?,?,?,?,default)
Hibernate: insert into libro (anio,autor,isbn,titulo,id) values (?,?,?,?,default)
Hibernate: select count(*) from libro l1_0
Libros después de guardar: 4
Libros guardados:
Hibernate: select l1_0.id,l1_0.anio,l1_0.autor,l1_0.isbn,l1_0.titulo from libro l1_0
  Libro{id=1, titulo='Don Quijote de la Mancha', autor='Miguel de Cervantes', anio=1605, isbn='978-84-000-0001-1'}
  Libro{id=2, titulo='Cien años de soledad', autor='Gabriel García Márquez', anio=1967, isbn='978-84-000-0002-8'}
  Libro{id=3, titulo='La sombra del viento', autor='Carlos Ruiz Zafón', anio=2001, isbn='978-84-000-0003-5'}
  Libro{id=4, titulo='Rayuela', autor='Julio Cortázar', anio=1963, isbn='978-84-000-0004-2'}
Closing JPA EntityManagerFactory for persistence unit 'default'
Hibernate: drop table if exists libro cascade
HikariPool-1 - Shutdown completed.

Process finished with exit code 0
</pre>

En la consola real cada línea de `INFO` empieza por la fecha, el número de proceso, el nombre de la aplicación y el hilo; aquí las hemos recortado para que se lea mejor.

**Cómo leer esta salida**, de arriba abajo:
- **El banner** de Spring Boot y su versión (`v4.1.1`).
- **`Found 1 JPA repository interface`**: Spring Data JPA ha encontrado `LibroRepository` y ha generado su implementación.
- **`Hibernate ORM core version`**: Hibernate arranca.
- **`HikariPool-1 - Added connection`**: se ha abierto una conexión con `jdbc:h2:mem:libreria`, la URL que escribimos en `application.properties`. El usuario `SA` lo ha puesto Spring Boot.
- **`Database dialect: H2Dialect`**: Hibernate ha detectado que la base de datos es H2 y genera el SQL en el dialecto de H2. No se lo dijimos nosotros.
- **`drop table` y `create table`**: es `create-drop` en acción. Hibernate ha creado la tabla `libro` a partir de nuestra clase `Libro`: un campo por columna, `id` como clave primaria autoincremental y las columnas `varchar(255)` para los `String`.
  - `anio integer not null`: es `int` en Java, primitivo, y por eso no admite `null`.
  - `autor`, `isbn` y `titulo` sí admiten `null`.
- **`Started Aplicacion in 3.53 seconds`**: el contenedor ya está listo. A partir de aquí empieza a ejecutarse nuestro código.
- **`Libros antes de guardar: 0`**: la primera salida de `CargaDatos`. Justo antes ha salido el `select count(*)` que ha lanzado Hibernate.
- **Cuatro `insert`**: un libro guardado con `save()` es un `INSERT`. Los `?` son huecos que Hibernate rellena con los valores de cada libro. `default` en `id` significa "que lo ponga la base de datos".
- **`Libros después de guardar: 4`** y la lista final con los `id` del 1 al 4, escritos con nuestro `toString()`.
- **`drop table` final**: al terminar el programa, `create-drop` borra la tabla. Después, la conexión se cierra.
- **`Process finished with exit code 0`**: el programa ha terminado, con código 0, que significa "todo correcto".

Lo que hemos conseguido sin escribir una sola línea de SQL:
- Una tabla creada.
- Cuatro filas guardadas.
- Cuatro filas leídas y convertidas en objetos.

Y fijémonos en lo último: **la aplicación ha terminado sola**. Es lo normal en un programa Java: cuando `main()` y el código que lanza acaban, el programa acaba. En el paso siguiente vemos qué cambia al añadir un servidor web.

---

### Paso 10: Añadir el servidor web, Tomcat embebido

Para que una aplicación atienda peticiones desde un navegador necesita un **servidor web**: un programa que escucha en una dirección y un puerto, y responde a las peticiones que llegan.

Un repaso de cómo funciona la web:
- Es una conversación de **petición y respuesta**. El navegador envía una petición ("dame la página `/libros`") y el servidor devuelve una respuesta (el HTML de esa página).
- **URL**: la dirección completa que escribimos en el navegador, por ejemplo `http://localhost:8080/libros`.
  - `http` es el protocolo de la conversación.
  - `localhost` es el nombre que significa "este mismo ordenador".
  - `8080` es el **puerto**: la "puerta" del ordenador por la que escucha el servidor. Un mismo ordenador puede tener muchos programas escuchando, cada uno en un puerto distinto.
  - `/libros` es la **ruta** de lo que pedimos.
- **GET** es el tipo de petición que hace el navegador cuando escribimos una dirección: "dame esto".
- **Código de estado**: un número en la respuesta. `200` significa "todo bien" y `404` significa "esa ruta no existe".

**Tomcat** es un servidor web escrito en Java, muy extendido. Lo habitual, durante años, fue instalar Tomcat por un lado y entregarle la aplicación empaquetada. Con Spring Boot el enfoque se invierte: **Tomcat viaja dentro de nuestra aplicación**, como una librería más. Por eso se llama **embebido**. Ejecutamos nuestro `main()` y es la propia aplicación la que arranca el servidor. Es la diferencia entre ir a un restaurante y ocupar una mesa en un local ajeno, o llevar el restaurante en una furgoneta.

**Añadir la dependencia**

1. Abrimos `pom.xml`.
2. Dentro de `<dependencies>`, justo debajo de la dependencia `spring-boot-starter-data-jpa`, pegamos este fragmento:

```xml
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-webmvc</artifactId>
        </dependency>
```

3. Pulsamos **Load Maven Changes** (el icono `m` de la esquina superior derecha del editor).

Qué significa:
- **`spring-boot-starter-webmvc`** es el starter de las aplicaciones web con Spring MVC. Trae:
  - **Spring MVC** (`spring-webmvc`), el módulo de Spring para aplicaciones web.
  - **Tomcat embebido** (`tomcat-embed-core`).
  - **Jackson**, una librería para convertir objetos a JSON y al revés (no la usamos hoy).
- No hemos escrito ninguna línea de código ni de configuración para arrancar un servidor. La autoconfiguración de Spring Boot ve que Tomcat está en el classpath y lo arranca.

**Arrancar de nuevo**

4. Pulsamos ▶ (o el icono de volver a ejecutar de la ventana **Run**).

**Qué debe verse** en la consola, entre otras líneas:

<pre>
Tomcat initialized with port 8080 (http)
Starting service [Tomcat]
Starting Servlet engine: [Apache Tomcat/11.0.24]
...
WARN ... JpaBaseConfiguration$JpaWebConfiguration : spring.jpa.open-in-view is enabled by default. Therefore, database queries may be performed during view rendering. Explicitly configure spring.jpa.open-in-view to disable this warning
Tomcat started on port 8080 (http) with context path '/'
Started Aplicacion in 3.857 seconds (process running for 4.29)
</pre>

Seguirán saliendo, a continuación, las líneas de `CargaDatos` con los cuatro libros, igual que en el paso anterior.

**Qué ha cambiado**
- Tomcat arranca en el puerto 8080.
- **El programa no termina**. Los botones de la ventana **Run** siguen mostrando ■ rojo (está en marcha) y no aparece `Process finished`. Antes, al acabar `main()` y `run()`, no quedaba nada que hacer y el programa terminaba. Ahora, Tomcat mantiene vivos unos hilos de ejecución que esperan peticiones. Mientras haya un hilo esperando, el programa no puede terminar. Es como el bar que, aunque ya no queden clientes, no cierra mientras el camarero siga detrás de la barra esperando a que llegue alguien.
- Para parar la aplicación pulsamos ■.

**Comprobar que el servidor responde**
5. Abrimos el navegador y escribimos `http://localhost:8080`.
6. Aparece una página de error con el texto **Whitelabel Error Page** y el código **404**.

Esto es lo correcto: el servidor funciona, pero todavía no hay nadie que atienda ninguna ruta. El `404` lo ha contestado Tomcat.

**El aviso `open-in-view`**
- Es un `WARN`, un aviso, no un error.
- Se refiere a una opción de Spring MVC que mantiene abierta la conexión con la base de datos hasta que termina de construirse la página. Cómodo, pero puede mantener conexiones ocupadas más tiempo del necesario.
- Lo desactivamos para que el aviso desaparezca y el comportamiento sea el más seguro. Al final de `application.properties`, añadimos:

```properties
# Por defecto, en una aplicación web Spring Boot mantiene abierta la sesión de Hibernate durante toda la petición,
# incluido el momento de generar la página, y avisa de ello en el arranque.
# Lo desactivamos: nuestros controladores consultarán los datos antes de generar la página,
# así que no necesitamos que la sesión siga abierta, y evitamos el aviso.
spring.jpa.open-in-view=false
```

- `false` significa que la conexión se libera en cuanto el código de la aplicación termina su trabajo con la base de datos, antes de pintar la página. Por eso conviene que el controlador deje todos los datos listos antes de entregarlos a la vista, tal como haremos en el Paso 12.

Volvemos a ejecutar (■ y después ▶). El aviso ya no aparece.

---

### Paso 11: Mirar dentro de la base de datos con la consola de H2

Hasta ahora solo hemos visto los datos por la consola de IntelliJ. H2 incluye una **consola web**: una página del navegador para escribir consultas SQL contra la base de datos. En Spring Boot 4 esta consola es un módulo aparte, así que añadimos su starter.

**Añadir la dependencia**

1. En `pom.xml`, justo debajo de la dependencia `spring-boot-starter-webmvc`, pegamos:

```xml
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-h2console</artifactId>
        </dependency>
```

2. Pulsamos **Load Maven Changes**.

**Activar la consola**

3. Al final de `application.properties`, añadimos:

```properties
# Activa la consola web de H2 para consultar las tablas desde el navegador: http://localhost:8080/h2-console
spring.h2.console.enabled=true
```

Qué significa:
- La consola está desactivada por defecto, porque dejar abierta una puerta de acceso a la base de datos no es lo que se quiere en un sistema real. Con `enabled=true` la activamos, y solo la usaremos mientras desarrollamos.

**Arrancar y abrir la consola**

4. Arrancamos de nuevo (■ y ▶, o el icono de reiniciar).
5. Buscamos en la consola esta línea:

<pre>
H2 console available at '/h2-console'. Database available at 'jdbc:h2:mem:libreria'
</pre>

6. Abrimos `http://localhost:8080/h2-console`.
7. Rellenamos el formulario de acceso. Tenemos que cambiar la **JDBC URL**, porque la consola propone otra por defecto:

| Campo | Valor |
|---|---|
| **Driver Class** | `org.h2.Driver` (viene así) |
| **JDBC URL** | `jdbc:h2:mem:libreria` |
| **User Name** | `sa` |
| **Password** | (vacío) |

8. Pulsamos **Connect**.
9. A la izquierda aparece el árbol de la base de datos y, dentro, la tabla **LIBRO**.
10. Escribimos en el cuadro grande de la derecha:

```sql
SELECT * FROM LIBRO
```

11. Pulsamos **Run** (o `Ctrl+Enter`).

**Qué debe verse**: una tabla con cuatro filas y las columnas `ANIO`, `ID`, `AUTOR`, `ISBN` y `TITULO`, con los mismos cuatro libros que imprimió `CargaDatos`.

Qué hemos aprendido:
- La tabla existe de verdad en la base de datos, con los datos de `save()`.
- La URL tiene que ser exactamente `jdbc:h2:mem:libreria`: es el nombre que pusimos en `application.properties`. Si escribimos otra, H2 crea una base de datos nueva y vacía, o da un error `Database ... not found`.
- Los nombres aparecen en mayúsculas porque H2 guarda en mayúsculas los nombres que no van entre comillas.

Dejamos la aplicación en marcha. Quedan por construir el controlador y la página.

Así queda `application.properties` completo, idéntico al del zip:

```properties
# Nombre de la aplicación. Spring Boot lo muestra en el log y lo usan otras herramientas para identificarla.
spring.application.name=s06-1-demo

# URL JDBC de la base de datos H2 en memoria: "jdbc:h2:mem:" indica que vive en memoria
# y "libreria" es su nombre. Fijamos el nombre para poder conectarnos a ella desde la consola de H2.
# Si no lo indicamos, Spring Boot crea la base de datos igualmente, pero con un nombre aleatorio distinto en cada arranque.
spring.datasource.url=jdbc:h2:mem:libreria

# Qué hace Hibernate con las tablas al arrancar y al parar:
# create-drop crea las tablas a partir de las entidades al arrancar y las borra al parar la aplicación.
# Es el comportamiento adecuado con H2 en memoria, donde los datos desaparecen igualmente al terminar.
spring.jpa.hibernate.ddl-auto=create-drop

# Hibernate escribe en la consola cada sentencia SQL que ejecuta, precedida de "Hibernate:".
# Así vemos qué SQL genera Spring Data JPA a partir de nuestro código Java.
spring.jpa.show-sql=true

# Por defecto, en una aplicación web Spring Boot mantiene abierta la sesión de Hibernate durante toda la petición,
# incluido el momento de generar la página, y avisa de ello en el arranque.
# Lo desactivamos: nuestros controladores consultarán los datos antes de generar la página,
# así que no necesitamos que la sesión siga abierta, y evitamos el aviso.
spring.jpa.open-in-view=false

# Activa la consola web de H2 para consultar las tablas desde el navegador: http://localhost:8080/h2-console
spring.h2.console.enabled=true
```

---

### Paso 12: El controlador y el patrón MVC

Tenemos datos y servidor, pero ninguna ruta atendida. Falta quien reciba una petición para `/libros`, pida los libros al repositorio y los entregue a una página. Esa pieza es el **controlador**, y forma parte de un patrón de diseño llamado **MVC**.

**MVC** significa **Modelo, Vista, Controlador**. Es una forma de repartir el trabajo entre tres roles, para que cada clase se dedique a una sola cosa. Lo entendemos con una biblioteca:

| Rol en la biblioteca | Pieza MVC | En nuestra aplicación |
|---|---|---|
| Los libros | **Modelo**: los datos y su significado | La clase `Libro` |
| El expositor que los enseña al público | **Vista**: lo que ve el usuario | La plantilla `libros.html` |
| El bibliotecario que atiende al cliente | **Controlador**: recibe la petición, busca lo necesario y decide qué mostrar | La clase `LibroController` |
| El almacén | Quien guarda y recupera | `LibroRepository` |

La escena completa: un cliente pide "quiero ver todos los libros" (**petición**). El bibliotecario va al almacén, trae los libros, los deja en un carrito (**el modelo de la petición**) y se los lleva al expositor que sabe ordenarlos en una estantería bonita (**la vista**). El cliente ve el resultado (**la respuesta**).

Ventajas de separar los roles:
- Se puede cambiar la presentación (el HTML) sin tocar la lógica.
- Se puede cambiar el almacenamiento sin tocar la presentación.
- Cada clase es más corta y más fácil de entender.

Dos aclaraciones para no confundir palabras:
- **Modelo** se usa en dos sentidos. Por un lado, la clase `Libro`, que representa los datos. Por otro, el objeto `Model` de Spring, que es el "carrito" donde el controlador deja los datos para la vista en cada petición. Más abajo lo usamos.
- Las **capas** (controlador, repositorio, base de datos) son otra forma de ordenar el código: cada capa solo habla con la siguiente.

**Quién recibe las peticiones: el DispatcherServlet**
- Spring MVC pone en la entrada un único objeto, el **`DispatcherServlet`**, que recibe todas las peticiones que llegan a Tomcat.
- Es el recepcionista de un hotel: no atiende a nadie en persona, pregunta qué se quiere y avisa a la persona adecuada.
- Mira la ruta de la petición, busca el controlador que la declara y le pasa el trabajo.
- Lo crea la autoconfiguración. No lo escribimos nosotros.

**Crear el controlador**
1. Clic derecho sobre `src/main/java`, `New > Package`, escribimos `com.curso.controller` y pulsamos Enter.
2. Clic derecho sobre `com.curso.controller`, `New > Java Class`, escribimos `LibroController` y pulsamos Enter.

**Primer bloque: la clase y su dependencia**

3. Abrimos `LibroController.java`, seleccionamos todo (`Ctrl+A`) y lo sustituimos por:

```java
package com.curso.controller;

import com.curso.model.Libro;
import com.curso.repository.LibroRepository;

import java.util.List;

// Importamos @Controller, el estereotipo de Spring para la capa que recibe las peticiones.
// Procede de spring-context, que Maven ha descargado de forma transitiva con los starters.
import org.springframework.stereotype.Controller;
// Importamos Model, el objeto en el que el controlador deja los datos que la vista va a mostrar.
// Procede de spring-context (paquete org.springframework.ui).
import org.springframework.ui.Model;
// Importamos @GetMapping, que enlaza una dirección y el verbo GET con un método del controlador.
// Procede de spring-web, que llega con spring-boot-starter-webmvc.
import org.springframework.web.bind.annotation.GetMapping;

/**
 * S06-1 Demo 1: Controlador que lista los libros
 *
 * Objetivo: atender una petición web, recoger los libros y entregarlos a una plantilla.
 *
 * Lo que hace este ejemplo:
 *   - Atiende las peticiones GET a /libros
 *   - Consulta los libros con el repositorio
 *   - Deja la lista en el modelo y devuelve el nombre de la plantilla
 *
 * Concepto clave: el controlador coordina, no muestra ni guarda datos.
 * Recibe la petición, pide los datos a quien los tiene y se los pasa a la vista.
 */
// @Controller es un @Component: Spring crea un bean de esta clase.
// Spring crea una única instancia de este controlador (scope singleton) y la comparte entre todas las peticiones.
// Por eso no guardamos datos de una petición en campos de la clase: los datos viajan en el Model.
@Controller
public class LibroController {

    // La dependencia del controlador: el repositorio con el que consulta los libros.
    // En S08-1 pondremos entre ambos una capa de servicio; de momento el controlador usa el repositorio directamente.
    private final LibroRepository libroRepository;

    // Inyección por constructor: Spring entrega el repositorio al crear el controlador.
    public LibroController(LibroRepository libroRepository) {
        this.libroRepository = libroRepository;
    }
}
```

Qué significa:
- **`@Controller`**: marca la clase como controlador. Es un tipo especial de `@Component`, así que Spring crea un bean de ella al escanear el paquete, y además el `DispatcherServlet` la tiene en cuenta cuando busca quién atiende cada ruta.
- **Inyección por constructor** del repositorio, igual que hicimos en `CargaDatos`.

**Segundo bloque: el método que atiende la ruta**

4. Pegamos este bloque debajo del constructor y encima de la llave final `}`:

```java
    // @GetMapping("/libros") significa: cuando llegue una petición GET a la dirección /libros,
    // ejecuta este método. Es lo que ocurre al escribir http://localhost:8080/libros en el navegador.
    // Spring pasa solo el parámetro Model: es un objeto nuevo en cada petición.
    @GetMapping("/libros")
    public String listar(Model model) {
        // findAll() devuelve todos los libros de la tabla como una lista de objetos Libro.
        List<Libro> libros = libroRepository.findAll();

        // addAttribute() deja la lista en el modelo con el nombre "libros".
        // La plantilla recuperará la lista por ese mismo nombre: ${libros}.
        model.addAttribute("libros", libros);

        // El String que devuelve el método es el nombre de la vista (la plantilla), no el contenido de la página.
        // Spring Boot busca src/main/resources/templates/libros.html y Thymeleaf lo convierte en HTML.
        return "libros";
    }
```

Qué significa:
- **`@GetMapping("/libros")`**: este método atiende las peticiones GET de la ruta `/libros`.
- **`Model model`**: el "carrito" del que hablábamos. Spring lo crea para cada petición y lo pasa como parámetro.
- **`model.addAttribute("libros", ...)`**: deja en el carrito la lista que devuelve `findAll()`, con el nombre `libros`. La página usará ese nombre para encontrarla.
- **`return "libros"`**: el valor devuelto es el **nombre de la vista**. Spring buscará una plantilla llamada `libros` y le entregará el modelo. En el paso siguiente la creamos.

Así queda `LibroController.java` completo, idéntico al del zip:

```java
package com.curso.controller;

import com.curso.model.Libro;
import com.curso.repository.LibroRepository;

import java.util.List;

// Importamos @Controller, el estereotipo de Spring para la capa que recibe las peticiones.
// Procede de spring-context, que Maven ha descargado de forma transitiva con los starters.
import org.springframework.stereotype.Controller;
// Importamos Model, el objeto en el que el controlador deja los datos que la vista va a mostrar.
// Procede de spring-context (paquete org.springframework.ui).
import org.springframework.ui.Model;
// Importamos @GetMapping, que enlaza una dirección y el verbo GET con un método del controlador.
// Procede de spring-web, que llega con spring-boot-starter-webmvc.
import org.springframework.web.bind.annotation.GetMapping;

/**
 * S06-1 Demo 1: Controlador que lista los libros
 *
 * Objetivo: atender una petición web, recoger los libros y entregarlos a una plantilla.
 *
 * Lo que hace este ejemplo:
 *   - Atiende las peticiones GET a /libros
 *   - Consulta los libros con el repositorio
 *   - Deja la lista en el modelo y devuelve el nombre de la plantilla
 *
 * Concepto clave: el controlador coordina, no muestra ni guarda datos.
 * Recibe la petición, pide los datos a quien los tiene y se los pasa a la vista.
 */
// @Controller es un @Component: Spring crea un bean de esta clase.
// Spring crea una única instancia de este controlador (scope singleton) y la comparte entre todas las peticiones.
// Por eso no guardamos datos de una petición en campos de la clase: los datos viajan en el Model.
@Controller
public class LibroController {

    // La dependencia del controlador: el repositorio con el que consulta los libros.
    // En S08-1 pondremos entre ambos una capa de servicio; de momento el controlador usa el repositorio directamente.
    private final LibroRepository libroRepository;

    // Inyección por constructor: Spring entrega el repositorio al crear el controlador.
    public LibroController(LibroRepository libroRepository) {
        this.libroRepository = libroRepository;
    }

    // @GetMapping("/libros") significa: cuando llegue una petición GET a la dirección /libros,
    // ejecuta este método. Es lo que ocurre al escribir http://localhost:8080/libros en el navegador.
    // Spring pasa solo el parámetro Model: es un objeto nuevo en cada petición.
    @GetMapping("/libros")
    public String listar(Model model) {
        // findAll() devuelve todos los libros de la tabla como una lista de objetos Libro.
        List<Libro> libros = libroRepository.findAll();

        // addAttribute() deja la lista en el modelo con el nombre "libros".
        // La plantilla recuperará la lista por ese mismo nombre: ${libros}.
        model.addAttribute("libros", libros);

        // El String que devuelve el método es el nombre de la vista (la plantilla), no el contenido de la página.
        // Spring Boot busca src/main/resources/templates/libros.html y Thymeleaf lo convierte en HTML.
        return "libros";
    }
}
```

**Qué debe verse**
- En el panel **Project**: `com.curso.controller` con `LibroController`.
- Sin subrayados en rojo.
- Todavía no probamos: falta la vista.

---

### Paso 13: La vista con Thymeleaf

La vista es una página HTML que se rellena con los datos que el controlador dejó en el modelo. Para rellenarla usamos **Thymeleaf**, un motor de plantillas.

Un **motor de plantillas** funciona como la combinación de correspondencia de un procesador de textos. Escribimos una carta con huecos ("Estimado ‹nombre›") y el programa genera una carta distinta por cada fila de datos. Aquí la plantilla es un HTML con huecos, y el servidor produce el HTML final antes de enviarlo al navegador.

**Añadir la dependencia**

1. En `pom.xml`, justo debajo de la dependencia `spring-boot-starter-data-jpa`, pegamos:

```xml
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-thymeleaf</artifactId>
        </dependency>
```

2. Pulsamos **Load Maven Changes**.

Así queda el `pom.xml` completo, con todas las dependencias, idéntico al del zip:

<pre>
&amp;lt;?xml version="1.0" encoding="UTF-8"?&amp;gt;
&amp;lt;project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd"&amp;gt;
    &amp;lt;modelVersion&amp;gt;4.0.0&amp;lt;/modelVersion&amp;gt;
    &amp;lt;parent&amp;gt;
        &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
        &amp;lt;artifactId&amp;gt;spring-boot-starter-parent&amp;lt;/artifactId&amp;gt;
        &amp;lt;version&amp;gt;4.1.1&amp;lt;/version&amp;gt;
        &amp;lt;relativePath/&amp;gt; &amp;lt;!-- lookup parent from repository --&amp;gt;
    &amp;lt;/parent&amp;gt;
    &amp;lt;groupId&amp;gt;com.curso&amp;lt;/groupId&amp;gt;
    &amp;lt;artifactId&amp;gt;s06-1-demo&amp;lt;/artifactId&amp;gt;
    &amp;lt;version&amp;gt;0.0.1-SNAPSHOT&amp;lt;/version&amp;gt;
    &amp;lt;name&amp;gt;s06-1-demo&amp;lt;/name&amp;gt;
    &amp;lt;description&amp;gt;S06-1 Demo 1: aplicación Spring Boot con Libro, Spring Data JPA, H2 y Thymeleaf&amp;lt;/description&amp;gt;
    &amp;lt;properties&amp;gt;
        &amp;lt;java.version&amp;gt;21&amp;lt;/java.version&amp;gt;
    &amp;lt;/properties&amp;gt;
    &amp;lt;dependencies&amp;gt;
        &amp;lt;dependency&amp;gt;
            &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
            &amp;lt;artifactId&amp;gt;spring-boot-starter-data-jpa&amp;lt;/artifactId&amp;gt;
        &amp;lt;/dependency&amp;gt;
        &amp;lt;dependency&amp;gt;
            &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
            &amp;lt;artifactId&amp;gt;spring-boot-starter-thymeleaf&amp;lt;/artifactId&amp;gt;
        &amp;lt;/dependency&amp;gt;
        &amp;lt;dependency&amp;gt;
            &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
            &amp;lt;artifactId&amp;gt;spring-boot-starter-webmvc&amp;lt;/artifactId&amp;gt;
        &amp;lt;/dependency&amp;gt;
        &amp;lt;dependency&amp;gt;
            &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
            &amp;lt;artifactId&amp;gt;spring-boot-h2console&amp;lt;/artifactId&amp;gt;
        &amp;lt;/dependency&amp;gt;
        &amp;lt;dependency&amp;gt;
            &amp;lt;groupId&amp;gt;com.h2database&amp;lt;/groupId&amp;gt;
            &amp;lt;artifactId&amp;gt;h2&amp;lt;/artifactId&amp;gt;
            &amp;lt;scope&amp;gt;runtime&amp;lt;/scope&amp;gt;
        &amp;lt;/dependency&amp;gt;
    &amp;lt;/dependencies&amp;gt;

    &amp;lt;build&amp;gt;
        &amp;lt;plugins&amp;gt;
            &amp;lt;plugin&amp;gt;
                &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
                &amp;lt;artifactId&amp;gt;spring-boot-maven-plugin&amp;lt;/artifactId&amp;gt;
            &amp;lt;/plugin&amp;gt;
        &amp;lt;/plugins&amp;gt;
    &amp;lt;/build&amp;gt;

&amp;lt;/project&amp;gt;
</pre>

El orden de las dependencias no importa para Maven.

**Crear la carpeta y el fichero de la plantilla**

Spring Boot busca las plantillas en la carpeta `src/main/resources/templates`.

3. Clic derecho sobre `src/main/resources`.
4. `New > Directory`.
5. Escribimos `templates` y pulsamos Enter.
6. Clic derecho sobre `templates`.
7. `New > File`.
8. Escribimos `libros.html` y pulsamos Enter. El nombre, sin la extensión, es el que devolvió el controlador (`"libros"`).

**Primer bloque: la estructura de la página**

9. Abrimos `libros.html`, seleccionamos todo (`Ctrl+A`) y pegamos:

```html
<!DOCTYPE html>
<!--/*
  S06-1 Demo 1: Plantilla Thymeleaf del listado de libros

  Los comentarios con la forma "barra asterisco" como este son comentarios de Thymeleaf:
  desaparecen al procesar la plantilla y no llegan al navegador. Los comentarios HTML normales (con signos de menos) sí llegan.

  xmlns:th declara el prefijo "th": todos los atributos que empiezan por th: los procesa Thymeleaf en el servidor.
  Un navegador que abriera este fichero directamente ignoraría esos atributos y mostraría los valores de ejemplo
  que hay escritos dentro de cada etiqueta.
*/-->
<html lang="es" xmlns:th="http://www.thymeleaf.org">
<head>
    <meta charset="UTF-8">
    <title>Biblioteca</title>
    <style>
        body { font-family: sans-serif; margin: 2rem; }
        table { border-collapse: collapse; }
        th, td { border: 1px solid #999; padding: 0.4rem 0.8rem; text-align: left; }
        th { background: #eee; }
    </style>
</head>
<body>
<h1>Biblioteca</h1>

<!--/*
  th:text sustituye el contenido de la etiqueta por el resultado de la expresión.
  ${libros} recupera del modelo el atributo "libros" que dejó el controlador con model.addAttribute("libros", ...).
  #lists.size(...) es una utilidad de Thymeleaf que devuelve cuántos elementos tiene una lista.
*/-->
<p>Libros registrados: <span th:text="${#lists.size(libros)}">0</span></p>
</body>
</html>
```

Qué significa:
- Un HTML normal. Los comentarios con la forma `<!--/* ... */-->` son comentarios de Thymeleaf: desaparecen al procesar la plantilla y no llegan al navegador.
- **`xmlns:th`** declara el prefijo `th`: los atributos que empiezan por `th:` los procesa Thymeleaf en el servidor.
- **`th:text="${#lists.size(libros)}"`**: sustituye el contenido de la etiqueta por el resultado de la expresión.
  - **`${libros}`** es la forma de leer del modelo: busca el atributo llamado `libros`, el que dejó el controlador con `addAttribute`.
  - **`#lists.size(...)`** es una utilidad de Thymeleaf que devuelve cuántos elementos tiene una lista.
  - El `0` que hay escrito dentro del `span` es un valor de ejemplo. Si abrimos el fichero directamente en el navegador, se ve ese `0`; cuando lo procesa Thymeleaf, el `0` se sustituye por el número real. La plantilla es una página HTML válida incluso sin servidor.

**Segundo bloque: la tabla con un bucle**

10. Pegamos este bloque en lugar de las dos líneas finales `</body>` y `</html>` que acabamos de poner, y volvemos a cerrarlas al final:

```html
<table>
    <thead>
    <tr>
        <th>Id</th>
        <th>Título</th>
        <th>Autor</th>
        <th>Año</th>
        <th>ISBN</th>
    </tr>
    </thead>
    <tbody>
    <!--/*
      th:each repite la etiqueta en la que está (aquí, la fila tr) una vez por cada elemento de la lista.
      "libro : ${libros}" se lee: para cada libro de la lista libros. Dentro de la fila, "libro" es el elemento actual.
      ${libro.titulo} llama al método getTitulo() del objeto Libro: por eso la clase necesita sus getters.
      El texto que hay escrito dentro de cada td (Título, Autor...) es solo de ejemplo: th:text lo sustituye.
    */-->
    <tr th:each="libro : ${libros}">
        <td th:text="${libro.id}">1</td>
        <td th:text="${libro.titulo}">Título</td>
        <td th:text="${libro.autor}">Autor</td>
        <td th:text="${libro.anio}">2000</td>
        <td th:text="${libro.isbn}">978-00-000-0000-0</td>
    </tr>
    </tbody>
</table>
</body>
</html>
```

Qué significa:
- **`th:each="libro : ${libros}"`** repite la etiqueta en la que está (la fila `tr`) una vez por cada elemento de la lista. Se lee "para cada `libro` de `libros`". Dentro de la fila, `libro` es el elemento actual.
- **`${libro.titulo}`** llama al método `getTitulo()` del objeto `Libro`. Por eso la clase necesita sus getters: Thymeleaf los usa para leer los datos.
- El texto de ejemplo de cada `td` (`Título`, `Autor`...) lo sustituye `th:text`.

Así queda `libros.html` completo, idéntico al del zip:

```html
<!DOCTYPE html>
<!--/*
  S06-1 Demo 1: Plantilla Thymeleaf del listado de libros

  Los comentarios con la forma "barra asterisco" como este son comentarios de Thymeleaf:
  desaparecen al procesar la plantilla y no llegan al navegador. Los comentarios HTML normales (con signos de menos) sí llegan.

  xmlns:th declara el prefijo "th": todos los atributos que empiezan por th: los procesa Thymeleaf en el servidor.
  Un navegador que abriera este fichero directamente ignoraría esos atributos y mostraría los valores de ejemplo
  que hay escritos dentro de cada etiqueta.
*/-->
<html lang="es" xmlns:th="http://www.thymeleaf.org">
<head>
    <meta charset="UTF-8">
    <title>Biblioteca</title>
    <style>
        body { font-family: sans-serif; margin: 2rem; }
        table { border-collapse: collapse; }
        th, td { border: 1px solid #999; padding: 0.4rem 0.8rem; text-align: left; }
        th { background: #eee; }
    </style>
</head>
<body>
<h1>Biblioteca</h1>

<!--/*
  th:text sustituye el contenido de la etiqueta por el resultado de la expresión.
  ${libros} recupera del modelo el atributo "libros" que dejó el controlador con model.addAttribute("libros", ...).
  #lists.size(...) es una utilidad de Thymeleaf que devuelve cuántos elementos tiene una lista.
*/-->
<p>Libros registrados: <span th:text="${#lists.size(libros)}">0</span></p>

<table>
    <thead>
    <tr>
        <th>Id</th>
        <th>Título</th>
        <th>Autor</th>
        <th>Año</th>
        <th>ISBN</th>
    </tr>
    </thead>
    <tbody>
    <!--/*
      th:each repite la etiqueta en la que está (aquí, la fila tr) una vez por cada elemento de la lista.
      "libro : ${libros}" se lee: para cada libro de la lista libros. Dentro de la fila, "libro" es el elemento actual.
      ${libro.titulo} llama al método getTitulo() del objeto Libro: por eso la clase necesita sus getters.
      El texto que hay escrito dentro de cada td (Título, Autor...) es solo de ejemplo: th:text lo sustituye.
    */-->
    <tr th:each="libro : ${libros}">
        <td th:text="${libro.id}">1</td>
        <td th:text="${libro.titulo}">Título</td>
        <td th:text="${libro.autor}">Autor</td>
        <td th:text="${libro.anio}">2000</td>
        <td th:text="${libro.isbn}">978-00-000-0000-0</td>
    </tr>
    </tbody>
</table>
</body>
</html>
```

**Qué debe verse**
- En el panel **Project**: `src/main/resources/templates/libros.html`.
- El `pom.xml` con las cinco dependencias: `spring-boot-starter-data-jpa`, `spring-boot-starter-thymeleaf`, `spring-boot-starter-webmvc`, `spring-boot-h2console` y `h2`.

---

### Paso 14: Probar en el navegador

1. Paramos la aplicación con ■ y la arrancamos con ▶ (hace falta, porque el `pom.xml` ha cambiado y hay clases nuevas).
2. Abrimos `http://localhost:8080/libros`.

**Qué debe verse**
- Un título **Biblioteca**.
- El texto **Libros registrados: 4**.
- Una tabla con cinco columnas (**Id**, **Título**, **Autor**, **Año**, **ISBN**) y cuatro filas con Don Quijote de la Mancha, Cien años de soledad, La sombra del viento y Rayuela.

**Qué ha pasado, de principio a fin**
1. El navegador envía `GET /libros` a Tomcat.
2. Tomcat entrega la petición al `DispatcherServlet`.
3. El `DispatcherServlet` encuentra el método con `@GetMapping("/libros")` y lo ejecuta.
4. El controlador pide los libros al repositorio, que lanza un `select` contra H2.
5. El controlador deja la lista en el `Model` y devuelve el nombre de la vista, `libros`.
6. Thymeleaf procesa `libros.html`, sustituye los huecos por los datos y genera el HTML final.
7. Tomcat devuelve ese HTML al navegador, con código `200`.

**Dos comprobaciones**
- **En la consola de IntelliJ**, tras la primera petición, aparecen líneas como estas. Spring crea el `DispatcherServlet` la primera vez que llega una petición, y después aparece el `select` de `findAll()`:

<pre>
Initializing Spring DispatcherServlet 'dispatcherServlet'
Initializing Servlet 'dispatcherServlet'
Completed initialization in 1 ms
Hibernate: select l1_0.id,l1_0.anio,l1_0.autor,l1_0.isbn,l1_0.titulo from libro l1_0
</pre>

  Si recargamos la página, solo aparece el `select`: la inicialización se hace una vez.
- **El código fuente que recibe el navegador**: en la página, `Ctrl+U` (o clic derecho y **Ver código fuente de la página**). Veremos HTML normal, con las cuatro filas ya escritas, sin ningún atributo `th:` ni los comentarios de Thymeleaf. El navegador no sabe que existe Thymeleaf: recibe el resultado.

**Opcional: seguir una petición con el depurador**
- Ponemos un punto de parada haciendo clic en el margen izquierdo, junto a la línea `model.addAttribute(...)` de `LibroController` (aparece un círculo rojo).
- Paramos la aplicación y la arrancamos con el icono del escarabajo (**Debug**), no con ▶.
- Recargamos la página en el navegador: IntelliJ se detiene en esa línea.
- `F8` avanza una línea, `F9` continúa hasta el final. Con el cursor sobre `model` vemos su contenido.
- Quitamos el punto de parada con otro clic.

---

### Paso 15: Una nota sobre los scopes

Todos los beans que hemos usado (`CargaDatos`, `LibroController` y el repositorio) tienen el mismo **scope**: la regla que dice cuántas instancias crea Spring de un bean y cuánto tiempo viven.
- El scope por defecto es **singleton**: Spring crea **un único objeto** al arrancar y lo comparte con todos los que lo piden. Hay un solo `LibroController` para todas las peticiones de todos los usuarios.
- Existen otros, que aquí solo nombramos:
  - **prototype**: se crea un objeto nuevo cada vez que alguien lo pide.
  - **request**: un objeto nuevo por cada petición HTTP.
  - **session**: un objeto por cada sesión de usuario.
- No cambiamos nada del proyecto: es solo un nombre que conviene reconocer.
- Lo importante es que, al ser el controlador un singleton, **no debe guardar datos de un usuario en sus campos**, porque todos los usuarios compartirían ese dato. Por eso el controlador solo tiene el repositorio y deja los datos en el `Model`, que sí es nuevo en cada petición.

---

### Paso 16: Cierre

**Estructura final del proyecto**

<pre>
s06-1-demo
├── pom.xml
└── src
    └── main
        ├── java
        │   └── com
        │       └── curso
        │           ├── Aplicacion.java
        │           ├── config
        │           │   └── CargaDatos.java
        │           ├── controller
        │           │   └── LibroController.java
        │           ├── model
        │           │   └── Libro.java
        │           └── repository
        │               └── LibroRepository.java
        └── resources
            ├── application.properties
            └── templates
                └── libros.html
</pre>

(Además están los ficheros que genera el asistente: `.idea`, `.mvn`, `mvnw`, `.gitignore`, `HELP.md`, etc.)

**El recorrido de una petición**

<pre>
navegador  →  Tomcat  →  DispatcherServlet  →  LibroController  →  LibroRepository  →  H2
                                                     ↓
navegador  ←  Tomcat  ←  libros.html (Thymeleaf) ←  Model con la lista de libros
</pre>

**Lo que hemos hecho**
- Creado un proyecto Spring Boot con el generador de IntelliJ, eligiendo solo dos dependencias.
- Visto qué hace cada parte del `pom.xml`: el `parent` fija las versiones, los starters traen las librerías y la autoconfiguración las configura.
- Declarado una entidad (`Libro`) y un repositorio (`LibroRepository`) sin escribir SQL.
- Guardado y leído datos al arrancar con un `CommandLineRunner`.
- Visto por qué una aplicación con Tomcat embebido no termina sola.
- Consultado la base de datos desde el navegador con la consola de H2.
- Repartido el trabajo en MVC: modelo (`Libro`), vista (`libros.html`) y controlador (`LibroController`).
- Mostrado los datos en una página con Thymeleaf.

---

### Apéndice: Problemas frecuentes

**Los `import` aparecen en rojo**
- Maven aún no ha cargado el `pom.xml`. Pulsamos **Load Maven Changes** o, en el panel **Maven**, el icono de recargar.

**`Unable to create injector` al sincronizar Maven**
- Ver el recuadro del Paso 2: cambiar **Maven home path** a `Bundled (Maven 3)`.

**`Port 8080 was already in use`**
- Hay otra copia de la aplicación en marcha, o otro programa usa el puerto 8080.
- Pulsamos ■ en la ventana **Run** (puede haber varias pestañas) y volvemos a arrancar.

**La página `/libros` da error 404**
- Comprobamos que `LibroController` está dentro de `com.curso` (o de un subpaquete) y lleva `@Controller` y `@GetMapping("/libros")`.
- Comprobamos que arrancamos de nuevo después de crear el controlador.

**La página da error 500 con `Error resolving template [libros]`**
- La plantilla no está donde Spring Boot la busca. Debe estar en `src/main/resources/templates/libros.html`, con ese nombre exacto y en minúsculas.

**La tabla sale vacía o aparece `Libros registrados: 0`**
- Comprobamos que `CargaDatos` lleva `@Component` y que en la consola aparecen los cuatro `insert`.

**La consola de H2 da `Database "mem:..." not found`**
- La **JDBC URL** del formulario no coincide con la de `application.properties`. Debe ser `jdbc:h2:mem:libreria`.

**`/h2-console` da error 404**
- Falta la dependencia `spring-boot-h2console` o la propiedad `spring.h2.console.enabled=true`. Reiniciamos la aplicación tras añadirlas.

**La aplicación arranca y termina enseguida (`exit code 0`)**
- Falta la dependencia `spring-boot-starter-webmvc`: sin servidor, el programa acaba al terminar `run()`.

**Los acentos salen como `?` en la consola**
- Es cosa de la codificación de la consola, no del programa. Si ocurre en IntelliJ, en `Help > Edit Custom VM Options` añadimos la línea `-Dfile.encoding=UTF-8` y reiniciamos IntelliJ.
