# S12-1 Demos

## Objetivos

Hasta ahora todas las bases de datos del curso han sido relacionales: PostgreSQL guarda los datos en tablas con columnas fijas, y los datos de un mismo objeto se reparten entre varias tablas unidas por claves. MongoDB funciona de otra manera. Guarda **documentos**, estructuras parecidas a un JSON, agrupados en colecciones, y no obliga a que todos los documentos de una colección tengan los mismos campos. Los datos relacionados pueden ir dentro del propio documento. Es una ventaja cuando la información se lee siempre junta y cambia de forma, y un inconveniente cuando hay muchas relaciones entre entidades que se consultan por separado.

En esta parte primero se trabaja con MongoDB sin Java, desde la consola `mongosh` y desde la aplicación gráfica Compass, para entender el modelo de documentos antes de ponerle un framework encima. Después se crea una API REST de tareas con Spring Data MongoDB, que se parece mucho a la de JPA, y se guardan las etiquetas de cada tarea dentro de su documento para compararlo con el diseño relacional.

El código de esta parte está en `s12-1-demos.zip`, dentro de la carpeta `tareas-mongo`. Para esta parte hace falta MongoDB instalado, como se indicó al final de S11-2.

Al terminar esta parte los alumnos son capaces de:
- Insertar, consultar, modificar y borrar documentos desde `mongosh` y desde Compass.
- Crear un proyecto de Spring Boot con Spring Data MongoDB y exponer su CRUD como API REST.
- Declarar un documento con `@Document` y su repositorio con `MongoRepository`.
- Guardar una lista dentro de un documento, consultar por ella y explicar qué ventajas e inconvenientes tiene frente al diseño relacional.

---

## Demo 1: MongoDB en local con mongosh y Compass

Antes de escribir nada de Java conviene ver MongoDB funcionando, porque su modelo de datos se entiende mejor viéndolo. Esta demo no usa ninguna clase: se trabaja con la consola de MongoDB.

### Los conceptos

MongoDB organiza los datos en tres niveles:

- Una **base de datos** agrupa colecciones, igual que en PostgreSQL.
- Una **colección** agrupa documentos. Es el equivalente de una tabla, pero sin columnas definidas de antemano.
- Un **documento** es un objeto con campos, escrito con la sintaxis de JSON: `{ titulo: "Instalar MongoDB", completada: true }`. Es el equivalente de una fila, pero cada documento puede tener campos distintos de los demás.

| PostgreSQL | MongoDB |
|---|---|
| Base de datos | Base de datos |
| Tabla | Colección |
| Fila | Documento |
| Columna | Campo |
| `CREATE TABLE` antes de guardar nada | No hace falta: la colección se crea al guardar el primer documento |

Cada documento lleva siempre un campo `_id` que lo identifica dentro de su colección, como la clave primaria. Si no se indica, MongoDB lo genera: es un **ObjectId**, un valor único de 12 bytes que se escribe como 24 caracteres hexadecimales, por ejemplo `ObjectId('6ad847b7383a558e0c8323e3')`. Los valores concretos de los ejemplos de esta demo serán distintos en cada equipo.

### Comprobar la instalación

Si se siguió la sección final de `s11-2-demos.md`, el servidor MongoDB está instalado como servicio de Windows y arranca solo. Para comprobarlo, abrimos una terminal (en IntelliJ, `Alt+F12`; sirve cualquier `cmd`) y escribimos:

```bash
mongosh --version
```

Debe mostrar un número de versión. Si el servicio no estuviera en marcha, se arranca desde los servicios de Windows (`Win+R`, `services.msc`, clic derecho sobre `MongoDB` y `Iniciar`).

### Abrir mongosh

```bash
mongosh
```

Sin argumentos, `mongosh` se conecta al servidor local (`mongodb://127.0.0.1:27017`). Tras un texto de bienvenida aparece el indicador `test>`: `test` es la base de datos en la que se está, la que MongoDB ofrece por defecto. Las órdenes de `mongosh` se escriben a continuación del indicador y se ejecutan con Enter. La consola entiende JavaScript, y por eso los documentos se escriben con la sintaxis de los objetos de JavaScript.

### Cambiar de base de datos

`use` cambia la base de datos de trabajo, y `show dbs` lista las que existen. Usamos una base de pruebas para no mezclar estos datos con los de las demos siguientes:

<pre>
test&gt; use pruebas
switched to db pruebas
pruebas&gt; show dbs
admin   40.00 KiB
config  12.00 KiB
local   40.00 KiB
</pre>

`pruebas` no aparece en la lista porque todavía no existe: `use pruebas` solo indica a qué base de datos se refieren las órdenes siguientes. La base de datos se crea cuando se guarda en ella el primer documento. Las tres bases que sí aparecen (`admin`, `config` y `local`) son internas de MongoDB y no se tocan.

### Insertar un documento

`db` es la base de datos actual, y `db.tareas` es la colección `tareas` dentro de ella. `insertOne()` guarda un documento:

```
db.tareas.insertOne({ titulo: "Instalar MongoDB", completada: true })
```

<pre>
pruebas&gt; db.tareas.insertOne({ titulo: "Instalar MongoDB", completada: true })
{
  acknowledged: true,
  insertedId: ObjectId('6ad847c5963478806ac1b7a0')
}
</pre>

La respuesta confirma la operación (`acknowledged: true`) y devuelve el `_id` generado. No se ha creado ninguna tabla antes: la colección `tareas` y la base de datos `pruebas` han nacido con esta orden.

### Insertar documentos distintos

`insertMany()` guarda varios documentos recibidos en una lista, entre corchetes. Cada uno tiene campos diferentes:

```
db.tareas.insertMany([
    { titulo: "Preparar la presentación", descripcion: "Diapositivas de la sesión 12", completada: false },
    { titulo: "Revisar los apuntes", completada: false, etiquetas: ["curso", "mongo"] },
    { titulo: "Entregar la práctica", completada: false, vence: new Date("2026-11-02") }
])
```

En la consola se escribe en una sola línea. La respuesta es la lista de los `_id` generados:

<pre>
pruebas&gt; db.tareas.insertMany([{ titulo: "Preparar la presentación", descripcion: "Diapositivas de la sesión 12", completada: false }, { titulo: "Revisar los apuntes", completada: false, etiquetas: ["curso", "mongo"] }, { titulo: "Entregar la práctica", completada: false, vence: new Date("2026-11-02") }])
{
  acknowledged: true,
  insertedIds: {
    '0': ObjectId('6ad847c5963478806ac1b7a1'),
    '1': ObjectId('6ad847c5963478806ac1b7a2'),
    '2': ObjectId('6ad847c5963478806ac1b7a3')
  }
}
</pre>

Los cuatro documentos tienen `titulo` y `completada`, pero uno tiene además `descripcion`, otro una lista `etiquetas` y otro una fecha `vence`. En una tabla habría que haber creado de antemano las columnas `descripcion`, `etiquetas` y `vence`, y las filas que no las usan tendrían `NULL`. En una colección cada documento tiene solo los campos que necesita.

Ahora la base de datos existe:

<pre>
pruebas&gt; show dbs
admin    40.00 KiB
config   12.00 KiB
local    40.00 KiB
pruebas   8.00 KiB
pruebas&gt; show collections
tareas
</pre>

### Consultar

`find()` sin argumentos devuelve todos los documentos de la colección:

<pre>
pruebas&gt; db.tareas.find()
[
  {
    _id: ObjectId('6ad847c5963478806ac1b7a0'),
    titulo: 'Instalar MongoDB',
    completada: true
  },
  {
    _id: ObjectId('6ad847c5963478806ac1b7a1'),
    titulo: 'Preparar la presentación',
    descripcion: 'Diapositivas de la sesión 12',
    completada: false
  },
  {
    _id: ObjectId('6ad847c5963478806ac1b7a2'),
    titulo: 'Revisar los apuntes',
    completada: false,
    etiquetas: [ 'curso', 'mongo' ]
  },
  {
    _id: ObjectId('6ad847c5963478806ac1b7a3'),
    titulo: 'Entregar la práctica',
    completada: false,
    vence: ISODate('2026-11-02T00:00:00.000Z')
  }
]
</pre>

Se ve cómo MongoDB ha añadido el `_id` a cada documento y cómo cada uno conserva su forma: la fecha se muestra como `ISODate`, y la lista, entre corchetes.

`find()` recibe como primer argumento un **filtro**: un documento con las condiciones que deben cumplir los resultados. Con un campo y un valor, devuelve los documentos donde ese campo vale eso. Si el campo es una lista, devuelve los documentos cuya lista contiene el valor. El segundo argumento es la **proyección**, que dice qué campos se devuelven: `titulo: 1` incluye el título y `_id: 0` excluye el `_id`, que se devuelve siempre si no se pide lo contrario.

```
db.tareas.find({ completada: false })
db.tareas.find({ etiquetas: "curso" })
db.tareas.find({ completada: false }, { titulo: 1, _id: 0 })
```

<pre>
pruebas&gt; db.tareas.find({ completada: false })
[
  {
    _id: ObjectId('6ad847c5963478806ac1b7a1'),
    titulo: 'Preparar la presentación',
    descripcion: 'Diapositivas de la sesión 12',
    completada: false
  },
  {
    _id: ObjectId('6ad847c5963478806ac1b7a2'),
    titulo: 'Revisar los apuntes',
    completada: false,
    etiquetas: [ 'curso', 'mongo' ]
  },
  {
    _id: ObjectId('6ad847c5963478806ac1b7a3'),
    titulo: 'Entregar la práctica',
    completada: false,
    vence: ISODate('2026-11-02T00:00:00.000Z')
  }
]
pruebas&gt; db.tareas.find({ etiquetas: "curso" })
[
  {
    _id: ObjectId('6ad847c5963478806ac1b7a2'),
    titulo: 'Revisar los apuntes',
    completada: false,
    etiquetas: [ 'curso', 'mongo' ]
  }
]
pruebas&gt; db.tareas.find({ completada: false }, { titulo: 1, _id: 0 })
[
  { titulo: 'Preparar la presentación' },
  { titulo: 'Revisar los apuntes' },
  { titulo: 'Entregar la práctica' }
]
</pre>

`countDocuments()` cuenta los documentos de la colección:

<pre>
pruebas&gt; db.tareas.countDocuments()
4
</pre>

### Modificar y borrar

`updateOne()` recibe un filtro y un documento con la modificación. `$set` cambia solo los campos que se indican y deja el resto del documento como está. Sin `$set`, el documento entero se sustituiría por lo que se escribiera. `matchedCount` dice cuántos documentos cumplían el filtro y `modifiedCount`, cuántos se han cambiado:

```
db.tareas.updateOne({ titulo: "Revisar los apuntes" }, { $set: { completada: true } })
db.tareas.find({ titulo: "Revisar los apuntes" })
```

<pre>
pruebas&gt; db.tareas.updateOne({ titulo: "Revisar los apuntes" }, { $set: { completada: true } })
{
  acknowledged: true,
  insertedId: null,
  matchedCount: 1,
  modifiedCount: 1,
  upsertedCount: 0
}
pruebas&gt; db.tareas.find({ titulo: "Revisar los apuntes" })
[
  {
    _id: ObjectId('6ad847c5963478806ac1b7a2'),
    titulo: 'Revisar los apuntes',
    completada: true,
    etiquetas: [ 'curso', 'mongo' ]
  }
]
</pre>

`deleteOne()` borra el primer documento que cumple el filtro, y existe también `deleteMany()` para borrar todos los que lo cumplen:

```
db.tareas.deleteOne({ titulo: "Preparar la presentación" })
db.tareas.countDocuments()
```

<pre>
pruebas&gt; db.tareas.deleteOne({ titulo: "Preparar la presentación" })
{ acknowledged: true, deletedCount: 1 }
pruebas&gt; db.tareas.countDocuments()
3
</pre>

### MongoDB Compass

Compass es la aplicación gráfica de MongoDB, parecida a pgAdmin en PostgreSQL. Si se marcó al instalar MongoDB, ya está en el equipo. La usamos para ver los mismos datos sin escribir órdenes:

1. Abrimos **MongoDB Compass** desde el menú Inicio de Windows.
2. En la pantalla inicial, la conexión que propone es `mongodb://localhost:27017`, la misma que usa `mongosh`. Hacemos clic en `Connect` (en algunas versiones, antes hay que crear la conexión con `Add new connection`).
3. En el panel izquierdo aparecen las bases de datos. Desplegamos `pruebas` y hacemos clic en la colección `tareas`.
4. La pestaña `Documents` muestra los documentos de la colección, uno debajo de otro, con sus campos. Se ve igual que la salida de `find()`: cada documento con los campos que tiene.
5. En la barra de filtro, sobre los documentos, escribimos `{ completada: false }` y hacemos clic en `Find`. Compass aplica el mismo filtro que `find({ completada: false })`.
6. Con el botón `Add Data` y la opción `Insert document` se añade un documento nuevo escribiéndolo en formato JSON, y con el lápiz que aparece al pasar el ratón sobre un documento, se edita.

Compass sirve para explorar y para comprobar lo que hace una aplicación. Las órdenes de `mongosh` son las que se usan para repetir operaciones, y las que interesan para entender lo que hará después Spring Data.

### Limpiar

Dejamos MongoDB sin los datos de prueba. `dropDatabase()` borra la base de datos actual con todas sus colecciones:

<pre>
pruebas&gt; db.dropDatabase()
{ ok: 1, dropped: 'pruebas' }
</pre>

Salimos de `mongosh` con `exit`. Las órdenes de esta demo están reunidas en `mongo/01-tareas.js`, dentro del zip, por si se quieren tener a mano.

---

## Demo 2: API de tareas con Spring Data MongoDB

Esta demo repite la API de tareas de S11, pero guardando los datos en MongoDB. El proyecto se parece mucho al de JPA: cambia la anotación de la clase, la interfaz del repositorio y la propiedad de conexión. Y desaparecen cosas: el script SQL, el driver de PostgreSQL y la configuración del esquema.

### Crear el proyecto

Creamos un proyecto nuevo con `File > New > Project` y, en el panel izquierdo, `Generators > Spring Boot`. Name `tareas-mongo`, Type `Maven`, Language `Java`, Group `com.curso`, Artifact `tareas-mongo`, Package name `com.curso`, JDK `21`, Java `21`, Packaging `Jar` y Configuration `Properties`. En la segunda pantalla dejamos Spring Boot `4.1.1` y marcamos tres dependencias: `Spring Web` (dentro de `Web`), `Spring Data MongoDB` (dentro de `NoSQL`) y `Lombok` (dentro de `Developer Tools`). Hacemos clic en `Create`.

Renombramos con `Shift+F6` las clases que genera el asistente: la principal pasa a llamarse `Aplicacion` y la de `src/test/java`, `AplicacionTests`. Los paquetes `com.curso.model`, `com.curso.repository` y `com.curso.controller` se crean con clic derecho sobre `src/main/java`, `New > Package`.

### Las dependencias

En el `pom.xml` el starter de datos es `spring-boot-starter-data-mongodb`, en lugar de `spring-boot-starter-data-jpa`, y no hay driver de PostgreSQL. Ese starter trae Spring Data MongoDB y el driver de MongoDB para Java, de modo que no hay que añadir nada más. Su starter de pruebas, `spring-boot-starter-data-mongodb-test`, también lo declara el asistente.

Para probar la API desde la página de Swagger, como en S11-2, añadimos a mano la dependencia de springdoc dentro de `<dependencies>`, después de la de `spring-boot-starter-webmvc`:

```xml
		<dependency>
			<groupId>org.springdoc</groupId>
			<artifactId>springdoc-openapi-starter-webmvc-ui</artifactId>
			<version>3.1.1</version>
		</dependency>
```

Pulsamos **Load Maven Changes**. No hace falta ninguna anotación: la página queda en `http://localhost:8080/swagger-ui.html`.

### La conexión

En `application.properties` ya no hay URL de JDBC, usuario ni contraseña, ni propiedades de Hibernate:

```properties
# Nombre de la aplicación: aparece entre corchetes en cada línea del log.
spring.application.name=tareas-mongo

# Conexión a MongoDB: dirección del servidor local (puerto 27017 por defecto) y nombre de la
# base de datos, tareas. No lleva usuario ni contraseña porque la instalación local de
# MongoDB no tiene la autenticación activada. La base de datos no hay que crearla: MongoDB
# la crea al guardar el primer documento.
spring.mongodb.uri=mongodb://localhost:27017/tareas
```

`spring.mongodb.uri` es la dirección de la base de datos, y se lee por partes: `mongodb://` es el protocolo, `localhost:27017` es el servidor y su puerto (el que usa MongoDB por defecto), y `/tareas` es el nombre de la base de datos. No lleva usuario ni contraseña porque la instalación local de MongoDB no tiene la autenticación activada, así que tampoco hace falta la variable de entorno `POSTGRES_PASSWORD`. Y la base de datos `tareas` no hay que crearla: MongoDB la crea al guardar el primer documento.

### El documento

La entidad `Tarea` pasa a ser un **documento**. Se escribe en el paquete `com.curso.model`:

```java
package com.curso.model;

// @Document y @Id (de Spring Data MongoDB) se importan de paquetes distintos a los de JPA.
// Maven las ha descargado al declarar spring-boot-starter-data-mongodb en el pom.xml.
// @Id es la de Spring Data (org.springframework.data.annotation), no la de jakarta.persistence.
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// Importamos las anotaciones de Lombok. Maven ha descargado la librería al declarar
// org.projectlombok:lombok en el pom.xml. Lombok las lee al compilar y escribe por nosotros
// el código repetitivo, que queda dentro del .class pero no aparece en el .java.
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * S12-1 Demo 2: Documento Tarea
 *
 * Objetivo: guardar tareas en MongoDB como documentos de la colección tareas.
 *
 * Lo que hace este ejemplo:
 *   - Declara la clase Tarea como documento de la colección tareas
 *   - Usa un id de tipo String, que genera MongoDB
 *   - Usa Lombok para los getters, los setters y el constructor vacío, como en S11
 *
 * Concepto clave: una clase Java se convierte en un documento con solo anotar la clase.
 * No hay script de creación ni esquema: la colección se crea al guardar el primer documento.
 */
// @Document indica que los objetos de esta clase se guardan como documentos de MongoDB.
// collection = "tareas" fija el nombre de la colección. Sin él, Spring usaría el nombre de
// la clase en minúscula y en singular ("tarea").
@Document(collection = "tareas")
@Getter
@Setter
@NoArgsConstructor
public class Tarea {

    // @Id marca el campo que se guarda como _id, el identificador del documento.
    // Es un String porque MongoDB genera un ObjectId, un valor de 24 caracteres
    // hexadecimales (por ejemplo "6718f2a1c3b4d5e6f7a8b9c0"). Vale null hasta que se guarda.
    @Id
    private String id;

    private String titulo;

    private String descripcion;

    private boolean completada;

    // Este constructor sí lo escribimos nosotros: Lombok no sabe qué campos queremos recibir.
    // No incluye el id ni completada: el id lo genera MongoDB y una tarea nueva está pendiente.
    public Tarea(String titulo, String descripcion) {
        this.titulo = titulo;
        this.descripcion = descripcion;
    }

    // toString() devuelve el texto con el que se imprime la tarea;
    // @Override avisa al compilador de que reescribimos el método heredado de Object.
    @Override
    public String toString() {
        return "Tarea{id=" + id + ", titulo='" + titulo + "', completada=" + completada + "}";
    }
}
```

Comparada con la entidad de JPA, hay tres diferencias. `@Document(collection = "tareas")` sustituye a `@Entity`, e indica el nombre de la colección. El `id` es un `String` sin `@GeneratedValue`: MongoDB genera el `ObjectId` y Spring Data lo convierte a texto. Y el `@Id` es el de `org.springframework.data.annotation`, no el de `jakarta.persistence`: IntelliJ puede ofrecer los dos, hay que elegir el de Spring Data. No hay ninguna anotación de columna porque no hay columnas: cada campo de la clase se guarda como un campo del documento, con su mismo nombre.

### El repositorio

```java
package com.curso.repository;

// MongoRepository procede de Spring Data MongoDB, que Maven trae con spring-boot-starter-data-mongodb.
import org.springframework.data.mongodb.repository.MongoRepository;

// Importamos el documento que gestiona este repositorio.
import com.curso.model.Tarea;

/**
 * S12-1 Demo 2: Repositorio de tareas
 *
 * Objetivo: disponer de las operaciones de guardar, buscar y borrar tareas en MongoDB sin escribirlas.
 *
 * Lo que hace este ejemplo:
 *   - Declara una interfaz vacía que extiende MongoRepository
 *   - Hereda save(), findAll(), findById(), existsById() y deleteById()
 *
 * Concepto clave: el repositorio se declara igual que con JPA. Cambia la interfaz de la que
 * se hereda (MongoRepository en lugar de JpaRepository) y el tipo del id (String en lugar de Long).
 */
// MongoRepository<Tarea, String> = documento que gestiona (Tarea) y tipo de su id (String).
public interface TareaRepository extends MongoRepository<Tarea, String> {
}
```

La interfaz extiende `MongoRepository<Tarea, String>`, que ofrece los mismos métodos que `JpaRepository` (`save()`, `findAll()`, `findById()`, `existsById()`, `deleteById()`...). Como en JPA, no se escribe ninguna clase que la implemente: Spring Data la genera al arrancar.

### El controlador

El controlador es el mismo de S11, con dos diferencias: el `id` de las rutas es un `String` y se añade la operación `PUT` para reemplazar una tarea. Todo lo demás (los `Optional`, los `ResponseEntity`, los códigos 201, 204 y 404) es lo ya visto en S09:

```java
package com.curso.controller;

import java.util.List;

// HttpStatus enumera los códigos de estado de HTTP y ResponseEntity representa la respuesta
// completa (estado y cuerpo). Ambas proceden de Spring, que Maven trae con los starters del pom.xml.
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

// Estas anotaciones proceden de Spring MVC, que Maven trae con spring-boot-starter-webmvc.
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.curso.model.Tarea;
import com.curso.repository.TareaRepository;

// RequiredArgsConstructor procede de Lombok, que Maven ha descargado con el pom.xml.
import lombok.RequiredArgsConstructor;

/**
 * S12-1 Demo 2: Controlador REST de tareas sobre MongoDB
 *
 * Objetivo: ofrecer las cinco operaciones del CRUD de tareas como API REST.
 *
 * Lo que hace este ejemplo:
 *   - GET /api/tareas devuelve todas las tareas en JSON
 *   - GET /api/tareas/{id} devuelve una tarea, o 404 si no existe
 *   - POST /api/tareas guarda una tarea nueva y devuelve 201
 *   - PUT /api/tareas/{id} reemplaza una tarea existente, o devuelve 404
 *   - DELETE /api/tareas/{id} borra la tarea y devuelve 204, o 404 si no existe
 *
 * Concepto clave: el controlador es el mismo que con JPA. Solo cambia el tipo del id, que es
 * un String: el repositorio oculta si por debajo hay una tabla o una colección.
 */
@RestController
@RequestMapping("/api/tareas")
@RequiredArgsConstructor
public class TareaController {

    // final = el campo se asigna una sola vez, en el constructor que genera Lombok.
    private final TareaRepository tareaRepository;

    /**
     * Devuelve todas las tareas.
     *
     * Ejemplo:
     *   GET /api/tareas  →  [{"id":"6718...","titulo":"Instalar MongoDB", ...}, ...]
     */
    @GetMapping
    public List<Tarea> listar() {
        // findAll() devuelve todos los documentos de la colección tareas.
        return tareaRepository.findAll();
    }

    /**
     * Devuelve una tarea por su id.
     *
     * Ejemplo:
     *   GET /api/tareas/6718f2a1c3b4d5e6f7a8b9c0  →  200 y la tarea
     *   GET /api/tareas/no-existe                 →  404
     */
    @GetMapping("/{id}")
    public ResponseEntity<Tarea> obtener(@PathVariable String id) {
        // findById() devuelve un Optional. map(ResponseEntity::ok) lo convierte en un 200 con
        // la tarea si existe; orElse() devuelve el 404 si el Optional está vacío.
        return tareaRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Guarda una tarea nueva.
     *
     * Ejemplo:
     *   POST /api/tareas  {"titulo": "Comprar café"}  →  201 y la tarea con su id
     */
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Tarea crear(@RequestBody Tarea tarea) {
        // Anulamos el id recibido: save() inserta si el id es null y reemplaza el documento
        // si ya existe, y aquí queremos que siempre cree una tarea nueva.
        tarea.setId(null);
        return tareaRepository.save(tarea);
    }

    /**
     * Reemplaza una tarea existente.
     *
     * Ejemplo:
     *   PUT /api/tareas/6718...  {"titulo": "Comprar té", "completada": true}  →  200 y la tarea
     *   PUT /api/tareas/no-existe  {...}                                       →  404
     */
    @PutMapping("/{id}")
    public ResponseEntity<Tarea> actualizar(@PathVariable String id, @RequestBody Tarea tarea) {
        // existsById() comprueba que haya un documento con ese id, para devolver 404 si no.
        if (!tareaRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        // Ponemos en la tarea el id de la ruta: save() reemplaza el documento que tiene ese _id.
        tarea.setId(id);
        return ResponseEntity.ok(tareaRepository.save(tarea));
    }

    /**
     * Borra una tarea por su id.
     *
     * Ejemplo:
     *   DELETE /api/tareas/6718...      →  204 (borrada, sin cuerpo)
     *   DELETE /api/tareas/no-existe    →  404 (no existe)
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable String id) {
        // existsById() devuelve true si hay un documento con ese id. Lo comprobamos antes de borrar
        // para poder distinguir "borrada" (204) de "no existía" (404).
        if (!tareaRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        tareaRepository.deleteById(id);
        // 204 = hecho y sin cuerpo.
        return ResponseEntity.noContent().build();
    }
}
```

En la operación `PUT`, `save()` hace lo que su nombre no dice: si el documento recibido tiene un `id` que ya existe en la colección, lo reemplaza entero; si el `id` es `null`, inserta uno nuevo. Por eso `crear()` pone el `id` a `null` antes de guardar (para que un `POST` nunca reemplace una tarea existente) y `actualizar()` pone el `id` de la ruta.

### Arrancar y probar

Arrancamos `Aplicacion` con ▶. Con el servidor de MongoDB en marcha, la consola de IntelliJ muestra la conexión al servidor y termina con `Started Aplicacion`. Comprobamos que MongoDB todavía no tiene nuestra base de datos:

<pre>
test&gt; show dbs
admin   40.00 KiB
config  12.00 KiB
local   40.00 KiB
</pre>

Abrimos `http://localhost:8080/swagger-ui.html` y, en `POST /api/tareas`, `Try it out`, escribimos el cuerpo y `Execute`:

```json
{
  "titulo": "Instalar MongoDB",
  "descripcion": "Servidor y mongosh"
}
```

<pre>
HTTP/1.1 201
Content-Type: application/json

{"titulo":"Instalar MongoDB","descripcion":"Servidor y mongosh","completada":false,"id":"6ad847e28988f90f67203b19"}
</pre>

La tarea vuelve con su `id`, un texto de 24 caracteres que ha generado MongoDB. Ahora, en `mongosh`, la base de datos y la colección existen sin que nadie las haya creado:

<pre>
test&gt; show dbs
admin   40.00 KiB
config  12.00 KiB
local   40.00 KiB
tareas   8.00 KiB
test&gt; use tareas
switched to db tareas
tareas&gt; show collections
tareas
tareas&gt; db.tareas.find()
[
  {
    _id: ObjectId('6ad847ed8988f90f67203b1b'),
    titulo: 'Instalar MongoDB',
    descripcion: 'Servidor y mongosh',
    completada: false,
    _class: 'com.curso.model.Tarea'
  }
]
</pre>

Hay un campo que no hemos declarado: `_class`. Spring Data lo añade a cada documento con el nombre completo de la clase Java con la que se guardó, para saber con qué clase reconstruirlo al leerlo. Es normal y no hay que tocarlo. El `id` de la clase se guarda como `_id`.

Probamos el resto de operaciones desde Swagger, copiando el `id` de la tarea. Con el `id` de ejemplo `6ad847e28988f90f67203b19`:

`GET /api/tareas/{id}` devuelve la tarea con el estado 200:

<pre>
HTTP/1.1 200
Content-Type: application/json

{"titulo":"Instalar MongoDB","descripcion":"Servidor y mongosh","completada":false,"id":"6ad847e28988f90f67203b19"}
</pre>

`PUT /api/tareas/{id}` con el cuerpo completo y `completada` a `true` devuelve la tarea ya modificada:

<pre>
HTTP/1.1 200
Content-Type: application/json

{"titulo":"Instalar MongoDB","descripcion":"Servidor y mongosh","completada":true,"id":"6ad847e28988f90f67203b19"}
</pre>

`DELETE /api/tareas/{id}` devuelve 204. Y un `id` que no existe (por ejemplo, repetir el borrado, o `no-existe`) devuelve 404 en `GET`, `PUT` y `DELETE`:

<pre>
HTTP/1.1 204
</pre>

<pre>
HTTP/1.1 404
</pre>

### Si MongoDB no está en marcha

La aplicación arranca aunque el servidor de MongoDB esté parado, porque el driver se conecta de forma perezosa, al hacer la primera operación. Lo que se nota es que la primera petición tarda unos treinta segundos y termina con un error 500. En la consola de IntelliJ aparece `MongoSocketOpenException` o un mensaje de que no se puede conectar a `localhost:27017`. La solución es arrancar el servicio `MongoDB` desde la consola de servicios de Windows. El test `AplicacionTests` que genera el asistente, en cambio, arranca la aplicación completa y no necesita el servidor para pasar, pero sí lo necesita cualquier test que guarde o lea datos.

---

## Demo 3: Documento incrustado frente a relacional

Supongamos que cada tarea puede tener etiquetas (`curso`, `mongo`...) y que queremos listar las tareas que llevan una etiqueta concreta. Con PostgreSQL, una tarea tiene muchas etiquetas y una etiqueta está en muchas tareas: una relación de muchos a muchos, que exige tres tablas:

```sql
tarea (id, titulo, descripcion, completada)
etiqueta (id, nombre)
tarea_etiqueta (tarea_id, etiqueta_id)
```

Y para obtener las tareas con la etiqueta `curso`, un `JOIN` de las tres. En MongoDB las etiquetas son una lista dentro del propio documento de la tarea, y no hay nada que unir. Es lo que hacemos en esta demo.

### Añadir las etiquetas al documento

En `Tarea` añadimos un campo de tipo `List<String>`:

```java
    private List<String> etiquetas = new ArrayList<>();
```

Es el único cambio en esa clase, más sus imports de `java.util`. No hay ninguna anotación: MongoDB guarda una lista de textos como un array dentro del documento. La lista empieza vacía (y no `null`) para que una tarea sin etiquetas se guarde con `etiquetas: []` y no haya que comprobar `null` al usarla.

### Consultar por etiqueta

En el repositorio añadimos un método derivado del nombre, como los de JPA:

```java
    List<Tarea> findByEtiquetas(String etiqueta);
```

Spring Data lee el nombre: `findBy` + el campo `Etiquetas`. Como el campo es una lista y se pasa un solo texto, construye la consulta `{ etiquetas: "curso" }` que ya escribimos en `mongosh`, y devuelve las tareas cuya lista incluye ese valor.

En el controlador, la operación de listar acepta ahora un parámetro opcional de la URL, `etiqueta`:

```java
    @GetMapping
    public List<Tarea> listar(@RequestParam(required = false) String etiqueta) {
        if (etiqueta == null) {
            return tareaRepository.findAll();
        }
        return tareaRepository.findByEtiquetas(etiqueta);
    }
```

`@RequestParam` lee un parámetro de la URL, lo que va detrás de la `?`, como en `/api/tareas?etiqueta=curso`. Con `required = false`, si no se indica, vale `null` y se devuelven todas las tareas.

### Probar

Reiniciamos la aplicación. Vaciamos antes la base de datos de la demo anterior, para empezar de cero (en `mongosh`, `use tareas` y `db.dropDatabase()`). Creamos tres tareas con `POST /api/tareas`, desde Swagger:

```json
{
  "titulo": "Revisar los apuntes",
  "etiquetas": ["curso", "mongo"]
}
```

```json
{
  "titulo": "Preparar la presentación",
  "etiquetas": ["curso"]
}
```

```json
{
  "titulo": "Comprar café"
}
```

La respuesta de la primera incluye las etiquetas, y el campo `descripcion` vale `null` porque no se envió:

<pre>
HTTP/1.1 201
Content-Type: application/json

{"titulo":"Revisar los apuntes","descripcion":null,"completada":false,"etiquetas":["curso","mongo"],"id":"6ad8482e75721435e19ede92"}
</pre>

`GET /api/tareas?etiqueta=curso` devuelve las dos tareas que tienen esa etiqueta:

<pre>
HTTP/1.1 200
Content-Type: application/json

[{"titulo":"Revisar los apuntes","descripcion":null,"completada":false,"etiquetas":["curso","mongo"],"id":"6ad8482e75721435e19ede92"},{"titulo":"Preparar la presentación","descripcion":null,"completada":false,"etiquetas":["curso"],"id":"6ad8482e75721435e19ede93"}]
</pre>

Con una etiqueta que ninguna tarea tiene, `GET /api/tareas?etiqueta=nada`, la lista llega vacía y el estado sigue siendo 200:

<pre>
HTTP/1.1 200
Content-Type: application/json

[]
</pre>

Y la tercera tarea, creada sin etiquetas, se guardó con la lista vacía: `GET /api/tareas` la devuelve con `"etiquetas":[]`.

### Lo que se gana y lo que se pierde

En `mongosh` vemos cómo está guardado, y qué pasa cuando una etiqueta cambia de nombre:

```
db.tareas.find({}, { titulo: 1, etiquetas: 1, _id: 0 })
db.tareas.find({ etiquetas: "curso" }, { titulo: 1, etiquetas: 1, _id: 0 })
db.tareas.updateMany({ etiquetas: "curso" }, { $set: { "etiquetas.$": "clase" } })
db.tareas.find({}, { titulo: 1, etiquetas: 1, _id: 0 })
```

<pre>
test&gt; use tareas
switched to db tareas
tareas&gt; db.tareas.find({}, { titulo: 1, etiquetas: 1, _id: 0 })
[
  { titulo: 'Revisar los apuntes', etiquetas: [ 'curso', 'mongo' ] },
  { titulo: 'Preparar la presentación', etiquetas: [ 'curso' ] },
  { titulo: 'Comprar café', etiquetas: [] }
]
tareas&gt; db.tareas.find({ etiquetas: "curso" }, { titulo: 1, etiquetas: 1, _id: 0 })
[
  { titulo: 'Revisar los apuntes', etiquetas: [ 'curso', 'mongo' ] },
  { titulo: 'Preparar la presentación', etiquetas: [ 'curso' ] }
]
tareas&gt; db.tareas.updateMany({ etiquetas: "curso" }, { $set: { "etiquetas.$": "clase" } })
{
  acknowledged: true,
  insertedId: null,
  matchedCount: 2,
  modifiedCount: 2,
  upsertedCount: 0
}
tareas&gt; db.tareas.find({}, { titulo: 1, etiquetas: 1, _id: 0 })
[
  { titulo: 'Revisar los apuntes', etiquetas: [ 'clase', 'mongo' ] },
  { titulo: 'Preparar la presentación', etiquetas: [ 'clase' ] },
  { titulo: 'Comprar café', etiquetas: [] }
]
</pre>

En la tercera orden, `updateMany()` aplica el cambio a todos los documentos que cumplen el filtro (aquí, los dos que tenían `curso`). En `"etiquetas.$"`, el signo `$` representa la posición de la etiqueta que ha coincidido con el filtro: así se cambia solo esa etiqueta de la lista y no las demás.

La comparación con el diseño relacional:

| | Relacional (tres tablas) | Documental (lista incrustada) |
|---|---|---|
| Leer una tarea con sus etiquetas | `JOIN` de tres tablas | Un solo documento, una sola lectura |
| Guardar una tarea con etiquetas | `INSERT` en la tabla de tareas y en la intermedia, y en la de etiquetas si es nueva | Un solo `insert` |
| Cambiar el nombre de una etiqueta | Una fila en la tabla `etiqueta` | Cada documento que la contiene (`updateMany()`) |
| Listar todas las etiquetas distintas | `SELECT` sobre la tabla `etiqueta` | Hay que recorrer los documentos de las tareas |
| Garantizar que una etiqueta escrita está bien | La clave foránea lo exige | Nada lo impide: `"cursso"` se guarda sin protestar |

La lista incrustada simplifica mucho las lecturas y las escrituras de una tarea, que es lo que más hace la aplicación. A cambio, cualquier dato que se repite en muchos documentos hay que mantenerlo en cada uno de ellos, y la base de datos no comprueba su coherencia. Cuando los datos relacionados se leen casi siempre juntos y apenas cambian, el documento incrustado gana. Cuando se relacionan con muchas otras cosas, se consultan por separado o se modifican a menudo, las tablas con sus claves foráneas siguen siendo mejor opción.

### El código completo

Las tres clases que cambian respecto a la Demo 2 quedan así (son las del zip). La entidad:

```java
package com.curso.model;

// ArrayList y List son clases estándar de Java: no hace falta ninguna librería.
import java.util.ArrayList;
import java.util.List;

// @Document y @Id (de Spring Data MongoDB) se importan de paquetes distintos a los de JPA.
// Maven las ha descargado al declarar spring-boot-starter-data-mongodb en el pom.xml.
// @Id es la de Spring Data (org.springframework.data.annotation), no la de jakarta.persistence.
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// Importamos las anotaciones de Lombok. Maven ha descargado la librería al declarar
// org.projectlombok:lombok en el pom.xml. Lombok las lee al compilar y escribe por nosotros
// el código repetitivo, que queda dentro del .class pero no aparece en el .java.
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * S12-1 Demo 3: Documento Tarea con etiquetas incrustadas
 *
 * Objetivo: guardar tareas en MongoDB junto con su lista de etiquetas, dentro del mismo documento.
 *
 * Lo que hace este ejemplo:
 *   - Declara la clase Tarea como documento de la colección tareas
 *   - Usa un id de tipo String, que genera MongoDB
 *   - Guarda las etiquetas como una lista de textos dentro de la propia tarea
 *   - Usa Lombok para los getters, los setters y el constructor vacío, como en S11
 *
 * Concepto clave: los datos relacionados pueden ir dentro del documento. Con JPA las etiquetas
 * necesitarían otra tabla y una tabla intermedia; aquí son un campo más de la tarea.
 */
// @Document indica que los objetos de esta clase se guardan como documentos de MongoDB.
// collection = "tareas" fija el nombre de la colección. Sin él, Spring usaría el nombre de
// la clase en minúscula y en singular ("tarea").
@Document(collection = "tareas")
@Getter
@Setter
@NoArgsConstructor
public class Tarea {

    // @Id marca el campo que se guarda como _id, el identificador del documento.
    // Es un String porque MongoDB genera un ObjectId, un valor de 24 caracteres
    // hexadecimales (por ejemplo "6718f2a1c3b4d5e6f7a8b9c0"). Vale null hasta que se guarda.
    @Id
    private String id;

    private String titulo;

    private String descripcion;

    private boolean completada;

    // Una lista de textos es un campo más: MongoDB la guarda como un array dentro del documento
    // ("etiquetas": ["curso", "mongo"]). Empieza vacía y no null para que una tarea sin etiquetas
    // se guarde con una lista vacía y no haya que comprobar null al usarla.
    private List<String> etiquetas = new ArrayList<>();

    // Este constructor sí lo escribimos nosotros: Lombok no sabe qué campos queremos recibir.
    // No incluye el id ni completada: el id lo genera MongoDB y una tarea nueva está pendiente.
    public Tarea(String titulo, String descripcion) {
        this.titulo = titulo;
        this.descripcion = descripcion;
    }

    // toString() devuelve el texto con el que se imprime la tarea;
    // @Override avisa al compilador de que reescribimos el método heredado de Object.
    @Override
    public String toString() {
        return "Tarea{id=" + id + ", titulo='" + titulo + "', completada=" + completada + "}";
    }
}
```

El repositorio:

```java
package com.curso.repository;

import java.util.List;

// MongoRepository procede de Spring Data MongoDB, que Maven trae con spring-boot-starter-data-mongodb.
import org.springframework.data.mongodb.repository.MongoRepository;

// Importamos el documento que gestiona este repositorio.
import com.curso.model.Tarea;

/**
 * S12-1 Demo 3: Repositorio de tareas con búsqueda por etiqueta
 *
 * Objetivo: disponer de las operaciones de guardar, buscar y borrar tareas en MongoDB y de una
 * búsqueda por etiqueta, sin escribir ninguna consulta.
 *
 * Lo que hace este ejemplo:
 *   - Declara una interfaz que extiende MongoRepository
 *   - Hereda save(), findAll(), findById(), existsById() y deleteById()
 *   - Declara findByEtiquetas(), un método derivado del nombre como los de JPA
 *
 * Concepto clave: los métodos derivados funcionan igual que con JPA. Spring Data lee el nombre
 * del método y construye la consulta de MongoDB; sobre un campo lista, busca los documentos
 * cuya lista contiene el valor.
 */
// MongoRepository<Tarea, String> = documento que gestiona (Tarea) y tipo de su id (String).
public interface TareaRepository extends MongoRepository<Tarea, String> {

    // El nombre se lee como "buscar por etiquetas": el campo es la lista etiquetas y,
    // al pasarle un solo texto, devuelve las tareas cuya lista incluye ese texto.
    // Ejemplo: findByEtiquetas("curso")  →  las tareas con "curso" entre sus etiquetas
    List<Tarea> findByEtiquetas(String etiqueta);
}
```

Y el controlador:

```java
package com.curso.controller;

import java.util.List;

// HttpStatus enumera los códigos de estado de HTTP y ResponseEntity representa la respuesta
// completa (estado y cuerpo). Ambas proceden de Spring, que Maven trae con los starters del pom.xml.
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

// Estas anotaciones proceden de Spring MVC, que Maven trae con spring-boot-starter-webmvc.
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.curso.model.Tarea;
import com.curso.repository.TareaRepository;

// RequiredArgsConstructor procede de Lombok, que Maven ha descargado con el pom.xml.
import lombok.RequiredArgsConstructor;

/**
 * S12-1 Demo 3: Controlador REST de tareas sobre MongoDB, con filtro por etiqueta
 *
 * Objetivo: ofrecer las cinco operaciones del CRUD de tareas como API REST y poder filtrar
 * la lista por etiqueta.
 *
 * Lo que hace este ejemplo:
 *   - GET /api/tareas devuelve todas las tareas en JSON
 *   - GET /api/tareas?etiqueta=curso devuelve solo las que tienen esa etiqueta
 *   - GET /api/tareas/{id} devuelve una tarea, o 404 si no existe
 *   - POST /api/tareas guarda una tarea nueva y devuelve 201
 *   - PUT /api/tareas/{id} reemplaza una tarea existente, o devuelve 404
 *   - DELETE /api/tareas/{id} borra la tarea y devuelve 204, o 404 si no existe
 *
 * Concepto clave: el controlador es el mismo que con JPA. Solo cambia el tipo del id, que es
 * un String: el repositorio oculta si por debajo hay una tabla o una colección.
 */
@RestController
@RequestMapping("/api/tareas")
@RequiredArgsConstructor
public class TareaController {

    // final = el campo se asigna una sola vez, en el constructor que genera Lombok.
    private final TareaRepository tareaRepository;

    /**
     * Devuelve las tareas, todas o solo las que tienen una etiqueta.
     *
     * Ejemplo:
     *   GET /api/tareas                  →  todas las tareas
     *   GET /api/tareas?etiqueta=curso   →  solo las que tienen la etiqueta "curso"
     */
    @GetMapping
    // @RequestParam lee un parámetro de la URL (lo que va detrás de la ?). Con required = false
    // el parámetro es opcional: si no viene, etiqueta vale null.
    public List<Tarea> listar(@RequestParam(required = false) String etiqueta) {
        // Si no hay etiqueta, findAll() devuelve todos los documentos de la colección tareas.
        if (etiqueta == null) {
            return tareaRepository.findAll();
        }
        // Si la hay, el método derivado devuelve solo las tareas cuya lista de etiquetas la contiene.
        return tareaRepository.findByEtiquetas(etiqueta);
    }

    /**
     * Devuelve una tarea por su id.
     *
     * Ejemplo:
     *   GET /api/tareas/6718f2a1c3b4d5e6f7a8b9c0  →  200 y la tarea
     *   GET /api/tareas/no-existe                 →  404
     */
    @GetMapping("/{id}")
    public ResponseEntity<Tarea> obtener(@PathVariable String id) {
        // findById() devuelve un Optional. map(ResponseEntity::ok) lo convierte en un 200 con
        // la tarea si existe; orElse() devuelve el 404 si el Optional está vacío.
        return tareaRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Guarda una tarea nueva.
     *
     * Ejemplo:
     *   POST /api/tareas  {"titulo": "Comprar café"}  →  201 y la tarea con su id
     */
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Tarea crear(@RequestBody Tarea tarea) {
        // Anulamos el id recibido: save() inserta si el id es null y reemplaza el documento
        // si ya existe, y aquí queremos que siempre cree una tarea nueva.
        tarea.setId(null);
        return tareaRepository.save(tarea);
    }

    /**
     * Reemplaza una tarea existente.
     *
     * Ejemplo:
     *   PUT /api/tareas/6718...  {"titulo": "Comprar té", "completada": true}  →  200 y la tarea
     *   PUT /api/tareas/no-existe  {...}                                       →  404
     */
    @PutMapping("/{id}")
    public ResponseEntity<Tarea> actualizar(@PathVariable String id, @RequestBody Tarea tarea) {
        // existsById() comprueba que haya un documento con ese id, para devolver 404 si no.
        if (!tareaRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        // Ponemos en la tarea el id de la ruta: save() reemplaza el documento que tiene ese _id.
        tarea.setId(id);
        return ResponseEntity.ok(tareaRepository.save(tarea));
    }

    /**
     * Borra una tarea por su id.
     *
     * Ejemplo:
     *   DELETE /api/tareas/6718...      →  204 (borrada, sin cuerpo)
     *   DELETE /api/tareas/no-existe    →  404 (no existe)
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable String id) {
        // existsById() devuelve true si hay un documento con ese id. Lo comprobamos antes de borrar
        // para poder distinguir "borrada" (204) de "no existía" (404).
        if (!tareaRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        tareaRepository.deleteById(id);
        // 204 = hecho y sin cuerpo.
        return ResponseEntity.noContent().build();
    }
}
```

Las órdenes de `mongosh` de esta demo están en `mongo/02-etiquetas.js`, dentro del zip.
