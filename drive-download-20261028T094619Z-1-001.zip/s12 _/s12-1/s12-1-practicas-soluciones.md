# S12-1 Soluciones

## Práctica 1: Colección de notas con mongosh

La solución crea la base de datos `notas` guardando la primera nota, inserta el resto con `insertMany()` para ver que los documentos de una colección pueden tener campos distintos, y practica los cuatro grupos de operaciones: consultar, filtrar, modificar y borrar. Las salidas llevan `ObjectId` que serán distintos en cada equipo. Las órdenes están reunidas en `mongo/01-notas.js`, dentro de `s12-1-practicas.zip`, carpeta `notas-api`; ese fichero deja las notas preparadas para la práctica siguiente.

### Crear la base de datos e insertar

Se abre `mongosh` y se cambia de base de datos. La nota con `titulo` y `texto` se guarda con `insertOne()`; las otras cuatro, con `insertMany()`:

```
use notas
db.notas.insertOne({ titulo: "Comprar café", texto: "Café en grano para la oficina" })
db.notas.insertMany([
    { titulo: "Apuntes de MongoDB", texto: "MongoDB guarda documentos parecidos a un JSON", importante: true },
    { titulo: "Reunión del grupo", texto: "Repasar el proyecto de Spring Boot", importante: true, etiquetas: ["proyecto", "reunión"] },
    { titulo: "Lista de la compra", texto: "Pan, leche y café", importante: false },
    { titulo: "Ideas", texto: "Probar MongoDB Compass para ver los documentos" }
])
```

(`insertMany()` se escribe en una sola línea en la consola.)

<pre>
test&gt; use notas
switched to db notas
</pre>

<pre>
notas&gt; db.notas.insertOne({ titulo: "Comprar café", texto: "Café en grano para la oficina" })
{
  acknowledged: true,
  insertedId: ObjectId('6ad848e0a727d0be3353fcd6')
}
notas&gt; db.notas.insertMany([{ titulo: "Apuntes de MongoDB", texto: "MongoDB guarda documentos parecidos a un JSON", importante: true }, { titulo: "Reunión del grupo", texto: "Repasar el proyecto de Spring Boot", importante: true, etiquetas: ["proyecto", "reunión"] }, { titulo: "Lista de la compra", texto: "Pan, leche y café", importante: false }, { titulo: "Ideas", texto: "Probar MongoDB Compass para ver los documentos" }])
{
  acknowledged: true,
  insertedIds: {
    '0': ObjectId('6ad848e0a727d0be3353fcd7'),
    '1': ObjectId('6ad848e0a727d0be3353fcd8'),
    '2': ObjectId('6ad848e0a727d0be3353fcd9'),
    '3': ObjectId('6ad848e0a727d0be3353fcda')
  }
}
</pre>

### Consultar con filtros

```
db.notas.find({ importante: true })
db.notas.find({ texto: /café/i })
db.notas.find({ importante: true, etiquetas: "proyecto" })
db.notas.find({}, { titulo: 1, _id: 0 })
```

<pre>
notas&gt; db.notas.find({ importante: true })
[
  {
    _id: ObjectId('6ad848e0a727d0be3353fcd7'),
    titulo: 'Apuntes de MongoDB',
    texto: 'MongoDB guarda documentos parecidos a un JSON',
    importante: true
  },
  {
    _id: ObjectId('6ad848e0a727d0be3353fcd8'),
    titulo: 'Reunión del grupo',
    texto: 'Repasar el proyecto de Spring Boot',
    importante: true,
    etiquetas: [ 'proyecto', 'reunión' ]
  }
]
notas&gt; db.notas.find({ texto: /café/i })
[
  {
    _id: ObjectId('6ad848e0a727d0be3353fcd6'),
    titulo: 'Comprar café',
    texto: 'Café en grano para la oficina'
  },
  {
    _id: ObjectId('6ad848e0a727d0be3353fcd9'),
    titulo: 'Lista de la compra',
    texto: 'Pan, leche y café',
    importante: false
  }
]
notas&gt; db.notas.find({ importante: true, etiquetas: "proyecto" })
[
  {
    _id: ObjectId('6ad848e0a727d0be3353fcd8'),
    titulo: 'Reunión del grupo',
    texto: 'Repasar el proyecto de Spring Boot',
    importante: true,
    etiquetas: [ 'proyecto', 'reunión' ]
  }
]
notas&gt; db.notas.find({}, { titulo: 1, _id: 0 })
[
  { titulo: 'Comprar café' },
  { titulo: 'Apuntes de MongoDB' },
  { titulo: 'Reunión del grupo' },
  { titulo: 'Lista de la compra' },
  { titulo: 'Ideas' }
]
</pre>

La primera consulta devuelve las dos notas con `importante: true`. La nota `Comprar café` y la nota `Ideas` no aparecen porque no tienen el campo: un filtro por un campo solo devuelve los documentos que lo tienen con ese valor. La segunda usa una expresión regular, `/café/i`, entre barras, y encuentra las notas cuyo texto contiene `café` con cualquier combinación de mayúsculas, como `Café en grano...` y `...leche y café`. La tercera junta dos condiciones en el mismo documento del filtro, que se leen como "y": importante y con la etiqueta `proyecto` (que es una condición sobre una lista, igual que en la Demo 1). La cuarta es una proyección: solo el título, sin el `_id`.

### Modificar y borrar

```
db.notas.updateOne({ titulo: "Ideas" }, { $set: { importante: true } })
db.notas.updateMany({ importante: { $exists: false } }, { $set: { importante: false } })
db.notas.deleteOne({ titulo: "Lista de la compra" })
db.notas.countDocuments()
```

<pre>
notas&gt; db.notas.updateOne({ titulo: "Ideas" }, { $set: { importante: true } })
{
  acknowledged: true,
  insertedId: null,
  matchedCount: 1,
  modifiedCount: 1,
  upsertedCount: 0
}
notas&gt; db.notas.updateMany({ importante: { $exists: false } }, { $set: { importante: false } })
{
  acknowledged: true,
  insertedId: null,
  matchedCount: 1,
  modifiedCount: 1,
  upsertedCount: 0
}
</pre>

<pre>
notas&gt; db.notas.deleteOne({ titulo: "Lista de la compra" })
{ acknowledged: true, deletedCount: 1 }
notas&gt; db.notas.countDocuments()
4
</pre>

`updateOne()` con `$set` cambia solo el campo `importante` de la nota `Ideas`. `updateMany()` aplica el cambio a todos los documentos que cumplen el filtro; `{ importante: { $exists: false } }` selecciona los que no tienen el campo, que en este momento es solo `Comprar café` (`matchedCount: 1`). Tras borrar `Lista de la compra` quedan 4 notas.

### Compass

En Compass se entra en `notas` y en la colección `notas`. La pestaña `Documents` muestra las cuatro notas que quedan, y escribiendo `{ importante: true }` en la barra de filtro y pulsando `Find` se obtienen las importantes, como con `find()`.

**Decisiones tomadas**

- El campo de importancia se rellena con `updateMany()` porque es el caso típico de una colección que evoluciona: unos documentos nuevos traen un campo que los antiguos no tienen, y se corrige después sin tocar ningún esquema.
- Se usó una expresión regular (`/café/i`) en lugar de un valor exacto porque lo que se busca es una palabra dentro del texto, no el texto entero. Es el equivalente en `mongosh` de lo que hará `Containing` e `IgnoreCase` en la práctica siguiente.
- Se dejó la base de datos `notas` con datos al terminar, sin `dropDatabase()`, porque la Práctica 2 los lee desde la API.

---

## Práctica 2: API de notas con Spring Data MongoDB

La solución repite la secuencia de la Demo 2 con otro dominio: el mismo proyecto con otro nombre y otra clase de documento. Lo único nuevo es el método derivado para buscar por texto. El proyecto completo está en `s12-1-practicas.zip`, carpeta `notas-api`.

### Crear el proyecto

En el generador se marcan `Spring Web`, `Spring Data MongoDB` y `Lombok`, y se renombran las dos clases con `Shift+F6` (`Aplicacion` y `AplicacionTests`). Después se añade a mano la dependencia de Swagger, dentro de `<dependencies>`:

```xml
		<dependency>
			<groupId>org.springdoc</groupId>
			<artifactId>springdoc-openapi-starter-webmvc-ui</artifactId>
			<version>3.1.1</version>
		</dependency>
```

`application.properties`:

```properties
# Nombre de la aplicación: aparece entre corchetes en cada línea del log.
spring.application.name=notas-api

# Conexión a MongoDB: dirección del servidor local (puerto 27017 por defecto) y nombre de la
# base de datos, notas. No lleva usuario ni contraseña porque la instalación local de
# MongoDB no tiene la autenticación activada. La base de datos no hay que crearla: MongoDB
# la crea al guardar el primer documento.
spring.mongodb.uri=mongodb://localhost:27017/notas
```

### El documento y el repositorio

```java
package com.curso.model;

// @Id y @Document proceden de Spring Data MongoDB, que Maven ha descargado al declarar
// spring-boot-starter-data-mongodb en el pom.xml.
// @Id es la de Spring Data (org.springframework.data.annotation), no la de jakarta.persistence.
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

// Importamos las anotaciones de Lombok. Maven ha descargado la librería al declarar
// org.projectlombok:lombok en el pom.xml. Lombok las lee al compilar y escribe por nosotros
// el código repetitivo, que queda dentro del .class pero no aparece en el .java.
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * S12-1 Práctica 2: Documento Nota
 *
 * Objetivo: guardar notas en MongoDB como documentos de la colección notas.
 *
 * Aplica las técnicas de S12-1:
 *   1. Clase anotada con @Document y su colección
 *   2. Identificador de tipo String que genera MongoDB
 *   3. Lombok para los getters, los setters y el constructor vacío
 *
 * Concepto clave: los documentos que se crearon a mano con mongosh y los que guarda la API
 * son de la misma colección, porque la clase solo describe cómo se lee y se escribe cada documento.
 */
// @Document indica que los objetos de esta clase se guardan como documentos de MongoDB.
// collection = "notas" es el nombre de la colección que se creó con mongosh.
@Document(collection = "notas")
@Getter
@Setter
@NoArgsConstructor
public class Nota {

    // @Id marca el campo que se guarda como _id. Es un String porque MongoDB genera un
    // ObjectId, que Spring Data convierte a texto. Vale null hasta que se guarda.
    @Id
    private String id;

    private String titulo;

    private String texto;

    // Si un documento no tiene este campo (por ejemplo, una nota insertada a mano sin él),
    // al leerlo el boolean vale false, el valor por defecto.
    private boolean importante;

    // toString() devuelve el texto con el que se imprime la nota;
    // @Override avisa al compilador de que reescribimos el método heredado de Object.
    @Override
    public String toString() {
        return "Nota{id=" + id + ", titulo='" + titulo + "', importante=" + importante + "}";
    }
}
```

```java
package com.curso.repository;

import java.util.List;

// MongoRepository procede de Spring Data MongoDB, que Maven trae con spring-boot-starter-data-mongodb.
import org.springframework.data.mongodb.repository.MongoRepository;

// Importamos el documento que gestiona este repositorio.
import com.curso.model.Nota;

/**
 * S12-1 Práctica 2: Repositorio de notas con búsqueda por texto
 *
 * Objetivo: guardar, buscar y borrar notas, y buscar las que contienen una palabra en su texto.
 *
 * Aplica las técnicas de S12-1:
 *   1. Repositorio que extiende MongoRepository, sin implementarlo
 *   2. Método derivado del nombre con Containing e IgnoreCase
 *
 * Concepto clave: los métodos derivados funcionan igual que con JPA. Spring Data lee el nombre
 * y construye la consulta de MongoDB, que aquí es una expresión regular insensible a mayúsculas.
 */
// MongoRepository<Nota, String> = documento que gestiona (Nota) y tipo de su id (String).
public interface NotaRepository extends MongoRepository<Nota, String> {

    // Containing = el campo contiene el texto indicado; IgnoreCase = sin distinguir mayúsculas.
    // Ejemplo: findByTextoContainingIgnoreCase("mongo")  →  las notas cuyo texto incluye "Mongo", "MONGO"...
    List<Nota> findByTextoContainingIgnoreCase(String texto);
}
```

El método `findByTextoContainingIgnoreCase()` se declara solo, sin implementarlo: Spring Data lo lee por partes, `findBy` + `Texto` (el campo) + `Containing` (contiene) + `IgnoreCase` (sin distinguir mayúsculas), y construye la consulta de MongoDB.

### El controlador

```java
package com.curso.controller;

import java.util.List;

// HttpStatus enumera los códigos de estado de HTTP y ResponseEntity representa la respuesta
// completa (estado y cuerpo). Ambas proceden de Spring, que Maven trae con los starters del pom.xml.
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

// Estas anotaciones proceden de Spring MVC, que Maven trae con spring-boot-starter-webmvc.
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.curso.model.Nota;
import com.curso.repository.NotaRepository;

// RequiredArgsConstructor procede de Lombok, que Maven ha descargado con el pom.xml.
import lombok.RequiredArgsConstructor;

/**
 * S12-1 Práctica 2: Controlador REST de notas sobre MongoDB
 *
 * Objetivo: ofrecer el CRUD de notas como API REST y poder buscarlas por una palabra de su texto.
 *
 * Aplica las técnicas de S12-1:
 *   1. Controlador REST que usa un MongoRepository
 *   2. Ids de tipo String en las rutas
 *   3. Parámetro opcional de la URL con @RequestParam, que activa el método derivado
 *
 * Concepto clave: el controlador es el mismo que con JPA. Solo cambia el tipo del id, que es
 * un String: el repositorio oculta si por debajo hay una tabla o una colección.
 */
@RestController
@RequestMapping("/api/notas")
@RequiredArgsConstructor
public class NotaController {

    // final = el campo se asigna una sola vez, en el constructor que genera Lombok.
    private final NotaRepository notaRepository;

    /**
     * Devuelve las notas, todas o solo las que contienen una palabra en su texto.
     *
     * Ejemplo:
     *   GET /api/notas               →  todas las notas
     *   GET /api/notas?texto=mongo   →  las notas cuyo texto incluye "mongo", sin distinguir mayúsculas
     */
    @GetMapping
    // @RequestParam lee un parámetro de la URL (lo que va detrás de la ?). Con required = false
    // el parámetro es opcional: si no viene, texto vale null.
    public List<Nota> listar(@RequestParam(required = false) String texto) {
        // Si no hay texto, findAll() devuelve todos los documentos de la colección notas.
        if (texto == null) {
            return notaRepository.findAll();
        }
        // Si lo hay, el método derivado devuelve solo las notas cuyo texto lo contiene.
        return notaRepository.findByTextoContainingIgnoreCase(texto);
    }

    /**
     * Devuelve una nota por su id.
     *
     * Ejemplo:
     *   GET /api/notas/6718f2a1c3b4d5e6f7a8b9c0  →  200 y la nota
     *   GET /api/notas/no-existe                 →  404
     */
    @GetMapping("/{id}")
    public ResponseEntity<Nota> obtener(@PathVariable String id) {
        // findById() devuelve un Optional. map(ResponseEntity::ok) lo convierte en un 200 con
        // la nota si existe; orElse() devuelve el 404 si el Optional está vacío.
        return notaRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Guarda una nota nueva.
     *
     * Ejemplo:
     *   POST /api/notas  {"titulo": "Comprar café"}  →  201 y la nota con su id
     */
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Nota crear(@RequestBody Nota nota) {
        // Anulamos el id recibido: save() inserta si el id es null y reemplaza el documento
        // si ya existe, y aquí queremos que siempre cree una nota nueva.
        nota.setId(null);
        return notaRepository.save(nota);
    }

    /**
     * Reemplaza una nota existente.
     *
     * Ejemplo:
     *   PUT /api/notas/6718...  {"titulo": "Comprar té", "completada": true}  →  200 y la nota
     *   PUT /api/notas/no-existe  {...}                                       →  404
     */
    @PutMapping("/{id}")
    public ResponseEntity<Nota> actualizar(@PathVariable String id, @RequestBody Nota nota) {
        // existsById() comprueba que haya un documento con ese id, para devolver 404 si no.
        if (!notaRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        // Ponemos en la nota el id de la ruta: save() reemplaza el documento que tiene ese _id.
        nota.setId(id);
        return ResponseEntity.ok(notaRepository.save(nota));
    }

    /**
     * Borra una nota por su id.
     *
     * Ejemplo:
     *   DELETE /api/notas/6718...      →  204 (borrada, sin cuerpo)
     *   DELETE /api/notas/no-existe    →  404 (no existe)
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable String id) {
        // existsById() devuelve true si hay un documento con ese id. Lo comprobamos antes de borrar
        // para poder distinguir "borrada" (204) de "no existía" (404).
        if (!notaRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        notaRepository.deleteById(id);
        // 204 = hecho y sin cuerpo.
        return ResponseEntity.noContent().build();
    }
}
```

`Aplicacion` y `AplicacionTests` son las que genera el asistente, con los nombres cambiados.

### Resultados

Arrancamos con el servidor de MongoDB en marcha y las notas de la práctica anterior en la colección. `GET /api/notas?texto=café` encuentra la nota con `Café`, y `texto=CAFÉ` devuelve lo mismo, porque `IgnoreCase` no distingue mayúsculas, ni siquiera con tilde:

<pre>
HTTP/1.1 200
Content-Type: application/json

[{"id":"6ad848bd485949d97b1d694b","importante":false,"texto":"Café en grano para la oficina","titulo":"Comprar café"}]
</pre>

`texto=mongo` encuentra dos notas, cuyo texto incluye `MongoDB`:

<pre>
HTTP/1.1 200
Content-Type: application/json

[{"id":"6ad848bd485949d97b1d694c","importante":true,"texto":"MongoDB guarda documentos parecidos a un JSON","titulo":"Apuntes de MongoDB"},{"id":"6ad848bd485949d97b1d694f","importante":true,"texto":"Probar MongoDB Compass para ver los documentos","titulo":"Ideas"}]
</pre>

Una palabra que no está en ninguna nota devuelve una lista vacía con estado 200:

<pre>
HTTP/1.1 200
Content-Type: application/json

[]
</pre>

La API lee sin problema las notas que se insertaron a mano con `mongosh`. Una nota creada desde la API, en cambio, trae un campo más en MongoDB, `_class`, que Spring Data añade con el nombre de la clase. Las notas hechas con `mongosh` no lo tienen y se leen igual:

<pre>
test&gt; use notas
switched to db notas
notas&gt; db.notas.find({ titulo: "Entrega" })
[
  {
    _id: ObjectId('6ad849e8adadc93b862e7623'),
    titulo: 'Entrega',
    texto: 'Subir el proyecto de MongoDB',
    importante: true,
    _class: 'com.curso.model.Nota'
  }
]
notas&gt; db.notas.find({ titulo: "Comprar café" })
[
  {
    _id: ObjectId('6ad849d347b907ce0a1b2875'),
    titulo: 'Comprar café',
    texto: 'Café en grano para la oficina',
    importante: false
  }
]
</pre>

El resto de operaciones responde como en la demo: `POST` devuelve 201 con la nota y su `id`, `PUT` devuelve 200 con la nota reemplazada, `DELETE` devuelve 204 y cualquier operación por `id` con un `id` que no existe devuelve 404.

<pre>
HTTP/1.1 201
Content-Type: application/json

{"id":"6ad848cc29ad11c282972ad5","importante":true,"texto":"Subir el proyecto de MongoDB","titulo":"Entrega"}
</pre>

**Decisiones tomadas**

- El campo `id` es un `String` y no un `Long` porque MongoDB genera un `ObjectId`, que Spring Data convierte a texto. Un `Long` no se podría rellenar.
- `importante` es un `boolean` y no un `Boolean` para que una nota insertada a mano sin ese campo se lea como `false` y no como `null`. Con `Boolean` el JSON de esa nota llevaría `null`, y el cliente tendría que distinguir tres estados.
- La búsqueda por texto es un parámetro opcional del mismo `GET` de listar, y no una ruta nueva. Una lista y la misma lista filtrada son el mismo recurso, y el filtro se pide en la URL con `?`.
- `crear()` pone el `id` a `null` y `actualizar()` pone el `id` de la ruta, para que `save()` siempre haga lo que dice el verbo HTTP: el `POST` inserta y el `PUT` reemplaza.
- Se mantiene el `ResponseEntity` con `orElse` y el `existsById` de S09, porque el repositorio oculta si por debajo hay una tabla o una colección: el controlador de MongoDB es casi idéntico al de JPA.

---

## Práctica 3: Relacional o documental en el proyecto del grupo

Cada grupo tiene un proyecto distinto, así que no hay una solución única. Lo que sigue es un ejemplo resuelto con un proyecto imaginario de tienda online, para ver la forma que debe tener el razonamiento. Lo que se valora en un grupo es que cada decisión se apoye en las respuestas a las tres preguntas del enunciado.

### Ejemplo: una tienda online

Entidades: `Cliente`, `Producto`, `Categoría` y `Pedido`, con líneas de pedido (producto y cantidad). Relaciones: un producto pertenece a una categoría; un pedido es de un cliente y tiene varias líneas, cada una de un producto.

| Relación | ¿Se lee junto? | ¿Se consulta por separado? | Decisión |
|---|---|---|---|
| Pedido y sus líneas | Siempre: un pedido se muestra con sus líneas | No: las líneas no se usan fuera de su pedido | **Incrustar** las líneas en el documento del pedido |
| Línea de pedido y producto | Se muestra el nombre y el precio | Sí: los productos se listan y se modifican a menudo | **Referencia** al producto, más una copia del nombre y del precio en el momento de comprar |
| Producto y categoría | Se muestra la categoría con el producto | Sí: se listan por categoría, y el nombre de una categoría puede cambiar | **Tablas** o colecciones separadas, con la categoría referenciada |
| Pedido y cliente | A veces | Sí: los clientes se consultan por separado | **Referencia** al cliente |

Un documento de pedido resultante, escrito con la sintaxis de `mongosh`:

```
{
  numero: 1001,
  cliente: ObjectId("..."),
  fecha: ISODate("2026-11-05T10:30:00Z"),
  lineas: [
    { producto: ObjectId("..."), nombre: "Taza", precio: 8.5, cantidad: 2 },
    { producto: ObjectId("..."), nombre: "Cuaderno", precio: 4, cantidad: 1 }
  ]
}
```

La consulta más fácil con este diseño es mostrar un pedido completo: un solo documento, sin unir nada. La más difícil, calcular las ventas totales por categoría, porque la categoría no está en el pedido y hay que ir a buscarla a cada producto.

**Conclusión del ejemplo:** la parte de pedidos se beneficiaría de MongoDB, pero el catálogo (productos y categorías) y los clientes, con muchas relaciones y consultas por separado, siguen encajando mejor en tablas. Un diseño mixto es posible, pero obliga a mantener dos bases de datos, y para un proyecto de este tamaño probablemente no compense: la decisión final también depende del coste.

**Decisiones tomadas**

- Se copian el nombre y el precio del producto en la línea del pedido porque el pedido debe conservar lo que se pagó, aunque el producto cambie de precio después. Es el caso en que repetir un dato en el documento es una ventaja, no un defecto.
- Se mantiene la referencia al producto, y no solo su copia, porque hace falta saber de qué producto se trata para consultarlo o devolverlo.
- La conclusión no es "usar MongoDB" ni "no usarlo": es qué parte del dominio gana y cuál pierde, y qué cuesta combinarlas.
