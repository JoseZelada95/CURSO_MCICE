# S12-1 Prácticas

## Objetivos

Se aplica lo aprendido en las demos con un dominio nuevo: las notas. En la primera práctica se trabaja solo con `mongosh`, para manejar con soltura las operaciones básicas de MongoDB sin ningún framework. En la segunda se crea una API REST de notas con Spring Data MongoDB, sobre la misma colección que se creó a mano, con un método derivado del repositorio para buscar por texto. La tercera práctica no lleva código: cada grupo analiza las entidades de su proyecto y decide cuáles guardaría en un documento y cuáles dejaría en tablas.

Las dos primeras prácticas son acumulativas: la API de la segunda lee los documentos que se insertaron en la primera. Se necesita MongoDB en marcha, como se explica en la sección final de `s11-2-demos.md`.

---

## Práctica 1: Colección de notas con mongosh

Se crea la base de datos `notas` con la colección `notas`, se insertan documentos de forma distinta cada uno y se practican consultas con filtros, actualizaciones y borrados desde `mongosh`.

**Pasos**

1. Abrimos una terminal, escribimos `mongosh` y cambiamos a la base de datos `notas`.
2. Insertamos una nota con `titulo` y `texto`: `Comprar café`, con el texto `Café en grano para la oficina`.
3. Insertamos de una sola vez cuatro notas más, con estos datos. Fijémonos en que no todas tienen los mismos campos:
   - `Apuntes de MongoDB`, texto `MongoDB guarda documentos parecidos a un JSON`, importante.
   - `Reunión del grupo`, texto `Repasar el proyecto de Spring Boot`, importante, con las etiquetas `proyecto` y `reunión`.
   - `Lista de la compra`, texto `Pan, leche y café`, no importante.
   - `Ideas`, texto `Probar MongoDB Compass para ver los documentos`, sin el campo de importancia.
4. Mostramos todos los documentos y comprobamos que cada uno conserva los campos con los que se insertó.
5. Con filtros, mostramos: las notas importantes; las notas cuyo texto contiene la palabra `café` (con cualquier combinación de mayúsculas y minúsculas); y las notas importantes que tienen la etiqueta `proyecto`.
6. Mostramos solo el título de cada nota, sin el `_id`.
7. Marcamos como importante la nota `Ideas`.
8. Añadimos el campo de importancia, con valor falso, a todas las notas que todavía no lo tienen.
9. Borramos la nota `Lista de la compra` y contamos cuántas notas quedan.
10. Abrimos Compass, entramos en la colección `notas` y comprobamos que muestra las mismas notas. Filtramos allí las importantes.

**Pistas**

- `use notas` cambia a la base de datos; la base de datos se crea al guardar el primer documento.
- La colección se escribe tras `db.`: `db.notas.insertOne(...)`.
- `insertMany()` recibe una lista de documentos entre corchetes. Un documento es un par de llaves con los campos separados por comas: `{ campo: valor, otro: valor }`.
- Una lista dentro de un documento se escribe con corchetes: `etiquetas: ["proyecto", "reunión"]`.
- `find()` recibe el filtro como primer argumento y la proyección como segundo. En la proyección, `campo: 1` incluye el campo y `_id: 0` excluye el identificador.
- Para buscar una palabra dentro de un texto se puede usar una expresión regular en lugar de un valor: `/palabra/i`. La `i` final hace que no distinga mayúsculas de minúsculas.
- Se combinan dos condiciones escribiéndolas en el mismo documento del filtro.
- Para modificar solo un campo se usa `$set` dentro de la actualización. Sin `$set`, el documento entero se sustituye.
- Para filtrar por los documentos que no tienen un campo existe el operador `$exists`, con el valor `false`.
- Para modificar a la vez todos los documentos que cumplen el filtro hay un método `updateMany()`.
- Si se repite la práctica, se puede empezar de cero con `db.dropDatabase()`.

---

## Práctica 2: API de notas con Spring Data MongoDB

Se crea el proyecto `notas-api`, con la API REST completa de notas sobre la colección de la práctica anterior y con un método derivado del repositorio para buscar notas por una palabra de su texto.

**Pasos**

1. Creamos un proyecto nuevo con `File > New > Project` y, en el panel izquierdo, `Generators > Spring Boot`. Name `notas-api`, Type `Maven`, Language `Java`, Group `com.curso`, Artifact `notas-api`, Package name `com.curso`, JDK `21`, Java `21`, Packaging `Jar` y Configuration `Properties`. En la segunda pantalla dejamos Spring Boot `4.1.1` y marcamos `Spring Web`, `Spring Data MongoDB` y `Lombok`. Hacemos clic en `Create`.
2. Renombramos con `Shift+F6` las clases que genera el asistente: la principal pasa a llamarse `Aplicacion` y la de `src/test/java`, `AplicacionTests`.
3. Añadimos al `pom.xml` la dependencia de Swagger (`springdoc-openapi-starter-webmvc-ui`, versión `3.1.1`) y pulsamos **Load Maven Changes**.
4. Configuramos `application.properties`: nombre de la aplicación `notas-api` y conexión a la base de datos `notas` del servidor local.
5. Creamos los paquetes `com.curso.model`, `com.curso.repository` y `com.curso.controller`. En el primero escribimos el documento `Nota`, de la colección `notas`, con los campos `id`, `titulo`, `texto` e `importante`, y con Lombok para los getters, los setters y el constructor vacío. En el segundo, `NotaRepository`. En el tercero, `NotaController`, bajo la ruta `/api/notas`, con estas operaciones:
   - Listar todas las notas.
   - Listar las notas cuyo texto contiene una palabra indicada, sin distinguir mayúsculas, con un parámetro opcional de la URL llamado `texto`.
   - Obtener una nota por su id. Devuelve 404 si no existe.
   - Crear una nota. Devuelve 201 con la nota guardada, ya con su id.
   - Reemplazar una nota. Devuelve 404 si no existe.
   - Borrar una nota. Devuelve 204 si la borra y 404 si no existe.
6. Arrancamos la aplicación y, desde `http://localhost:8080/swagger-ui.html`, comprobamos que el listado devuelve las notas insertadas con `mongosh` en la práctica anterior, aunque no todas tengan los mismos campos.
7. Probamos la búsqueda por texto con `café`, con `CAFÉ` y con `mongo`, y con una palabra que no esté en ninguna nota. Anotamos qué devuelve cada una.
8. Creamos una nota nueva y comprobamos con `mongosh` o con Compass cómo se ha guardado. Anotamos qué campo ha añadido Spring Data a mayores de los de la clase.
9. Probamos las operaciones por id: obtener, reemplazar y borrar, con un id que existe y con uno que no.

**Pistas**

- En el generador, `Spring Data MongoDB` está dentro de la categoría `NoSQL`; `Spring Web`, en `Web`; `Lombok`, en `Developer Tools`.
- La propiedad de conexión es `spring.mongodb.uri`, y la dirección tiene la forma `mongodb://servidor:puerto/base-de-datos`. El puerto por defecto de MongoDB es 27017.
- La clase lleva `@Document(collection = "notas")`. El `@Id` es el de `org.springframework.data.annotation`, no el de `jakarta.persistence`.
- El `id` es de tipo `String`, y también el parámetro `@PathVariable` de las rutas.
- El nombre del método derivado para buscar por texto sigue el patrón de S10 (`findBy` + campo + `Containing` + `IgnoreCase`).
- Para que un parámetro de la URL sea opcional, `@RequestParam` tiene el atributo `required`.
- Si un documento de la colección no tiene un campo de la clase, al leerlo ese campo toma su valor por defecto (`false` en un `boolean`).
- En `PUT`, el `id` de la ruta es el que debe quedar en el documento guardado; en `POST`, el `id` debe ser `null` antes de guardar.
- Si la primera petición tarda unos treinta segundos y termina en 500, el servidor de MongoDB no está en marcha.

---

## Práctica 3: Relacional o documental en el proyecto del grupo

Cada grupo analiza las entidades de su proyecto y decide cuáles guardaría en un documento con datos incrustados y cuáles dejaría en tablas, justificando la decisión. Esta práctica no lleva código: el resultado es un documento corto (una página) que cada grupo comparte con el resto.

**Pasos**

1. Hacemos una lista de las entidades del proyecto del grupo, con los datos principales de cada una y con las relaciones que tienen entre ellas.
2. Para cada relación entre dos entidades, respondemos a tres preguntas: ¿los datos de una se leen casi siempre junto con los de la otra?; ¿los datos de la entidad relacionada se consultan o se modifican también por separado?; ¿cuántas entidades distintas se relacionan con ella?
3. Con las respuestas, decidimos para cada entidad si iría en una colección (y qué datos de otras entidades llevaría incrustados) o en tablas. Indicamos qué datos se repetirían en varios documentos y qué ocurriría al modificarlos.
4. Dibujamos, para una entidad que se guardaría como documento, un ejemplo del documento que resultaría, con sus datos incrustados, escrito con la sintaxis de `mongosh`.
5. Señalamos qué consulta de la aplicación sería más sencilla con el diseño documental y cuál sería más difícil.
6. Escribimos una conclusión: si el proyecto, tal como está, se beneficiaría de MongoDB, y por qué sí o por qué no.

**Pistas**

- Un dato se incrusta cuando se lee casi siempre junto con el documento que lo contiene y cuando pertenece a un solo documento (el caso de las etiquetas de una tarea).
- Un dato se deja en su propia tabla o colección cuando varios documentos lo comparten, se consulta por separado o cambia con frecuencia.
- Que la aplicación necesite listar las entidades relacionadas por separado, o contarlas o agruparlas, es una señal de que tienen que ser independientes.
- No hay una única respuesta correcta: lo que se valora es que la decisión se justifique con las respuestas del paso 2.
- Mantener un dato repetido en muchos documentos es un coste del diseño documental. Conviene preguntarse con qué frecuencia cambiaría.
