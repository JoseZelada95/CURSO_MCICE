# Cuestionario tipo test · IFCD0014 (S01–S12)

**Curso:** IFCD0014 – Desarrollo de Aplicaciones con Spring e Hibernate (26/2138)
**Nivel:** fácil · **Preguntas:** 30, en el orden en que se imparte el temario · **Formato:** 4 opciones, solo una correcta, con explicación de la correcta y de cada incorrecta.

Al final hay una tabla con las respuestas.

---

## S01 · Entorno de desarrollo

### Pregunta 1 (S01 · JDK)

¿Qué contiene el JDK (Java Development Kit)?

**A)** Solo la máquina virtual de Java, para ejecutar programas que ya están compilados.

**B)** El compilador, que transforma el código en un formato ejecutable, y la máquina virtual de Java, que lo ejecuta.

**C)** Un editor de texto y un navegador web para probar los programas.

**D)** Las herramientas Git y Maven, para guardar versiones y descargar librerías.

**Respuesta correcta: B.**

**B (correcta):** el JDK es el «kit de desarrollo» de Java. Incluye `javac`, el compilador que convierte los ficheros `.java` (el código que escribimos) en ficheros `.class` (el bytecode, que es el formato que entiende la máquina virtual), y `java`, la máquina virtual que ejecuta ese resultado. Por eso, para programar, se comprueba tanto `java -version` como `javac -version`.

**A:** describe un *runtime*, que solo ejecuta. Un runtime no trae compilador, así que con él no se puede compilar el código propio.

**C:** el JDK no trae editor ni navegador. El código se escribe con un editor o un IDE (en el curso, IntelliJ).

**D:** Git y Maven son programas distintos que se instalan aparte. Git guarda el historial de un proyecto y Maven organiza el proyecto y descarga librerías.

---

### Pregunta 2 (S01 · Git y GitHub)

¿Cuál es la diferencia entre Git y GitHub?

**A)** Son dos nombres del mismo programa: GitHub es la versión de Git para Windows.

**B)** Git es un servicio en Internet y GitHub es el programa que se instala en el ordenador.

**C)** Git solo funciona si hay conexión a Internet, porque guarda los datos en GitHub.

**D)** Git es un sistema de control de versiones que funciona en el propio ordenador; GitHub es un servicio en Internet que aloja repositorios de Git.

**Respuesta correcta: D.**

**D (correcta):** Git es el programa que guarda el historial de cambios de un proyecto (cada punto guardado es un *commit*) y permite volver a un estado anterior. Funciona en local, sin Internet. GitHub es una web donde se pueden subir esos repositorios para compartirlos y tener una copia en la nube.

**A:** no son lo mismo. La versión de Git para Windows se llama *Git for Windows* y trae, además, una terminal llamada Git Bash.

**B:** está invertida. Git es el programa y GitHub es el servicio.

**C:** es una confusión muy habitual. Se puede hacer `git commit` sin conexión. Solo hace falta Internet para subir (`push`) o bajar (`pull`, `clone`) cambios de GitHub.

---

## S02 · Maven y primeros tests

### Pregunta 3 (S02 · Maven)

¿Para qué sirve principalmente Maven en un proyecto Java?

**A)** Para organizar el proyecto, descargar las librerías que necesita y automatizar tareas como compilar y empaquetar.

**B)** Para escribir el código Java de forma automática a partir de una descripción.

**C)** Para diseñar la pantalla y los botones de la aplicación.

**D)** Para almacenar los datos de los usuarios de la aplicación.

**Respuesta correcta: A.**

**A (correcta):** Maven es una herramienta de construcción (*build*). Lee el fichero `pom.xml`, donde se anotan los datos del proyecto y sus librerías (dependencias), y con eso las descarga de Internet, compila el código y genera el fichero `.jar` final.

**B:** Maven no escribe código. Lo escribe el programador.

**C:** el diseño de pantallas no es cosa de Maven. En el curso, de eso se encarga Thymeleaf más adelante.

**D:** los datos se guardan en una base de datos (H2 y después PostgreSQL en el curso). Maven trabaja con el proyecto, no con los datos de los usuarios.

---

### Pregunta 4 (S02 · JUnit)

En un test con JUnit, ¿qué hace `assertEquals(esperado, real)`?

**A)** Ejecuta el programa completo y muestra el resultado por pantalla.

**B)** Borra el resultado anterior del test para empezar de cero.

**C)** Compara el valor esperado con el real y hace fallar el test si no coinciden.

**D)** Comprueba que el código compila sin errores.

**Respuesta correcta: C.**

**C (correcta):** un test es un método que comprueba que otro código funciona como se espera. `assertEquals` (del inglés, «afirmar que es igual») recibe primero el valor que debería salir y después el que sale de verdad. Si son distintos, el test falla y JUnit lo marca en rojo.

**A:** `assertEquals` no ejecuta el programa entero ni imprime nada. Solo compara dos valores.

**B:** no borra nada. Cada test se ejecuta de forma independiente.

**D:** que el código compile lo comprueba el compilador antes de ejecutar ningún test. Si no compila, los tests ni llegan a ejecutarse.

---

## S03 · Dependencias y ciclo de vida de Maven

### Pregunta 5 (S03 · Dependencia transitiva)

¿Qué es una dependencia transitiva?

**A)** Una dependencia que solo se puede usar durante los tests.

**B)** Una dependencia que otra dependencia trae «por debajo»: no la hemos escrito en nuestro `pom.xml`, pero Maven la descarga igualmente.

**C)** Una dependencia que Maven descarga cada vez que se ejecuta un build, sin guardarla en ningún sitio.

**D)** Una dependencia con una versión provisional, que todavía está en desarrollo.

**Respuesta correcta: B.**

**B (correcta):** una librería puede necesitar a su vez otras librerías. Maven las detecta y las descarga sin que tengamos que declararlas. Se pueden ver con el comando `mvn dependency:tree`: las líneas con más sangría debajo de una dependencia son sus transitivas. Por ejemplo, la dependencia `spring-context` trae por debajo otras ocho librerías.

**A:** eso describe el *scope* `test`, que hace que una dependencia solo esté disponible en `src/test/java`. Nada que ver con la transitividad.

**C:** Maven guarda lo que descarga en una caché local (la carpeta `~/.m2`), así que no lo vuelve a descargar cada vez.

**D:** una versión en desarrollo se llama `SNAPSHOT`. Es otro concepto distinto.

---

### Pregunta 6 (S03 · Ciclo de vida)

¿Qué ocurre al ejecutar `mvn package`?

**A)** Maven compila el código, ejecuta los tests y genera el JAR en la carpeta `target`.

**B)** Maven genera el JAR directamente, sin compilar ni ejecutar tests.

**C)** Maven sube el proyecto a Maven Central para que lo use todo el mundo.

**D)** Maven borra la carpeta `target` y deja el proyecto sin compilar.

**Respuesta correcta: A.**

**A (correcta):** el ciclo de vida de Maven es una secuencia de fases (`compile`, `test`, `package`…) y cada fase ejecuta antes las anteriores. Por eso `package` incluye compilar y ejecutar los tests, y al final deja el `.jar` en `target/`.

**B:** no se salta nada. Si se quiere construir el JAR sin ejecutar tests, hay que añadir `-DskipTests`.

**C:** subir un artefacto a un repositorio remoto lo hace la fase `deploy`, no `package`. Y se sube al repositorio configurado, no a Maven Central sin más.

**D:** borrar `target` lo hace `mvn clean`. Se suele combinar así: `mvn clean package`.

---

## S04 · Perfiles y proyectos multi-módulo

### Pregunta 7 (S04 · Perfil de Maven)

¿Qué es un perfil de Maven?

**A)** Un usuario de Maven con su nombre y su contraseña.

**B)** La carpeta donde Maven guarda las librerías descargadas.

**C)** Un fichero aparte que sustituye al `pom.xml` del proyecto.

**D)** Un bloque de configuración adicional dentro del `pom.xml` que solo se aplica cuando se activa, por ejemplo con `-Pdev`.

**Respuesta correcta: D.**

**D (correcta):** un perfil tiene un identificador (`id`) y se ignora mientras no esté activo. Al activarlo con `-P<id>`, sus valores (por ejemplo, propiedades) tienen prioridad sobre los del resto del `pom.xml`. Sirve para tener configuraciones distintas, como desarrollo y producción, en un mismo proyecto.

**A:** las credenciales de Maven se guardan en el fichero `settings.xml`, en una sección distinta (`<servers>`). No se llaman perfiles.

**B:** esa carpeta es el repositorio local, `~/.m2`.

**C:** el perfil va dentro del propio `pom.xml`, en el bloque `<profiles>`. No es un fichero aparte ni lo sustituye.

---

### Pregunta 8 (S04 · POM padre)

En un proyecto Maven multi-módulo, ¿para qué sirve el POM padre?

**A)** Para contener todo el código de la aplicación, mientras que los módulos solo tienen los tests.

**B)** Para sustituir a Maven Central cuando no hay conexión.

**C)** Para agrupar los módulos y compartir con ellos configuración heredada; el padre no compila código propio.

**D)** Para que cada módulo se construya por separado, sin relación con los demás.

**Respuesta correcta: C.**

**C (correcta):** un proyecto multi-módulo es un proyecto grande dividido en proyectos Maven más pequeños, llamados módulos. El padre los agrupa (con `<packaging>pom</packaging>` y una lista `<modules>`) y los módulos hijos heredan de él propiedades y dependencias, sin tener que repetirlas.

**A:** al revés. El padre no tiene código propio; el código está en los módulos.

**B:** el padre no tiene nada que ver con el repositorio de librerías.

**D:** justo lo contrario: un solo comando lanzado desde el padre construye todos los módulos juntos, en el orden que exigen sus dependencias.

---

### Pregunta 9 (S04 · `mvn install`)

¿Para qué sirve la fase `install` de Maven?

**A)** Para instalar Maven en el ordenador.

**B)** Para copiar el artefacto generado (el JAR y el POM) al repositorio local `~/.m2`, de modo que otros proyectos o módulos de la misma máquina puedan usarlo como dependencia.

**C)** Para subir el artefacto a un repositorio de la empresa en Internet.

**D)** Para instalar las librerías que faltan en la carpeta `src`.

**Respuesta correcta: B.**

**B (correcta):** `install` va después de `package`. Es la fase que hace posible un proyecto multi-módulo: para que un módulo (`app`) use a otro (`core`) como dependencia, Maven tiene que encontrar el artefacto de `core` en `~/.m2`, y solo `mvn install` lo deja ahí.

**A:** instalar Maven es otra cosa, que se hace una sola vez al preparar el entorno.

**C:** subir a un repositorio remoto es la fase `deploy`, que va después de `install`.

**D:** las librerías no se guardan en `src` (que contiene el código del proyecto), sino en `~/.m2`.

---

## S05 · Spring y Spring Boot

### Pregunta 10 (S05 · Inversión de control)

¿Qué significa «inversión de control» (IoC) en Spring?

**A)** Que las clases se ejecutan en orden inverso al de su declaración.

**B)** Que el programador escribe todos los `new` en una única clase de configuración.

**C)** Que el controlador pasa a controlar la base de datos en lugar del repositorio.

**D)** Que el contenedor de Spring crea los objetos, los guarda y se los entrega a quien los necesita, en lugar de que cada clase los cree con `new`.

**Respuesta correcta: D.**

**D (correcta):** normalmente cada clase crea con `new` los objetos que necesita. Con IoC, el control de esa creación pasa del código propio al framework: Spring crea los objetos una vez, los guarda en su contenedor (una especie de almacén) y se los entrega a quien los pide.

**A:** IoC no tiene que ver con el orden de ejecución.

**B:** es una de las formas de declarar objetos para Spring (`@Configuration` con `@Bean`), pero ahí el `new` sigue escribiéndolo el programador. IoC trata de quién crea y entrega los objetos.

**C:** confunde IoC con el patrón MVC. Un controlador recibe peticiones, pero no controla la base de datos.

---

### Pregunta 11 (S05 · Bean)

En Spring, ¿qué es un *bean*?

**A)** Un objeto corriente de Java que crea y guarda Spring en su contenedor, en lugar de crearlo el programador con `new`.

**B)** Un fichero de texto donde se escribe la configuración de la aplicación.

**C)** Un tipo especial de base de datos que incluye Spring.

**D)** Una anotación que se escribe encima de las clases.

**Respuesta correcta: A.**

**A (correcta):** un objeto es una «copia viva» de una clase, con la que trabaja el programa. Si lo crea Spring y lo guarda en su contenedor, ese objeto se llama *bean*.

**B:** la configuración sencilla se escribe en `application.properties`. Un bean es un objeto, no un fichero.

**C:** Spring no incluye ninguna base de datos propia. En el curso se usa H2 y después PostgreSQL.

**D:** una anotación es una etiqueta que empieza por `@` (por ejemplo, `@Component`). Sirve para indicar a Spring qué clases debe convertir en beans, pero ella no es el bean.

---

### Pregunta 12 (S05 · Spring Boot)

¿Qué relación hay entre Spring Boot y Spring?

**A)** Spring Boot es un competidor de Spring: se usa uno u otro, pero nunca los dos.

**B)** Spring Boot es una base de datos que se usa junto con Spring.

**C)** Spring Boot lleva Spring por dentro (mismo contenedor, mismos beans, mismas anotaciones) y lo prepara todo: arranque en una línea, starters, autoconfiguración y JAR ejecutable.

**D)** Spring Boot es una versión antigua de Spring que ya no se usa.

**Respuesta correcta: C.**

**C (correcta):** Spring Boot no sustituye a Spring, lo incluye y se encarga de la preparación. Es como un piso amueblado y con suministros frente a uno vacío: lo que se vio de Spring sigue valiendo. Un *starter* es una dependencia única que arrastra todas las librerías necesarias para una tarea, y la autoconfiguración configura sola lo que detecta en el proyecto.

**A:** no compiten. Spring Boot está construido sobre Spring.

**B:** Spring Boot no es una base de datos. Es un conjunto de herramientas para arrancar y configurar aplicaciones Spring.

**D:** al contrario, es lo que más se usa hoy en la práctica profesional.

---

## S06 · Hibernate, MVC y Thymeleaf

### Pregunta 13 (S06 · `@Entity`)

Al marcar una clase Java con `@Entity`, ¿a qué corresponde cada elemento en la base de datos?

**A)** La clase es una fila, cada campo es una tabla y cada objeto es una columna.

**B)** La clase es una columna, cada campo es una fila y cada objeto es una tabla.

**C)** La clase es una base de datos completa, cada campo es una fila y cada objeto es una tabla.

**D)** La clase es una tabla, cada campo es una columna y cada objeto es una fila.

**Respuesta correcta: D.**

**D (correcta):** una tabla es como una hoja de cálculo: tiene columnas con nombre (por ejemplo, `titulo` o `autor`) y cada fila es un elemento concreto (un libro). Hibernate convierte objetos en filas y filas en objetos; a esto se le llama mapeo objeto-relacional. Por eso la clase `Libro` es la tabla, sus campos son las columnas y cada objeto `Libro` es una fila.

**A:** invierte los papeles. Una fila es un elemento concreto (un objeto), no la plantilla completa, que es la clase.

**B:** una columna es un dato de una tabla (un campo), no una clase entera, y una tabla agrupa muchas filas.

**C:** una base de datos contiene varias tablas. Una clase corresponde a una tabla, no a toda la base de datos.

---

### Pregunta 14 (S06 · MVC)

En el patrón MVC (modelo, vista, controlador), ¿qué papel tiene el controlador?

**A)** Recibe la petición del usuario, pide los datos que hagan falta y se los pasa a la vista.

**B)** Es la plantilla HTML que ve el usuario en el navegador.

**C)** Es la clase que representa los datos, como `Libro`.

**D)** Es la base de datos donde se guardan los datos.

**Respuesta correcta: A.**

**A (correcta):** MVC reparte el trabajo en tres roles para que cada clase se dedique a una sola cosa. Con la analogía de la biblioteca, el controlador es el bibliotecario: atiende la petición, busca los libros en el almacén (el repositorio) y los deja listos para el expositor (la vista).

**B:** eso es la vista, la plantilla que muestra los datos (en el curso, un fichero de Thymeleaf).

**C:** eso es el modelo, la clase con los datos.

**D:** la base de datos no es uno de los tres roles de MVC. A ella se accede a través del repositorio.

---

### Pregunta 15 (S06 · Thymeleaf)

¿Qué es Thymeleaf?

**A)** Un servidor web escrito en Java, como Tomcat.

**B)** Un motor de plantillas: un HTML con huecos que el servidor rellena con datos antes de enviarlo al navegador.

**C)** Una librería que genera el SQL para hablar con la base de datos.

**D)** Un programa para descargar las librerías de un proyecto.

**Respuesta correcta: B.**

**B (correcta):** funciona como la combinación de correspondencia de un procesador de textos: una plantilla con huecos y unos datos que los rellenan. Los atributos que empiezan por `th:` (por ejemplo, `th:text`) los procesa el servidor, y al navegador le llega HTML normal.

**A:** el servidor web es Tomcat, que en Spring Boot viaja dentro de la aplicación (embebido). Thymeleaf trabaja dentro de él, pero no es un servidor.

**C:** eso lo hace Hibernate, que genera el SQL y lo envía por JDBC.

**D:** descargar librerías es tarea de Maven.

---

## S07 · PostgreSQL y relaciones

### Pregunta 16 (S07 · Variable de entorno)

¿Por qué la contraseña de la base de datos se lee de una variable de entorno (`${POSTGRES_PASSWORD}`) y no se escribe en `application.properties`?

**A)** Porque Spring Boot no permite escribir contraseñas en `application.properties`.

**B)** Porque así la base de datos funciona más rápido.

**C)** Porque `application.properties` se versiona y se comparte (por ejemplo, en un repositorio o en un zip), y una contraseña no debe viajar con el código.

**D)** Porque PostgreSQL solo acepta contraseñas que vengan de variables de entorno.

**Respuesta correcta: C.**

**C (correcta):** una variable de entorno es un valor con nombre que el sistema operativo entrega al programa al arrancar, como un sobre cerrado. Los ficheros del proyecto se suben a repositorios y se reparten, así que cualquier secreto escrito en ellos quedaría expuesto. Con la variable, cada persona define la suya en su equipo.

**A:** técnicamente se puede escribir, pero es una mala práctica por la razón anterior.

**B:** la velocidad no cambia. Es una decisión de seguridad.

**D:** PostgreSQL no sabe de dónde saca Spring la contraseña. Solo recibe una contraseña al conectar.

---

### Pregunta 17 (S07 · Clave foránea)

¿Qué es una clave foránea en una base de datos?

**A)** Una columna cuyos valores solo pueden ser los de la clave primaria de otra tabla, lo que impide referenciar filas que no existen.

**B)** Una contraseña que protege el acceso a una tabla.

**C)** Una columna que genera sola un número distinto para cada fila.

**D)** Una copia de seguridad de una tabla en otra base de datos.

**Respuesta correcta: A.**

**A (correcta):** por ejemplo, `clase.monitor_id` solo puede contener el `id` de un monitor que exista en la tabla `monitor`. Así la base de datos evita filas «huérfanas», es decir, una clase que apunte a un monitor inexistente.

**B:** una contraseña no tiene relación con las claves foráneas. Es el usuario de la base de datos quien tiene contraseña.

**C:** eso describe la clave primaria autogenerada (`generated by default as identity`), que da un número distinto a cada fila.

**D:** una copia de seguridad es otra cosa. La clave foránea es una restricción que se declara dentro de la tabla.

---

### Pregunta 18 (S07 · PostgreSQL frente a H2)

¿Qué diferencia principal hay entre usar PostgreSQL y usar la base de datos H2 en memoria de S06?

**A)** Con PostgreSQL no se pueden usar entidades de Hibernate.

**B)** Con PostgreSQL no hace falta ninguna URL de conexión.

**C)** PostgreSQL funciona dentro del propio programa, como una librería, y no hay que instalar nada.

**D)** Con PostgreSQL los datos permanecen entre ejecuciones: no se borran al parar la aplicación.

**Respuesta correcta: D.**

**D (correcta):** PostgreSQL es un servidor de base de datos que corre como programa aparte y siempre está en marcha, así que lo que se guarda se queda guardado. H2 en memoria funcionaba como una pizarra: se borraba al apagar la aplicación y cada arranque empezaba en blanco.

**A:** sí se pueden usar entidades; son las mismas, ahora sobre tablas reales.

**B:** sí hace falta: la URL JDBC (`jdbc:postgresql://localhost:5432/...`) indica dónde está el servidor.

**C:** eso describe H2, que se ejecuta dentro del programa. PostgreSQL se instala una vez como servidor independiente.

---

## S08 · Relaciones en JPA

### Pregunta 19 (S08 · Lado propietario)

En una relación entre dos entidades, ¿cuál es el «lado propietario»?

**A)** La clase que tiene la lista de objetos relacionados.

**B)** La clase cuya tabla contiene la columna de la clave foránea: es la que escribe esa columna.

**C)** La clase que se ha creado primero en el proyecto.

**D)** La clase que lleva `mappedBy`.

**Respuesta correcta: B.**

**B (correcta):** la columna de la clave foránea está en una sola de las dos tablas, y la clase de esa tabla es la propietaria. Por ejemplo, `Clase` (con `@ManyToOne` y su campo `monitor`) es la propietaria, porque la tabla `clase` tiene la columna `monitor_id`.

**A:** la lista es el lado inverso: un reflejo de la misma clave foránea desde el otro extremo, que no añade ninguna columna.

**C:** el orden de creación no influye. Solo importa dónde está la columna.

**D:** `mappedBy` se escribe justo en el lado inverso, para decir qué campo del lado propietario define la relación.

---

### Pregunta 20 (S08 · Carga diferida)

¿Qué significa que una relación tiene carga diferida (`LAZY`)?

**A)** Que Hibernate no carga nunca los objetos relacionados.

**B)** Que Hibernate lee los objetos relacionados al mismo tiempo que el objeto principal.

**C)** Que Hibernate no lee los objetos relacionados hasta que se usan por primera vez.

**D)** Que la relación se borra automáticamente después de un tiempo.

**Respuesta correcta: C.**

**C (correcta):** con `LAZY` los datos relacionados se leen solo cuando alguien los pide. Así se evita leer lo que quizá no se use. Por defecto, un `@OneToMany` es `LAZY`. Ese «cuando alguien los pide» necesita que la sesión de Hibernate (la conexión de trabajo) siga abierta; si ya se cerró, aparece `LazyInitializationException`.

**A:** sí se cargan, pero más tarde, al usarlos.

**B:** eso es la carga inmediata (`EAGER`), que es el valor por defecto de `@ManyToOne`.

**D:** la carga diferida no borra nada. Solo controla cuándo se leen los datos.

---

## S09 · API REST

### Pregunta 21 (S09 · Verbos HTTP)

En una API REST, ¿qué verbo HTTP se usa normalmente para **crear** un recurso nuevo?

**A)** GET

**B)** DELETE

**C)** PUT

**D)** POST

**Respuesta correcta: D.**

**D (correcta):** el verbo de la petición indica qué se quiere hacer. `POST` crea un recurso nuevo (por ejemplo, un producto).

**A:** `GET` sirve para leer. Es el que envía el navegador al escribir una dirección.

**B:** `DELETE` sirve para borrar.

**C:** `PUT` sirve para actualizar un recurso que ya existe, sustituyendo sus datos.

---

### Pregunta 22 (S09 · Códigos de estado)

Una petición `POST` crea un producto correctamente. ¿Qué código de estado HTTP es el adecuado para la respuesta?

**A)** 201 Created

**B)** 404 Not Found

**C)** 500 Internal Server Error

**D)** 204 No Content

**Respuesta correcta: A.**

**A (correcta):** los códigos de estado son números que resumen qué ha pasado, antes de leer el cuerpo de la respuesta. `201 Created` significa «se ha creado».

**B:** `404` significa que el recurso de la ruta no existe, por ejemplo, `/api/productos/999` con un id que no está.

**C:** `500` indica un error interno del servidor. No es lo que ocurre si todo ha ido bien.

**D:** `204 No Content` significa «hecho, y no hay nada que devolver». Se usa al borrar, no al crear.

---

## S10 · API REST con relaciones

### Pregunta 23 (S10 · `@JsonIgnore`)

¿Qué hace la anotación `@JsonIgnore` en un campo de una entidad, como la lista `Monitor.clases`?

**A)** Elimina la relación de la base de datos.

**B)** Hace que el campo se guarde de forma cifrada.

**C)** Hace que el campo no se escriba en el JSON ni se lea de él.

**D)** Hace que Hibernate ignore el campo al guardar en la base de datos.

**Respuesta correcta: C.**

**C (correcta):** JSON es el formato de texto con el que la API envía los datos, y Jackson es la librería que convierte los objetos Java a JSON. Con `@JsonIgnore`, Jackson se salta ese campo. Se pone en la lista del lado inverso para evitar el fallo `LazyInitializationException` (la lista no está cargada) o un bucle infinito (clase → monitor → clases → monitor…).

**A:** no toca la base de datos ni la relación JPA. Solo afecta a la conversión a JSON.

**B:** no cifra nada.

**D:** esa decisión es de JPA. `@JsonIgnore` es de Jackson y no cambia lo que Hibernate guarda.

---

### Pregunta 24 (S10 · `@RequestParam`)

En la dirección `/api/clases/buscar?nombre=yoga`, ¿cómo se lee el valor `yoga` en el controlador?

**A)** Con `@PathVariable`, porque forma parte de la ruta.

**B)** Con `@RequestParam`, porque es un parámetro de consulta (lo que va detrás del `?`).

**C)** Con `@RestController`, porque devuelve datos.

**D)** Con `@Valid`, porque comprueba el dato.

**Respuesta correcta: B.**

**B (correcta):** `@RequestParam` lee los parámetros que van tras el `?` de la dirección. No forman parte de la ruta, sirven para filtrar y se pueden combinar varios.

**A:** `@PathVariable` lee un trozo variable de la propia ruta, como el `{id}` de `/api/clases/{id}`.

**C:** `@RestController` marca la clase para que devuelva datos (JSON) en lugar de plantillas. No lee parámetros.

**D:** `@Valid` pide comprobar las reglas de validación de un objeto, pero no lee valores de la dirección.

---

## S11 · Git en equipo, Swagger y validación

### Pregunta 25 (S11 · Área de preparación)

En Git, ¿qué hace el comando `git add`?

**A)** Coloca los ficheros en el área de preparación (*staging*), es decir, lo que irá en el próximo commit.

**B)** Guarda la versión definitiva en el historial.

**C)** Sube los cambios a GitHub.

**D)** Descarga los cambios de otras personas.

**Respuesta correcta: A.**

**A (correcta):** el área de preparación es una zona intermedia donde se eligen qué cambios entrarán en el siguiente commit. Es como colocar a la gente antes de hacer la foto.

**B:** guardar la instantánea en el historial lo hace `git commit` (la «foto»).

**C:** subir a GitHub lo hace `git push`.

**D:** descargar cambios de otras personas lo hace `git pull`.

---

### Pregunta 26 (S11 · Swagger UI)

¿Qué es Swagger UI en una aplicación Spring Boot con springdoc?

**A)** Una base de datos para guardar las peticiones que recibe la API.

**B)** Un lenguaje de programación para escribir controladores.

**C)** Un sustituto de Spring Boot que arranca la aplicación más rápido.

**D)** Una página web interactiva, generada a partir de los controladores, que muestra los endpoints de la API y permite probarlos.

**Respuesta correcta: D.**

**D (correcta):** springdoc es la librería que lee los controladores al arrancar y genera una descripción de la API siguiendo el estándar OpenAPI. Swagger UI es la página web (`/swagger-ui.html`) que lee esa descripción y la muestra de forma interactiva. Como se genera al arrancar, la documentación no se queda anticuada.

**A:** no guarda nada. Solo muestra y permite probar la API.

**B:** no es un lenguaje. Los controladores se siguen escribiendo en Java.

**C:** no sustituye a nada. Se añade como una dependencia más.

---

### Pregunta 27 (S11 · `@Valid`)

En un controlador, ¿para qué sirve poner `@Valid` en el parámetro `@RequestBody`?

**A)** Para que Spring guarde el objeto en la base de datos.

**B)** Para que Spring compruebe las reglas de validación (como `@NotBlank`) antes de ejecutar el método, y devuelva un 400 si no se cumplen.

**C)** Para que el método se ejecute dos veces y así asegurarse de que funciona.

**D)** Para que la respuesta se devuelva en formato JSON.

**Respuesta correcta: B.**

**B (correcta):** las anotaciones como `@NotBlank` o `@Size` de la clase, por sí solas, no comprueban nada. `@Valid` en el parámetro es lo que le pide a Spring que las compruebe. Si falla alguna regla, el método no llega a ejecutarse y la respuesta es un 400 (el cliente envió algo incorrecto), en lugar de un 500 por un fallo de la base de datos.

**A:** guardar en la base de datos lo hace el repositorio con `save()`, no `@Valid`.

**C:** el método se ejecuta una sola vez, y solo si los datos son válidos.

**D:** la conversión a JSON la hace Jackson cuando la clase es un `@RestController`. No depende de `@Valid`.

---

## S12 · MongoDB

### Pregunta 28 (S12 · Colección y documento)

En MongoDB, ¿a qué equivalen aproximadamente una *colección* y un *documento* en una base de datos relacional?

**A)** Colección ≈ fila; documento ≈ columna.

**B)** Colección ≈ base de datos; documento ≈ servidor.

**C)** Colección ≈ tabla (pero sin columnas definidas de antemano); documento ≈ fila.

**D)** Colección ≈ clave foránea; documento ≈ restricción.

**Respuesta correcta: C.**

**C (correcta):** MongoDB guarda documentos (estructuras parecidas a un JSON) dentro de colecciones. Cada documento puede tener campos distintos de los demás de su colección, y no hay un `CREATE TABLE`: la colección se crea al guardar el primer documento.

**A:** invierte los papeles. Una fila corresponde a un documento, no a una colección.

**B:** una base de datos de MongoDB contiene varias colecciones. El servidor es el programa que aloja las bases de datos.

**D:** las claves foráneas y las restricciones son mecanismos del modelo relacional. MongoDB no comprueba esas relaciones por su cuenta.

---

### Pregunta 29 (S12 · `_id`)

¿Qué es el campo `_id` de un documento de MongoDB?

**A)** El identificador único del documento, equivalente a la clave primaria. Si no se indica, MongoDB genera un `ObjectId`.

**B)** Un número entero que aumenta de uno en uno, como la clave primaria autogenerada de PostgreSQL.

**C)** Un campo opcional que se usa solo para ordenar los documentos.

**D)** La contraseña del documento.

**Respuesta correcta: A.**

**A (correcta):** todo documento lleva un `_id` que lo identifica. Si no se lo damos, MongoDB genera un `ObjectId`, un valor de 24 caracteres hexadecimales.

**B:** no es un entero autoincremental. El `ObjectId` es una cadena larga generada por MongoDB.

**C:** no es opcional (siempre existe) y no sirve para ordenar, sino para identificar.

**D:** no es una contraseña. MongoDB protege el acceso por otros medios, no mediante este campo.

---

### Pregunta 30 (S12 · `@Document`)

En Spring Data MongoDB, ¿qué anotación se pone sobre una clase para indicar que se guarda en una colección de MongoDB, en lugar de `@Entity`?

**A)** `@Entity` también, porque sirve para cualquier base de datos.

**B)** `@Table`

**C)** `@Component`

**D)** `@Document`

**Respuesta correcta: D.**

**D (correcta):** `@Document(collection = "tareas")` marca la clase como un documento de MongoDB, guardado en la colección indicada. El repositorio pasa a ser `MongoRepository<Tarea, String>`, con los mismos métodos que `JpaRepository`, y el `id` es un `String` porque MongoDB genera un `ObjectId`.

**A:** `@Entity` es de JPA y Hibernate, y solo sirve para bases de datos relacionales.

**B:** `@Table` también es de JPA: sirve para dar a una entidad el nombre de una tabla de la base de datos relacional.

**C:** `@Component` convierte una clase en un bean de Spring, pero no dice nada sobre MongoDB.

---

## Tabla de respuestas

| Nº | Sesión | Resp. | Nº | Sesión | Resp. | Nº | Sesión | Resp. |
|---|---|---|---|---|---|---|---|---|
| 1 | S01 | B | 11 | S05 | A | 21 | S09 | D |
| 2 | S01 | D | 12 | S05 | C | 22 | S09 | A |
| 3 | S02 | A | 13 | S06 | D | 23 | S10 | C |
| 4 | S02 | C | 14 | S06 | A | 24 | S10 | B |
| 5 | S03 | B | 15 | S06 | B | 25 | S11 | A |
| 6 | S03 | A | 16 | S07 | C | 26 | S11 | D |
| 7 | S04 | D | 17 | S07 | A | 27 | S11 | B |
| 8 | S04 | C | 18 | S07 | D | 28 | S12 | C |
| 9 | S04 | B | 19 | S08 | B | 29 | S12 | A |
| 10 | S05 | D | 20 | S08 | C | 30 | S12 | D |
