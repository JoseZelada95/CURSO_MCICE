# S05-1 Prácticas

## Objetivos

Se aplica lo aprendido en las demos y se preparan las dos cosas que el resto del módulo necesita: el proyecto propio de cada grupo y la base de datos en la nube de cada alumno. La Práctica 1 consolida el ciclo completo de Spring a secas: marcar una clase como bean, arrancar el contenedor y pedirle el bean. La Práctica 2 no lleva código: cada grupo decide qué aplicación va a construir durante las sesiones siguientes, y lo hace ahora, cuando ya se entiende qué es un bean. La Práctica 3 tampoco lleva código: cada alumno crea su propia cuenta en Supabase, el servicio de base de datos en la nube que se usará a partir de la parte siguiente, y comprueba que se puede llegar a ella desde el aula.

---

## Práctica 1: Bean de saludo

Se crea un proyecto Maven nuevo con Spring y se escribe un bean que da la bienvenida al curso. Es el mismo ciclo que en la Demo 1, pero escrito de principio a fin sin copiar nada: anotar la clase, crear el contenedor, pedir el bean y usarlo.

**Pasos**

1. Creamos un nuevo proyecto Maven en IntelliJ desde `File > New > Project`, con `Java` seleccionado en el panel izquierdo: Name `s05-1-practica1`, Build system `Maven`, JDK `21` y **Add sample code** desmarcada. En `Advanced Settings`, usamos `com.curso` como GroupId y `s05-1-practica1` como ArtifactId.
2. Añadimos al `pom.xml` la dependencia `spring-context` en la versión `7.0.9`, igual que en la Demo 1, y pulsamos `Load Maven Changes`. Comprobamos en `External Libraries` que aparece `spring-context`.
3. Creamos el paquete `com.curso.practica1`: clic derecho sobre `src/main/java`, `New > Package`, escribimos `com.curso.practica1` y pulsamos Enter.
4. Creamos la clase `BienvenidaCurso` en ese paquete y la marcamos para que Spring pueda crear y guardar un objeto de ella.
5. Añadimos a `BienvenidaCurso` un constructor sin parámetros que escriba en la consola el mensaje `  [BienvenidaCurso] Se ha creado el bean de bienvenida` (con dos espacios al principio).
6. Añadimos a `BienvenidaCurso` el método `saludar(String nombre)`, que devuelve el texto `Bienvenido/a al curso, ` seguido del nombre recibido.
7. Creamos la clase `Practica1` en el mismo paquete, con un `main()` que:
   1. Cree el contenedor de Spring indicándole el paquete `com.curso.practica1`.
   2. Pida al contenedor el bean `BienvenidaCurso`.
   3. Escriba en la consola el resultado de llamar a `saludar("Ana")`.
8. Ejecutamos `Practica1` con ▶ y comprobamos que la consola muestra exactamente estas dos líneas, en este orden:

<pre>
  [BienvenidaCurso] Se ha creado el bean de bienvenida
Bienvenido/a al curso, Ana
</pre>

**Pistas**

- La anotación que marca la clase como bean es `@Component`. Hay que importarla: `org.springframework.stereotype.Component`.
- El contenedor se crea con `new AnnotationConfigApplicationContext("com.curso.practica1")` dentro de un `try (...)`, igual que en `ConSpring` de la Demo 1, para que Java lo cierre al terminar. La clase se importa de `org.springframework.context.annotation`.
- El bean se pide con `getBean(BienvenidaCurso.class)` y el resultado se guarda en una variable del tipo `BienvenidaCurso`.
- El mensaje del constructor tiene que aparecer **antes** que el saludo: el constructor lo ejecuta Spring al crear el contenedor, antes de que nosotros pidamos el bean. En ninguna parte del código debe aparecer `new BienvenidaCurso()`.
- Si el programa termina con `NoSuchBeanDefinitionException`, Spring no ha encontrado ningún bean de esa clase: hay que revisar que la clase lleva la anotación y que el paquete que se pasa al contenedor es el correcto.
- Si el programa no escribe el mensaje del constructor, es la misma causa: Spring no ha encontrado la clase al escanear el paquete.

---

## Práctica 2: Propuesta de proyectos en grupos

Cada grupo propone el proyecto que construirá a lo largo del resto del módulo de Spring y Hibernate. Esta práctica no lleva código: lo que se escribe es una propuesta, y se presenta a la clase.

El proyecto tiene que ser una aplicación pequeña y realista, con lógica de negocio (cálculos o reglas, como el IVA de las demos) y con datos que se guarden en una base de datos. En las sesiones siguientes se va construyendo por partes: primero una API REST (el servicio que la aplicación ofrece por Internet para que otros programas le pidan o le envíen datos), después la persistencia con Hibernate (guardar los datos en una base de datos desde Java), después las páginas web. Por eso conviene que sea **pequeña**: dos o tres entidades y uno o dos servicios.

Una **entidad** es un tipo de cosa de la que la aplicación guarda datos, con los datos que la describen: en una aplicación de facturas, `Cliente` (nombre, NIF, correo) y `Factura` (fecha, base imponible, cliente). Un **servicio** es una clase que contiene una operación de negocio: calcular el total de una factura, comprobar que un aula está libre, aplicar un descuento.

**Pasos**

1. Formamos el grupo con las personas que indique el profesor y elegimos entre todos una idea de aplicación. Tiene que gustar al grupo y poder explicarse en una frase.
2. Rellenamos la ficha de la propuesta con estos apartados:
   - **Nombre** del proyecto.
   - **Problema** que resuelve, en dos o tres frases.
   - **Usuarios**: quién usaría la aplicación.
   - **Entidades** previstas, cada una con los campos que tendría.
   - **Operaciones de negocio**: al menos dos reglas o cálculos que la aplicación haría por su cuenta (no solo guardar y listar datos).
   - **Clases principales** previstas, incluidos los servicios.
3. Para cada clase principal indicamos si sería un **bean** de Spring y, si lo es, con qué anotación se registraría: `@Component` o `@Bean`. Justificamos la elección con el criterio de la Demo 2: `@Component` si Spring puede crear la clase sin datos, `@Bean` si hay que indicar datos al crearla.
4. Revisamos la propuesta con una pregunta: ¿cabe en las sesiones que quedan y se puede enseñar con tres o cuatro pantallas? Si no, recortamos.
5. Preparamos una presentación oral de unos tres minutos: el problema, los usuarios, las entidades y qué clases serían beans.
6. Presentamos la propuesta a la clase y recogemos las sugerencias del profesor.

**Pistas**

- Una buena propuesta describe un problema de la vida real que conocemos: un taller, un club deportivo, una biblioteca, una tienda pequeña, reservas de un local. Si el grupo conoce el problema, las reglas de negocio salen solas.
- Las operaciones de negocio son lo que distingue una aplicación de una simple lista de datos. Si una operación se puede resumir en "guardar o mostrar un dato", no cuenta como regla de negocio.
- Las entidades se escriben en singular y con la inicial en mayúscula, como las clases de Java: `Cliente`, no `clientes`.
- Los servicios son los candidatos naturales a bean: son las piezas fijas de la aplicación, que viven mientras vive la aplicación. Si una clase solo guarda datos (como `Cliente`), normalmente no es un bean.
- La propuesta se puede cambiar en las sesiones siguientes, pero conviene partir de una idea acotada.

---

## Práctica 3: Cuenta en Supabase y comprobación de acceso

Cada alumno crea su propia cuenta y su propia base de datos en **Supabase**. Supabase es un servicio en Internet que ofrece bases de datos **PostgreSQL** ya instaladas y administradas: en lugar de instalar un servidor de base de datos en nuestro ordenador, alquilamos uno en la nube, como alquilar un trastero en lugar de construirlo. PostgreSQL es una base de datos relacional de código abierto, de las más usadas en empresa. Hay plan gratuito, y es el que usamos.

La base de datos de cada alumno es **personal**: nadie comparte usuario ni contraseña con nadie. Esta práctica no escribe código: crea la cuenta, guarda los datos de conexión y comprueba que desde el aula se puede llegar a la base de datos. En la parte siguiente nos conectaremos desde un programa Java.

**Pasos**

1. Abrimos el navegador y entramos en `supabase.com`. Pulsamos `Start your project` (o `Sign in`, si ya hay cuenta) y nos registramos con una dirección de correo electrónico y una contraseña. Confirmamos el correo desde el mensaje que llega a nuestra bandeja.
2. Si Supabase pide crear una **organización**, escribimos como nombre el nuestro y dejamos el plan `Free`. Una organización es solo la carpeta que agrupa los proyectos de una cuenta.
3. Pulsamos `New project` y rellenamos:
   - **Project name**: `curso-spring`.
   - **Database Password**: la contraseña de la base de datos. No es la de la cuenta: es la que usará nuestro programa para conectarse. Elegimos una contraseña **larga y formada solo por letras y números**, sin símbolos como `@`, `:`, `/`, `?`, `#` o `%` (más abajo se explica por qué).
   - **Region**: una región de Europa, por ejemplo `West EU (Ireland)` o `Central EU (Frankfurt)`.
4. Pulsamos `Create new project` y esperamos a que el panel termine de preparar el proyecto (uno o dos minutos).
5. Creamos en nuestro ordenador un fichero de texto llamado `supabase-datos.txt`, **fuera de la carpeta de los proyectos del curso**, y apuntamos en él: el correo de la cuenta, la contraseña de la base de datos y el nombre del proyecto.
6. Pulsamos el botón `Connect`, en la parte superior del panel. Supabase ofrece varias formas de conectarse (`Direct connection`, `Session pooler`, `Transaction pooler`). Elegimos el método `Session pooler` y apuntamos en `supabase-datos.txt` el **host** (empieza por `aws-` y termina en `pooler.supabase.com`), el **puerto** (`5432`), el **usuario** (tiene la forma `postgres.` seguido de una cadena de letras, que es la referencia del proyecto) y el nombre de la base de datos (`postgres`).
7. Comprobamos que la base de datos responde: en el menú de la izquierda abrimos `SQL Editor`, pulsamos `New query`, escribimos `select now();` y pulsamos `Run`. Debe aparecer una fila con la fecha y la hora actuales.
8. Comprobamos que desde el ordenador del aula se llega al servidor. Abrimos PowerShell y ejecutamos la orden indicada justo debajo de esta lista, cambiando `HOST` por el host apuntado en el paso 6. En el resultado debe aparecer la línea `TcpTestSucceeded : True`. Si aparece `False`, avisamos al profesor: puede que la red del aula bloquee ese puerto.

```powershell
Test-NetConnection HOST -Port 5432
```

**Pistas**

- La contraseña de la base de datos solo se puede ver en el momento de crearla. Si se pierde, se puede restablecer desde el panel, en los ajustes de la base de datos (`Project Settings`, apartado `Database`), pero conviene apuntarla bien a la primera.
- Las contraseñas con símbolos como `@` o `:` dan problemas cuando se escriben dentro de una dirección de conexión, porque esos símbolos tienen un significado propio en las direcciones. Una contraseña solo de letras y números evita el problema.
- **IPv4** e **IPv6** son las dos versiones del sistema de direcciones de Internet. El método `Direct connection` solo admite conexiones por IPv6 en el plan gratuito, y muchas redes (incluida la del aula) usan todavía IPv4. Por eso usamos `Session pooler`: un **pooler** es un intermediario que mantiene abiertas varias conexiones con la base de datos y las reparte entre los programas que las piden, y el de Supabase funciona por IPv4 en todos los planes.
- El **host** es la dirección del servidor (como `aws-...pooler.supabase.com`) y el **puerto** es la "puerta" de ese servidor por la que entra la conexión (el `5432` es el habitual de PostgreSQL).
- Según la documentación de Supabase, el plan gratuito permite dos proyectos activos por cuenta, 500 MB por base de datos y **pausa los proyectos tras una semana sin actividad**. Un proyecto pausado no se pierde: se reactiva desde el panel con el botón `Restore project`.
- La contraseña de la base de datos no se escribe nunca en un fichero del proyecto que se vaya a compartir ni se envía por correo o por mensajería.
