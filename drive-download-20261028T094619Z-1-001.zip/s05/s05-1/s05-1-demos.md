# S05-1 Demos

## Objetivos

Hasta ahora las clases que hemos escrito creaban sus propios objetos con `new`. En esta parte empezamos con Spring, el framework sobre el que se construyen la mayoría de las aplicaciones Java de empresa, y lo primero que cambia es **quién crea los objetos**: en lugar de crearlos nosotros, se los pedimos a Spring.

Un **framework** es un conjunto de código ya escrito que fija la estructura de una aplicación y resuelve por nosotros las tareas que se repiten en todas: nosotros escribimos las piezas propias (las clases del negocio) y el framework se encarga de crearlas, conectarlas y ponerlas a funcionar. Una **librería**, en cambio, es código que llamamos cuando lo necesitamos, como `Math` o `String`. Con una librería mandamos nosotros; con un framework, en gran parte, manda él.

La parte tiene tres demos. En las dos primeras trabajamos con **Spring a secas**: sin ninguna ayuda, para ver con claridad qué es un contenedor, qué es un bean y qué hace la anotación `@Component` frente a `@Bean`. En la tercera repetimos el mismo ejemplo con **Spring Boot**, que es lo que se usa en la práctica profesional y lo que utilizaremos el resto del módulo. Veremos qué es exactamente Spring Boot, qué trabajo nos quita y por qué lo elegimos.

Para todas las ideas nuevas usamos ejemplos de la vida real. El ejemplo de programación es siempre el mismo, para no tener que aprender un problema nuevo en cada demo: una calculadora de **IVA** (el Impuesto sobre el Valor Añadido, el impuesto que se suma al precio de casi todo lo que compramos en España). La **base imponible** es el precio antes de añadir el impuesto; el **total** es la base más el IVA. En España el tipo general es el 21 %, y hay un tipo reducido del 10 % para algunos productos y servicios, como los restaurantes. Con una base de 100 euros, el total con IVA general es 121 y con IVA reducido es 110.

Al terminar esta parte los alumnos son capaces de:
- Explicar qué problema resuelve la inversión de control y qué es el acoplamiento entre clases.
- Añadir Spring a un proyecto Maven con una dependencia y crear un contenedor de Spring.
- Registrar una clase como bean con `@Component` y obtenerla del contenedor con `getBean`.
- Definir beans con `@Configuration` y `@Bean`, incluidos varios beans de la misma clase, y explicar cuándo usar cada anotación.
- Explicar qué es Spring Boot, en qué se diferencia de Spring y por qué lo usamos.
- Crear un proyecto de Spring Boot con el asistente de IntelliJ, leer su `pom.xml` y ejecutarlo.
- Construir el JAR ejecutable de una aplicación de Spring Boot y lanzarlo con `java -jar`.

---

## Demo 1: Primer proyecto Spring

### El problema: quién crea los objetos

Imaginamos una cafetería pequeña. Cuando un cliente pide un café, el camarero **fabrica él mismo la cafetera**, prepara el café y la tira. Al siguiente cliente le vuelve a fabricar otra cafetera. Funciona, pero tiene dos problemas claros. El primero es que se fabrican cafeteras de más: con una bastaría para toda la cafetería. El segundo es que el camarero está **atado** a esa forma concreta de hacer la cafetera: si el dueño decide comprar una cafetera mejor, hay que reeducar a todos los camareros, uno por uno, para que fabriquen la nueva.

La solución de cualquier cafetería real es otra: el **dueño** compra la cafetera una vez, la deja en la barra, y los camareros simplemente **la usan**. Los camareros ya no deciden cómo se consigue la cafetera ni cuántas hay; solo dicen "necesito una cafetera" y la tienen delante.

Eso es exactamente lo que ocurre en Java. Cuando una clase crea con `new` los objetos que necesita, decimos que está **acoplada** a ellos: conoce el nombre de la otra clase y también cómo se construye. Si esa construcción cambia, hay que modificar todas las clases que hacen el `new`. Y si cien clases necesitan lo mismo, se crean cien objetos aunque con uno bastara.

**Spring** es el framework que hace de dueño de la cafetería. Su idea central se llama **inversión de control** (IoC, de *Inversion of Control*): en lugar de que cada clase cree lo que necesita, es Spring quien crea los objetos, los guarda y se los entrega a quien los pide. Se llama "inversión" porque el control de la creación pasa de nuestro código al framework: lo habitual era mandar nosotros, y ahora manda él.

Spring guarda esos objetos en un almacén que se llama **contenedor** (en inglés, *application context*), igual que el dueño guarda la cafetera en la barra. Cada objeto que Spring crea y guarda en su contenedor se llama **bean** (en inglés, "grano", como el de café; es solo el nombre que eligieron). Un bean es, por tanto, un objeto corriente de Java con una única particularidad: en vez de crearlo nosotros con `new`, lo ha creado y lo guarda Spring.

Para comprobarlo, en esta demo escribimos primero el ejemplo **sin** Spring, con las clases acopladas, y después el mismo ejemplo **con** Spring.

### Crear el proyecto

Vamos a `File > New > Project`. En el panel izquierdo, dentro de `New Project`, seleccionamos `Java`.

Rellenamos los campos:

- **Name**: `s05-1-demos`.
- **Location**: la carpeta donde guardamos los proyectos del curso.
- **Create Git repository**: desmarcada.
- **Build system**: `Maven`.
- **JDK**: `21`.
- **Add sample code**: desmarcada. Así `src/main/java` queda vacía y creamos nosotros los paquetes y las clases.

Desplegamos `Advanced Settings` y rellenamos:

- **GroupId**: `com.curso`.
- **ArtifactId**: `s05-1-demos`.

Hacemos clic en `Create`.

### Añadir Spring al proyecto

Spring es una **librería externa**: no viene con Java. Para usarla hay que declararla como **dependencia** en el `pom.xml`, que es la forma en que le decimos a Maven "este proyecto necesita esta librería". Maven la descarga de **Maven Central**, el repositorio público donde se publican las librerías del ecosistema Java, y la deja disponible para el proyecto, es decir, la añade al **classpath**: la lista de ficheros JAR y carpetas donde Java busca las clases al compilar y al ejecutar. Sin Maven, habría que buscar nosotros los ficheros de Spring en Internet, descargarlos uno a uno y configurarlos a mano en el proyecto.

La librería que necesitamos se llama `spring-context`. Contiene el contenedor de Spring y las anotaciones básicas. Abrimos el `pom.xml` y añadimos este bloque justo después de `</properties>`, antes de `</project>`:

```xml
    <dependencies>
        <!-- spring-context: el contenedor de Spring (los beans y su gestión).
             Maven la descarga de Maven Central junto con sus dependencias transitivas
             (spring-core, spring-beans, spring-aop...), sin que tengamos que declararlas. -->
        <dependency>
            <groupId>org.springframework</groupId>
            <artifactId>spring-context</artifactId>
            <version>7.0.9</version>
        </dependency>
    </dependencies>
```

Cada elemento tiene un significado:

- `<dependencies>` agrupa todas las dependencias del proyecto. Cada librería va en su propio `<dependency>`.
- `<groupId>` identifica a la organización que publica la librería: `org.springframework` es el proyecto Spring. Es el mismo concepto que el `groupId` de nuestro proyecto.
- `<artifactId>` es el nombre de la librería dentro de esa organización: `spring-context`.
- `<version>` es la versión de la librería. Usamos la `7.0.9`, la versión de Spring Framework que corresponde a la versión de Spring Boot que usaremos en la Demo 3.

Al guardar el `pom.xml`, IntelliJ detecta el cambio y muestra arriba a la derecha del editor un pequeño icono de recarga de Maven (`Load Maven Changes`). Hacemos clic en él (o pulsamos `Ctrl+Shift+O`). IntelliJ pide a Maven que descargue la librería. La primera vez puede tardar unos segundos, porque Maven guarda una copia en una caché local en el disco (`~/.m2`) y las veces siguientes la usa sin conexión.

Cuando termina, desplegamos `External Libraries` al final del panel de proyecto. Hemos declarado **una sola** dependencia, pero aparecen **nueve** librerías:

<pre>
org.springframework:spring-context:7.0.9
org.springframework:spring-aop:7.0.9
org.springframework:spring-beans:7.0.9
org.springframework:spring-core:7.0.9
org.springframework:spring-expression:7.0.9
commons-logging:commons-logging:1.3.5
org.jspecify:jspecify:1.0.0
io.micrometer:micrometer-observation:1.16.7
io.micrometer:micrometer-commons:1.16.7
</pre>

Las otras ocho son las **dependencias transitivas**: librerías que `spring-context` necesita para funcionar y que Maven descarga por su cuenta, sin que tengamos que pedirlas. Es la misma razón por la que Maven es imprescindible con Spring: la gestión manual de esas nueve librerías, con sus versiones compatibles entre sí, sería inviable en cuanto el proyecto crece.

### La clase CalculadoraIva

Creamos el paquete de la demo: clic derecho sobre `src/main/java`, `New > Package`, escribimos `com.curso.demo1` y pulsamos Enter. Después, clic derecho sobre `com.curso.demo1`, `New > Java Class`, escribimos `CalculadoraIva` y pulsamos Enter.

Esta clase calcula el IVA y el total de una factura. Tiene tres cosas que merece la pena explicar antes de leer el código:

- El **constructor**: un bloque de código que Java ejecuta cada vez que se crea un objeto de la clase, tanto si lo creamos nosotros con `new` como si lo crea Spring. Aquí lo usamos para escribir un mensaje en la consola y poder ver **cuándo y cuántas veces** se crea una calculadora.
- La **constante** `TIPO_IVA`: el 21 %. Es `private static final`, como la constante `TIPO_CAMBIO_EUR_USD` de S02-1.
- La anotación **`@Component`**. Una **anotación** es una etiqueta que se coloca encima de una clase, un método o un campo, y que empieza por `@`. Por sí sola no cambia lo que hace el código. Es información que otro programa (aquí, Spring) puede leer. `@Component` significa "esta clase es un componente: Spring puede crear un objeto de ella y guardarlo".

```java
package com.curso.demo1;

// Importamos la anotación @Component del paquete org.springframework.stereotype.
// Procede de la librería spring-context, que Maven ha descargado de Maven Central
// al declarar la dependencia en el pom.xml y pulsar Load Maven Changes.
// Sin Maven habría que buscar el JAR de Spring, descargarlo y añadirlo al classpath a mano.
import org.springframework.stereotype.Component;

/**
 * S05-1 Demo 1: Primer proyecto Spring
 *
 * Objetivo: disponer de una clase sencilla (una calculadora de IVA) con la que comparar
 * que la creemos nosotros con new frente a que la cree Spring.
 *
 * Lo que hace este ejemplo:
 *   - Calcula el IVA y el total de una factura a partir de su base imponible
 *   - Lleva la anotación @Component, que le indica a Spring que puede crear y guardar un objeto de esta clase
 *   - Escribe un mensaje cada vez que se crea un objeto, para ver quién lo crea y cuándo
 *
 * Concepto clave: @Component es solo una etiqueta. La clase funciona igual con new, sin Spring;
 * la etiqueta solo tiene efecto cuando existe un contenedor de Spring que la lea.
 */
@Component
public class CalculadoraIva {

    // Tipo general de IVA en España, expresado en porcentaje (21 %).
    // private static final: es una constante de la clase, no cambia nunca (se vio en S02-1).
    private static final double TIPO_IVA = 21.0;

    // Constructor: bloque que Java ejecuta cada vez que se crea un objeto de esta clase,
    // tanto si lo creamos nosotros con new como si lo crea Spring.
    // El mensaje nos permite ver en la consola cuándo y cuántas veces se crea la calculadora.
    public CalculadoraIva() {
        System.out.println("  [CalculadoraIva] Se ha creado una calculadora de IVA");
    }

    /**
     * Calcula el importe del IVA de una factura a partir de su base imponible
     * (el precio antes de añadir el impuesto).
     *
     * Ejemplo:
     *   calcularIva(100.0)  →  21.0
     *   calcularIva(50.0)   →  10.5
     */
    public double calcularIva(double base) {
        // Multiplicamos la base por el porcentaje y dividimos entre 100.
        // Con 100.0: 100.0 * 21.0 / 100 → 21.0
        return base * TIPO_IVA / 100;
    }

    /**
     * Calcula el total de una factura: la base imponible más su IVA.
     *
     * Ejemplo:
     *   calcularTotal(100.0)  →  121.0
     *   calcularTotal(50.0)   →  60.5
     */
    public double calcularTotal(double base) {
        // Sumamos la base y el IVA que calcula el método anterior: 100.0 + 21.0 → 121.0
        return base + calcularIva(base);
    }
}
```

Fijémonos en que `@Component` es solo una etiqueta: la clase funciona exactamente igual con `new` y sin Spring. La etiqueta solo tiene efecto cuando existe un contenedor de Spring que la lea.

### Sin Spring: el acoplamiento

Creamos ahora la clase `FacturaSinSpring` en el mismo paquete. Representa una factura con su base imponible y necesita una calculadora para saber el total. Observemos la línea del campo `calculadora`: la propia factura **fabrica** su calculadora con `new`, como el camarero que fabrica su cafetera.

```java
package com.curso.demo1;

/**
 * S05-1 Demo 1: Primer proyecto Spring (la factura sin Spring)
 *
 * Objetivo: ver qué significa que una clase esté acoplada a otra.
 *
 * Lo que hace este ejemplo:
 *   - Guarda la base imponible de una factura
 *   - Crea ella misma, con new, la calculadora de IVA que necesita
 *   - Calcula su total usando esa calculadora
 *
 * Concepto clave: acoplamiento. Esta clase no solo usa CalculadoraIva: también decide cómo se crea.
 * Si mañana hubiera que crearla de otra manera, habría que abrir esta clase y cambiarla,
 * y lo mismo en cada clase que la cree con new.
 */
public class FacturaSinSpring {

    // La factura crea su propia calculadora en el momento de crearse ella.
    // Así de directo es el acoplamiento: FacturaSinSpring conoce el nombre de la clase
    // CalculadoraIva y también cómo se construye (con new y sin datos).
    // final: el campo se asigna una sola vez y ya no cambia.
    private final CalculadoraIva calculadora = new CalculadoraIva();

    // La base imponible de esta factura (el precio sin IVA).
    private final double base;

    // El constructor recibe la base imponible y la guarda en el campo.
    // El parámetro se llama baseImponible para no confundirlo con el campo base.
    public FacturaSinSpring(double baseImponible) {
        base = baseImponible;
    }

    /**
     * Devuelve el total de la factura, con el IVA incluido.
     *
     * Ejemplo:
     *   new FacturaSinSpring(100.0).total()  →  121.0
     *   new FacturaSinSpring(50.0).total()   →  60.5
     */
    public double total() {
        // Delegamos el cálculo en la calculadora que esta misma factura creó.
        return calculadora.calcularTotal(base);
    }
}
```

Y la clase `SinSpring`, con el `main()` que lo prueba. Primero crea una calculadora con `new`; después crea dos facturas.

```java
package com.curso.demo1;

/**
 * S05-1 Demo 1: Primer proyecto Spring (sin Spring)
 *
 * Objetivo: ver cómo se trabaja con la calculadora de IVA cuando la creamos nosotros con new.
 *
 * Lo que hace este ejemplo:
 *   - Crea una calculadora con new y calcula un total
 *   - Crea dos facturas, cada una con su propia calculadora escondida dentro
 *
 * Concepto clave: sin Spring, cada new es una decisión nuestra: quién crea el objeto, cuándo
 * y cuántos. Con dos facturas hay dos calculadoras, aunque con una bastaría.
 */
public class SinSpring {

    // main() permite ejecutar esta clase directamente desde IntelliJ (▶)
    // sin necesidad de un framework. Es el punto de entrada del programa.
    public static void main(String[] args) {
        // Primera forma: creamos la calculadora nosotros, con new, y la usamos.
        // Al ejecutarse el constructor, aparece su mensaje en la consola.
        System.out.println("1) Creamos la calculadora con new:");
        CalculadoraIva calculadora = new CalculadoraIva();
        System.out.println("   Total de 100.0: " + calculadora.calcularTotal(100.0));  // → Total de 100.0: 121.0

        // Segunda forma: creamos dos facturas. Cada una crea por su cuenta su propia calculadora
        // dentro de su constructor, así que aparecen dos mensajes de creación.
        System.out.println("2) Creamos dos facturas:");
        FacturaSinSpring factura1 = new FacturaSinSpring(100.0);
        FacturaSinSpring factura2 = new FacturaSinSpring(50.0);
        System.out.println("   Total de la factura 1: " + factura1.total());  // → Total de la factura 1: 121.0
        System.out.println("   Total de la factura 2: " + factura2.total());  // → Total de la factura 2: 60.5
    }
}
```

Hacemos clic en ▶ junto al `main()`.

Salida esperada:

<pre>
1) Creamos la calculadora con new:
  [CalculadoraIva] Se ha creado una calculadora de IVA
   Total de 100.0: 121.0
2) Creamos dos facturas:
  [CalculadoraIva] Se ha creado una calculadora de IVA
  [CalculadoraIva] Se ha creado una calculadora de IVA
   Total de la factura 1: 121.0
   Total de la factura 2: 60.5
</pre>

El resultado numérico es el correcto, pero el mensaje de creación aparece **tres veces**: una por la calculadora de la primera parte y una por cada factura. Con dos facturas hay dos calculadoras escondidas dentro, aunque con una bastaría para todas. Y `FacturaSinSpring` conoce el nombre de la clase y cómo se construye: si mañana `CalculadoraIva` necesitara un dato para crearse, habría que abrir `FacturaSinSpring` y modificarla. Es el problema de la cafetería.

### El contenedor vacío

Antes de pedirle nada a Spring, comprobamos que arranca en nuestro proyecto. Creamos la clase `ContenedorVacio`. El contenedor se representa con la clase `AnnotationConfigApplicationContext`: es un objeto de Java que se crea con `new`, como cualquier otro. Se llama así porque lee la configuración a través de **anotaciones** (`@Component` y otras).

Tres detalles del código antes de leerlo:

- `try (...) { ... }` es el **try-with-resources** de S04-1: el contenedor es un recurso que hay que cerrar al terminar, y Java llama automáticamente a su método `close()` al salir del bloque.
- `refresh()` es el método que **arranca** el contenedor. Cuando al crearlo le indicamos una clase o un paquete, Spring llama a `refresh()` por nosotros; aquí lo hacemos a mano porque no le hemos indicado nada, para ver el antes y el después.
- `getBeanDefinitionNames()` devuelve un array de `String` con los nombres de todos los beans, y lo recorremos con el `for` clásico de S02-2 (`i`, `.length` y acceso por posición).

```java
package com.curso.demo1;

// AnnotationConfigApplicationContext es el contenedor de Spring que lee anotaciones.
// Procede de spring-context, la dependencia que declaramos en el pom.xml.
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * S05-1 Demo 1: Primer proyecto Spring (el contenedor vacío)
 *
 * Objetivo: comprobar que Spring arranca correctamente en nuestro proyecto antes de usarlo.
 *
 * Lo que hace este ejemplo:
 *   - Crea un contenedor de Spring sin indicarle ninguna clase ni paquete
 *   - Lo arranca con refresh()
 *   - Muestra si está activo y qué contiene
 *
 * Concepto clave: el contenedor es un objeto más. Se crea con new desde un main() y, aunque
 * no le hayamos pedido nada, ya contiene objetos internos que Spring necesita para trabajar.
 */
public class ContenedorVacio {

    // main() permite ejecutar esta clase directamente desde IntelliJ (▶)
    // sin necesidad de un framework. Es el punto de entrada del programa.
    public static void main(String[] args) {
        // try-with-resources (S04-1): el contenedor es un recurso que hay que cerrar.
        // Al salir del bloque, Java llama automáticamente a su método close().
        // new AnnotationConfigApplicationContext() sin argumentos crea el contenedor sin arrancarlo.
        try (AnnotationConfigApplicationContext contexto = new AnnotationConfigApplicationContext()) {

            // isActive() responde si el contenedor está arrancado. Todavía no lo hemos arrancado.
            System.out.println("¿Arrancado antes de refresh()? " + contexto.isActive());  // → false

            // refresh() arranca el contenedor: lee su configuración y prepara los objetos que gestiona.
            // Cuando indicamos un paquete o una clase de configuración al crearlo, Spring llama a
            // refresh() por nosotros; aquí lo hacemos a mano porque no le hemos indicado nada.
            contexto.refresh();
            System.out.println("¿Arrancado después de refresh()? " + contexto.isActive());  // → true

            // getBeanDefinitionCount() devuelve cuántos beans tiene el contenedor.
            // No hemos declarado ninguno, pero Spring registra los suyos propios: son los objetos
            // internos que necesita para leer las anotaciones y procesar la configuración.
            System.out.println("Beans en el contenedor: " + contexto.getBeanDefinitionCount());  // → 4

            // getBeanDefinitionNames() devuelve los nombres de esos beans en un array de String.
            // Lo recorremos con el for clásico de S02-2: índice, .length y acceso por posición.
            String[] nombres = contexto.getBeanDefinitionNames();
            for (int i = 0; i < nombres.length; i++) {
                System.out.println("  " + nombres[i]);
            }
        }
    }
}
```

Hacemos clic en ▶ junto al `main()`.

Salida esperada:

<pre>
¿Arrancado antes de refresh()? false
¿Arrancado después de refresh()? true
Beans en el contenedor: 4
  org.springframework.context.annotation.internalConfigurationAnnotationProcessor
  org.springframework.context.annotation.internalAutowiredAnnotationProcessor
  org.springframework.context.event.internalEventListenerProcessor
  org.springframework.context.event.internalEventListenerFactory
</pre>

El contenedor pasa de no estar arrancado (`false`) a estarlo (`true`). Y aunque no hemos declarado ningún bean, ya contiene **cuatro**. Son los beans internos de Spring: objetos que el propio Spring necesita para trabajar. Tres de ellos son procesadores que leen las anotaciones (`internalConfigurationAnnotationProcessor` entiende `@Configuration` y `@Bean`; `internalAutowiredAnnotationProcessor` entiende `@Autowired`, que veremos en S05-2; `internalEventListenerProcessor` entiende los oyentes de eventos, que no usaremos) y el cuarto es una fábrica auxiliar para esos oyentes. No hace falta entender ahora ninguno de ellos ni recordar sus nombres: lo importante es saber que **el contenedor es un objeto más, que cuando arranca ya tiene objetos dentro** y que cualquier bean nuestro se sumará a esos cuatro.

### Con Spring: inversión de control

Creamos la clase `ConSpring`. Ahora le pasamos al contenedor, al crearlo, el nombre de un paquete: `"com.curso.demo1"`. Spring **recorre ese paquete y sus subpaquetes** buscando clases con `@Component`, y de cada una que encuentra crea un objeto (un bean) y lo guarda. Ese recorrido se llama **escaneo de componentes** (*component scan*): es como si el dueño de la cafetería pasara por el almacén buscando todo lo que lleva una etiqueta "comprar" y lo comprara.

Después, para obtener un bean, se lo pedimos al contenedor con `getBean`. Hay dos formas:

- `getBean(CalculadoraIva.class)`: pedimos un bean **por su clase**. Spring devuelve el bean de esa clase.
- `getBean("calculadoraIva", CalculadoraIva.class)`: pedimos un bean **por su nombre** e indicamos la clase que esperamos. Todo bean tiene un nombre. Con `@Component`, Spring usa el nombre de la clase con la primera letra en minúscula: `CalculadoraIva` se convierte en `calculadoraIva`.

```java
package com.curso.demo1;

// AnnotationConfigApplicationContext es el contenedor de Spring que lee anotaciones.
// Procede de spring-context, la dependencia que declaramos en el pom.xml.
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * S05-1 Demo 1: Primer proyecto Spring (con Spring)
 *
 * Objetivo: obtener la calculadora de IVA sin crearla nosotros: que la cree Spring.
 *
 * Lo que hace este ejemplo:
 *   - Crea el contenedor de Spring indicándole el paquete donde buscar clases con @Component
 *   - Pide al contenedor la calculadora, primero por su clase y después por su nombre
 *   - Calcula con ella el mismo total que en SinSpring
 *
 * Concepto clave: inversión de control. El cálculo es el mismo; lo que cambia es quién crea el
 * objeto. En SinSpring lo creábamos nosotros con new; aquí lo crea y lo guarda Spring.
 */
public class ConSpring {

    // main() permite ejecutar esta clase directamente desde IntelliJ (▶)
    // sin necesidad de un framework. Es el punto de entrada del programa.
    public static void main(String[] args) {
        System.out.println("Creamos el contenedor de Spring...");

        // Al crear el contenedor le pasamos el nombre de un paquete: Spring lo recorre, junto con
        // sus subpaquetes, buscando clases con @Component y crea un objeto de cada una.
        // Esos objetos son los beans. La calculadora se crea aquí dentro, durante el arranque:
        // su mensaje aparece antes de "Contenedor listo".
        // try-with-resources (S04-1): al terminar el bloque, Java cierra el contenedor solo.
        try (AnnotationConfigApplicationContext contexto = new AnnotationConfigApplicationContext("com.curso.demo1")) {
            System.out.println("Contenedor listo.");

            // getBean(Clase.class) pide al contenedor el bean de esa clase.
            // Devuelve directamente un CalculadoraIva: no hace falta ninguna conversión.
            // Nosotros no hemos escrito new CalculadoraIva() en ningún sitio de esta clase.
            CalculadoraIva calculadora = contexto.getBean(CalculadoraIva.class);
            System.out.println("Total de 100.0: " + calculadora.calcularTotal(100.0));  // → Total de 100.0: 121.0

            // Todo bean tiene un nombre. Con @Component, Spring usa el de la clase con la primera
            // letra en minúscula: CalculadoraIva → calculadoraIva.
            // getBean("nombre", Clase.class) pide el bean por su nombre e indica la clase esperada.
            CalculadoraIva otraVez = contexto.getBean("calculadoraIva", CalculadoraIva.class);
            System.out.println("Total de 50.0:  " + otraVez.calcularTotal(50.0));  // → Total de 50.0:  60.5

            // 4 beans internos de Spring + 1 propio: la calculadora.
            System.out.println("Beans en el contenedor: " + contexto.getBeanDefinitionCount());  // → 5
        }
    }
}
```

Hacemos clic en ▶ junto al `main()`.

Salida esperada:

<pre>
Creamos el contenedor de Spring...
  [CalculadoraIva] Se ha creado una calculadora de IVA
Contenedor listo.
Total de 100.0: 121.0
Total de 50.0:  60.5
Beans en el contenedor: 5
</pre>

Lo importante está en tres cosas:

- **No hay ningún `new CalculadoraIva()`** en `ConSpring`. La calculadora la crea Spring durante el arranque del contenedor, y por eso su mensaje aparece **antes** de "Contenedor listo".
- El mensaje de creación sale **una sola vez**, aunque hemos pedido la calculadora dos veces (por clase y por nombre). Spring crea cada bean una vez y entrega siempre el mismo objeto. Es la cafetera de la barra: una sola, que usan todos. El número de objetos que Spring crea de cada bean tiene un nombre, *scope*, que estudiaremos en S05-2.
- Ahora hay **cinco** beans: los cuatro internos de Spring y nuestra calculadora.

El cálculo es el mismo que en `SinSpring`. Lo que ha cambiado es **quién crea el objeto**.

---

## Demo 2: Clase de configuración con @Configuration y @Bean

`@Component` tiene un límite. Spring crea el objeto por sí solo, llamando al constructor sin datos. Pero ¿qué pasa si la clase necesita un dato para crearse?

Pensemos en una panadería. Si pedimos "una barra de pan", el panadero la saca del horno sin hacer preguntas: es siempre igual. Eso es `@Component`. Pero si pedimos "una tarta", el panadero necesita saber **de qué**: ¿chocolate?, ¿fresa? La etiqueta "tarta" no basta; alguien tiene que escribir la **receta** de cada una. Eso es `@Bean`: nosotros escribimos el código que fabrica el objeto, con los datos que queramos, y Spring lo guarda.

En nuestro ejemplo, la calculadora de IVA de esta demo recibe el **porcentaje** de IVA al crearse. Así podemos tener una calculadora con el IVA general (21 %, para ropa, electrónica, servicios profesionales...) y otra con el IVA reducido (10 %, para restaurantes y transporte de viajeros). Dos objetos de la **misma clase**, con datos distintos. Con `@Component` no se puede: Spring no sabría qué porcentaje pasar.

### La clase CalculadoraIva de esta demo

Creamos el paquete `com.curso.demo2` (clic derecho sobre `src/main/java`, `New > Package`) y dentro la clase `CalculadoraIva`. Es una clase nueva, **distinta** de la de la Demo 1, aunque se llame igual. Pueden convivir sin problema porque están en paquetes distintos: el paquete es el espacio de nombres de la clase (S02-1), así que `com.curso.demo1.CalculadoraIva` y `com.curso.demo2.CalculadoraIva` son dos clases diferentes. Y eso nos conviene: cuando la Demo 1 escanea el paquete `com.curso.demo1`, no ve esta clase.

Esta clase **no lleva anotaciones de Spring**: es una clase corriente. Su constructor recibe el porcentaje y lo guarda en el campo `tipoIva`.

```java
package com.curso.demo2;

/**
 * S05-1 Demo 2: Clase de configuración con @Configuration y @Bean
 *
 * Objetivo: disponer de una calculadora de IVA cuyo porcentaje se decide al crearla.
 *
 * Lo que hace este ejemplo:
 *   - Recibe el porcentaje de IVA en el constructor y lo guarda
 *   - Calcula el IVA y el total de una factura con ese porcentaje
 *   - No lleva ninguna anotación de Spring: es una clase corriente
 *
 * Concepto clave: esta clase necesita un dato para crearse (el porcentaje), y Spring no sabe
 * qué dato darle. Por eso no puede llevar @Component: alguien tiene que decir cómo se construye.
 */
public class CalculadoraIva {

    // El porcentaje de IVA de esta calculadora. Cada objeto tiene el suyo.
    // final: se asigna una sola vez, en el constructor, y ya no cambia.
    private final double tipoIva;

    // El constructor recibe el porcentaje y lo guarda. Sin ese dato no se puede crear la calculadora.
    // El mensaje muestra en la consola cuándo se crea cada objeto y con qué porcentaje.
    public CalculadoraIva(double porcentaje) {
        tipoIva = porcentaje;
        System.out.println("  [CalculadoraIva] Creada con un IVA del " + porcentaje + " %");
    }

    /**
     * Calcula el importe del IVA de una factura a partir de su base imponible.
     *
     * Ejemplo (calculadora creada con 21.0):
     *   calcularIva(100.0)  →  21.0
     *   calcularIva(50.0)   →  10.5
     */
    public double calcularIva(double base) {
        // Multiplicamos la base por el porcentaje propio de esta calculadora y dividimos entre 100.
        return base * tipoIva / 100;
    }

    /**
     * Calcula el total de una factura: la base imponible más su IVA.
     *
     * Ejemplo (calculadora creada con 21.0):
     *   calcularTotal(100.0)  →  121.0
     *   calcularTotal(50.0)   →  60.5
     */
    public double calcularTotal(double base) {
        // Sumamos la base y el IVA que calcula el método anterior.
        return base + calcularIva(base);
    }
}
```

### La clase de configuración

Creamos la clase `ConfiguracionIva` en el mismo paquete. Es una **clase de configuración**: una clase cuyo único trabajo es decirle a Spring cómo crear beans. Se marca con dos anotaciones:

- **`@Configuration`** sobre la clase: "esta clase contiene definiciones de beans". Spring la lee al arrancar.
- **`@Bean`** sobre cada método: "el objeto que devuelve este método es un bean". Spring llama a cada método **una vez**, al arrancar el contenedor, y guarda lo que devuelve. El **nombre** del bean es el nombre del método.

El `new` lo escribimos nosotros, con el dato que queramos. Esa es la diferencia con `@Component`: aquí controlamos exactamente cómo se crea el objeto.

```java
package com.curso.demo2;

// @Bean y @Configuration están en el paquete org.springframework.context.annotation.
// Proceden de spring-context, la dependencia que ya declaramos en el pom.xml.
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * S05-1 Demo 2: Clase de configuración con @Configuration y @Bean
 *
 * Objetivo: decidir nosotros cómo se crean los beans, escribiendo el código que los construye.
 *
 * Lo que hace este ejemplo:
 *   - Declara dos beans del mismo tipo: una calculadora con IVA general y otra con IVA reducido
 *   - Cada bean se define con un método anotado con @Bean
 *
 * Concepto clave: @Component deja que Spring cree el objeto; @Bean permite que lo creemos
 * nosotros con el código que queramos y que Spring lo guarde. Así se pueden tener varios beans
 * de la misma clase con configuraciones distintas.
 */
@Configuration
public class ConfiguracionIva {

    /**
     * Bean con el IVA general (21 %): ropa, electrónica, servicios profesionales...
     *
     * Ejemplo:
     *   el bean "calculadoraGeneral" calcula calcularTotal(100.0)  →  121.0
     */
    // @Bean indica que el objeto que devuelve este método es un bean: Spring llama al método
    // una vez, al arrancar el contenedor, y guarda lo que devuelve.
    // El nombre del bean es el nombre del método: calculadoraGeneral.
    @Bean
    public CalculadoraIva calculadoraGeneral() {
        // El new lo escribimos nosotros, con el dato que queremos (21.0).
        return new CalculadoraIva(21.0);
    }

    /**
     * Bean con el IVA reducido (10 %): restaurantes, transporte de viajeros...
     *
     * Ejemplo:
     *   el bean "calculadoraReducida" calcula calcularTotal(100.0)  →  110.0
     */
    // Segundo bean de la misma clase, con otro dato. Su nombre es calculadoraReducida.
    @Bean
    public CalculadoraIva calculadoraReducida() {
        return new CalculadoraIva(10.0);
    }
}
```

### Obtener los beans

Creamos la clase `ConBean`. Ahora el contenedor se crea pasándole **la clase de configuración** (`ConfiguracionIva.class`) y no un paquete: Spring lee esa clase y llama a cada método `@Bean`. Como hay dos beans del mismo tipo, los pedimos **por su nombre**.

```java
package com.curso.demo2;

// AnnotationConfigApplicationContext es el contenedor de Spring que lee anotaciones.
// Procede de spring-context, la dependencia que declaramos en el pom.xml.
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * S05-1 Demo 2: Clase de configuración con @Configuration y @Bean
 *
 * Objetivo: obtener del contenedor las dos calculadoras definidas con @Bean y usar cada una.
 *
 * Lo que hace este ejemplo:
 *   - Crea el contenedor a partir de la clase de configuración, no de un paquete
 *   - Pide cada calculadora por su nombre
 *   - Calcula el total de una misma base con cada una
 *
 * Concepto clave: con dos beans de la misma clase hay que pedir cada uno por su nombre,
 * porque la clase sola no basta para saber cuál se quiere.
 */
public class ConBean {

    // main() permite ejecutar esta clase directamente desde IntelliJ (▶)
    // sin necesidad de un framework. Es el punto de entrada del programa.
    public static void main(String[] args) {
        System.out.println("Creamos el contenedor a partir de ConfiguracionIva...");

        // Ahora le pasamos al contenedor una clase de configuración (ConfiguracionIva.class) en
        // lugar de un paquete. Spring lee esa clase y llama a cada método @Bean: los mensajes de
        // creación de las dos calculadoras aparecen aquí, durante el arranque.
        // try-with-resources (S04-1): al terminar el bloque, Java cierra el contenedor solo.
        try (AnnotationConfigApplicationContext contexto = new AnnotationConfigApplicationContext(ConfiguracionIva.class)) {
            System.out.println("Contenedor listo.");

            // Pedimos cada bean por su nombre, que es el del método @Bean.
            CalculadoraIva general = contexto.getBean("calculadoraGeneral", CalculadoraIva.class);
            CalculadoraIva reducida = contexto.getBean("calculadoraReducida", CalculadoraIva.class);

            // La misma base con cada calculadora: el resultado depende del porcentaje con que se creó.
            System.out.println("Ropa, base 100.0:        " + general.calcularTotal(100.0));  // → Ropa, base 100.0:        121.0
            System.out.println("Restaurante, base 100.0: " + reducida.calcularTotal(100.0));  // → Restaurante, base 100.0: 110.0

            // 4 beans internos de Spring + 2 calculadoras + la propia clase de configuración,
            // que también es un bean.
            System.out.println("Beans en el contenedor: " + contexto.getBeanDefinitionCount());  // → 7
        }
    }
}
```

Hacemos clic en ▶ junto al `main()`.

Salida esperada:

<pre>
Creamos el contenedor a partir de ConfiguracionIva...
  [CalculadoraIva] Creada con un IVA del 21.0 %
  [CalculadoraIva] Creada con un IVA del 10.0 %
Contenedor listo.
Ropa, base 100.0:        121.0
Restaurante, base 100.0: 110.0
Beans en el contenedor: 7
</pre>

Los dos mensajes de creación aparecen durante el arranque, uno por cada método `@Bean`, cada uno con su porcentaje. La misma base de 100 euros da 121 con una calculadora y 110 con la otra. Los beans son **siete**: los cuatro internos, las dos calculadoras y la propia clase de configuración, que también es un bean.

### El error de la ambigüedad

¿Qué ocurre si, con dos beans del mismo tipo, pedimos uno solo por su clase, como hacíamos en la Demo 1? Lo comprobamos a propósito con la clase `ErrorAmbiguo`.

```java
package com.curso.demo2;

// AnnotationConfigApplicationContext es el contenedor de Spring que lee anotaciones.
// Procede de spring-context, la dependencia que declaramos en el pom.xml.
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * S05-1 Demo 2: Clase de configuración con @Configuration y @Bean (el error de la ambigüedad)
 *
 * Objetivo: provocar a propósito el error que aparece cuando hay dos beans del mismo tipo
 * y se pide uno solo por su clase.
 *
 * Lo que hace este ejemplo:
 *   - Crea el mismo contenedor que ConBean, con las dos calculadoras
 *   - Pide una calculadora indicando solo la clase, sin decir cuál de las dos
 *   - Termina con una excepción: Spring no puede adivinar cuál queremos
 *
 * Concepto clave: Spring no elige por nosotros cuando hay varias opciones. Prefiere fallar
 * con un mensaje claro a devolver un bean que quizá no sea el esperado.
 */
public class ErrorAmbiguo {

    // main() permite ejecutar esta clase directamente desde IntelliJ (▶)
    // sin necesidad de un framework. Es el punto de entrada del programa.
    public static void main(String[] args) {
        try (AnnotationConfigApplicationContext contexto = new AnnotationConfigApplicationContext(ConfiguracionIva.class)) {
            System.out.println("Contenedor listo. Pedimos una calculadora solo por su clase...");

            // En el contenedor hay dos beans de tipo CalculadoraIva: calculadoraGeneral y
            // calculadoraReducida. Con getBean(Clase.class) Spring no sabe cuál entregar y lanza
            // una NoUniqueBeanDefinitionException: el programa termina aquí, con un mensaje de error.
            // La solución es la de ConBean: pedir cada bean por su nombre.
            CalculadoraIva calculadora = contexto.getBean(CalculadoraIva.class);

            // Esta línea no llega a ejecutarse.
            System.out.println("Total de 100.0: " + calculadora.calcularTotal(100.0));
        }
    }
}
```

Hacemos clic en ▶ junto al `main()`.

Salida esperada (la traza de la excepción se acorta con `...`):

<pre>
  [CalculadoraIva] Creada con un IVA del 21.0 %
  [CalculadoraIva] Creada con un IVA del 10.0 %
Contenedor listo. Pedimos una calculadora solo por su clase...
Exception in thread "main" org.springframework.beans.factory.NoUniqueBeanDefinitionException: No qualifying bean of type 'com.curso.demo2.CalculadoraIva' available: expected single matching bean but found 2: calculadoraGeneral,calculadoraReducida
	at org.springframework.beans.factory.support.DefaultListableBeanFactory.resolveNamedBean(DefaultListableBeanFactory.java:1619)
	at org.springframework.beans.factory.support.DefaultListableBeanFactory.resolveBean(DefaultListableBeanFactory.java:556)
	...
	at com.curso.demo2.ErrorAmbiguo.main(ErrorAmbiguo.java:33)
</pre>

El programa termina con una **excepción**, un error que interrumpe la ejecución (S04-1). Su nombre, `NoUniqueBeanDefinitionException`, se lee casi como una frase: "definición de bean no única". Y el mensaje lo explica: `expected single matching bean but found 2: calculadoraGeneral,calculadoraReducida`, es decir, "se esperaba un único bean que encajara pero se han encontrado 2", y nos dice cuáles. Spring prefiere fallar con un mensaje claro antes que entregar la calculadora equivocada, que daría facturas con el IVA incorrecto. La solución es la de `ConBean`: pedir cada bean por su nombre.

### Cuándo usar @Component y cuándo @Bean

| | `@Component` | `@Bean` |
|---|---|---|
| Dónde se escribe | Sobre la clase | Sobre un método de una clase `@Configuration` |
| Quién escribe el `new` | Spring | Nosotros |
| Cuántos beans de la clase | Uno | Los que declaremos, con datos distintos |
| Cuándo usarlo | Clases propias que Spring puede crear sin datos | Clases que necesitan datos al crearse, o clases que no podemos anotar porque no son nuestras (de una librería) |

Cada bean debe declararse por una sola de las dos vías.

---

## Demo 3: El mismo ejemplo con Spring Boot

### Qué es Spring Boot

En las dos demos anteriores, antes de poder usar Spring hemos tenido que hacer varias tareas que no tienen nada que ver con la calculadora de IVA: elegir la versión de `spring-context`, crear el contenedor a mano en cada `main()`, indicarle qué paquete escanear... Y todavía no hemos hecho nada realista: una aplicación de verdad necesita además una base de datos, un servidor web, un sistema de registro de mensajes, y cada una de esas librerías tiene su propia versión, que debe ser compatible con las demás.

Una comparación con la vida real. Alquilar un piso **sin amueblar** (Spring) nos da las paredes y la libertad total: nosotros elegimos los muebles, damos de alta la luz y el agua, instalamos internet. Alquilar un piso **amueblado y con los suministros ya dados de alta** (Spring Boot) significa llegar con la maleta y empezar a vivir: los muebles están elegidos para que combinen, la luz y el agua funcionan. Y si no nos gusta algún mueble, lo cambiamos. **Es el mismo piso**: las paredes son las mismas. Spring Boot **no sustituye a Spring**: por dentro lleva Spring (el mismo contenedor, los mismos beans, las mismas anotaciones) y se limita a prepararlo todo por nosotros.

Concretamente, Spring Boot aporta cuatro cosas:

- **Arranque en una línea.** Una sola instrucción crea el contenedor, escanea los componentes y deja la aplicación funcionando.
- **Starters.** Un **starter** es una dependencia que arrastra todas las librerías necesarias para una tarea, con versiones que se sabe que funcionan bien juntas. En lugar de buscar cinco librerías y acertar con sus versiones, escribimos una sola línea.
- **Autoconfiguración.** Spring Boot mira qué librerías hay en el proyecto y **configura por su cuenta** lo que esas librerías necesitan. Si más adelante añadimos una librería de base de datos, Boot prepara la conexión; si añadimos una librería web, prepara el servidor. Nosotros solo ajustamos lo que queramos cambiar.
- **Una aplicación autónoma.** Boot construye un único fichero ejecutable con todo lo necesario dentro, que se lanza con una sola orden en cualquier ordenador que tenga Java.

### Por qué usamos Spring Boot en el curso

| | Spring a secas (Demos 1 y 2) | Spring Boot (Demo 3) |
|---|---|---|
| Versiones de las librerías | Las elegimos y las declaramos una a una | El padre y los starters las fijan, ya compatibles entre sí |
| Crear el contenedor | A mano, en el `main()` | `SpringApplication.run(...)`, una línea |
| Escanear componentes | Indicamos el paquete | Automático, desde el paquete de la clase principal |
| Mensajes de la aplicación (logs) | Hay que configurarlos para verlos | Preparados, con hora, nivel y origen en cada línea |
| Fichero ejecutable | No | Sí, con `mvn package` y `java -jar` |
| Añadir una base de datos o un servidor web | Muchas líneas de configuración | Una dependencia y, a lo sumo, una propiedad |

Las razones para elegirlo son tres. **Es lo que se usa en la práctica profesional**: la inmensa mayoría de las aplicaciones Spring nuevas se crean con Boot. **Nos permite llegar antes a lo interesante**: el resto del módulo (una API REST, una base de datos con Hibernate, páginas web con Thymeleaf) se apoya en Boot, y con Spring a secas cada una exigiría una sesión entera de configuración previa. Y **no perdemos nada**: todo lo que hemos visto en las Demos 1 y 2 (contenedor, beans, `@Component`, `@Bean`) funciona igual dentro de Spring Boot. Por eso hemos empezado con Spring a secas: para que, cuando Boot haga algo por nosotros, sepamos qué es lo que está haciendo.

### Crear el proyecto con el asistente de Spring Boot

Los proyectos de Spring Boot se crean con su propio generador, no con el asistente `Java` que hemos usado hasta ahora. IntelliJ lo incluye: es el generador `Spring Boot`, que se conecta a **start.spring.io**, la página web oficial de Spring para crear proyectos. Necesita conexión a Internet.

Vamos a `File > New > Project`. En el panel izquierdo, dentro de `Generators`, seleccionamos `Spring Boot`.

Rellenamos los campos. Atención a los que traen un valor por defecto que **no** nos sirve:

- **Server URL**: `start.spring.io`. Es la dirección del servicio que genera el proyecto. No la tocamos.
- **Name**: `s05-1-demo3`.
- **Location**: la misma carpeta que en las demos anteriores.
- **Create Git repository**: desmarcada.
- **Language**: `Java`.
- **Type**: `Maven`. El asistente puede traer marcado `Gradle - Groovy` (en nuestra comprobación venía así), por lo que **hay que comprobar que queda en `Maven`**. Gradle es otra herramienta de construcción, alternativa a Maven. En el curso usamos Maven, así que lo cambiamos.
- **Group**: `com.curso`.
- **Artifact**: `s05-1-demo3`. Se rellena solo con el `Name`.
- **Package name**: `com.curso`. **Lo comprobamos siempre antes de continuar:** el asistente lo recalcula cada vez que cambiamos `Name` o `Artifact` y suele dejarlo con un valor propio (por ejemplo `com.example.demo`). Lo escribimos de nuevo a mano.
- **JDK**: `21`.
- **Java**: `21`. El asistente puede proponer `17` (en nuestra comprobación venía así): **hay que comprobar que pone `21`**. Es la versión de Java del proyecto, y tiene que coincidir con el JDK.
- **Packaging**: `Jar`. Es el formato del fichero que producirá Maven (se explicó en S02-1). La otra opción, `War`, es para instalar la aplicación en un servidor externo; no lo usaremos.
- **Configuration**: `Properties`. Es el formato del fichero de configuración de la aplicación. La otra opción, `YAML`, escribe lo mismo con otra sintaxis.

Hacemos clic en `Next`.

En la pantalla siguiente:

- **Spring Boot**: `4.1.1`. Es la versión que propone el asistente y la que usamos. Incluye Spring Framework 7.0.9, la misma que escribimos a mano en la Demo 1.
- **Dependencies**: no marcamos ninguna. La lista aparece vacía (*No dependencies added*). El asistente añade siempre por su cuenta el starter básico y el de pruebas, que son los que necesitamos.

Hacemos clic en `Create`.

Si el generador de IntelliJ no estuviera disponible, el mismo proyecto se obtiene entrando en la web start.spring.io desde el navegador, rellenando estos mismos campos y pulsando `Generate`: descarga un `.zip` que se descomprime y se abre en IntelliJ con `File > Open`.

### Estructura del proyecto

El generador crea más ficheros que el asistente `Java`:

<pre>
s05-1-demo3/
├── .idea/
├── .mvn/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/
│   │   │       └── curso/
│   │   │           └── Demo3Application.java
│   │   └── resources/
│   │       └── application.properties
│   └── test/
│       └── java/
│           └── com/
│               └── curso/
│                   └── Demo3ApplicationTests.java
├── .gitattributes
├── .gitignore
├── HELP.md
├── mvnw
├── mvnw.cmd
└── pom.xml
</pre>

Las carpetas `src/main/java`, `src/main/resources` y `src/test/java` son las mismas que ya conocemos. De los ficheros nuevos:

- `application.properties` es el **fichero de configuración de la aplicación**, en `src/main/resources`. Lo explicamos más abajo.
- `HELP.md` es un fichero de ayuda con enlaces a la documentación de Spring Boot. No se usa.
- `mvnw` y `mvnw.cmd` forman el **Maven Wrapper**: un pequeño script (el primero para Linux y macOS, el segundo para Windows) que descarga y ejecuta la versión de Maven que el proyecto necesita, de modo que se puede construir en un ordenador que no tenga Maven instalado. La carpeta `.mvn` guarda su configuración. En el curso trabajamos desde IntelliJ y no los usamos.
- `.gitattributes` y `.gitignore` son ficheros de ayuda para repositorios de código. No los usamos.

El generador da nombre a las clases a partir del nombre del proyecto. Si la clase principal y la de test no se llaman `Demo3Application` y `Demo3ApplicationTests`, las renombramos para que coincidan con las del documento: clic derecho sobre la clase en el panel de proyecto, `Refactor > Rename` (o `Shift+F6`), escribimos el nombre nuevo y pulsamos Enter.

### El pom.xml

Abrimos el `pom.xml`. Lo ha generado el asistente: no lo escribimos, lo leemos. Los comentarios en español son del curso; el generador no los pone.

<pre>
&amp;lt;?xml version="1.0" encoding="UTF-8"?&amp;gt;
&amp;lt;project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd"&amp;gt;
    &amp;lt;modelVersion&amp;gt;4.0.0&amp;lt;/modelVersion&amp;gt;

    &amp;lt;!-- parent: este proyecto hereda de spring-boot-starter-parent, igual que en S04-2 los módulos
         heredaban de un POM padre. Aporta las versiones de Spring, Jackson, JUnit y cientos de
         librerías más, ya comprobadas entre sí, y la configuración de plugins de Maven.
         La versión 4.1.1 de Spring Boot lleva dentro Spring Framework 7.0.9, la misma que
         escribimos a mano en las Demos 1 y 2. --&amp;gt;
    &amp;lt;parent&amp;gt;
        &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
        &amp;lt;artifactId&amp;gt;spring-boot-starter-parent&amp;lt;/artifactId&amp;gt;
        &amp;lt;version&amp;gt;4.1.1&amp;lt;/version&amp;gt;
        &amp;lt;relativePath/&amp;gt; &amp;lt;!-- buscar el padre en el repositorio (Maven Central), no en una carpeta local --&amp;gt;
    &amp;lt;/parent&amp;gt;

    &amp;lt;groupId&amp;gt;com.curso&amp;lt;/groupId&amp;gt;
    &amp;lt;artifactId&amp;gt;s05-1-demo3&amp;lt;/artifactId&amp;gt;
    &amp;lt;version&amp;gt;0.0.1-SNAPSHOT&amp;lt;/version&amp;gt;
    &amp;lt;name&amp;gt;s05-1-demo3&amp;lt;/name&amp;gt;
    &amp;lt;description&amp;gt;s05-1-demo3&amp;lt;/description&amp;gt;

    &amp;lt;!-- url, licenses, developers y scm: datos descriptivos que el generador deja vacíos.
         No afectan a la compilación ni a la ejecución. --&amp;gt;
    &amp;lt;url/&amp;gt;
    &amp;lt;licenses&amp;gt;
        &amp;lt;license/&amp;gt;
    &amp;lt;/licenses&amp;gt;
    &amp;lt;developers&amp;gt;
        &amp;lt;developer/&amp;gt;
    &amp;lt;/developers&amp;gt;
    &amp;lt;scm&amp;gt;
        &amp;lt;connection/&amp;gt;
        &amp;lt;developerConnection/&amp;gt;
        &amp;lt;tag/&amp;gt;
        &amp;lt;url/&amp;gt;
    &amp;lt;/scm&amp;gt;

    &amp;lt;properties&amp;gt;
        &amp;lt;!-- Versión de Java del proyecto. El padre la usa para configurar el compilador
             (en las Demos 1 y 2 lo hacíamos con maven.compiler.source y maven.compiler.target). --&amp;gt;
        &amp;lt;java.version&amp;gt;21&amp;lt;/java.version&amp;gt;
    &amp;lt;/properties&amp;gt;

    &amp;lt;dependencies&amp;gt;
        &amp;lt;!-- spring-boot-starter: el starter básico. Un starter es una única dependencia que arrastra
             todas las librerías necesarias para una tarea. Este trae Spring (spring-context y sus
             transitivas), el arranque automático de Spring Boot y el sistema de registro de mensajes.
             No lleva &amp;lt;version&amp;gt;: la fija el padre. --&amp;gt;
        &amp;lt;dependency&amp;gt;
            &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
            &amp;lt;artifactId&amp;gt;spring-boot-starter&amp;lt;/artifactId&amp;gt;
        &amp;lt;/dependency&amp;gt;

        &amp;lt;!-- spring-boot-starter-test: el starter de pruebas (JUnit, utilidades de Spring para tests...).
             scope test: solo está disponible en src/test/java, igual que JUnit en S02-2. --&amp;gt;
        &amp;lt;dependency&amp;gt;
            &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
            &amp;lt;artifactId&amp;gt;spring-boot-starter-test&amp;lt;/artifactId&amp;gt;
            &amp;lt;scope&amp;gt;test&amp;lt;/scope&amp;gt;
        &amp;lt;/dependency&amp;gt;
    &amp;lt;/dependencies&amp;gt;

    &amp;lt;build&amp;gt;
        &amp;lt;plugins&amp;gt;
            &amp;lt;!-- spring-boot-maven-plugin: plugin de Spring Boot para Maven. Permite arrancar la
                 aplicación con mvn spring-boot:run y construir un JAR ejecutable que lleva dentro
                 todas sus dependencias. Sin versión: la fija el padre. --&amp;gt;
            &amp;lt;plugin&amp;gt;
                &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
                &amp;lt;artifactId&amp;gt;spring-boot-maven-plugin&amp;lt;/artifactId&amp;gt;
            &amp;lt;/plugin&amp;gt;
        &amp;lt;/plugins&amp;gt;
    &amp;lt;/build&amp;gt;

&amp;lt;/project&amp;gt;
</pre>

Los elementos nuevos respecto a los `pom.xml` que conocemos:

- **`<parent>`**: este proyecto **hereda** de `spring-boot-starter-parent`, un `pom.xml` padre que mantiene el equipo de Spring Boot. Lo que hereda es muy valioso: las **versiones** de Spring, de JUnit y de cientos de librerías más (algunas, como Jackson, las usaremos más adelante), ya comprobadas entre sí, y la configuración de los **plugins** de Maven (las piezas que hacen el trabajo de Maven: compilar, ejecutar tests, empaquetar; se trabajan en S03-2). La herencia entre `pom.xml` es la misma idea que vimos en S04-2 con los módulos. Por eso en las dependencias de abajo **no aparece ninguna `<version>`**: la fija el padre.
- **`<relativePath/>`**: vacío a propósito. Le dice a Maven que busque el padre en el repositorio (Maven Central) y no en una carpeta local.
- **`java.version`**: la versión de Java. El padre la usa para configurar el compilador, de modo que ya no escribimos `maven.compiler.source` ni `maven.compiler.target`.
- **`url`, `licenses`, `developers` y `scm`**: datos descriptivos que el generador deja vacíos. No afectan a nada.
- **`spring-boot-starter`**: el starter básico. Arrastra Spring (`spring-context` y sus transitivas), el arranque automático de Boot y el sistema de mensajes. Una sola línea trae lo que en la Demo 1 declaramos con `spring-context` y mucho más.
- **`spring-boot-starter-test`**: el starter de pruebas, con `scope` `test`: solo está disponible en `src/test/java`, igual que JUnit en S02-2.
- **`spring-boot-maven-plugin`**: el plugin de Spring Boot para Maven. Permite arrancar la aplicación con Maven y construir el JAR ejecutable. Más abajo lo usamos.

### La clase CalculadoraIva: la copiamos de la Demo 1

La calculadora de esta demo **no se escribe de nuevo**: es la clase `CalculadoraIva` de la Demo 1 (la que lleva `@Component` y tiene el mensaje `Se ha creado una calculadora de IVA`), que **copiamos tal cual** en este proyecto. Lo hacemos así porque queremos comparar el mismo ejemplo con y sin Boot, y para eso la calculadora tiene que ser idéntica.

Para copiarla: en el proyecto `s05-1-demos`, seleccionamos `CalculadoraIva` dentro de `com.curso.demo1` y pulsamos `Ctrl+C`. Cambiamos al proyecto `s05-1-demo3`, hacemos clic sobre el paquete `com.curso` (en `src/main/java`) y pulsamos `Ctrl+V`. IntelliJ pide confirmar el nombre: pulsamos `OK`. Al pegarla en otro paquete, IntelliJ actualiza solo la línea `package`: comprobamos que ahora dice `package com.curso;`. Es el **único** cambio respecto a la clase de la Demo 1; el resto del código, comentarios incluidos, es el mismo.

### La clase principal

Abrimos `Demo3Application`, que ha generado el asistente. El generador solo escribe la anotación y una línea en `main`; nosotros guardamos el contenedor en una variable para poder pedirle la calculadora.

```java
package com.curso;

// SpringApplication es la clase de Spring Boot que arranca la aplicación.
// @SpringBootApplication es la anotación que convierte esta clase en el punto de partida de Spring Boot.
// Las dos proceden de spring-boot y spring-boot-autoconfigure, que llegan con spring-boot-starter:
// no las hemos declarado en el pom.xml, el starter las ha traído.
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// ConfigurableApplicationContext es el tipo del contenedor que devuelve Spring Boot al arrancar.
// Es el mismo tipo de objeto que en las Demos 1 y 2 creábamos con new AnnotationConfigApplicationContext(...).
import org.springframework.context.ConfigurableApplicationContext;

/**
 * S05-1 Demo 3: El mismo ejemplo con Spring Boot
 *
 * Objetivo: obtener la calculadora de IVA del contenedor, como en la Demo 1, pero dejando que
 * Spring Boot cree y configure el contenedor por nosotros.
 *
 * Lo que hace este ejemplo:
 *   - Arranca la aplicación con SpringApplication.run()
 *   - Recibe el contenedor ya creado, con la calculadora dentro (la clase copiada de la Demo 1)
 *   - Calcula el mismo total y cuenta cuántos beans tiene el contenedor
 *
 * Concepto clave: Spring Boot no sustituye a Spring, lo arranca y lo configura. El contenedor, los
 * beans y @Component son exactamente los mismos; desaparecen la creación a mano del contenedor,
 * las versiones en el pom.xml y la configuración que hay que escribir antes de poder empezar.
 */
// @SpringBootApplication marca esta clase como la de arranque y activa tres cosas a la vez:
//   - Es una clase de configuración (como @Configuration de la Demo 2).
//   - Busca clases con @Component en este paquete (com.curso) y en sus subpaquetes
//     (el escaneo que en la Demo 1 indicábamos escribiendo el nombre del paquete).
//   - Activa la autoconfiguración: Spring Boot mira qué librerías hay en el proyecto y prepara
//     por su cuenta lo que esas librerías necesitan.
@SpringBootApplication
public class Demo3Application {

    // main() permite ejecutar esta clase directamente desde IntelliJ (▶)
    // sin necesidad de un framework. Es el punto de entrada del programa.
    public static void main(String[] args) {
        // SpringApplication.run() hace en un solo paso lo que en la Demo 1 hacíamos a mano:
        // crea el contenedor, lo arranca, busca los @Component y crea sus beans.
        // Además configura el sistema de mensajes (por eso aparecen líneas con hora, nivel y
        // origen), lee application.properties y muestra el banner de Spring Boot.
        // Devuelve el contenedor ya arrancado, igual que new AnnotationConfigApplicationContext(...).
        // args son los argumentos con que se lanza el programa; Spring Boot puede usarlos como configuración.
        ConfigurableApplicationContext contexto = SpringApplication.run(Demo3Application.class, args);

        // A partir de aquí es idéntico a ConSpring de la Demo 1: pedimos la calculadora al contenedor.
        // Nosotros no hemos escrito new CalculadoraIva() en ningún sitio.
        CalculadoraIva calculadora = contexto.getBean(CalculadoraIva.class);
        System.out.println("Total de 100.0: " + calculadora.calcularTotal(100.0));  // → Total de 100.0: 121.0

        // Con Spring a secas el contenedor tenía 4 beans internos y, con la calculadora, 5.
        // Aquí hay muchos más: son los beans que Spring Boot ha preparado él solo.
        System.out.println("Beans en el contenedor: " + contexto.getBeanDefinitionCount());  // → Beans en el contenedor: 51
    }
}
```

Lo central de este código:

- **`@SpringBootApplication`** convierte la clase en la de arranque y activa tres cosas a la vez: es una clase de configuración (como `@Configuration` de la Demo 2), escanea los `@Component` del paquete `com.curso` y sus subpaquetes (el escaneo que en la Demo 1 indicábamos escribiendo el nombre del paquete) y activa la autoconfiguración. Por eso la clase principal **debe estar en el paquete raíz** (`com.curso`): el escaneo solo mira hacia abajo, y así encuentra `CalculadoraIva` sin que se lo indiquemos.
- **`SpringApplication.run(...)`** hace en una línea lo que en la Demo 1 hacíamos a mano: crear el contenedor, arrancarlo y crear los beans. Devuelve el contenedor ya arrancado, del tipo `ConfigurableApplicationContext`: una interfaz que `AnnotationConfigApplicationContext` implementa, así que en la práctica es el mismo contenedor que en las demos anteriores. Aquí no lo envolvemos en un `try` para cerrarlo: Spring Boot se encarga de cerrarlo al terminar el programa.
- A partir de ahí, el código es **idéntico a `ConSpring`**: pedimos la calculadora con `getBean`.

Hacemos clic en ▶ junto al `main()`.

Salida esperada (las líneas de mensajes son largas; el tiempo y el número de proceso cambian en cada ejecución):

<pre>

  .   ____          _            __ _ _
 /\\ / ___'_ __ _ _(_)_ __  __ _ \ \ \ \
( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \
 \\/  ___)| |_)| | | | | || (_| |  ) ) ) )
  '  |____| .__|_| |_|_| |_\__, | / / / /
 =========|_|==============|___/=/_/_/_/

 :: Spring Boot ::                (v4.1.1)

2026-10-08T19:29:03.429+02:00  INFO 1327 --- [s05-1-demo3] [           main] com.curso.Demo3Application               : Starting Demo3Application using Java 21.0.12.1 with PID 1327 (/ruta/s05-1-demo3/target/classes started by root in /ruta/s05-1-demo3)
2026-10-08T19:29:03.436+02:00  INFO 1327 --- [s05-1-demo3] [           main] com.curso.Demo3Application               : No active profile set, falling back to 1 default profile: "default"
  [CalculadoraIva] Se ha creado una calculadora de IVA
2026-10-08T19:29:04.368+02:00  INFO 1327 --- [s05-1-demo3] [           main] com.curso.Demo3Application               : Started Demo3Application in 1.607 seconds (process running for 2.046)
Total de 100.0: 121.0
Beans en el contenedor: 51
</pre>

Qué vemos:

- El **banner** de Spring Boot, con la versión `v4.1.1`. Es el dibujo que Boot muestra al arrancar.
- Las líneas con **hora, nivel, número de proceso y origen** son el sistema de mensajes que Boot ha configurado por nosotros (en las Demos 1 y 2 solo veíamos nuestros `println`). Cada línea indica la hora exacta, el **nivel** (`INFO` es información normal; los avisos y errores salen como `WARN` y `ERROR`), el número del proceso, el nombre de la aplicación entre corchetes (`s05-1-demo3`, que viene de `application.properties`), el hilo (`main`, el flujo de ejecución en el que corre el programa), la clase que escribe el mensaje y el mensaje.
- Nuestro mensaje `[CalculadoraIva] Se ha creado una calculadora de IVA` aparece **una sola vez**, igual que en `ConSpring`: Spring Boot ha escaneado, ha encontrado el `@Component` y ha creado el bean.
- `Started Demo3Application in ... seconds` indica que el contenedor está listo.
- El total y el número de beans: **51** beans, frente a los 5 de `ConSpring`. Los 46 beans de diferencia (cifra aproximada, porque los beans internos de Boot no son exactamente los de Spring a secas) los ha preparado Spring Boot por su cuenta, y entre ellos está la propia clase principal, que también es un bean: es la autoconfiguración. Con más librerías en el proyecto, serían más.

### El fichero application.properties

Abrimos `src/main/resources/application.properties`. Es el fichero donde se **configura la aplicación sin tocar el código Java**. Cada línea tiene la forma `clave=valor`. Spring Boot lo lee al arrancar, antes de crear ningún bean. Por ahora tiene una sola línea de configuración, `spring.application.name`, que el asistente ha escrito con el nombre del proyecto. Las líneas que empiezan por `#` son comentarios del curso y Boot las ignora:

```properties
# application.properties: fichero de configuración de la aplicación. Cada línea tiene la forma
# clave=valor y Spring Boot lo lee al arrancar, antes de crear ningún bean.
# Los cambios que se hagan aquí no obligan a tocar ni a recompilar el código Java.

# Nombre de la aplicación. Lo escribe el generador con el nombre del proyecto y Spring Boot
# lo usa, por ejemplo, para identificar la aplicación en los mensajes y en las herramientas de seguimiento.
spring.application.name=s05-1-demo3

# Experimento de la Demo 3: quitamos el # de la línea siguiente para que Spring Boot
# no muestre el banner al arrancar. off es el valor que apaga el banner.
# spring.main.banner-mode=off
```

Hacemos un experimento: quitamos el `#` de la última línea (en un fichero `.properties`, `#` convierte la línea en un comentario) y ejecutamos de nuevo. Salida esperada:

<pre>
2026-10-08T19:29:10.035+02:00  INFO 1411 --- [s05-1-demo3] [           main] com.curso.Demo3Application               : Starting Demo3Application using Java 21.0.12.1 with PID 1411 (/ruta/s05-1-demo3/target/classes started by root in /ruta/s05-1-demo3)
2026-10-08T19:29:10.040+02:00  INFO 1411 --- [s05-1-demo3] [           main] com.curso.Demo3Application               : No active profile set, falling back to 1 default profile: "default"
  [CalculadoraIva] Se ha creado una calculadora de IVA
2026-10-08T19:29:10.810+02:00  INFO 1411 --- [s05-1-demo3] [           main] com.curso.Demo3Application               : Started Demo3Application in 1.459 seconds (process running for 1.931)
Total de 100.0: 121.0
Beans en el contenedor: 51
</pre>

El banner ha desaparecido **sin tocar una línea de Java**. Es la idea de las propiedades: ajustar el comportamiento de la aplicación desde un fichero. En las sesiones siguientes lo usaremos para indicar la conexión a la base de datos o el puerto del servidor. Volvemos a poner el `#` para dejar el ejemplo como estaba.

### El test generado

Abrimos `src/test/java/com/curso/Demo3ApplicationTests.java`. Lo genera el asistente; solo se han sustituido los comentarios por los del curso.

```java
package com.curso;

// @Test marca un método como test que JUnit debe ejecutar (S02-2).
// @SpringBootTest es una anotación de spring-boot-starter-test que, al ejecutar el test,
// arranca la aplicación entera de Spring Boot con su contenedor.
// Ambas están disponibles porque spring-boot-starter-test está declarado en el pom.xml con scope test.
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * S05-1 Demo 3: El mismo ejemplo con Spring Boot (test generado)
 *
 * Objetivo: ver el test de ejemplo que genera el asistente de Spring Boot en src/test/java.
 *
 * Lo que hace este ejemplo:
 *   - Arranca la aplicación completa dentro de un test
 *   - Pasa si el contenedor arranca sin errores y falla si Spring no puede crear algún bean
 *
 * Concepto clave: este test no comprueba ninguna operación; comprueba que la aplicación arranca.
 * Es la prueba más barata y una de las más útiles: detecta de inmediato los beans mal configurados.
 */
// @SpringBootTest hace que Spring Boot arranque el contenedor antes de ejecutar los tests de esta clase.
@SpringBootTest
class Demo3ApplicationTests {

    // El método está vacío a propósito: no hay nada que comprobar con assertEquals.
    // Si el contenedor no consigue arrancar, el test falla antes de llegar aquí;
    // si arranca, el test pasa.
    @Test
    void contextLoads() {
    }
}
```

El test **no comprueba ninguna operación**: comprueba que la aplicación arranca. `@SpringBootTest` arranca el contenedor completo dentro del test; si Spring no consigue crear algún bean, el test falla. Es la prueba más barata y una de las más útiles: detecta de inmediato un bean mal configurado.

Lo ejecutamos desde el panel de proyecto: clic derecho sobre `Demo3ApplicationTests`, `Run 'Demo3ApplicationTests'`. Obtendremos el mismo resultado desde Maven, con la orden `mvn test` (o desde el panel `Maven`, a la derecha: `Lifecycle > test`). Salida esperada de Maven (abreviada):

<pre>
[INFO] --- resources:3.5.0:resources (default-resources) @ s05-1-demo3 ---
[INFO] --- compiler:3.15.0:compile (default-compile) @ s05-1-demo3 ---
[INFO] --- resources:3.5.0:testResources (default-testResources) @ s05-1-demo3 ---
[INFO] --- compiler:3.15.0:testCompile (default-testCompile) @ s05-1-demo3 ---
[INFO] --- surefire:3.5.6:test (default-test) @ s05-1-demo3 ---
[INFO] Running com.curso.Demo3ApplicationTests
[INFO] Tests run: 1, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 2.263 s -- in com.curso.Demo3ApplicationTests
[INFO] Results:
[INFO] Tests run: 1, Failures: 0, Errors: 0, Skipped: 0
[INFO] BUILD SUCCESS
[INFO] Total time:  5.052 s
</pre>

`Tests run: 1, Failures: 0, Errors: 0` y `BUILD SUCCESS` significan que el contenedor arrancó sin problemas.

### Qué trae el starter

El starter que hemos declarado es **una** línea en el `pom.xml`, pero arrastra una cadena de librerías. Podemos verla con el panel `Maven` de IntelliJ (`Dependencies`) o con la orden `mvn dependency:tree`. Abreviado, y sin las librerías de test:

<pre>
com.curso:s05-1-demo3:jar:0.0.1-SNAPSHOT
\- org.springframework.boot:spring-boot-starter:jar:4.1.1
   +- org.springframework.boot:spring-boot-starter-logging:jar:4.1.1
   |  +- ch.qos.logback:logback-classic:jar:1.5.38
   |  |  \- ch.qos.logback:logback-core:jar:1.5.38
   |  +- org.apache.logging.log4j:log4j-to-slf4j:jar:2.25.5
   |  |  \- org.apache.logging.log4j:log4j-api:jar:2.25.5
   |  \- org.slf4j:jul-to-slf4j:jar:2.0.18
   +- org.springframework.boot:spring-boot-autoconfigure:jar:4.1.1
   |  \- org.springframework.boot:spring-boot:jar:4.1.1
   |     \- org.springframework:spring-context:jar:7.0.9
   |        +- org.springframework:spring-aop:jar:7.0.9
   |        +- org.springframework:spring-beans:jar:7.0.9
   |        +- org.springframework:spring-expression:jar:7.0.9
   |        \- io.micrometer:micrometer-observation:jar:1.17.1
   |           \- io.micrometer:micrometer-commons:jar:1.17.1
   +- jakarta.annotation:jakarta.annotation-api:jar:3.0.0
   \- org.yaml:snakeyaml:jar:2.6
</pre>

El árbol está abreviado: no muestra algunas librerías que ya aparecen en otra rama (`spring-core`, `commons-logging`, `jspecify` y `slf4j-api`). Las versiones de las librerías auxiliares pueden diferir de las de la Demo 1 (por ejemplo `micrometer`, 1.17.1 aquí y 1.16.7 allí) porque ahora las fija el padre de Boot. Reconocemos `spring-context` 7.0.9 de la Demo 1, dentro de `spring-boot`. Alrededor, el starter añade el sistema de mensajes (`logback` y compañía), la autoconfiguración y una librería (`snakeyaml`) que permite leer ficheros de configuración en formato YAML. En total, **20** librerías en el classpath de ejecución, frente a las 9 de Spring a secas. Y todas las versiones las ha decidido el padre.

### El JAR ejecutable

Spring Boot construye un fichero que contiene la aplicación y todas sus librerías. Es como la diferencia entre llevar las **piezas sueltas** de un mueble y una **maleta ya hecha**: se abre y se usa. Para construirlo ejecutamos en la terminal de IntelliJ (`View > Tool Windows > Terminal`, o `Alt+F12`), en la carpeta del proyecto. La terminal necesita que `mvn` y `java` estén instalados y accesibles desde cualquier carpeta (en el `PATH` del sistema). Si `mvn` no se reconoce, hay dos alternativas: lanzar la fase desde el panel `Maven` de IntelliJ (`Lifecycle`, doble clic en `clean` y después en `package`) o usar el Maven Wrapper del proyecto, escribiendo `.\mvnw.cmd` en lugar de `mvn`.

```bash
mvn clean package
```

`package` es la **fase** de Maven (cada paso de la construcción: compilar, testear, empaquetar...) que construye el JAR. `clean` borra antes la carpeta `target` para empezar de cero. Salida esperada (abreviada, con las rutas sustituidas):

<pre>
[INFO] --- clean:3.5.0:clean (default-clean) @ s05-1-demo3 ---
[INFO] --- resources:3.5.0:resources (default-resources) @ s05-1-demo3 ---
[INFO] --- compiler:3.15.0:compile (default-compile) @ s05-1-demo3 ---
[INFO] --- resources:3.5.0:testResources (default-testResources) @ s05-1-demo3 ---
[INFO] --- compiler:3.15.0:testCompile (default-testCompile) @ s05-1-demo3 ---
[INFO] --- surefire:3.5.6:test (default-test) @ s05-1-demo3 ---
[INFO] Tests run: 1, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 2.559 s -- in com.curso.Demo3ApplicationTests
[INFO] Tests run: 1, Failures: 0, Errors: 0, Skipped: 0
[INFO] --- jar:3.5.1:jar (default-jar) @ s05-1-demo3 ---
[INFO] Building jar: /ruta/s05-1-demo3/target/s05-1-demo3-0.0.1-SNAPSHOT.jar
[INFO] --- spring-boot:4.1.1:repackage (repackage) @ s05-1-demo3 ---
[INFO] Replacing main artifact /ruta/s05-1-demo3/target/s05-1-demo3-0.0.1-SNAPSHOT.jar with repackaged archive, adding nested dependencies in BOOT-INF/.
[INFO] BUILD SUCCESS
[INFO] Total time:  7.260 s
</pre>

La última línea relevante, `spring-boot:repackage`, es el plugin de Spring Boot: **reempaqueta** el JAR que acaba de construir Maven para meter dentro todas las librerías. En `target` quedan dos ficheros:

<pre>
9106166 s05-1-demo3-0.0.1-SNAPSHOT.jar
4816 s05-1-demo3-0.0.1-SNAPSHOT.jar.original
</pre>

`s05-1-demo3-0.0.1-SNAPSHOT.jar` es el ejecutable, de unos 9 MB, con la aplicación y sus 20 librerías (dentro de la carpeta `BOOT-INF/lib`). El fichero `.jar.original` es el JAR que construyó Maven antes del reempaquetado: solo contiene nuestras dos clases, de ahí su tamaño (unos 5 KB). Lo lanzamos con Java, sin Maven ni IntelliJ:

```bash
java -jar target/s05-1-demo3-0.0.1-SNAPSHOT.jar
```

Salida esperada: la misma que al ejecutar con ▶ desde IntelliJ (banner, líneas de mensajes, `Total de 100.0: 121.0` y `Beans en el contenedor: 51`). Es lo que se haría para llevar la aplicación a un servidor: se copia un solo fichero y se ejecuta.

También se puede arrancar la aplicación directamente desde Maven, sin construir el JAR, con `mvn spring-boot:run`: lo permite el plugin de Spring Boot y da la misma salida.

### Resumen: lo mismo, con menos trabajo

En las tres demos hemos calculado lo mismo, una calculadora de IVA. Esto es lo que ha cambiado:

| | `SinSpring` | `ConSpring` (Demo 1) | `Demo3Application` (Demo 3) |
|---|---|---|---|
| Quién crea la calculadora | Nosotros, con `new` | Spring, tras escanear el paquete | Spring Boot, tras escanear el paquete |
| Cómo se crea el contenedor | No hay | `new AnnotationConfigApplicationContext("com.curso.demo1")` | `SpringApplication.run(...)` |
| Versiones de las librerías | No hay librerías | Las declaramos nosotros | Las fija el padre |
| Beans en el contenedor | 0 | 5 | 51 |
| Fichero ejecutable | No | No | Sí |

Todo lo demás es idéntico: la clase `CalculadoraIva`, la anotación `@Component`, el `getBean`. Spring Boot no ha cambiado cómo funciona Spring: ha quitado el trabajo de preparación.
