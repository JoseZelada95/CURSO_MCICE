# S13-1 Demos

## Objetivos

Esta parte abre el módulo de integración continua. Primero entendemos qué problema resuelve y cómo está organizada la herramienta que lo resuelve, Jenkins, y después la instalamos en cada equipo con el instalador `.msi` de Windows. No se escribe código Java: el trabajo es de herramientas y de sistema operativo. Todo lo que sigue en el módulo (los primeros jobs, el pipeline, las ramas, los avisos por correo) se construye sobre un Jenkins que ya está en marcha, por eso esta parte termina cuando cada equipo tiene el suyo funcionando.

Los proyectos que construirá Jenkins son los que ya conocemos: proyectos Maven con pruebas de JUnit, guardados en un repositorio de Git. Los alumnos ya tienen JDK 21, Maven, Git e IntelliJ, y ya han hecho el repaso de S12-2. De Jenkins no saben nada todavía.

Al terminar esta parte los alumnos son capaces de:
- Explicar qué problema resuelve la integración continua y qué hace Jenkins dentro de ella.
- Nombrar las piezas de Jenkins (controlador, job, build, plugin, carpeta de datos) y decir para qué sirve cada una.
- Instalar Jenkins en Windows como servicio con el instalador `.msi`.
- Desbloquear el primer arranque, instalar los plugins sugeridos y crear el usuario administrador.
- Comprobar en la consola de servicios de Windows que Jenkins está en ejecución.
- Arrancar y parar el servicio, y saber que Jenkins vuelve a arrancar solo al encender el equipo.

---

## Demo 1: La integración continua y la arquitectura de Jenkins

### El problema

Cuando varias personas trabajan sobre el mismo proyecto, cada una hace sus cambios en su propio ordenador. Tarde o temprano hay que juntar esos cambios, y ese momento es donde aparecen los problemas. Tres casos habituales:

- Algo que compila en un ordenador no compila en otro, porque falta una librería, la versión de Java es distinta o hay un fichero que alguien tiene y no ha subido.
- Una prueba que pasaba deja de pasar y nadie sabe qué cambio la rompió, porque en medio hay veinte cambios de cuatro personas.
- Dos cambios que funcionan bien por separado fallan al combinarse.

Un ejemplo cotidiano: cuatro personas preparan juntas la cena de Nochebuena y cada una cocina un plato en su casa. Si nadie junta los platos hasta llegar a la mesa, es ahí donde se descubre que hay cuatro postres y ningún plato principal. Si el día antes se prueba un poco de cada cosa y se ajusta, el fallo se detecta con tiempo.

### La solución: integración continua

**Integrar** es juntar los cambios de todas las personas en un mismo proyecto. La **integración continua** (en inglés *continuous integration*, abreviado CI) consiste en integrar con mucha frecuencia y, cada vez que cambia el proyecto, construirlo y probarlo de forma automática en un equipo aparte, sin que nadie tenga que acordarse de hacerlo. Si algo falla, se avisa a los pocos minutos, cuando el cambio que lo causó todavía está fresco.

El flujo es siempre el mismo:

1. Una persona termina un cambio y lo envía al repositorio con `git push` (lo hicimos en S11-1).
2. El servidor de integración continua se entera del cambio.
3. El servidor descarga el código del repositorio.
4. Construye el proyecto: es el mismo `mvn clean package` que ya conocemos de S03-2.
5. Ejecuta las pruebas de JUnit, que Maven lanza en la fase `test` (S02-2).
6. Guarda el resultado y, si algo ha fallado, avisa.

Lo que automatizamos no es nada nuevo: son los mismos comandos que cada alumno ejecuta a mano en su equipo. Lo nuevo es que los ejecuta un programa que no se cansa ni se olvida, siempre con el mismo entorno.

Un **servidor de integración continua** es el programa que ejecuta ese flujo. **Jenkins** es el más extendido. Es una aplicación escrita en Java, gratuita y de código abierto, que se ejecuta como cualquier otra aplicación de servidor y que se maneja desde una página web.

### Las piezas de Jenkins

Para entender cualquier pantalla de Jenkins conviene conocer cinco piezas. Los nombres son los de la documentación oficial.

- **Controlador** (*controller*): el proceso central de Jenkins. Guarda la configuración, carga los plugins y genera la interfaz web. Es lo que se instala hoy. En la documentación antigua se le llama *master*, un nombre que ya no se usa.
- **Job**: la descripción de un trabajo que Jenkins debe hacer, por ejemplo "descargar este repositorio y construirlo con Maven". Es la receta. La documentación antigua lo llama también *project*.
- **Build**: el resultado de una ejecución concreta de un job. Cada vez que el job se ejecuta se crea un build con su número (`#1`, `#2`, `#3`...), su salida de consola y su estado. El job es la receta y el build es cada vez que se cocina.
- **Plugin**: una extensión que añade capacidades a Jenkins. El Jenkins básico (el *core*) es pequeño, y casi todo lo demás, como hablar con Git o publicar el resultado de las pruebas, viene en plugins. Se instalan desde la propia interfaz.
- **Carpeta de datos** (`JENKINS_HOME`): la carpeta del disco donde Jenkins guarda todo lo suyo. Contiene el fichero de configuración principal (`config.xml`), la carpeta `jobs` con los jobs y los resultados de sus builds, y los plugins instalados. Según la documentación oficial, la carpeta `jobs` incluye también el espacio de trabajo (*workspace*), que es la carpeta donde Jenkins descarga el código de cada job para construirlo. Copiar esta carpeta a otro equipo es copiar el Jenkins entero.

Dos piezas más aparecerán más adelante y se nombran ahora para que no sorprendan: el **agente** (*agent*), una máquina que recibe trabajo del controlador, y el **ejecutor** (*executor*), cada hueco de trabajo simultáneo de una máquina. En el curso todo corre en el propio controlador, así que no se configura nada de esto.

Cuando un job se ejecuta, el resultado queda marcado con un estado. Los tres que vamos a ver más son:

- **Stable**: el build terminó sin errores y ninguna comprobación se quejó.
- **Unstable** (inestable): el build terminó, pero alguna comprobación posterior encontró errores no fatales. El caso típico es una prueba de JUnit que falla.
- **Failed** (fallido): el build tuvo un error fatal, por ejemplo un error de compilación.

En la interfaz estos estados se ven con colores (azul o verde para el éxito, amarillo para inestable, rojo para fallido). Los vemos en cuanto haya el primer job, en la parte siguiente.

---

## Demo 2: Instalación de Jenkins en Windows con el instalador MSI

Esta demo instala Jenkins en el equipo y lo deja listo para usar. Antes de empezar se comprueban cuatro requisitos, porque dos de los fallos más frecuentes (un puerto ocupado y una versión de Java inadecuada) se evitan con un minuto de comprobación.

### Qué es un servicio de Windows y por qué instalamos así

Un **servicio de Windows** es un programa que Windows arranca por su cuenta al encender el equipo y que sigue funcionando sin ninguna ventana abierta ni ninguna persona con la sesión iniciada. Se gestiona desde la consola de servicios. El instalador `.msi` (*Microsoft Installer*, el formato de instalación estándar de Windows) deja Jenkins instalado como un servicio. Es la forma de usarlo en un equipo real: si se reinicia el equipo, Jenkins vuelve a arrancar solo. Es distinto de arrancar Jenkins desde una terminal, donde al cerrar la terminal se para.

### Requisitos que se comprueban antes de instalar

La documentación oficial pide, para el controlador, Java 21 o posterior (con la política de soporte actual, Java 21 y Java 25). Pide además un puerto libre y unos mínimos de hardware pequeños: 256 MB de memoria y 1 GB de disco, aunque recomienda para un equipo pequeño 4 GB o más de memoria y 50 GB o más de disco.

Abrimos un `cmd` (pulsamos la tecla Windows, escribimos `cmd` y pulsamos Enter).

**1. Versión de Java.**

```bash
java -version
```

La primera línea de la salida tiene que mostrar la versión 21: empieza por `openjdk version "21` o por `java version "21`, según el fabricante del JDK. La tercera línea debe contener `64-Bit`. El instalador exige una máquina virtual de 64 bits.

**2. Dónde está ese Java.**

```bash
where java
```

Muestra la ruta del `java.exe` que Windows encuentra primero. Sirve para saber en qué carpeta está el JDK por si el instalador no la rellena solo.

**3. Puerto 8080 libre.** Un **puerto** es el número de la "puerta" por la que un programa recibe conexiones; en un mismo equipo, dos programas no pueden usar a la vez el mismo puerto. Jenkins usa por defecto el `8080`, el mismo que ya usa Spring Boot desde S06-1. Comprobamos si hay algo escuchando:

```bash
netstat -ano | findstr :8080
```

Si no sale ninguna línea, el puerto está libre. Si sale alguna con la palabra `LISTENING`, hay un programa usándolo. La última columna es el identificador del proceso (PID). Para saber qué programa es:

```bash
tasklist /FI "PID eq 1234"
```

(se sustituye `1234` por el PID de la salida anterior). Lo más habitual en este curso es que sea una aplicación de Spring Boot que quedó arrancada en IntelliJ: se para con ■.

**4. Permisos de administrador.** Instalar un servicio requiere permisos de administrador. El instalador los pide solo con una ventana de Windows.

### Descargar el instalador

Abrimos `https://www.jenkins.io/download/`. La página ofrece dos líneas de versiones. **LTS** (*long-term support*, soporte a largo plazo) es la estable: se elige una versión cada doce semanas y recibe correcciones. **Weekly** trae las novedades cada semana. Para el curso usamos siempre la LTS: es la que se usa en un entorno profesional y la que menos cambia de un día para otro.

En el bloque **LTS** pulsamos el icono de **Windows**. Se descarga el fichero `jenkins.msi` (en el momento de redactar esta parte, la versión LTS era la 2.580.1; el instalador viene firmado por LF Open Source LLC). La dirección directa es `https://get.jenkins.io/windows-stable/2.580.1/jenkins.msi`, pero la versión cambia cada pocas semanas: se descarga siempre desde la página.

Si Windows muestra el aviso de SmartScreen (*Windows protegió su PC*), pulsamos `More info` o `Más información` y después `Run anyway` o `Ejecutar de todas formas`. La documentación de la descarga indica que en Windows 11 puede ocurrir.

### Recorrido del asistente de instalación

Hacemos doble clic en `jenkins.msi`. El asistente está en inglés aunque Windows esté en español y tiene unas ocho pantallas. El título de la ventana lleva la versión (`Jenkins 2.580.1 Setup`). Las pantallas **3** (`Service Logon Credentials`) y **6** (`Custom Setup`) se han comprobado en un equipo real. Las demás se describen con los nombres de la documentación oficial y están marcadas como no verificadas; si su texto difiere ligeramente, lo importante es el campo que describimos.

**1. Setup wizard.** Pantalla de bienvenida. Pulsamos `Next`.

**2. Destination folder.** La carpeta donde se instala el programa. Por defecto es `C:\Program Files\Jenkins`. La dejamos. Pulsamos `Next`.

**3. Service Logon Credentials.** Es la pantalla que más preguntas genera. El texto de la pantalla dice que Jenkins se instala y se ejecuta como un servicio de Windows independiente y que hay que darle las credenciales de una cuenta para que funcione. El servicio se ejecuta siempre con una **cuenta de Windows**, y esa cuenta decide qué puede hacer Jenkins en el equipo: qué carpetas puede leer y escribir y a qué recursos puede llegar. Hay dos opciones, bajo el título **Logon Type**:

| Opción | Qué es | Cuándo |
|---|---|---|
| **Run service as local or domain user** | Una cuenta normal de Windows, con los campos **Account** y **Password** | Es la que recomienda la documentación y la que usamos: si Jenkins o un plugin se ve comprometido, el daño queda limitado a lo que esa cuenta puede hacer |
| **Run service as LocalSystem (not recommended)** | Una cuenta interna de Windows con privilegios muy altos, casi el equivalente de `root` | El propio instalador la marca como no recomendada. La documentación solo la admite para pruebas locales rápidas o instalaciones de un solo equipo |

Debajo está el botón **Test Credentials** y un aviso en amarillo: *Credentials must be tested to continue*. El botón `Next` **no se activa hasta que la prueba pasa**, así que no se puede saltar este paso.

![Pantalla Service Logon Credentials del instalador, con las dos opciones, los campos Account y Password y el botón Test Credentials](s13-1-img/01-service-logon-credentials.png)

Necesitamos el nombre exacto de la cuenta, con el equipo delante. Lo obtenemos en el `cmd`:

```bash
whoami
```

Devuelve algo con la forma `nombre-del-equipo\usuario`; en el equipo de prueba, `g-cas-3711\mananas`. En **Account** escribimos la cuenta y en **Password** la contraseña con la que se inicia sesión en Windows (la de la cuenta, no un PIN ni la huella). Pulsamos `Test Credentials`.

![Resultado de whoami en un cmd: g-cas-3711\mananas](s13-1-img/03-whoami.png)

En el equipo de prueba, con una cuenta local normal, **la primera prueba falló** con una ventana **Invalid Logon** y este texto:

<pre>
This account either does not have the privilege to logon as a service or the account was unable to be verified.
</pre>

![Ventana Invalid Logon con el aviso de que la cuenta no tiene el derecho de iniciar sesión como servicio](s13-1-img/02-invalid-logon.png)

El mensaje junta dos causas: la contraseña es incorrecta, o la cuenta no tiene el derecho **Log on as a service** (*iniciar sesión como servicio*), el permiso de Windows que autoriza a una cuenta a ejecutar servicios. En el equipo de prueba la causa era la segunda, y es lo esperable con una cuenta normal, así que conviene tratarlo como un paso de la instalación y no como una avería. Para concederlo, sin cerrar el instalador:

1. Pulsamos Windows + R, escribimos `secpol.msc` y pulsamos Enter (directiva de seguridad local).
2. Abrimos `Directivas locales` (`Local Policies`) y pulsamos `Asignación de derechos de usuario` (`User Rights Assignment`).
3. Doble clic en `Iniciar sesión como servicio` (`Log on as a service`). La lista trae por defecto `NT SERVICE\ALL SERVICES` y `SERVICIOS RESTRINGIDOS\TODOS LOS SERVICIOS RESTRINGIDOS`; nuestro usuario no está.
4. Pulsamos `Agregar usuario o grupo...`, escribimos el usuario (por ejemplo `mananas`), `Comprobar nombres` (debe quedar subrayado con el nombre del equipo delante) y `Aceptar`. Después `Aceptar` en la ventana de propiedades.
5. Volvemos al instalador y pulsamos `Test Credentials` otra vez.

![Propiedades de Iniciar sesión como servicio en secpol.msc, con la lista por defecto y el botón Agregar usuario o grupo](s13-1-img/04-secpol-iniciar-sesion-como-servicio.png)

Con el derecho concedido, la prueba pasó escribiendo `.\mananas` en **Account** (el punto y la barra invertida significan «este equipo»). La forma `g-cas-3711\mananas` falló en el primer intento, pero entonces aún faltaba el derecho, así que no se sabe si también habría funcionado después. Recomendamos `.\usuario`, que es la comprobada.

La documentación avisa de que `secpol.msc` puede faltar en algunas ediciones de Windows (la Home, por ejemplo), y no se ha comprobado qué pantalla da en ese caso.

Si la cuenta no tiene contraseña (un servicio no puede arrancar con ella), o no hay forma de dar el derecho en ese equipo, se elige la opción LocalSystem. Es una decisión consciente: en un equipo de aula, donde Jenkins solo sirve para aprender, el riesgo es aceptable. Conviene decirlo en voz alta a los alumnos, porque en una empresa no se haría. Cambia además dónde guarda Jenkins sus datos, que es el siguiente dato no verificado: con `LocalSystem` la carpeta no será la de la cuenta del alumno.

Una consecuencia práctica que importa para S13-2: el servicio no se ejecuta con el entorno del usuario que ha iniciado sesión, sino con el de la cuenta que se haya elegido. Lo que el alumno tiene configurado en su sesión (variables de entorno, credenciales de Git guardadas) puede no verse desde Jenkins. Se retoma en la parte siguiente.

Pulsamos `Next`.

**4. Port selection.** El puerto en el que escuchará Jenkins. Escribimos `8080`, pulsamos `Test Port` y esperamos la marca verde, que indica que el puerto está libre. Si no sale la marca verde, volvemos a la comprobación del `netstat` y averiguamos qué lo ocupa. Pulsamos `Next`.

**5. Select Java home directory.** El instalador busca Java en el equipo y rellena la carpeta del JDK. Es la **carpeta de inicio de Java** (*Java home*): la carpeta que contiene `bin\java.exe`. Comprobamos que corresponde al JDK 21 que vimos antes con `where java` (si la ruta de `where java` termina en `bin\java.exe`, la carpeta del JDK es la ruta sin esa parte final). Si el campo está vacío o apunta a otra versión, pulsamos `Browse` y elegimos la del JDK 21. En el equipo de prueba, la carpeta del JDK 21 es `C:\Program Files\Eclipse Adoptium\jdk-21.0.12.101-hotspot\`. Esta pantalla no se vio durante la instalación real, así que su texto es el de la documentación y no está verificado. Este es el Java con el que se ejecuta Jenkins. No tiene por qué ser el que use Jenkins para construir los proyectos: la documentación dice que el JDK que construye un proyecto es independiente del que ejecuta el controlador. Esa distinción se usa en S13-2. Pulsamos `Next`.

**6. Custom Setup.** Muestra un árbol con lo que se instala. Bajo **Jenkins** hay dos componentes:

- **Start Service**: marcado para instalarse. Hace que el servicio arranque al terminar la instalación.
- **Firewall Exception**: marcado con una X roja, es decir, **no se instala por defecto**. Es la regla que abriría el puerto `8080` del cortafuegos de Windows a otros equipos de la red. Para el curso no hace falta: entramos desde el propio equipo con `localhost`. Solo habría que activarla si otra persona tuviera que conectarse a nuestro Jenkins.

A la derecha, el panel dice que la función necesita unos 52 MB de disco. Dejamos lo que viene marcado y pulsamos `Next`.

![Pantalla Custom Setup con Start Service instalado y Firewall Exception sin instalar](s13-1-img/05-custom-setup.png)

**7. Ready to install** (no verificada). Según la documentación, aquí se pulsa `Install`. Windows pide confirmar con la ventana de control de cuentas de usuario (UAC); pulsamos `Sí`. Avanza una barra de progreso.

**8. Completed** (no verificada). Se pulsa `Finish`.

En el equipo de prueba no se anotaron las pantallas 7 y 8: tras `Next` en `Custom Setup` la instalación terminó.

### Comprobar el servicio

Pulsamos Windows + R, escribimos `services.msc` y pulsamos Enter. Se abre la **consola de servicios**: una lista con todos los servicios de Windows, con su nombre, su estado y su tipo de inicio. Buscamos la fila de Jenkins. Debe aparecer con estado `Running` (En ejecución) y tipo de inicio `Automatic` (Automático): significa que arrancará con el equipo.

Hacemos doble clic sobre la fila. En la pestaña `General` se ve el campo **Nombre del servicio** (*Service name*): es el nombre interno, el que se usa en comandos como `net stop`. Es distinto del nombre que se ve en la lista (el *display name*). En el equipo de prueba los dos son `Jenkins`, y el **Tipo de inicio** es `Automático`.

Desde el `cmd` también se puede localizar:

```bash
sc query state= all | findstr /i jenkins
```

La orden `sc query` lista los servicios, y `findstr /i jenkins` se queda con las líneas que contienen «jenkins» sin distinguir mayúsculas. Hay que dejar un espacio después del `=` de `state=`; es una rareza de `sc`. Con Windows en español la salida usa etiquetas en español:

<pre>
NOMBRE_SERVICIO: Jenkins
NOMBRE_MOSTRAR : Jenkins
</pre>

![Salida de sc query state= all filtrada con findstr: NOMBRE_SERVICIO y NOMBRE_MOSTRAR con el valor Jenkins](s13-1-img/07-sc-query.png)

Ese filtro enseña solo las líneas que contienen «jenkins», así que **no muestra el estado**. Para ver el estado se consulta el servicio por su nombre:

```bash
sc query Jenkins
```

La línea `ESTADO` debe decir `RUNNING` (en ejecución). Esa salida no se ha capturado.

### Primer arranque: desbloquear Jenkins

Abrimos el navegador y escribimos `http://localhost:8080`. **`localhost`** es el nombre que designa a este mismo ordenador. La primera vez, Jenkins tarda uno o dos minutos en terminar de arrancar y muestra una página de espera. Esperamos hasta que aparezca **Unlock Jenkins**. La página tiene el título **Getting Started** y la dirección cambia a `localhost:8080/login?from=%2F`.

Jenkins no deja a nadie entrar en una instalación nueva sin demostrar que tiene acceso al equipo. Para ello genera una **contraseña inicial de administrador** y la guarda en un fichero llamado `initialAdminPassword`. Quien puede leer ese fichero tiene acceso al equipo, y por eso se le deja continuar. La contraseña son 32 caracteres, letras y números.

Hay que abrir ese fichero, y la pregunta es **dónde está**. La documentación oficial no la resuelve (da dos rutas que no coinciden), pero la propia pantalla sí. El texto dice *a password has been written to the log (not sure where to find it?) and this file on the server*, y debajo, en rojo, la ruta completa. En el equipo de prueba, con el servicio ejecutándose con la cuenta `mananas`:

<pre>
C:\Users\Mananas\AppData\Local\Jenkins\.jenkins\secrets\initialAdminPassword
</pre>

![Pantalla Unlock Jenkins con la ruta del fichero initialAdminPassword y el campo Administrator password](s13-1-img/08-unlock-jenkins.png)

De ahí sale algo más: la carpeta de datos de Jenkins (`JENKINS_HOME`) es la que contiene `secrets`, es decir, `C:\Users\<usuario>\AppData\Local\Jenkins\.jenkins`. Es la carpeta del **usuario con el que se ejecuta el servicio**, y por eso la ruta cambia de un equipo a otro. La ruta `C:\Program Files\Jenkins\secrets` que menciona una página de la documentación no es la de este caso. Cada alumno copia la ruta de **su** pantalla.

Tres vías para llegar al fichero, de la más cómoda a la más laboriosa:

1. **Leer la ruta de la pantalla de desbloqueo** (la que usamos y la más fiable, porque la escribe el propio Jenkins con la configuración real). Se copia y se usa con `type`, más abajo.
2. **Construirla.** Con un servicio ejecutándose con una cuenta de usuario, la ruta es `C:\Users\<usuario>\AppData\Local\Jenkins\.jenkins\secrets\initialAdminPassword`, con el usuario con el que se instaló. `AppData` es una carpeta oculta, y por eso conviene teclear la ruta en lugar de buscarla con el Explorador.
3. **Buscarlo.** Si las dos anteriores fallan (por ejemplo, con `LocalSystem`, donde no se ha comprobado dónde queda), se abre un `cmd` con permisos de administrador (se escribe `cmd` en el menú de inicio, clic derecho y `Ejecutar como administrador`) y se ejecuta. Este comando no se ha ejecutado en un equipo con Windows:

```bash
where /r C:\ initialAdminPassword
```

`where /r C:\` busca recursivamente desde la raíz del disco `C:`. Puede tardar un minuto. Si el servicio se ejecuta con LocalSystem, es probable (no verificado) que el fichero esté en una carpeta del sistema que un usuario normal no puede leer, y por eso el `cmd` tiene que ser de administrador.

La documentación añade otra vía: la contraseña también aparece en el fichero de registro `jenkins.err.log`, dentro de la carpeta de datos de Jenkins.

Con la ruta, se lee el contenido en un `cmd` (con una cuenta de usuario no hace falta ser administrador). Las comillas son necesarias si la ruta tiene espacios. Con la ruta del equipo de prueba:

```bash
type "C:\Users\Mananas\AppData\Local\Jenkins\.jenkins\secrets\initialAdminPassword"
```

Cada alumno sustituye la ruta por la de su pantalla. Copiamos el texto que sale, sin espacios al principio ni al final, lo pegamos en el campo **Administrator password** y pulsamos `Continue`. La contraseña inicial solo sirve para este primer desbloqueo y no se comparte.

### Instalar los plugins sugeridos

La pantalla siguiente es **Customize Jenkins** (esta pantalla y la de progreso no se vieron en el equipo de prueba, así que su texto es el de la documentación y no está verificado). Ofrece dos botones:

- **Install suggested plugins**: instala el conjunto que Jenkins recomienda para los usos más comunes.
- **Select plugins to install**: permite elegir uno a uno. Al abrir esa pantalla vienen marcados los sugeridos.

Pulsamos `Install suggested plugins`. Jenkins los descarga e instala mientras muestra el progreso, y tarda unos minutos. Necesita conexión a Internet: los descarga de su centro de actualizaciones (*Update Center*). Desde el aula se comprobó con `curl` que `updates.jenkins.io` responde, aunque con una redirección.

La documentación aclara que se pueden instalar o quitar plugins más adelante desde `Manage Jenkins > Plugins`. Elegir los sugeridos es, por tanto, una decisión reversible. Qué plugins quedan exactamente en cada equipo lo comprobamos en la Práctica 2, porque la lista concreta depende de la versión de Jenkins y no la hemos podido verificar.

### Crear el usuario administrador

Al terminar la instalación de plugins aparece **Create First Admin User**, con cinco campos. Si el navegador está en español, las etiquetas salen en español y los botones en inglés:

| Campo | Qué se escribe |
|---|---|
| **Usuario** | El nombre con el que entraremos en Jenkins (por ejemplo `admin`) |
| **Contraseña** y **Confirma la contraseña** | Una contraseña propia, que se anota en un lugar seguro del alumno |
| **Nombre completo** | El del alumno |
| **Email** | El del alumno. Se usará en S14-2 para los avisos por correo |

Abajo hay dos botones: **Save and Continue** (el que usamos) y, a su lado, el enlace **Skip and continue as admin**. Según la documentación, saltarse este paso deja el usuario `admin` con la contraseña inicial de antes. No lo hacemos: es una buena costumbre tener un usuario propio, y esa contraseña inicial es la de un fichero. En el pie de la página se ve la versión (`Jenkins 2.580.1`). Los datos del usuario no se comparten ni se escriben en ningún repositorio.

![Pantalla Create First Admin User con los campos Usuario, Contraseña, Confirma la contraseña, Nombre completo y Email](s13-1-img/09-create-first-admin-user.png)

Es posible que a continuación aparezca una pantalla de configuración de la instancia con la **Jenkins URL**, la dirección con la que se accede a Jenkins, y después **Jenkins is ready!** (con el botón `Start using Jenkins`) o **Jenkins is almost ready!** (con `Restart`). En el equipo de prueba no se anotó ninguna de las dos, así que están sin verificar. Si la Jenkins URL aparece, se deja la que propone, `http://localhost:8080/`. Si aparece **almost ready**, se pulsa `Restart` y, si la página no se refresca sola en un minuto, se recarga el navegador.

Entramos con el usuario que acabamos de crear y vemos el **panel principal**. La pestaña del navegador dice `Panel de control - Jenkins` y la página `¡Bienvenido a Jenkins!`. A la izquierda hay `Nueva Tarea`, `Historial de trabajos`, `Trabajos en la cola` (con «No hay trabajos en la cola») y `Estado del ejecutor de construcciones`, que marca `0/2`: el controlador tiene dos ejecutores libres, es decir, puede hacer dos builds a la vez. En el centro, una guía con `Create a job` (crear un job) y las opciones de builds distribuidos (`Set up an agent`, `Configure a cloud`), que no usamos. Abajo a la derecha, `REST API` y `Jenkins 2.580.1`. Todavía no hay ningún job. Arriba a la derecha, el engranaje de administración puede llevar un punto rojo: es un aviso del sistema, y no se ha comprobado qué dice.

![Panel principal de Jenkins con el mensaje Bienvenido a Jenkins y el ejecutor en 0/2](s13-1-img/10-panel-principal.png)

### Arrancar y parar Jenkins al día siguiente

Como el tipo de inicio del servicio es `Automático`, Jenkins arranca solo con Windows. Al encender el equipo al día siguiente:

1. Esperamos uno o dos minutos y abrimos `http://localhost:8080`. Entramos con el usuario y la contraseña que creamos.
2. Si no responde, miramos el estado del servicio:

```bash
sc query Jenkins
```

3. Si está parado, lo arrancamos desde un `cmd` abierto como administrador:

```bash
net start Jenkins
```

Para pararlo, el mismo `cmd` de administrador:

```bash
net stop Jenkins
```

Las dos órdenes también se pueden hacer desde la consola de servicios, con el botón derecho sobre la fila de Jenkins (`Iniciar`, `Detener`). Los comandos `net start` y `net stop` no se han ejecutado en el equipo de prueba; el nombre `Jenkins` sí es el comprobado.

### Un aviso que evita un fallo en las siguientes sesiones

Jenkins instalado como servicio ocupa el puerto `8080` **cada vez que arranca el equipo**. Desde esta sesión, cualquier aplicación de Spring Boot arrancada en IntelliJ con su puerto por defecto fallará con `Port 8080 was already in use`, y en S15 el contenedor de nginx de la Demo 2 también usa el 8080 del equipo. No es un error del proyecto: es Jenkins. Hay dos salidas:

- Parar el servicio cuando no se esté usando Jenkins (se practica en la Práctica 2).
- Arrancar la aplicación de Spring Boot en otro puerto, añadiendo a su `application.properties`:

```
server.port=8081
```

Dejamos Jenkins en el `8080`, que es el que usa toda la documentación. Cambiar el puerto de Jenkins después de instalado no se ha comprobado y no se explica aquí.
