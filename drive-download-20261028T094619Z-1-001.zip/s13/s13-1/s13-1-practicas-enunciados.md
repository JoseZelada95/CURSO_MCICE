# S13-1 Prácticas

## Objetivos

Se instala Jenkins en el equipo propio y se explora lo que ha dejado instalado. No hay código que escribir: el trabajo es seguir un procedimiento, comprobar cada paso y anotar lo que se averigua. Los datos que se anotan en estas prácticas (el nombre del servicio, la carpeta de datos, la cuenta con la que se ejecuta, el Java que usa) se necesitan en las partes siguientes, cuando Jenkins construya proyectos.

Se parte de un equipo con JDK 21, Maven, Git e IntelliJ ya instalados.

---

## Práctica 1: Jenkins en cada equipo

Se instala Jenkins con el instalador `.msi` como servicio de Windows, se comprueba que el servicio está en ejecución y que la interfaz responde, y se crea un usuario administrador propio.

**Pasos**

1. Abrimos un `cmd` y comprobamos tres cosas antes de instalar: la versión de Java, que haya un JDK 21 de 64 bits, y que el puerto `8080` esté libre. Si el puerto está ocupado, averiguamos qué programa lo usa y lo paramos.
2. Descargamos desde `https://www.jenkins.io/download/` el instalador de Windows de la línea **LTS** (no la *weekly*). Si Windows muestra el aviso de SmartScreen, lo permitimos con `More info` y `Run anyway`.
3. Ejecutamos el instalador. Dejamos la carpeta de instalación por defecto.
4. En la pantalla **Service Logon Credentials** elegimos **Run service as local or domain user**, escribimos nuestro usuario de Windows en **Account** y su contraseña en **Password**, y pulsamos `Test Credentials`. `Next` no se activa hasta que la prueba pasa. Lo normal es que la primera vez dé **Invalid Logon**: falta el derecho `Log on as a service` y hay que concederlo (ver las pistas). Si el equipo no lo permite, elegimos `LocalSystem` y anotamos que ha sido así.
5. En la pantalla del puerto escribimos `8080` y pulsamos `Test Port` hasta ver la marca verde.
6. En la pantalla del JDK comprobamos que la carpeta propuesta es la del JDK 21 y, si no, la cambiamos con `Browse`. En **Custom Setup** dejamos lo que viene marcado (`Start Service` sí, `Firewall Exception` no) y pulsamos `Next`.
7. Terminamos la instalación y abrimos la consola de servicios (`services.msc`). Comprobamos que el servicio de Jenkins está en estado `Running` y con inicio `Automatic`.
8. Abrimos `http://localhost:8080` en el navegador y esperamos a que aparezca **Unlock Jenkins**.
9. Leemos la ruta de `initialAdminPassword` que muestra la pantalla **Unlock Jenkins**, copiamos el contenido del fichero y desbloqueamos Jenkins. Anotamos esa ruta: la necesitamos en la Práctica 2.
10. Instalamos los plugins sugeridos y esperamos a que termine.
11. Creamos nuestro usuario administrador y entramos en el panel principal.

**Pistas**

- `java -version` indica la versión; la línea de la máquina virtual debe decir `64-Bit`. `where java` indica dónde está el `java.exe`, y la carpeta del JDK es la que contiene la subcarpeta `bin`.
- Para ver quién usa el puerto: `netstat -ano` muestra todas las conexiones y se puede filtrar con `findstr :8080`. La última columna es el identificador del proceso, que se puede consultar con `tasklist`.
- El comando `whoami` devuelve el nombre exacto de la cuenta con la que has iniciado sesión, con la forma `nombre-del-equipo\usuario`. En **Account** conviene escribir `.\usuario` (el punto y la barra significan «este equipo»), que es la forma comprobada.
- La **contraseña** es la de la cuenta de Windows, no el PIN ni la huella. Si la cuenta no tiene contraseña, el servicio no puede arrancar con ella: se usa `LocalSystem`.
- Para conceder el derecho: Windows + R, `secpol.msc`, Enter. Luego `Directivas locales` > `Asignación de derechos de usuario` > doble clic en `Iniciar sesión como servicio` > `Agregar usuario o grupo...` > escribimos nuestro usuario > `Comprobar nombres` > `Aceptar` > `Aceptar`. Volvemos al instalador y repetimos `Test Credentials`. Si `secpol.msc` no existe (pasa en Windows Home), se usa `LocalSystem`.
- Jenkins tarda uno o dos minutos en arrancar la primera vez: si la página no responde, se espera y se recarga.
- La ruta del fichero `initialAdminPassword` depende de la cuenta con que se ejecuta el servicio, y la escribe la propia pantalla **Unlock Jenkins** debajo del texto. Con un servicio de usuario local es del tipo `C:\Users\<usuario>\AppData\Local\Jenkins\.jenkins\secrets\initialAdminPassword`. El comando `type "ruta"` muestra el contenido; las comillas son necesarias si la ruta tiene espacios. Si la pantalla no muestra la ruta, se busca con `where /r C:\ initialAdminPassword` desde un `cmd` con permisos de administrador.
- La contraseña inicial son 32 caracteres. Se copia sin espacios al principio ni al final.
- Los campos de **Create First Admin User** salen en el idioma del navegador (`Usuario`, `Contraseña`, `Confirma la contraseña`, `Nombre completo`, `Email`). Se pulsa `Save and Continue`, no `Skip and continue as admin`.
- Si el asistente termina con **Jenkins is almost ready!**, hay que pulsar `Restart`.
- El usuario y la contraseña de Jenkins se anotan en un lugar propio y seguro. No se suben a ningún repositorio.

---

## Práctica 2: Exploración de Jenkins

Se localiza la carpeta de datos de Jenkins, se identifica qué guarda cada subcarpeta, se revisan los plugins instalados y se para y arranca el servicio desde la consola de servicios.

**Pasos**

1. Localizamos la carpeta de datos de Jenkins (`JENKINS_HOME`). La carpeta que contiene la subcarpeta `secrets` es esa. Anotamos su ruta completa.
2. Abrimos la carpeta de datos en el Explorador de archivos y hacemos una lista de las subcarpetas y los ficheros que contiene. Para cada uno anotamos qué creemos que guarda, y después comprobamos la lista con lo que dice la documentación de Jenkins sobre copias de seguridad (`https://www.jenkins.io/doc/book/system-administration/backing-up/`). Hay carpetas que todavía no existen porque aún no se ha creado ningún job.
3. En la interfaz de Jenkins vamos a `Manage Jenkins > Plugins` y abrimos la lista de plugins instalados. Anotamos el número de plugins y comprobamos si están instalados los cuatro que usaremos en las partes siguientes: **Git**, **Pipeline**, **JUnit** y **Mailer**. Si falta alguno, lo buscamos en la pestaña de plugins disponibles, lo instalamos y anotamos que ha hecho falta.
4. Anotamos la versión de Jenkins que se ve en la parte inferior de la página y la cuenta con la que se ejecuta el servicio (se consulta en las propiedades del servicio, pestaña de inicio de sesión).
5. En la consola de servicios, detenemos el servicio de Jenkins. Comprobamos que la página `http://localhost:8080` deja de responder y que el puerto `8080` ya no aparece en `netstat`.
6. Arrancamos el servicio de nuevo, esperamos a que Jenkins termine de iniciarse y volvemos a entrar con nuestro usuario.
7. Reunimos las notas en una ficha de cinco líneas con: nombre del servicio, ruta de la carpeta de datos, versión de Jenkins, cuenta con la que se ejecuta el servicio y carpeta del JDK que usa.

**Pistas**

- El nombre del servicio se lee en la ventana de propiedades del servicio, en el campo `Nombre del servicio` (`Service name`). Puede no ser igual que el nombre que aparece en la lista, aunque en un equipo de prueba coincidían. También se ve con `sc query state= all | findstr /i jenkins`.
- La interfaz sale en el idioma del navegador y algunos textos siguen en inglés. Los plugins instalados se ven en una pestaña que contiene la palabra `Installed` (o su equivalente en español). La página de plugins está en `http://localhost:8080/manage/pluginManager/`.
- Para ver el estado del servicio desde un `cmd`: `sc query Jenkins`. Para pararlo y arrancarlo, desde un `cmd` de administrador: `net stop Jenkins` y `net start Jenkins`.
- Para detener un servicio basta el botón derecho sobre su fila y `Stop`. Al arrancarlo, Jenkins tarda un rato en estar disponible, igual que la primera vez.
- Si se detiene el servicio, cualquier aplicación que use el puerto `8080` pasa a poder usarlo. Es la forma de resolver el aviso `Port 8080 was already in use` de una aplicación de Spring Boot cuando el culpable es Jenkins.
- Para ver la cuenta del servicio: en las propiedades del servicio, pestaña `Log On` (`Iniciar sesión` en Windows en español).
