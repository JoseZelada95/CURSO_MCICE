# S13-1 Soluciones

Esta parte no tiene código, así que las soluciones describen qué resultado hay que obtener en cada paso, cómo se comprueba y qué hacer cuando no sale. Los datos marcados como verificados salen de una instalación real de Jenkins 2.580.1 en Windows 11 en español, hecha el 21/10/2026 con una cuenta local normal. Lo que no se pudo comprobar se marca como no verificado.

---

## Práctica 1: Jenkins en cada equipo

La instalación es la misma de la Demo 2. Lo que se practica aquí es el orden de los pasos y, sobre todo, la costumbre de comprobar cada uno antes de pasar al siguiente. Casi todos los problemas de instalación se resuelven en las comprobaciones previas o en la pantalla concreta del asistente donde aparecen, y no al final.

### Resultado esperado en cada paso

| Paso | Qué hay que ver |
|---|---|
| Comprobaciones previas | `java -version` muestra la versión 21 en la primera línea y `64-Bit` en la línea de la máquina virtual. `netstat -ano \| findstr :8080` no devuelve ninguna línea |
| Cuenta del servicio | Primera prueba: **Invalid Logon** (verificado, lo esperable con una cuenta normal). Tras conceder el derecho en `secpol.msc`, `Test Credentials` pasa y `Next` se activa. Si se usó `LocalSystem`, se anota |
| Puerto | `Test Port` muestra la marca verde con `8080` (pantalla no verificada) |
| JDK | La carpeta propuesta contiene `bin\java.exe` y corresponde al JDK 21. Ejemplo del equipo de prueba: `C:\Program Files\Eclipse Adoptium\jdk-21.0.12.101-hotspot\` |
| Custom Setup | `Start Service` instalado y `Firewall Exception` con la X roja, sin instalar. Se deja así |
| Consola de servicios | El servicio de Jenkins aparece en `En ejecución` y con inicio `Automático` (verificado el nombre `Jenkins` y el inicio). Equivale a `Running` y `Automatic` en Windows en inglés |
| Navegador | `http://localhost:8080` muestra **Unlock Jenkins** (tras uno o dos minutos de espera la primera vez) |
| Desbloqueo | Con la contraseña inicial se pasa a **Customize Jenkins** (pantalla no verificada) |
| Plugins sugeridos | La instalación termina y aparece **Create First Admin User** |
| Usuario administrador | Tras crearlo se ve el panel principal de Jenkins (`¡Bienvenido a Jenkins!`), sin jobs, con el ejecutor marcando `0/2` |

### Cómo se localiza `initialAdminPassword`

La ruta depende de la cuenta con la que se ejecuta el servicio. La documentación oficial no la fija sin ambigüedad (una página la sitúa bajo `C:\Program Files\Jenkins\secrets` y otro artículo en `LocalAppData` de la cuenta del servicio). La instalación real lo resolvió para una cuenta de usuario local: **la ruta está en `LocalAppData`**. El orden que seguimos es:

1. **La pantalla Unlock Jenkins** muestra la ruta completa debajo del texto *a password has been written to the log (not sure where to find it?) and this file on the server* (verificado). En el equipo de prueba:

<pre>
C:\Users\Mananas\AppData\Local\Jenkins\.jenkins\secrets\initialAdminPassword
</pre>

![Pantalla Unlock Jenkins con la ruta del fichero initialAdminPassword](s13-1-img/08-unlock-jenkins.png)

2. Con la ruta, se lee el contenido en un `cmd` (con una cuenta de usuario no hace falta ser administrador):

```bash
type "C:\Users\Mananas\AppData\Local\Jenkins\.jenkins\secrets\initialAdminPassword"
```

3. Si la pantalla no mostrara la ruta, la búsqueda desde un `cmd` con permisos de administrador (no ejecutada en un equipo con Windows):

```bash
where /r C:\ initialAdminPassword
```

El resultado son 32 caracteres, letras y números. Se copia entero, sin espacios al principio ni al final: un espacio de más es la causa más habitual de que Jenkins rechace la contraseña.

La carpeta de datos (`JENKINS_HOME`) es la que contiene `secrets`: aquí, `C:\Users\Mananas\AppData\Local\Jenkins\.jenkins`. Con `LocalSystem` no se ha comprobado dónde queda.

### Problemas frecuentes

| Síntoma | Causa probable | Qué se hace |
|---|---|---|
| `Test Port` no da la marca verde | Otro programa usa el `8080`, normalmente una aplicación de Spring Boot que quedó arrancada en IntelliJ | Se localiza el proceso con `netstat -ano \| findstr :8080` y `tasklist`, y se detiene (■ en IntelliJ). Si es otro programa, se para o se elige otro puerto en el instalador |
| `Invalid Logon` al probar las credenciales. Texto exacto: *This account either does not have the privilege to logon as a service or the account was unable to be verified* | Contraseña incorrecta, o la cuenta no tiene el derecho `Log on as a service`. **Verificado: en el equipo de prueba era el derecho**, y con una cuenta local normal es lo esperable | Se revisa la contraseña (la de la cuenta, no el PIN). Se prueba `.\usuario` en lugar de `equipo\usuario`. Se concede el derecho: `secpol.msc` > `Directivas locales` > `Asignación de derechos de usuario` > `Iniciar sesión como servicio` > `Agregar usuario o grupo...` > usuario > `Comprobar nombres` > `Aceptar` > `Aceptar`. La lista trae por defecto `NT SERVICE\ALL SERVICES` y `SERVICIOS RESTRINGIDOS\TODOS LOS SERVICIOS RESTRINGIDOS`. Se repite `Test Credentials`. Si `secpol.msc` no existe (Windows Home), o la cuenta no tiene contraseña, se elige `LocalSystem` |
| El instalador no encuentra Java, o el JDK es de 32 bits o de otra versión | El JDK no está registrado en el equipo o es el equivocado | Se elige a mano con `Browse` la carpeta del JDK 21 de 64 bits. La documentación avisa de que si se usa una versión de Java no soportada, el controlador no arranca |
| `http://localhost:8080` no responde justo al terminar | Jenkins sigue arrancando | Se espera uno o dos minutos y se recarga. Si no responde, se comprueba en la consola de servicios que el servicio está `Running` |
| El servicio aparece parado y no arranca | Puerto ocupado, Java incorrecto o cuenta sin permisos sobre la carpeta de datos | Se mira el fichero `jenkins.err.log`. La documentación lo sitúa en la carpeta de datos en una página y en la carpeta de instalación en otra, así que se busca en las dos |
| Jenkins rechaza la contraseña inicial | Se ha copiado con espacios o saltos de línea, o es de otro fichero | Se vuelve a copiar con cuidado y se comprueba que se ha leído `initialAdminPassword` y no otro fichero |
| Tras el desbloqueo no se ve ninguna descarga de plugins | Sin conexión a Internet o bloqueo de red | Se comprueba la conexión. Desde el aula se comprobó con `curl` que `updates.jenkins.io` responde, aunque con una redirección |

### Decisiones tomadas

- **Comprobar antes de instalar.** Los dos fallos más frecuentes (puerto ocupado y Java inadecuado) tienen su propia pantalla en el asistente, pero es más fácil resolverlos antes. El minuto que cuestan los tres comandos ahorra reiniciar el asistente.
- **Línea LTS, no weekly.** La LTS cambia menos y es la que se usa en un entorno profesional. Con unos quince equipos distintos, una versión estable reduce las diferencias entre lo que ve cada alumno.
- **Cuenta de usuario antes que `LocalSystem`.** Es lo que recomienda la documentación porque limita lo que Jenkins puede hacer en el equipo, y el propio instalador marca `LocalSystem` como *not recommended*. `LocalSystem` queda como salida cuando la cuenta no tiene contraseña o el equipo no permite conceder el derecho, y se anota, porque cambia dónde guarda Jenkins sus datos y qué ve el servicio del entorno del usuario.
- **Conceder el derecho como paso normal.** Con una cuenta local normal, la primera prueba falla porque falta `Log on as a service`. Por eso las instrucciones lo cuentan como parte de la instalación, no como una incidencia.
- **Firewall Exception sin marcar.** Se deja como viene: Jenkins solo se usa desde el propio equipo (`localhost`) y no hace falta abrir el puerto al resto de la red.
- **Puerto `8080` por defecto.** Es el que usa toda la documentación y el que ya conocen. Tiene un coste: choca con las aplicaciones de Spring Boot y, más adelante, con el contenedor de nginx. Por eso la Práctica 2 incluye detener el servicio.
- **Plugins sugeridos.** Es la opción que la documentación indica cuando no se sabe qué plugins hacen falta, y es reversible desde `Manage Jenkins > Plugins`.
- **Usuario administrador propio.** Evita depender de la contraseña inicial como contraseña de `admin`.

---

## Práctica 2: Exploración de Jenkins

La Práctica 1 deja Jenkins funcionando. Esta segunda práctica sirve para saber dónde vive cada cosa. Cuando algo se estropea, o hay que mover la configuración a otro equipo, o hay que entender qué añade un plugin, la pregunta es siempre la misma: dónde está.

### Resultado esperado

**La carpeta de datos.** La carpeta que contiene `secrets` es `JENKINS_HOME`. Con el servicio ejecutándose con una cuenta de usuario local es `C:\Users\<usuario>\AppData\Local\Jenkins\.jenkins` (verificado; en el equipo de prueba, `C:\Users\Mananas\AppData\Local\Jenkins\.jenkins`). `AppData` es una carpeta oculta: se llega tecleando la ruta en la barra del Explorador o activando `Mostrar elementos ocultos`. Cada alumno anota la suya. Dentro, según la documentación oficial de copias de seguridad, es de esperar encontrar (no se ha abierto la carpeta del equipo de prueba, así que la lista no está verificada):

| Elemento | Qué guarda |
|---|---|
| `config.xml` y otros ficheros `.xml` | La configuración principal de Jenkins |
| `jobs` | Los jobs que se creen, con las carpetas de sus builds. Ahora puede estar vacía o no existir |
| `plugins` | Los plugins instalados: ficheros `.jpi` o `.hpi` y las carpetas en que se descomprimen |
| `secrets` | Credenciales y claves. Contiene `initialAdminPassword` mientras no se use, y la clave `master.key` que protege el resto. Nunca se copia ni se comparte |
| `war` | El Jenkins descomprimido (la aplicación) |
| `cache` y `tools` | Herramientas descargadas y descomprimidas |

Es normal que aparezcan otras carpetas que la documentación consultada no menciona (por ejemplo, la de los usuarios). Se anotan igualmente, con lo que cada alumno cree que guardan, y se consultan después en la documentación o en clase.

**Los plugins.** Con los sugeridos suele haber varias decenas de plugins instalados. Se cuentan los de la lista. De los cuatro que usaremos, Git, Pipeline, JUnit y Mailer, se espera que estén. No se ha podido comprobar que los sugeridos incluyan los cuatro, y por eso se mira. Si falta alguno, se instala desde la pestaña de plugins disponibles y se anota. Mailer es el plugin que permite a Jenkins enviar correos, y se usará en S14-2.

**Detener y arrancar el servicio.** Se hace desde `services.msc` o con `net stop Jenkins` y `net start Jenkins` desde un `cmd` de administrador (el nombre es el comprobado; los dos comandos no se ejecutaron en el equipo de prueba). Con el servicio detenido, `http://localhost:8080` deja de responder y `netstat -ano | findstr :8080` no devuelve ninguna línea. Al arrancarlo, Jenkins necesita un tiempo para iniciarse, y al volver a entrar se mantienen el usuario, la configuración y los plugins: todo vive en la carpeta de datos, no en el programa en ejecución.

### La ficha de cinco líneas

La ficha final es el entregable de la práctica. Cada alumno la rellena con sus propios valores. Esta es la plantilla:

<pre>
Nombre del servicio (Service name): &lt;lo que muestra la ventana de propiedades&gt;
Carpeta de datos (JENKINS_HOME):    &lt;ruta de la carpeta que contiene secrets&gt;
Versión de Jenkins:                 &lt;la del pie de la página&gt;
Cuenta del servicio:                &lt;usuario local o LocalSystem&gt;
Carpeta del JDK que usa:            &lt;la que se eligió en el instalador&gt;
</pre>

Y la del equipo de prueba, como ejemplo de cómo debe quedar (la cuenta es la que se escribió en el instalador, y el JDK el de ese equipo):

<pre>
Nombre del servicio (Service name): Jenkins
Carpeta de datos (JENKINS_HOME):    C:\Users\Mananas\AppData\Local\Jenkins\.jenkins
Versión de Jenkins:                 2.580.1
Cuenta del servicio:                .\mananas
Carpeta del JDK que usa:            C:\Program Files\Eclipse Adoptium\jdk-21.0.12.101-hotspot\
</pre>

### Decisiones tomadas

- **Anotar en una ficha, no recordar.** El nombre del servicio y la ruta de la carpeta de datos no son iguales en todos los equipos y no se pueden deducir. Tenerlos escritos permite usarlos en las sesiones siguientes sin volver a buscarlos.
- **Comprobar los cuatro plugins ahora.** Son los que usarán los dos jobs de S13-2 y el pipeline de S14. Descubrir en ese momento que falta uno, con la clase en marcha, cuesta más que instalarlo ahora.
- **Parar el servicio.** Es la forma de distinguir Jenkins como programa de Jenkins como servicio. Un programa se para al cerrar su ventana; un servicio sigue funcionando hasta que se le ordena detenerse desde la consola de servicios. Y detener el servicio es también lo que libera el puerto `8080`.
- **No tocar nada dentro de la carpeta de datos.** Se explora solo con el Explorador de archivos, en modo lectura. Un cambio a mano de un fichero de configuración con Jenkins en marcha puede dejar la instalación en un estado que obliga a reinstalar.
