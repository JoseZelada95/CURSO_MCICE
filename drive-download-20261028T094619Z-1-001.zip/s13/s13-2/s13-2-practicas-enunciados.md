# S13-2 Prácticas

## Objetivos

Cada persona construye con su propio Jenkins el proyecto `contactos` desde su propio repositorio, y después recorre el ciclo completo de la integración continua: romper una prueba, ver cómo Jenkins la señala, arreglarla y comprobar que vuelve el verde. No hay código nuevo que escribir. El trabajo es de configuración y de lectura de resultados, y la habilidad que se practica es la central de Jenkins: leer la salida de consola y encontrar la línea que explica un fallo.

Se parte de un Jenkins funcionando en el equipo (S13-1), con el servicio en marcha, y del proyecto `contactos` de las prácticas de S11-1.

El repositorio que se ve en las demos es el del profesor. Cada persona trabaja con **su propio repositorio y sus propias credenciales** (su usuario de GitHub y su token): donde las demos muestran `JD-CFTIC`, se pone el propio. Jenkins mezcla español e inglés en la misma pantalla, así que algún nombre puede no coincidir al 100 % con estas instrucciones; se deduce por la posición y el parecido.

---

## Práctica 1: Job de contactos

Se crea un job freestyle que descarga `contactos` de nuestro repositorio, lo construye con Maven y publica sus pruebas, y se comprueba que termina en verde.

**Pasos**

1. Comprobamos que `contactos` está publicado en nuestro repositorio de GitHub: abrimos su dirección en el navegador y vemos `pom.xml` y `src`. Si todavía no lo está, lo publicamos como en S11-1: repositorio vacío y privado, `git init`, `git add .`, `git commit`, `git remote add origin` y `git push -u origin main`.
2. Abrimos el proyecto en IntelliJ y ejecutamos `mvn clean package`. Anotamos cuántas pruebas se ejecutan y comprobamos que termina en `BUILD SUCCESS`.
3. En Jenkins, en `Administrar Jenkins > Tools`, declaramos el JDK 21 (con su carpeta) y un Maven, cada uno con su nombre, y guardamos.
4. En `Administrar Jenkins > Credentials`, creamos una credencial de tipo `Username with password` con nuestro usuario de GitHub y nuestro token (el token se pega en el campo `Password`), con un ID reconocible.
5. Creamos un job freestyle llamado `contactos`. En **Configurar el origen del código fuente** (*Source Code Management*) elegimos Git, la dirección de nuestro repositorio, la credencial y la rama que usa nuestro repositorio.
6. Añadimos un paso de Maven con los objetivos `clean package` y, en **Acciones para ejecutar después**, la acción que publica los resultados de JUnit, con la ruta de los informes que genera Maven.
7. Guardamos, lanzamos el job y esperamos a que termine. Comprobamos que el build está en verde.
8. Abrimos la consola del build y localizamos la línea que da el total de pruebas y la que da el estado final. Abrimos la página de resultados de las pruebas y comprobamos que el total coincide con el del paso 2.
9. Abrimos el espacio de trabajo del job desde su página y comprobamos qué carpetas y ficheros contiene.

**Pistas**

- El JDK se declara con la carpeta que contiene `bin` (la misma de S13-1), nunca con la ruta de `java.exe`. Si Jenkins responde `Invalid tool home`, se ha escrito otra cosa.
- Si el Maven se instala automáticamente, la primera construcción tarda más, porque Jenkins lo descarga.
- El campo de la rama del job (`Branch Specifier`) trae por defecto `*/master`. Si el repositorio usa `main` y no se cambia, el error de la consola menciona `couldn't find remote ref`.
- Los informes que Maven genera para JUnit están en `target/surefire-reports`, y se recogen con un comodín que coja los ficheros `.xml`. La ruta es relativa al espacio de trabajo.
- Si la credencial es correcta, el aviso rojo del campo del repositorio desaparece. Si no, la consola del build termina con `Authentication failed`: se revisa el usuario y el token, sin espacios al principio ni al final.
- Hasta que el job funciona, es normal que el primer build falle. La consola dice por qué.
- El token no se escribe en el job, ni en el proyecto, ni en ningún documento: solo en la credencial.

---

## Práctica 2: Romper y arreglar una prueba

Se cambia una clase para que una prueba falle, se envía el cambio, se construye, se localiza el fallo en el informe de Jenkins, se corrige y se comprueba que vuelve el verde.

**Pasos**

1. En la clase `Contacto` (paquete `com.curso.model`, fichero `src/main/java/com/curso/model/Contacto.java`), cambiamos `resumen()` para que no deje el espacio después de la coma que separa el correo del teléfono. Guardamos el fichero.
2. Antes de enviar el cambio, ejecutamos en IntelliJ las pruebas de `ContactoTests` y comprobamos que una falla. Es la prueba que Jenkins debería señalar.
3. Enviamos el cambio al repositorio con un mensaje de commit que diga qué se ha cambiado.
4. En Jenkins lanzamos el job y esperamos. Comprobamos que el build termina en rojo.
5. Localizamos el fallo de dos formas: en la consola, buscando la línea que explica el error, y en la página de resultados de las pruebas. Anotamos el nombre de la prueba, el valor esperado y el valor obtenido.
6. Corregimos `resumen()` en IntelliJ y ejecutamos otra vez las pruebas en local. Cuando pasan, enviamos la corrección con su mensaje.
7. Lanzamos el job y comprobamos que vuelve al verde.
8. Abrimos la lista de builds y la página de cambios de cada uno: comprobamos que el historial recoge el build verde, el rojo y el verde, y los dos mensajes de commit.
9. Ampliación: rompemos ahora `emailValido()` de otra forma, enviamos el cambio y comprobamos que Jenkins señala otra prueba distinta. Lo arreglamos.

**Pistas**

- El mensaje de un fallo de prueba tiene siempre la misma forma: el nombre de la clase y del método, el número de línea y los valores `expected` y `but was`. Se lee de abajo arriba: primero el estado final, y después el primer mensaje de error.
- Ejecutar las pruebas en local antes de enviar es más rápido que esperar al servidor, y evita ensuciar el historial con builds rojos que se podían haber visto antes. Jenkins es la red de seguridad, no el primer sitio donde se prueba.
- Todavía no hay construcción automática: cada cambio enviado se construye lanzando el job a mano. Esto se resuelve en S14-1.
- Si Windows muestra acentos mal en la consola de Jenkins (`Luc?a`), es la codificación de la consola y no un error del código.
- El mensaje de un commit se lee después en Jenkins junto al número de build: uno como «cambios» no ayudará a nadie a entender qué rompió el build.
