# S13-2 Demos

## Objetivos

Con Jenkins ya instalado en cada equipo, esta parte construye lo que justifica tenerlo: un job que obtiene el código de un repositorio, lo construye con Maven y publica el resultado de las pruebas. Se llega en dos pasos. Primero un job sencillo que solo ejecuta comandos, para aprender a lanzarlo, a leer su salida de consola, a interpretar el color con el que termina y a mirar qué entorno ve Jenkins al ejecutarse como servicio. Después el job completo, que reúne las tres piezas de cualquier job de integración continua: el repositorio de origen, las herramientas (JDK y Maven) y los pasos que se ejecutan.

No se escribe código nuevo. El proyecto que se construye es `contactos`, el de S11-1 (`s11-1-practicas.zip`): una clase `Contacto` con Lombok y seis pruebas de JUnit, sin base de datos, de modo que se construye en cualquier equipo sin preparar nada más. En la Demo 2 se publica en un repositorio propio, en directo, y a partir de ahí Jenkins lo clona y lo construye.

Este job es la versión manual y completa de lo que el pipeline hará con un fichero en S14-1. Entenderlo con la interfaz gráfica hace que el `Jenkinsfile` resulte una traducción y no un lenguaje nuevo.

**El repositorio de la demo es el del profesor.** La dirección `https://github.com/JD-CFTIC/contactos.git` y el usuario `JD-CFTIC` son los del profesor, y se usan para que se vea el recorrido completo. Cada persona lo hace con **su propio repositorio y sus propias credenciales**: crea su repositorio en su cuenta de GitHub, usa su usuario y su token, y en Jenkins pone su propia dirección. Todo lo que lleve `JD-CFTIC` hay que sustituirlo por lo propio.

**La interfaz de Jenkins mezcla español e inglés en la misma pantalla.** Traduce una parte de los textos y deja otra sin traducir. En la pantalla de un job, por ejemplo, `Configure`, `Triggers`, `Environment` y `Build Steps` salen en inglés, mientras que `Configurar el origen del código fuente` y `Acciones para ejecutar después` salen en español; el panel principal ofrece `Nueva Tarea`. Por eso estas instrucciones pueden no coincidir al 100 % con lo que se ve en cada equipo, pero se pueden deducir por la posición del elemento y por el parecido entre el nombre en inglés y el español. Donde se conoce el nombre que sale en pantalla, se da ese, y entre paréntesis el otro idioma; en el resto se usa el nombre inglés, que es el de la documentación.

Los nombres de las pantallas se han comprobado en una instalación real (Jenkins 2.580.1 en español de España). Los textos de la consola y lo que no se ha podido comprobar siguen la documentación oficial y se marcan con «no verificado».

---

## Demo 1: Primer job freestyle

### Qué es un job freestyle

Un **job** es la descripción de un trabajo que Jenkins debe hacer (S13-1). Jenkins ofrece varios tipos de job, y el más sencillo es el **freestyle** (*estilo libre*): un formulario donde se rellenan, de arriba abajo, de dónde sale el código, cuándo se lanza y qué pasos se ejecutan. Todo se configura con clics y campos, sin escribir un fichero. Cada vez que se lanza, Jenkins crea un **build** con su número (`#1`, `#2`...), su salida de consola y su estado (S13-1).

Cuando un job se ejecuta, Jenkins trabaja dentro de su **espacio de trabajo** (*workspace*): una carpeta propia del job, dentro de la carpeta de datos de Jenkins, donde descarga el código y deja lo que se genera. Para un job llamado `primer-job` es `JENKINS_HOME\workspace\primer-job`, que en el equipo de prueba de S13-1 queda en `C:\Users\Mananas\AppData\Local\Jenkins\.jenkins\workspace\primer-job`.

### Crear el job

1. Abrimos `http://localhost:8080` y entramos con el usuario que creamos en S13-1.
2. Pulsamos `Nueva Tarea` (en la columna izquierda; en inglés, `New Item`).
3. En **Enter an item name** escribimos `primer-job`.
4. En la lista de tipos elegimos **Freestyle project** y pulsamos `OK`.

Se abre la pantalla de configuración del job, con una barra de secciones a la izquierda: `General`, `Configurar el origen del código fuente` (*Source Code Management*), `Triggers`, `Environment`, `Build Steps` y `Acciones para ejecutar después` (*Post-build Actions*). Es una sola página con las secciones una debajo de otra, y los botones `Save` y `Apply` están abajo. Las usaremos de arriba abajo en la Demo 2. Ahora solo necesitamos la de pasos.

### Añadir un paso que ejecuta comandos

Bajamos hasta **Build Steps** y pulsamos `Add build step`. La lista ofrece varios tipos de paso. Elegimos **Execute Windows batch command**: ejecuta los comandos como si los escribiéramos en un `cmd`, que es el intérprete de comandos que usamos desde S02. (En una instalación en Linux se usaría `Execute shell`; el servicio está en Windows y por eso es el de batch.)

En el cuadro **Command** escribimos:

```bash
echo Hola desde Jenkins
whoami
java -version
where java
git --version
mvn -version
echo Fin del job
```

Pulsamos `Save`. Jenkins abre la página del job.

La idea de estos comandos es preguntar a Jenkins qué ve él: `whoami` dice con qué cuenta se ejecuta el servicio, `java -version` y `where java` qué Java encuentra, y `git --version` y `mvn -version` si encuentra Git y Maven. Todo lo que antes comprobábamos en un `cmd` propio lo comprobamos ahora desde dentro de Jenkins, porque **un servicio no ve el entorno de la sesión del usuario**: parte de un entorno propio, con sus variables y su `PATH`. (El `PATH` es la lista de carpetas donde Windows busca los programas cuando escribimos su nombre.) La última línea es un `echo` a propósito: un paso batch termina con el resultado del último comando, y así un `mvn` que no se encuentre aparece como error en la consola pero no tumba el job.

### Lanzar el job y leer la consola

1. En la página del job pulsamos `Build Now` (en la columna izquierda).
2. En **Builds** (parte inferior izquierda) aparece `#1`. Mientras se ejecuta tiene una animación; al terminar, un icono con su color.
3. Pulsamos sobre `#1` y después `Console Output`.

La salida de consola es el registro, línea a línea, de lo que ha hecho Jenkins. Su estructura es siempre la misma (los textos intermedios no se han capturado en el aula):

<pre>
Started by user &lt;usuario&gt;
Running as SYSTEM
Building in workspace C:\Users\Mananas\AppData\Local\Jenkins\.jenkins\workspace\primer-job
...
(las órdenes del paso y su salida)
...
Finished: SUCCESS
</pre>

- `Started by user ...` dice quién lanzó la construcción: una persona con `Build Now`. En S14-1 será el propio Jenkins al detectar un cambio.
- `Building in workspace ...` es la carpeta de trabajo del job. Es de Jenkins, no de nuestro proyecto de IntelliJ.
- Entre medias, cada comando y su salida. La última línea, `Finished: SUCCESS`, es el estado final: lo que se ve de color en la lista de builds. Un build termina en `SUCCESS` cuando el último paso devuelve el código de salida `0` (en Windows y en Maven, el `0` significa «sin errores»).

Comprobamos lo que Jenkins ve:

- **`whoami`:** debe mostrar la cuenta con la que instalamos el servicio, en el equipo de prueba `g-cas-3711\mananas` (S13-1). No es el usuario de Jenkins con el que entramos en la web: es la cuenta de Windows del servicio.
- **`java -version` y `where java`:** el Java que encuentra el servicio en su `PATH`. Puede coincidir con el JDK 21 que usa Jenkins para arrancar (S13-1) o no existir; en ese caso la consola muestra un error de comando no reconocido. Es el Java que usaría un paso que ejecute `java` a mano, y no tiene por qué ser el que use Jenkins para construir.
- **`git --version`:** si Git está instalado para todos los usuarios, debe mostrar la versión. Es el Git que usará Jenkins para clonar el repositorio en la Demo 2.
- **`mvn -version`:** puede fallar con un mensaje de comando no reconocido, y no pasa nada: Maven se configurará en Jenkins en la Demo 2 en lugar de depender del `PATH`.

Con esto queda a la vista la razón de las **herramientas globales** de la Demo 2: no conviene que los jobs dependan de lo que casualmente encuentre el servicio en su `PATH`.

### Provocar un fallo

Volvemos a la página del job, pulsamos `Configure` y, en **Build Steps**, añadimos con `Add build step` un segundo paso **Execute Windows batch command** con este comando, que no existe:

```bash
comando-que-no-existe
```

Pulsamos `Save` y `Build Now`. Aparece `#2`, que termina con otro color. Abrimos su consola: el final es del estilo

<pre>
'comando-que-no-existe' is not recognized as an internal or external command,
operable program or batch file.
...
Build step 'Execute Windows batch command' marked build as failure
Finished: FAILURE
</pre>

(con Windows en español, el mensaje del comando está en español; las dos líneas finales las escribe Jenkins en inglés). Lo importante es el orden de lectura, que vale para cualquier fallo:

1. Se mira la **última línea**: `FAILURE`.
2. Se sube hasta el primer mensaje de error. Casi siempre explica la causa: aquí, el comando no existe.
3. La línea `Build step ... marked build as failure` dice qué paso fue el que falló.

En la lista de **Builds** se ve el historial: `#1` con un color de éxito y `#2` en rojo. Los colores son los estados de S13-1: verde (o azul, en versiones antiguas) = `SUCCESS`, rojo = `FAILURE`.

### Dejar el job como estaba

Entramos en `Configure`, quitamos el segundo paso con la cruz de su esquina y pulsamos `Save`. Lanzamos un `#3` y comprobamos que vuelve a terminar en verde.

---

## Demo 2: Job freestyle con Git y Maven

Esta demo construye el job que justifica Jenkins: clona un proyecto de un repositorio, lo construye con Maven, ejecuta sus pruebas y las publica. Tiene seis partes: publicar el proyecto en un repositorio propio, declarar el JDK y Maven en Jenkins, dar a Jenkins las credenciales para leer el repositorio, crear el job, leer el resultado y, por último, provocar un fallo para ver los dos estados que no son verdes.

### Parte 1: Publicar `contactos` en un repositorio propio

Jenkins construye el código de un repositorio (S13-1), así que lo primero es tener uno. El proyecto es `contactos`, el de S11-1. Lo publicamos en directo. Recordatorio: el repositorio que se ve aquí es el del profesor; cada persona crea el suyo, con su cuenta de GitHub.

**Abrir el proyecto.** `contactos` viene del zip de prácticas de S11-1 (`s11-1-practicas.zip`). Lo descomprimimos y lo abrimos en IntelliJ con `File > Open`, eligiendo la carpeta `contactos` que contiene directamente el `pom.xml` (S06-1). Pulsamos `Trust Project` y, si aparece el aviso `Maven build scripts found`, `Load`. El proyecto tiene la clase `Contacto` (con `resumen()` y `emailValido()`) y dos clases de pruebas, `ContactoTests` (cinco pruebas) y `AplicacionTests` (una, `contextLoads`). No usa base de datos ni variables de entorno.

**Comprobar que construye.** Antes de subirlo comprobamos que el proyecto funciona. Abrimos la terminal de IntelliJ (`Alt+F12`) y ejecutamos:

```bash
mvn clean package
```

Debe terminar así (resumen):

<pre>
[INFO] Running com.curso.AplicacionTests
[INFO] Tests run: 1, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 2.596 s -- in com.curso.AplicacionTests
[INFO] Running com.curso.model.ContactoTests
[INFO] Tests run: 5, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 0.072 s -- in com.curso.model.ContactoTests
[INFO] Tests run: 6, Failures: 0, Errors: 0, Skipped: 0
...
[INFO] BUILD SUCCESS
</pre>

Son los seis tests que Jenkins ejecutará más adelante. Si aquí no está en verde, no tiene sentido continuar: Jenkins no arregla un proyecto que no construye en local.

**Crear el repositorio vacío en GitHub.** En el navegador abrimos `https://github.com/new` con la sesión de nuestra cuenta (aquí, la del profesor, `JD-CFTIC`) y rellenamos:

- **Owner:** nuestra cuenta (aquí, `JD-CFTIC`).
- **Repository name:** `contactos`.
- **Visibility:** `Private`. Un repositorio privado es lo habitual en un proyecto real y nos obliga a darle credenciales a Jenkins, que es justo lo que queremos ver en la Parte 3.
- **Add a README file**, **Add .gitignore** y **Choose a license**: sin marcar. El repositorio tiene que nacer vacío para que su historial no choque con el del proyecto (S11-1).

Pulsamos `Create repository`. GitHub muestra una página con la dirección del repositorio:

```
https://github.com/JD-CFTIC/contactos.git
```

**Enviar el proyecto.** Esto es lo que se aprendió en S11-1. En la terminal de IntelliJ, dentro de la carpeta del proyecto, ejecutamos:

```bash
git init
git add .
git commit -m "Primer commit de contactos"
git remote add origin https://github.com/JD-CFTIC/contactos.git
git push -u origin main
```

La rama se llama `main` porque en S11-1 se configuró `init.defaultBranch main`; si la terminal dice `master`, hay que repetir esa configuración o usar `master` en el último comando y, más adelante, en el job. En el `git push`, el Git Credential Manager de Windows pide el usuario (el propio; aquí, `JD-CFTIC`) y, como contraseña, el **token de acceso personal** de S11-1 (si el gestor lo recuerda de entonces, no pregunta). Si el token se ha perdido o ha caducado, se crea otro como se hizo en S11-1, con el alcance `repo`. El token no se escribe nunca en un fichero ni en un comando.

Las últimas líneas deben ser:

<pre>
To https://github.com/JD-CFTIC/contactos.git
 * [new branch]      main -> main
branch 'main' set up to track 'origin/main'.
</pre>

Actualizamos la página del repositorio en GitHub y comprobamos que aparecen `pom.xml`, `src`, `.gitignore` y `.gitattributes`, y que **no** aparecen `target` ni `.idea`: el `.gitignore` los deja fuera, porque se pueden reconstruir. Eso también ocurrirá en Jenkins: construirá `target` desde cero cada vez.

### Parte 2: Declarar el JDK y Maven en Jenkins

Jenkins no trae Maven ni un JDK para construir proyectos. Hay que decirle cuáles usar, y se hace una sola vez en **Administrar Jenkins** (*Manage Jenkins*) **> Tools** (el engranaje de la parte superior derecha lleva a `Administrar Jenkins`). Cada herramienta se declara con un **nombre** que luego se elige en los jobs, así los jobs no dependen de rutas concretas: si el JDK cambia de carpeta, se cambia en un solo sitio.

La página `Tools` tiene una sección por herramienta. Las que usamos:

**JDK installations.** Pulsamos `Add JDK` y rellenamos:

- **Name:** `jdk-21`.
- **Install automatically:** sin marcar. Jenkins no incluye un descargador de JDK, así que se le da una carpeta que ya está instalada.
- **JAVA_HOME:** la carpeta del JDK 21. Es la carpeta que contiene `bin`, la misma que vimos en S13-1 en la pantalla del instalador. En el equipo de prueba:

```
C:\Program Files\Eclipse Adoptium\jdk-21.0.12.101-hotspot
```

(Escribir solo `java` o `C:\...\bin\java.exe` da el error `Invalid tool home`: la herramienta espera la carpeta del JDK, no el programa. Si la ruta se escribe con la barra final, no está verificado que Jenkins la acepte: se deja sin ella.)

Este es el **JDK con el que se construye el proyecto**, distinto del JDK con el que se ejecuta Jenkins (S13-1). Pueden ser el mismo, pero son dos decisiones separadas.

**Git installations.** Se deja como viene: un Git llamado `Default` con **Path to Git executable** `git`. Basta el nombre porque Git for Windows se instala en el `PATH` del sistema, y lo comprobamos en la Demo 1 con `git --version`.

**Maven installations.** Pulsamos `Add Maven` y rellenamos:

- **Name:** `maven-3.9`.
- **Install automatically:** marcado, con **Install from Apache** y una versión `3.9.x` (la más reciente de esa línea que ofrezca la lista; el proyecto se ha probado con Maven 3.9.11).

La alternativa sería desmarcar la casilla y dar la carpeta de un Maven ya instalado en el equipo (**MAVEN_HOME**). Preferimos la instalación automática porque todos los equipos construyen con la misma versión de Maven, sin depender de dónde la tenga cada uno. Jenkins la descarga la primera vez que un job la necesita y la deja en la carpeta `tools` de su carpeta de datos (la de S13-1, de las «herramientas descargadas y descomprimidas»). Necesita Internet.

Pulsamos `Save` al final de la página.

### Parte 3: Dar a Jenkins las credenciales del repositorio

El repositorio es privado, y Jenkins es un programa más que lo lee: necesita identificarse como lo haría una persona. Una **credencial** es un dato secreto, aquí un usuario y un token, que Jenkins guarda cifrado en su carpeta de datos, con las claves de la carpeta `secrets` (S13-1), y que los jobs usan por su nombre, sin que nadie vea el valor. Por eso la carpeta `secrets` nunca se copia ni se comparte.

Recordatorio: el usuario y el token son los de cada persona. Aquí se ve el usuario del profesor, `JD-CFTIC`, y su token no se enseña nunca.

1. Entramos en `Administrar Jenkins > Credentials`.
2. Pulsamos `System` y, en la página `System`, el enlace **Global** (lleva el texto «Credentials that should be available everywhere»). No hay que pulsar `Add domain`. La ruta que se ve arriba es `Administrar Jenkins > Credentials > System > Global`.
3. Pulsamos `Add Credentials`. Se abre una ventana, **Add Credentials**, con el título «Select a type of credential». Elegimos **Username with password** (la primera opción) y pulsamos `Next`. Las otras opciones (`GitHub App`, `SSH Username with private key`, `Secret file`, `Secret text`, `Certificate`) no se usan aquí. El formulario siguiente no se ha capturado todavía, así que los nombres de los campos son los de la documentación (no verificado):
   - **Scope:** `Global`.
   - **Username:** nuestro usuario de GitHub (aquí, `JD-CFTIC`).
   - **Password:** el token de acceso personal de GitHub (S11-1). El campo se llama `Password`, pero lo que se pega es el token, no la contraseña de la cuenta. Es el mismo que usa Git en la terminal: Jenkins lo usa para clonar.
   - **ID:** `github-contactos`. Es el nombre con el que el job la elige. Una vez guardada, el ID ya no se puede cambiar; si se deja vacío, Jenkins pone uno aleatorio, difícil de reconocer.
   - **Description:** `Token de GitHub para contactos`.
4. Pulsamos `Create` (o `OK`, según la versión).

### Parte 4: Crear el job

1. `Nueva Tarea`, nombre `contactos`, tipo **Freestyle project**, `OK`.
2. En **Configurar el origen del código fuente** (*Source Code Management*), que ofrece `Ninguno` y `Git`, marcamos `Git` y rellenamos:
   - **Repository URL:** la dirección de nuestro repositorio (aquí, la del profesor: `https://github.com/JD-CFTIC/contactos.git`).
   - **Credentials:** elegimos `JD-CFTIC/****** (Token de GitHub para contactos)`. Mientras no hay credencial elegida, aparece un aviso en rojo (`Failed to connect to repository` o `Authentication failed`): desaparece al elegirla.
   - **Branches to build > Branch Specifier:** `*/main`. **Hay que cambiarlo:** el valor por defecto es `*/master` (verificado en Jenkins 2.580.1), y nuestro repositorio usa `main`. Si se deja `*/master`, el build falla con el error `couldn't find remote ref refs/heads/master`. El Branch Specifier indica qué rama construye Jenkins; `*/` significa «de cualquier remoto» (aquí solo hay uno, `origin`).
3. En **Build Steps** pulsamos `Add build step` y elegimos **Invoke top-level Maven targets** (no verificado si aparece sin un plugin adicional; si no aparece, se instala el plugin Maven Integration desde `Manage Jenkins > Plugins`, y la alternativa es un paso **Execute Windows batch command** con `mvn clean package`, que dependería del `PATH`):
   - **Maven Version:** `maven-3.9`, la que declaramos en la Parte 2.
   - **Goals:** `clean package`. Los objetivos (*goals*) son las fases de S03-2, las mismas que escribiríamos tras `mvn` en una terminal: `clean` borra `target`, y `package` compila, ejecuta las pruebas y empaqueta.
4. En **Acciones para ejecutar después** (*Post-build Actions*) pulsamos `Add post-build action` y elegimos **Publish JUnit test result report**. Una **acción posterior a la construcción** es algo que Jenkins hace cuando los pasos terminan. En **Test report XMLs** escribimos:

```
target/surefire-reports/*.xml
```

Es la carpeta de S03-2, donde Maven deja, por cada clase de pruebas, un `.txt` legible y un `.xml` pensado para herramientas externas, como Jenkins. El `*` es un comodín que recoge todos los `.xml` de la carpeta, y la ruta es relativa al espacio de trabajo del job.

Si en la sección **General** o en las opciones avanzadas aparece un campo **JDK**, elegimos `jdk-21` (no verificado dónde aparece exactamente: depende de la versión). Pulsamos `Save`.

### Parte 5: Primera construcción y resultados

Pulsamos `Build Now`. La primera construcción tarda más que las siguientes porque Jenkins descarga Maven (Parte 2) y, después, las dependencias del proyecto. Estas últimas las guarda en la carpeta `.m2` de la cuenta del servicio (S02-1), no en la de IntelliJ, aunque pueden coincidir si el servicio usa nuestra misma cuenta, como en el equipo de prueba.

Abrimos `#1` y `Console Output`. La salida tiene tres bloques (los textos de Jenkins no están capturados):

<pre>
Started by user &lt;usuario&gt;
...
(Jenkins clona el repositorio en el espacio de trabajo)
...
(Maven: el mismo registro que vimos en la terminal)
[INFO] Tests run: 6, Failures: 0, Errors: 0, Skipped: 0
[INFO] BUILD SUCCESS
...
Recording test results
Finished: SUCCESS
</pre>

1. **Jenkins clona el repositorio**, con la credencial elegida. El espacio de trabajo `...\workspace\contactos` contiene ahora el proyecto, sin `target` hasta que Maven lo crea.
2. **Maven construye**, y el registro es el mismo de la terminal de IntelliJ. Desde dentro de Jenkins, el comando es `mvn clean package`.
3. **Jenkins recoge los resultados** con la acción de JUnit (`Recording test results`).

De vuelta en la página del job, vemos que `#1` está en verde y que ha aparecido el enlace **Latest Test Result**. Lo abrimos: la página lista las pruebas agrupadas por paquete y clase, con un total de seis, ninguna fallida: una en `com.curso` (`AplicacionTests`) y cinco en `com.curso.model` (`ContactoTests`). Cada prueba se puede abrir. Esta página es lo que convierte las pruebas de JUnit de S02-2 en algo útil para todo el equipo: cualquiera ve qué se ha probado, sin tener el proyecto.

Pulsamos `Changes` en la página del build: Jenkins enseña los commits que entraron desde el build anterior, con su mensaje y su autor. Es otra razón para los mensajes claros de S11-1.

### Parte 6: Provocar un fallo y ver los estados

Hasta ahora todo es verde. Provocamos fallos para ver los otros estados de S13-1.

**Fallo de prueba (rojo).** En IntelliJ abrimos la clase `Contacto`, que está en el paquete `com.curso.model` (`src > main > java > com.curso > model > Contacto`, es decir, el fichero `src/main/java/com/curso/model/Contacto.java`). El método `emailValido()` está al final del fichero y su `return` es la línea 65. Quitamos la última condición, de modo que quede:

```java
return email.contains("@") && email.contains(".");
```

Con esto, un correo con espacios (`lucia @example.com`) pasaría por válido, y la prueba `emailSinPuntoOConEspaciosNoEsValido` debe detectarlo. Enviamos el cambio:

```bash
git add .
git commit -m "Quitar la comprobación de espacios del correo"
git push
```

En Jenkins pulsamos `Build Now`. Todavía no se construye solo: eso llega con el sondeo del repositorio en S14-1. `#2` termina en rojo. La consola explica exactamente qué pasa (salida real de Maven):

<pre>
[ERROR] Tests run: 5, Failures: 1, Errors: 0, Skipped: 0, Time elapsed: 0.084 s &lt;&lt;&lt; FAILURE! -- in com.curso.model.ContactoTests
[ERROR] com.curso.model.ContactoTests.emailSinPuntoOConEspaciosNoEsValido -- Time elapsed: 0.022 s &lt;&lt;&lt; FAILURE!
org.opentest4j.AssertionFailedError: expected: &lt;false&gt; but was: &lt;true&gt;
	at com.curso.model.ContactoTests.emailSinPuntoOConEspaciosNoEsValido(ContactoTests.java:57)
[ERROR] Failures:
[ERROR]   ContactoTests.emailSinPuntoOConEspaciosNoEsValido:57 expected: &lt;false&gt; but was: &lt;true&gt;
[ERROR] Tests run: 6, Failures: 1, Errors: 0, Skipped: 0
[INFO] BUILD FAILURE
...
Finished: FAILURE
</pre>

Se lee de abajo arriba, como en la Demo 1: `FAILURE`, y hacia arriba el primer mensaje con la causa. La línea `ContactoTests.emailSinPuntoOConEspaciosNoEsValido:57` da la clase, el método y el número de línea de la prueba, y `expected: <false> but was: <true>` dice que se esperaba un correo no válido y el código lo dio por válido. Volvemos a la página del build y abrimos **Test Result**: Jenkins muestra la prueba fallida con su mensaje y, según la versión, desde qué construcción falla. Para leer la consola no hace falta ir a la terminal de nadie.

El resultado es **rojo (Failed)** porque Maven termina con `BUILD FAILURE` y código de salida `1`, y entonces Jenkins marca el build como fallido (con una prueba rota, Maven se detiene antes de empaquetar).

**Fallo de prueba (amarillo).** Hay otra forma de tratar las pruebas rotas. En `Configure`, en los **Goals** del paso Maven, añadimos una propiedad de Maven (S03-2, `-D`):

```
clean package -Dmaven.test.failure.ignore=true
```

Con ella, Maven no se detiene por un test roto: muestra `[ERROR] There are test failures.` pero termina con `BUILD SUCCESS` (comprobado con Maven 3.9.11). Es entonces la acción de JUnit la que decide: según su documentación, con al menos una prueba fallida marca el build como **Unstable** (amarillo). Guardamos, pulsamos `Build Now` y `#3` termina en amarillo. Es la distinción de S13-1:

- **Failed (rojo):** el build no llegó a terminar bien.
- **Unstable (amarillo):** el build terminó, pero las pruebas encontraron errores.

Cuál elegir es una decisión de equipo. Con el rojo, una prueba rota tumba el job y no se genera el JAR. Con el amarillo, el job completa todo y avisa de forma distinta. Para el curso nos quedamos con el rojo, que es el comportamiento por defecto y el más sencillo de entender. Quitamos la propiedad de los **Goals** y volvemos a `clean package`.

**Arreglar.** Volvemos a poner la condición en `emailValido()`:

```java
return email.contains("@") && email.contains(".") && !email.contains(" ");
```

```bash
git add .
git commit -m "Restaurar la comprobación de espacios del correo"
git push
```

Lanzamos `Build Now`. `#4` vuelve a verde, y la lista de **Builds** muestra el historial entero: verde, rojo, amarillo, verde. A partir de dos construcciones, la página del job puede mostrar un gráfico con la evolución de las pruebas (no verificado el nombre exacto del gráfico). Ese historial, con el commit que rompió una prueba y el que la arregló, es lo que justifica la integración continua.
