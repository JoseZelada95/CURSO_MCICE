# S13-2 Soluciones

Esta parte no tiene código nuevo, así que las soluciones recogen los valores de configuración que hay que rellenar, el resultado esperado en cada paso, cómo se lee cada fallo y las decisiones tomadas. Jenkins mezcla español e inglés en la misma pantalla, así que algún nombre puede no coincidir al 100 % con estas instrucciones, pero se deduce por la posición y el parecido. Los nombres de las pantallas se han comprobado en una instalación real (Jenkins 2.580.1 en español); lo demás sigue la documentación oficial y lo que no se ha comparado con una ejecución real se marca como no verificado. El repositorio y el usuario de las demos (`JD-CFTIC`) son los del profesor: cada persona usa los suyos. Las salidas de Maven sí son reales (Maven 3.9.11, JDK 21, `contactos` de S11-1).

---

## Práctica 1: Job de contactos

### Valores de configuración

Son los valores que dejan el job funcionando. Los que dependen de la persona (usuario, repositorio, rutas) se indican con un marcador.

| Dónde | Campo | Valor |
|---|---|---|
| `Administrar Jenkins > Tools` > **JDK installations** | Name | `jdk-21` |
| | Install automatically | sin marcar |
| | JAVA_HOME | la carpeta que contiene `bin` del JDK 21, por ejemplo `C:\Program Files\Eclipse Adoptium\jdk-21.0.12.101-hotspot` |
| `Administrar Jenkins > Tools` > **Maven installations** | Name | `maven-3.9` |
| | Install automatically | marcado, **Install from Apache**, una versión `3.9.x` |
| `Administrar Jenkins > Credentials` > `System` > `Global` > `Add Credentials` | Tipo (ventana `Add Credentials`, luego `Next`) | `Username with password` |
| | Scope | `Global` (no verificado: formulario sin capturar) |
| | Username | `<usuario de GitHub>` |
| | Password | `<token de acceso personal>` (el campo se llama `Password`, pero se pega el token) |
| | ID | `github-contactos` |
| Job `contactos` > **Configurar el origen del código fuente** (*Source Code Management*) | Git > Repository URL | `https://github.com/<usuario>/contactos.git` (el propio, no el del profesor) |
| | Credentials | la creada, `<usuario>/****** (...)` |
| | Branch Specifier | `*/main` (el valor por defecto es `*/master`, verificado: hay que cambiarlo) |
| Job `contactos` > **Build Steps** | Invoke top-level Maven targets > Maven Version | `maven-3.9` |
| | Goals | `clean package` |
| Job `contactos` > **Acciones para ejecutar después** (*Post-build Actions*) | Publish JUnit test result report > Test report XMLs | `target/surefire-reports/*.xml` |

### Resultado esperado

| Paso | Qué hay que ver |
|---|---|
| 2 | `mvn clean package` en local: `Tests run: 6, Failures: 0, Errors: 0, Skipped: 0` y `BUILD SUCCESS` |
| 3 y 4 | Al guardar, Jenkins no da errores. En la lista de credenciales aparece la nueva |
| 5 | En el campo del repositorio no queda ningún aviso rojo |
| 7 | El build termina en verde. La primera vez tarda más porque Jenkins descarga Maven y las dependencias |
| 8 | En la consola, la línea `Tests run: 6, Failures: 0, Errors: 0, Skipped: 0`, y al final `Finished: SUCCESS`. En la página de resultados, seis pruebas: una en `com.curso` (`AplicacionTests`) y cinco en `com.curso.model` (`ContactoTests`) |
| 9 | El espacio de trabajo contiene el proyecto clonado (`pom.xml`, `src`, `.gitignore`, `.gitattributes`), la carpeta `target` que Maven crea en cada construcción y la carpeta `.git`, porque Jenkins clona con Git (no verificado el contenido exacto). No contiene `.idea`: el `.gitignore` lo dejó fuera del repositorio |

### Problemas frecuentes

| Síntoma | Causa probable | Qué se hace |
|---|---|---|
| `Invalid tool home` al guardar el JDK o el Maven | Se ha escrito la ruta de un programa (`java.exe`, `mvn.cmd`) en lugar de la carpeta | Se escribe la carpeta del JDK o de Maven, la que contiene `bin` |
| `Authentication failed` o un aviso rojo en el campo del repositorio | El usuario o el token son incorrectos, el token ha caducado, o no tiene el alcance `repo` | Se crea de nuevo la credencial, o se genera otro token como en S11-1. Se copia sin espacios sobrantes |
| `couldn't find remote ref refs/heads/master` | El **Branch Specifier** se ha dejado con su valor por defecto, `*/master`, y el repositorio usa `main` | Se cambia **Branch Specifier** a `*/main` |
| `Cannot run program "git"` o `git` no se reconoce | El servicio no ve Git en su `PATH` | Se comprueba con `git --version` en un job (Demo 1). Si falla, se reinstala Git for Windows para todos los usuarios y se reinicia el servicio. Como alternativa, se escribe la ruta completa de `git.exe` en `Administrar Jenkins > Tools > Git` |
| `No test report files were found` | La ruta del informe es incorrecta, o la construcción falló antes de ejecutar las pruebas (por ejemplo, un error de compilación) | Se comprueba la ruta `target/surefire-reports/*.xml`. Si la construcción falló antes, se corrige primero ese fallo |
| El job se queda esperando sin arrancar | El ejecutor está ocupado o el controlador no tiene ejecutores libres | Se mira el cuadro `Estado del ejecutor de construcciones` y se esperan unos segundos (el controlador tiene dos) |
| Un acento sale como `?` en la consola (`Luc?a`) | Es la codificación de la consola de Jenkins en Windows, no un error del código | No se hace nada: las pruebas no se ven afectadas |
| `mvn` no se reconoce con un paso de Windows batch | El servicio no ve Maven en su `PATH` | Se usa el paso **Invoke top-level Maven targets** con la herramienta declarada, que es justo la razón de `Tools` |

### Decisiones tomadas

- **Repositorio privado y credencial.** Es lo habitual en un proyecto real, y obliga a tratar los secretos como secretos: el token vive en la credencial de Jenkins y nunca en el job, en el proyecto o en un documento.
- **Maven instalado automáticamente.** Así todos los equipos construyen con la misma versión sin depender de dónde la tenga instalada cada uno. El coste es la primera descarga, que necesita Internet.
- **JDK con su carpeta, Maven automático.** Jenkins no incluye un descargador de JDK, así que el JDK que ya está instalado en el equipo (S13-1) se declara por su carpeta. Son dos decisiones separadas: el JDK con el que Jenkins arranca no tiene por qué ser el que construye los proyectos.
- **`clean package`, no `install`.** El job solo necesita comprobar que el proyecto compila y pasa sus pruebas. `install` copiaría el JAR a la carpeta `.m2` de la cuenta del servicio, y no hace falta para un proyecto de un solo módulo.
- **El rojo por defecto.** Con `clean package`, una prueba rota hace que Maven termine con `BUILD FAILURE` y Jenkins marque el build como fallido. Es el comportamiento más sencillo y el que se mantiene en el curso.

---

## Práctica 2: Romper y arreglar una prueba

### El cambio que rompe

El cambio es quitar el espacio que sigue a la coma entre el correo y el teléfono en `resumen()`. En `Contacto.java` (paquete `com.curso.model`, ruta `src/main/java/com/curso/model/Contacto.java`), la línea es:

```java
// Línea original: el separador entre el correo y el teléfono es una coma y un espacio.
return nombre + " (" + email + ", " + telefono + ")";
```

y pasa a ser:

```java
// Línea rota: sin el espacio detrás de la coma.
return nombre + " (" + email + "," + telefono + ")";
```

La prueba `resumenIncluyeEmailYTelefono` espera `Lucía Pérez (lucia@example.com, 600123456)` y recibe el texto sin espacio, por lo que falla. Los datos siguientes son reales (Maven 3.9.11).

### Resultado esperado

En local, tras el paso 2: una prueba falla en `ContactoTests` y las otras cuatro pasan.

En la consola del build rojo de Jenkins, la parte que explica el fallo es:

<pre>
[ERROR] Tests run: 5, Failures: 1, Errors: 0, Skipped: 0, Time elapsed: 0.094 s &lt;&lt;&lt; FAILURE! -- in com.curso.model.ContactoTests
[ERROR] com.curso.model.ContactoTests.resumenIncluyeEmailYTelefono -- Time elapsed: 0.025 s &lt;&lt;&lt; FAILURE!
org.opentest4j.AssertionFailedError: expected: &lt;Lucía Pérez (lucia@example.com, 600123456)&gt; but was: &lt;Lucía Pérez (lucia@example.com,600123456)&gt;
	at com.curso.model.ContactoTests.resumenIncluyeEmailYTelefono(ContactoTests.java:42)
[ERROR] Failures:
[ERROR]   ContactoTests.resumenIncluyeEmailYTelefono:42 expected: &lt;Lucía Pérez (lucia@example.com, 600123456)&gt; but was: &lt;Lucía Pérez (lucia@example.com,600123456)&gt;
[ERROR] Tests run: 6, Failures: 1, Errors: 0, Skipped: 0
[INFO] BUILD FAILURE
</pre>

(Con una consola de Windows sin UTF-8, `Lucía Pérez` puede salir como `Luc?a P?rez`: es solo la codificación al mostrar el texto.)

Se lee así, de abajo arriba:

1. **Estado final:** `BUILD FAILURE`, y en Jenkins, `Finished: FAILURE`.
2. **Dónde:** `ContactoTests.resumenIncluyeEmailYTelefono:42` es la clase, el método y la línea de la prueba (`ContactoTests.java`).
3. **Qué:** `expected` es lo que la prueba esperaba y `but was` lo que devolvió el código. Comparando las dos cadenas, la diferencia es una: falta el espacio después de la coma.

En la página de resultados de las pruebas, el mismo fallo aparece con el nombre de la prueba y su mensaje, y las otras cinco pruebas, en verde.

### La corrección y el historial

La corrección es devolver la línea original. Tras enviarla y lanzar el job, vuelve el verde. La lista de builds queda así:

| Build | Estado | Qué cambió |
|---|---|---|
| `#1` | verde | La primera construcción, de la Práctica 1 |
| `#2` | rojo | El commit que quitó el espacio |
| `#3` | verde | El commit que lo restauró |

La página `Changes` de `#2` y de `#3` muestra los mensajes de commit. Si los mensajes son claros («Quitar el espacio del resumen», «Restaurar el espacio del resumen»), el historial se entiende sin abrir el código.

### Ampliación

Un cambio distinto en `emailValido()` (por ejemplo, quitar la condición del punto) hace fallar otra prueba: `emailSinPuntoOConEspaciosNoEsValido`, con la misma estructura de mensaje (`expected: <false> but was: <true>`). Así se comprueba que Jenkins señala la prueba concreta que rompe cada cambio, y no solo que «algo falla».

### Decisiones tomadas

- **Romper `resumen()` y no `emailValido()`.** La demo de la parte rompe `emailValido()`. Aquí se rompe otro método para que cada persona tenga que localizar un fallo nuevo y no repetir el de la demo. El fallo de `resumen()` además enseña a comparar dos cadenas casi iguales, que es lo más habitual en un fallo real.
- **Ejecutar las pruebas en local antes de enviar.** Jenkins es la red de seguridad, no el primer sitio donde se prueba. Un fallo visible en el IDE se corrige en segundos, y no ensucia el historial con builds rojos que se podían haber evitado. Aquí se rompe a propósito para ver la señal.
- **Lanzar el job a mano.** Todavía no hay construcción automática. Que cada cambio exija un paso manual hace visible lo que se automatiza en S14-1 con el sondeo del repositorio.
- **Dos formas de localizar el fallo.** La consola es la fuente completa y la página de resultados la vista ordenada. Saber leer la consola es la habilidad central, porque no todos los fallos son de una prueba: un error de compilación no genera informe de pruebas, y solo la consola lo explica.
- **Mensajes de commit claros.** Jenkins muestra el mensaje junto a cada build. Un historial legible es parte del resultado de la práctica.
