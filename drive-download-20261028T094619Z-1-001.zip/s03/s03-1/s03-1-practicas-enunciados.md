# S03-1 Prácticas

## Objetivos

En las demos hemos añadido una dependencia que ya conocíamos (`commons-lang3`), hemos visto qué impide realmente el scope `test`, y hemos leído por primera vez un árbol de dependencias transitivas. En estas tres prácticas se da un paso más en cada uno de esos frentes: se busca una librería sin que nadie la haya elegido antes, se combinan varias librerías en una misma clase, y se provoca y se resuelve a propósito un conflicto real entre dos librerías que traen versiones distintas de una misma dependencia transitiva.

Las tres prácticas se hacen en el mismo proyecto Maven, `s03-1-practicas`, que se va ampliando: cada práctica añade dependencias o clases nuevas sobre lo que ya existe.

---

## Práctica 1: Búsqueda en Maven Central

Hasta ahora, cada dependencia que se ha usado en el curso ya venía decidida en el enunciado: solo había que copiarla. En esta práctica se busca por primera vez una librería sin esa ayuda, usando únicamente su nombre y el buscador de Maven Central. Es la habilidad que hace falta cada vez que un proyecto real necesita una función nueva y no viene ya indicado qué librería usar.

Se crea un proyecto Maven nuevo, `s03-1-practicas`, y se buscan y añaden tres librerías: **Gson** (para trabajar con JSON, aunque en esta práctica no se llegue a usar), **Guava** (una librería de utilidades de Google con clases para colecciones, texto y más) y **SLF4J** (una interfaz estándar de logging que usan la mayoría de librerías Java). No se escribe ninguna clase todavía: el objetivo de esta práctica es únicamente añadir las tres dependencias y comprobar que el proyecto sigue compilando.

**Pasos**

1. Creamos un nuevo proyecto Maven en IntelliJ desde `File > New > Project`, con `Java` seleccionado en el panel izquierdo: Name `s03-1-practicas`, Build system `Maven`, JDK `21` y **Add sample code** desmarcada. En `Advanced Settings`, usamos `com.curso` como GroupId y `s03-1-practicas` como ArtifactId.
2. Creamos el paquete `com.curso`: clic derecho sobre `src/main/java`, `New > Package`, escribimos `com.curso` y pulsamos Enter. Aunque esta práctica no lleve ninguna clase, el paquete hace falta ya para la Práctica 2.
3. Buscamos `gson` en [search.maven.org](https://search.maven.org), localizamos el artefacto `com.google.code.gson:gson` y copiamos sus coordenadas (`groupId`, `artifactId`, `version`) a una nueva sección `<dependencies>` del `pom.xml`.
4. Repetimos el paso anterior con `guava` (artefacto `com.google.guava:guava`) y con `slf4j-api` (artefacto `org.slf4j:slf4j-api`).
5. Guardamos el `pom.xml` y dejamos que IntelliJ recargue el proyecto (o ejecutamos `mvn compile` desde la terminal) para comprobar que Maven descarga las tres librerías sin errores.

**Pistas**

- En search.maven.org, cada resultado muestra un bloque de XML listo para copiar con las coordenadas ya rellenas: no hace falta escribirlas a mano.
- Hay más de un artefacto con "guava" en el nombre; el que se usa en el curso es `com.google.guava:guava`, no ninguna de sus variantes.
- Si el proyecto compila sin errores (`BUILD SUCCESS`), las tres dependencias están correctamente añadidas aunque todavía no se haya escrito ningún código que las use.
- Si IntelliJ no recarga solo el `pom.xml` (por ejemplo, al escribir código en la Práctica 2 una clase de Guava aparece como desconocida), fuerza la recarga desde el panel Maven (icono de refrescar) o con clic derecho sobre `pom.xml` > `Maven` > `Reload project`.

---

## Práctica 2: Clase Formateador

En el mismo proyecto, se implementa la clase `Formateador` combinando métodos de `commons-lang3` (que hay que añadir al `pom.xml`, siguiendo el mismo paso que en la Demo 1) y de Guava (ya añadida en la Práctica 1). El objetivo es resolver tres tareas de formato de texto habituales sin implementar ninguna a mano: capitalizar un texto, rellenar un número con ceros por la izquierda y unir una lista de textos con un separador.

**Pasos**

1. Añadimos `commons-lang3` al `pom.xml` del proyecto, con las mismas coordenadas usadas en la Demo 1.
2. Creamos la clase `Formateador` en el paquete `com.curso`.
3. Añadimos el método `capitalizarTexto(String texto)`, que devuelva el texto con la primera letra en mayúscula y el resto en minúscula.
4. Añadimos el método `rellenarConCeros(int numero, int longitud)`, que devuelva el número convertido a texto y rellenado con ceros a la izquierda hasta alcanzar la longitud indicada.
5. Añadimos el método `unirConSeparador(List<String> elementos, String separador)`, que devuelva los elementos de la lista unidos en un único texto, separados por el separador indicado.
6. Añadimos un `main()` que pruebe los tres métodos con distintos valores y comprobamos los resultados.

**Pistas**

- `capitalizarTexto` puede resolverse igual que `capitalizar` en la Demo 1: `StringUtils.capitalize()` combinado con `toLowerCase()`.
- Para rellenar con ceros, `commons-lang3` tiene un método en `StringUtils` que rellena un texto por la izquierda hasta una longitud dada, indicando el carácter de relleno. Antes hay que convertir el número a `String` con `String.valueOf(numero)`.
- Para unir una lista con un separador, Guava tiene una clase `Joiner` en el paquete `com.google.common.base`: se configura con `Joiner.on(separador)` y se usa con `.join(elementos)`.
- `List<String>` necesita `import java.util.List;`. Una lista de prueba puede crearse con `List.of("a", "b", "c")`.

---

## Práctica 3: Exclusión de dependencia transitiva

En la Demo 3 se ha visto que una dependencia trae otras por debajo sin que se pidan explícitamente (dependencias transitivas). Cuando dos librerías del mismo proyecto necesitan, cada una por su lado, una versión distinta de la misma dependencia transitiva, Maven tiene que elegir una sola versión para todo el proyecto, y por defecto no siempre elige la que conviene. En esta práctica se provoca ese conflicto a propósito con dos librerías reales y se resuelve con las dos herramientas que Maven ofrece para este problema: `<exclusions>` para quitar una dependencia transitiva no deseada, y `<dependencyManagement>` para fijar la versión correcta en todo el proyecto.

Se añaden al mismo proyecto dos librerías nuevas, **opencsv** (para leer y escribir ficheros CSV) y **commons-configuration2** (para leer ficheros de configuración), que no se llegan a usar en ningún código: el objetivo de la práctica es únicamente el `pom.xml`.

**Pasos**

1. Añadimos `com.opencsv:opencsv:4.6` al `pom.xml`.
2. Añadimos `org.apache.commons:commons-configuration2:2.11.0` al `pom.xml`.
3. Ejecutamos `mvn dependency:tree` desde la terminal y localizamos, entre las líneas marcadas como `omitted for conflict`, una dependencia transitiva que ambas librerías traen en versiones distintas.
4. Añadimos una sección `<exclusions>` dentro de la dependencia que trae la versión más antigua, excluyendo esa dependencia transitiva concreta.
5. Añadimos una sección `<dependencyManagement>` al `pom.xml` que fije la versión correcta (la más reciente de las dos) para todo el proyecto.
6. Volvemos a ejecutar `mvn dependency:tree` y comprobamos que la dependencia conflictiva aparece ahora una sola vez, con la versión fijada en el paso anterior.

**Pistas**

- En la salida de `mvn dependency:tree`, cada línea `(groupId:artifactId:jar:versión:scope - omitted for conflict with versión)` indica una versión que Maven ha descartado a favor de otra. Ambos artefactos conflictivos comparten `groupId` y `artifactId`; solo cambia la versión.
- `<exclusions>` va dentro de la etiqueta `<dependency>` de la librería cuya versión transitiva no queremos, con una `<exclusion>` que repite el `groupId` y `artifactId` (sin versión) de la dependencia a excluir.
- `<dependencyManagement>` va fuera de `<dependencies>`, como una sección propia al mismo nivel, con su propio bloque `<dependencies>` dentro. Fija la versión, pero no añade la dependencia al proyecto por sí sola: si ningún `<dependency>` la declara (directa o transitivamente), `dependencyManagement` no descarga nada.
- Después de aplicar la exclusión y el `dependencyManagement`, el proyecto tiene que seguir compilando (`mvn compile`) sin errores.
