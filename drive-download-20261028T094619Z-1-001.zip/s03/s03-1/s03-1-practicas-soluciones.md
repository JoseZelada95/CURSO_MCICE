# S03-1 Soluciones

## Práctica 1: Búsqueda en Maven Central

Las tres librerías se buscan en [search.maven.org](https://search.maven.org) por su nombre y se añaden al `pom.xml` con sus coordenadas exactas:

```xml
<dependency>
    <groupId>com.google.code.gson</groupId>
    <artifactId>gson</artifactId>
    <version>2.11.0</version>
</dependency>
<dependency>
    <groupId>com.google.guava</groupId>
    <artifactId>guava</artifactId>
    <version>33.3.1-jre</version>
</dependency>
<dependency>
    <groupId>org.slf4j</groupId>
    <artifactId>slf4j-api</artifactId>
    <version>2.0.16</version>
</dependency>
```

Al ejecutar `mvn compile`, Maven descarga las tres y el proyecto compila sin errores, aunque todavía no exista ninguna clase que las use:

<pre>
[INFO] --- resources:3.3.1:resources (default-resources) @ s03-1-practicas ---
[INFO] skip non existing resourceDirectory /ruta/s03-1-practicas/src/main/resources
[INFO]
[INFO] --- compiler:3.13.0:compile (default-compile) @ s03-1-practicas ---
[INFO] No sources to compile
[INFO] BUILD SUCCESS
</pre>

**Decisiones tomadas**

- Guava tiene el sufijo `-jre` en la versión (`33.3.1-jre`) porque el proyecto publica dos variantes: una para JRE completo (`-jre`) y otra reducida para Android (`-android`). En un proyecto de escritorio o servidor como los del curso, siempre se usa la variante `-jre`.
- No se ha escrito ninguna clase en esta práctica a propósito: el objetivo es exclusivamente comprobar que la búsqueda y la declaración de coordenadas son correctas. Usar estas librerías en código llega en la Práctica 2 (Guava) y en partes posteriores (Gson, SLF4J).
- El paquete `com.curso` se crea igualmente en esta práctica, aunque no reciba ninguna clase todavía: sin él, la Práctica 2 no tendría dónde crear `Formateador`.

---

## Práctica 2: Clase Formateador

Añadimos `commons-lang3` al `pom.xml`, con la misma versión que en la Demo 1:

```xml
<dependency>
    <groupId>org.apache.commons</groupId>
    <artifactId>commons-lang3</artifactId>
    <version>3.17.0</version>
</dependency>
```

```java
package com.curso;

import java.util.List;

// Importamos StringUtils de commons-lang3, añadida a este proyecto al empezar
// esta práctica siguiendo el mismo paso que en la Demo 1: declarar sus
// coordenadas en el pom.xml y dejar que Maven la descargue sola.
import org.apache.commons.lang3.StringUtils;

// Importamos Joiner de Guava, añadida en la Práctica 1 junto con Gson y SLF4J.
// Maven ya la tiene descargada en ~/.m2 desde entonces.
import com.google.common.base.Joiner;

/**
 * S03-1 Práctica 2: Clase Formateador
 *
 * Objetivo: aplicar Commons Lang y Guava, dos librerías externas, en tres
 * tareas de formato de texto distintas.
 *
 * Aplica las técnicas de S03:
 *   1. Añadir una dependencia externa al pom.xml (commons-lang3, S03-1 Demo 1)
 *   2. Usar métodos de dos librerías distintas en la misma clase
 *
 * Concepto clave: para tareas de formato habituales conviene usar una
 * librería ya probada en lugar de escribir la lógica desde cero.
 */
public class Formateador {

    /**
     * Pone en mayúscula solo la primera letra del texto recibido.
     *
     * Ejemplo:
     *   capitalizarTexto("HOLA")   →  "Hola"
     *   capitalizarTexto("adiós")  →  "Adiós"
     *
     * @param texto el texto a formatear
     * @return el texto con la primera letra en mayúscula y el resto en minúscula
     */
    public String capitalizarTexto(String texto) {
        // toLowerCase() convierte todo a minúsculas: "HOLA" → "hola"
        // StringUtils.capitalize() pone en mayúscula solo la primera letra: "hola" → "Hola"
        return StringUtils.capitalize(texto.toLowerCase());
    }

    /**
     * Rellena un número con ceros a la izquierda hasta alcanzar la longitud indicada.
     *
     * Ejemplo:
     *   rellenarConCeros(7, 4)    →  "0007"
     *   rellenarConCeros(123, 5)  →  "00123"
     *
     * @param numero el número a rellenar
     * @param longitud la longitud final del resultado
     * @return el número convertido a texto y rellenado con ceros a la izquierda
     */
    public String rellenarConCeros(int numero, int longitud) {
        // String.valueOf() convierte el int a String: 7 → "7"
        // StringUtils.leftPad() añade el carácter indicado a la izquierda hasta
        // completar la longitud pedida: "7" con longitud 4 y relleno '0' → "0007"
        return StringUtils.leftPad(String.valueOf(numero), longitud, '0');
    }

    /**
     * Une una lista de textos en una sola cadena, separados por el separador indicado.
     *
     * Ejemplo:
     *   unirConSeparador(List.of("pan", "leche", "huevos"), ", ")  →  "pan, leche, huevos"
     *   unirConSeparador(List.of("a", "b"), "-")                  →  "a-b"
     *
     * @param elementos la lista de textos a unir
     * @param separador el texto que se coloca entre cada dos elementos
     * @return los elementos de la lista unidos con el separador
     */
    public String unirConSeparador(List<String> elementos, String separador) {
        // Joiner.on(separador) crea un "unidor" configurado con ese separador.
        // .join(elementos) recorre la lista y concatena sus elementos,
        // intercalando el separador entre cada dos: no se añade al principio ni al final.
        return Joiner.on(separador).join(elementos);
    }

    // main() permite ejecutar esta clase directamente desde IntelliJ (▶)
    // sin necesidad de un framework. Útil para probar los tres métodos antes de escribir tests.
    public static void main(String[] args) {
        // Creamos una instancia para poder llamar a los métodos de instancia
        Formateador formateador = new Formateador();

        // Probamos capitalizarTexto con distintas entradas
        System.out.println(formateador.capitalizarTexto("HOLA"));    // → Hola
        System.out.println(formateador.capitalizarTexto("adiós"));   // → Adiós

        // Probamos rellenarConCeros con distintas longitudes
        System.out.println(formateador.rellenarConCeros(7, 4));      // → 0007
        System.out.println(formateador.rellenarConCeros(123, 5));    // → 00123

        // Probamos unirConSeparador con distintas listas y separadores
        System.out.println(formateador.unirConSeparador(List.of("pan", "leche", "huevos"), ", "));  // → pan, leche, huevos
        System.out.println(formateador.unirConSeparador(List.of("a", "b"), "-"));                    // → a-b
    }
}
```

Salida esperada:

<pre>
Hola
Adiós
0007
00123
pan, leche, huevos
a-b
</pre>

**Decisiones tomadas**

- `capitalizarTexto` reutiliza exactamente el mismo patrón que `capitalizar` de la Demo 1: no tenía sentido inventar una variante distinta para el mismo problema.
- Se ha usado `Joiner` de Guava en lugar de `String.join()`, que ya trae el propio Java, precisamente para practicar Guava: `String.join(separador, elementos)` habría resuelto lo mismo sin necesidad de la librería. En un proyecto real, si el propio lenguaje ya resuelve el problema, no hace falta añadir una dependencia para ello; aquí se elige `Joiner` porque el objetivo de la práctica es usar Guava.
- Los tres métodos son independientes entre sí: no comparten estado ni se llaman unos a otros, así que cada uno se puede probar por separado sin depender del resultado de los demás.

---

## Práctica 3: Exclusión de dependencia transitiva

Añadimos las dos librerías al `pom.xml`, sin ningún ajuste todavía:

```xml
<dependency>
    <groupId>com.opencsv</groupId>
    <artifactId>opencsv</artifactId>
    <version>4.6</version>
</dependency>
<dependency>
    <groupId>org.apache.commons</groupId>
    <artifactId>commons-configuration2</artifactId>
    <version>2.11.0</version>
</dependency>
```

Ejecutamos `mvn dependency:tree` y aparece el conflicto:

<pre>
[INFO] com.curso:s03-1-practicas:jar:1.0-SNAPSHOT
[INFO] +- com.google.code.gson:gson:jar:2.11.0:compile
[INFO] +- com.google.guava:guava:jar:33.3.1-jre:compile
[INFO] +- org.slf4j:slf4j-api:jar:2.0.16:compile
[INFO] +- org.apache.commons:commons-lang3:jar:3.17.0:compile
[INFO] +- com.opencsv:opencsv:jar:4.6:compile
[INFO] |  +- (org.apache.commons:commons-lang3:jar:3.8.1:compile - omitted for conflict with 3.17.0)
[INFO] |  +- org.apache.commons:commons-text:jar:1.3:compile
[INFO] |  |  \- (org.apache.commons:commons-lang3:jar:3.7:compile - omitted for conflict with 3.17.0)
[INFO] |  +- commons-beanutils:commons-beanutils:jar:1.9.3:compile
[INFO] |  |  \- commons-collections:commons-collections:jar:3.2.2:compile
[INFO] |  \- org.apache.commons:commons-collections4:jar:4.2:compile
[INFO] \- org.apache.commons:commons-configuration2:jar:2.11.0:compile
[INFO]    +- (org.apache.commons:commons-lang3:jar:3.14.0:compile - omitted for conflict with 3.17.0)
[INFO]    +- (org.apache.commons:commons-text:jar:1.12.0:compile - omitted for conflict with 1.3)
[INFO]    \- commons-logging:commons-logging:jar:1.3.2:compile
</pre>

La dependencia conflictiva es `org.apache.commons:commons-text`: `opencsv` trae transitivamente la versión `1.3`, y `commons-configuration2` necesita la `1.12.0`. Como ninguna de las dos está declarada directamente en el `pom.xml` (ambas llegan solo por transitividad), Maven aplica su regla por defecto ("gana la que esté más cerca en el árbol y, en caso de empate, la primera declarada") y elige la `1.3`, que es justo la más antigua de las dos y la que `commons-configuration2` no puede garantizar que funcione con su código. Es un conflicto silencioso: el proyecto compila igualmente, porque en tiempo de compilación no hace falta acceder a ningún método concreto de `commons-text`. El riesgo aparece en tiempo de ejecución, si `commons-configuration2` llama en algún momento a un método de `commons-text` que solo existe desde la versión `1.12.0`: el fallo (`NoSuchMethodError`) aparecería mucho más tarde y sin relación aparente con el `pom.xml`.

### La solución

Excluimos `commons-text` de `opencsv`, ya que es la que trae la versión antigua y no deseada:

```xml
<dependency>
    <groupId>com.opencsv</groupId>
    <artifactId>opencsv</artifactId>
    <version>4.6</version>
    <exclusions>
        <!-- opencsv trae commons-text 1.3, una versión antigua que además
             es la que Maven elegiría por defecto por ser la primera declarada.
             La excluimos para que no compita con la que necesita commons-configuration2. -->
        <exclusion>
            <groupId>org.apache.commons</groupId>
            <artifactId>commons-text</artifactId>
        </exclusion>
    </exclusions>
</dependency>
```

Y fijamos con `<dependencyManagement>` la versión correcta para todo el proyecto, para que el resultado no dependa del orden en que se declaren las dependencias ni de qué versión traiga cada una por su cuenta:

```xml
<dependencyManagement>
    <dependencies>
        <!-- Fija la versión de commons-text para todo el proyecto, gane quien gane
             la resolución de dependencias transitivas: opencsv y commons-configuration2
             arrastran versiones distintas (1.3 y 1.12.0) y esta es la que necesitamos. -->
        <dependency>
            <groupId>org.apache.commons</groupId>
            <artifactId>commons-text</artifactId>
            <version>1.12.0</version>
        </dependency>
    </dependencies>
</dependencyManagement>
```

Al volver a ejecutar `mvn dependency:tree`, `commons-text` aparece una sola vez, con la versión correcta:

<pre>
[INFO] com.curso:s03-1-practicas:jar:1.0-SNAPSHOT
[INFO] +- com.google.code.gson:gson:jar:2.11.0:compile
[INFO] +- com.google.guava:guava:jar:33.3.1-jre:compile
[INFO] +- org.slf4j:slf4j-api:jar:2.0.16:compile
[INFO] +- org.apache.commons:commons-lang3:jar:3.17.0:compile
[INFO] +- com.opencsv:opencsv:jar:4.6:compile
[INFO] |  +- (org.apache.commons:commons-lang3:jar:3.8.1:compile - omitted for conflict with 3.17.0)
[INFO] |  +- commons-beanutils:commons-beanutils:jar:1.9.3:compile
[INFO] |  |  \- commons-collections:commons-collections:jar:3.2.2:compile
[INFO] |  \- org.apache.commons:commons-collections4:jar:4.2:compile
[INFO] \- org.apache.commons:commons-configuration2:jar:2.11.0:compile
[INFO]    +- (org.apache.commons:commons-lang3:jar:3.14.0:compile - omitted for conflict with 3.17.0)
[INFO]    +- org.apache.commons:commons-text:jar:1.12.0:compile (version managed from 1.12.0)
[INFO]    \- commons-logging:commons-logging:jar:1.3.2:compile
</pre>

`commons-text:1.3` ha desaparecido del árbol (la exclusión ha impedido que Maven lo descargue siquiera), y `commons-text:1.12.0` aparece ahora una única vez, marcado como `(version managed from 1.12.0)`: la etiqueta indica que esa versión viene fijada por `dependencyManagement`. El proyecto sigue compilando sin errores (`mvn compile` → `BUILD SUCCESS`).

**Decisiones tomadas**

- Se ha excluido `commons-text` de `opencsv` y no al revés (de `commons-configuration2`) porque `opencsv` es quien trae la versión que no queremos, la `1.3`. Excluirla de `commons-configuration2` habría sido excluir la dependencia correcta y dejar viva la incorrecta.
- `<dependencyManagement>` se ha añadido además de la exclusión, no en su lugar, porque cada una resuelve una parte distinta del problema: `<exclusions>` impide que `opencsv` traiga su versión antigua; `<dependencyManagement>` garantiza que, declare quien declare `commons-text` en el futuro (una tercera librería, por ejemplo), la versión que se use sea siempre la `1.12.0`, sin depender de qué dependencia se declaró antes en el `pom.xml`.
- No se ha tocado la dependencia transitiva `commons-lang3` que también aparece en conflicto en el árbol (`3.8.1` y `3.14.0` frente a nuestro `3.17.0`): ese conflicto ya está resuelto correctamente, porque `commons-lang3` es una dependencia declarada directamente en el proyecto (Práctica 2) y una dependencia directa siempre gana a cualquier versión transitiva, sea cual sea. La práctica se centra en el caso en que eso no basta por sí solo: cuando el conflicto ocurre entre dos dependencias transitivas y ninguna versión está ya fijada de forma directa.
