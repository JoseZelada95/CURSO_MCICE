# S03-1 Demos

## Objetivos

Hasta ahora Maven se ha usado casi en exclusiva para organizar proyectos: la estructura de carpetas, el `pom.xml` mínimo, y una única dependencia (JUnit) que ya venía dada. En esta parte Maven pasa a ser lo que es de verdad: un gestor de librerías. Añadimos por primera vez una dependencia externa por decisión propia, entendemos qué significa el **scope** de una dependencia y qué impide realmente, y aprendemos a ver las dependencias que Maven trae sin que nadie las haya pedido (las **dependencias transitivas**), además de cómo se organizan los repositorios en un entorno de empresa.

Al terminar esta parte los alumnos son capaces de:
- Añadir una dependencia externa al `pom.xml` a partir de sus coordenadas y usar sus clases en el código.
- Explicar qué diferencia el scope `compile` del scope `test`, y comprobar en la práctica qué impide cada uno.
- Leer la salida de `mvn dependency:tree` e identificar las dependencias transitivas de una librería.
- Explicar qué es un repositorio corporativo y por qué existe además de Maven Central.

**Para qué sirve este proyecto**: en cualquier trabajo real, el primer paso al necesitar una funcionalidad que Java no trae de fábrica (dar formato a un texto, parsear JSON, conectar con una base de datos...) es buscar una librería que ya la resuelva y añadirla al proyecto. Este es el proyecto donde se practica exactamente eso por primera vez en el curso: no seguir instrucciones para añadir una dependencia que el profesor ya había decidido, sino entender el mecanismo completo para poder repetirlo con cualquier otra librería, incluidas Spring e Hibernate más adelante.

---

## Demo 1: Primera dependencia externa

Una **dependencia** es una librería que el proyecto necesita pero que no forma parte del propio proyecto: alguien más la ha escrito, la ha publicado y Maven se encarga de descargarla. Hasta ahora el curso ha usado una sola dependencia, JUnit, y siempre porque el profesor ya la había añadido al `pom.xml`. En esta demo la añadimos nosotros por primera vez, decidiendo qué necesitamos y buscándolo.

### Por qué no escribir la función a mano

Vamos a necesitar una función que ponga en mayúscula la primera letra de un texto y el resto en minúscula. Es una operación tan común (nombres, títulos, direcciones) que sería raro tener que escribirla desde cero en cada proyecto Java: seguro que alguien ya la ha escrito, probado y publicado. Esa es la razón de ser de las dependencias: en lugar de reinventar una función sencilla pero con casos límite (¿y si el texto está vacío? ¿y si ya empieza en mayúscula?), se usa una librería que ya los ha resuelto.

La librería que vamos a usar es **Apache Commons Lang** (`commons-lang3`), una de las más usadas del ecosistema Java: añade cientos de utilidades pequeñas para trabajar con `String`, números, fechas y objetos que el propio Java no incluye.

### Crear el proyecto

Como en cada parte del curso, empezamos creando un proyecto Maven nuevo. Vamos a `File > New > Project`. En el panel izquierdo, dentro de `New Project`, seleccionamos `Java`.

Rellenamos los campos:

- **Name**: `s03-1-demos`.
- **Location**: la carpeta donde guardamos los proyectos del curso.
- **Create Git repository**: desmarcada.
- **Build system**: `Maven`.
- **JDK**: `21`.
- **Add sample code**: desmarcada. A partir de S02-1 solo se marca la primera vez; en todos los demás proyectos del curso, incluido este, `src/main/java` sale vacía.

Desplegamos `Advanced Settings` y rellenamos:

- **GroupId**: `com.curso`.
- **ArtifactId**: `s03-1-demos`.

Hacemos clic en `Create`.

Con `Add sample code` desmarcada, `src/main/java` está vacía: no hay ni paquete ni clase. Creamos el paquete a mano, clic derecho sobre `src/main/java`, `New > Package`, escribimos `com.curso` y pulsamos Enter. Todavía no hay ninguna clase dentro; la crearemos al escribir `Formateador` más abajo.

El `pom.xml` que genera el asistente en este punto es mínimo: solo las coordenadas del proyecto y las propiedades de versión de Java y codificación, sin ninguna dependencia todavía.

### Buscar y añadir la dependencia

Toda dependencia Maven se identifica con tres datos, que ya conocemos porque son los mismos que `groupId`, `artifactId` y `version` del propio proyecto (S02-1): quién la publica, cómo se llama y qué versión se usa. Buscamos `commons-lang3` en [search.maven.org](https://search.maven.org) y copiamos sus coordenadas dentro de una nueva sección `<dependencies>` del `pom.xml`:

```xml
<dependencies>
    <dependency>
        <groupId>org.apache.commons</groupId>
        <artifactId>commons-lang3</artifactId>
        <version>3.17.0</version>
    </dependency>
</dependencies>
```

Cada `<dependency>` tiene que ir siempre dentro de un bloque `<dependencies>`: es lo que le indica a Maven que ese fragmento describe una dependencia del proyecto y no otra cosa. Un `<dependency>` suelto, fuera de `<dependencies>`, hace que el `pom.xml` sea inválido.

Al guardar el fichero, IntelliJ suele detectar el cambio (aparece un icono de recarga de Maven en la esquina del editor) y descarga el JAR de **Maven Central**, el repositorio público que ya conocemos de S02-1, guardándolo en la caché local `~/.m2`, sin necesidad de hacer nada más. Si ese icono no aparece o la clase de la librería no se reconoce más adelante al escribir código, es que IntelliJ no ha recargado el proyecto: hay que forzarlo a mano, con el panel Maven (icono `m` en la barra lateral derecha del IDE) y el botón de refrescar (dos flechas circulares) arriba del panel, o con clic derecho sobre `pom.xml` en el árbol de proyecto y `Maven > Reload project`.

Una vez recargado, cualquier clase pública de `commons-lang3` está disponible en el proyecto exactamente igual que si la hubiéramos escrito nosotros: sin instalar nada más, sin copiar ningún fichero a mano.

Para comprobar que la descarga se ha producido, abrimos la terminal de IntelliJ y ejecutamos:

```bash
mvn compile
```

Salida esperada:

<pre>
[INFO] BUILD SUCCESS
</pre>

Un `BUILD SUCCESS` confirma que Maven ha encontrado y descargado `commons-lang3` correctamente: si la dependencia no se hubiera descargado, `mvn compile` fallaría con un error indicando que no puede resolverla. La ruta exacta donde ha quedado guardada es `~/.m2/repository/org/apache/commons/commons-lang3/3.17.0/`: reproduce el `groupId` como carpetas (`org/apache/commons`), luego el `artifactId` (`commons-lang3`) y luego la versión (`3.17.0`), la misma lógica de carpetas que ya vimos con los paquetes Java en S02-1, aplicada ahora a cómo Maven organiza su caché. No hace falta navegar hasta ahí a mano para seguir con la demo: el `BUILD SUCCESS` ya es la confirmación.

### La clase Formateador

Creamos la clase `Formateador` en el paquete `com.curso` (clic derecho sobre `com.curso`, `New > Java Class`) con un método que usa `StringUtils`, una de las clases de utilidades de `commons-lang3`:

```java
package com.curso;

// Importamos StringUtils de la librería commons-lang3.
// Maven la ha descargado automáticamente al guardar el pom.xml, la primera vez
// que se pidió una dependencia externa en este proyecto.
// Sin Maven habría que buscar el JAR, descargarlo a mano y añadirlo al classpath.
import org.apache.commons.lang3.StringUtils;

/**
 * S03-1 Demo 1: Primera dependencia externa
 *
 * Objetivo: añadir una librería externa (commons-lang3) al proyecto y usar
 * uno de sus métodos.
 *
 * Lo que hace este ejemplo:
 *   - Define la clase Formateador en el paquete com.curso
 *   - Implementa el método capitalizar(texto), que usa StringUtils.capitalize
 *     de commons-lang3 para poner en mayúscula solo la primera letra
 *
 * Concepto clave: usar una librería externa consiste en declarar sus
 * coordenadas (groupId, artifactId, version) en el pom.xml. A partir de ahí,
 * sus clases están disponibles en el proyecto exactamente igual que las
 * propias, sin ningún paso adicional.
 */
public class Formateador {

    /**
     * Pone en mayúscula solo la primera letra del texto recibido,
     * y el resto en minúscula.
     *
     * Ejemplo:
     *   capitalizar("JUAN")   →  "Juan"
     *   capitalizar("maría")  →  "María"
     *
     * @param texto el texto a formatear
     * @return el texto con la primera letra en mayúscula
     */
    public String capitalizar(String texto) {
        // toLowerCase() convierte todo el texto a minúsculas: "JUAN" → "juan"
        // StringUtils.capitalize() pone en mayúscula solo la primera letra: "juan" → "Juan"
        // Encadenamos los dos: primero bajamos todo, luego capitalizamos la primera letra.
        return StringUtils.capitalize(texto.toLowerCase());
    }

    // main() permite ejecutar esta clase directamente desde IntelliJ (▶)
    // sin necesidad de un framework. Útil para probar el método antes de escribir tests.
    public static void main(String[] args) {
        // Creamos una instancia para poder llamar al método de instancia
        Formateador formateador = new Formateador();

        // Probamos con distintas entradas para ver que el formateo funciona
        // independientemente de cómo venga el texto
        System.out.println(formateador.capitalizar("JUAN"));    // → Juan
        System.out.println(formateador.capitalizar("maría"));   // → María
        System.out.println(formateador.capitalizar("PEDRO"));   // → Pedro
    }
}
```

`StringUtils.capitalize()` es un **método estático** (S02-1): se llama directamente sobre la clase, `StringUtils.capitalize(...)`, sin necesidad de crear una instancia de `StringUtils`. Muchas clases de utilidades como esta están pensadas para usarse así, ya que no guardan ningún estado propio: solo transforman lo que reciben y lo devuelven.

Hacemos clic en ▶ junto al `main()`.

Salida esperada:

<pre>
Juan
María
Pedro
</pre>

---

## Demo 2: Scopes de dependencia

En S02-2 se añadió JUnit al proyecto con `<scope>test</scope>` y se dijo que ese scope hace que la dependencia "solo esté disponible en `src/test/java`". Hasta ahora esa frase había que creérsela. En esta demo comprobamos qué significa exactamente y qué pasa si se incumple.

### Qué es el scope

Cuando se declara una dependencia en el `pom.xml`, por defecto (si no se pone nada, como en `commons-lang3`) su scope es `compile`: está disponible en todo el proyecto, tanto en `src/main/java` como en `src/test/java`, y además se empaqueta dentro del `.jar` final.

El scope `test` restringe eso: la dependencia solo se pone a disposición del compilador cuando compila lo que hay en `src/test/java`. Para el compilador, cuando compila `src/main/java`, esa librería directamente no existe, como si no estuviera en el `pom.xml`.

Por eso JUnit lleva `scope test`: solo sirve para escribir tests, así que no tiene sentido que viaje dentro de la aplicación final que se despliega en producción. Si no llevara ese scope, cada `.jar` generado incluiría de regalo una librería de testing que el usuario final nunca necesita, y cualquier clase de `src/main/java` podría importar `@Test` sin que nadie se diera cuenta del error de diseño.

Añadimos JUnit al `pom.xml` con scope `test`:

```xml
<dependency>
    <groupId>org.junit.jupiter</groupId>
    <artifactId>junit-jupiter</artifactId>
    <version>5.11.0</version>
    <scope>test</scope>
</dependency>
```

### Un test sobre Formateador

Escribimos un test sobre el método `capitalizar()` de la Demo 1, en `src/test/java/com/curso/FormateadorTest.java`:

```java
package com.curso;

// Importamos assertEquals y @Test de JUnit 5, disponibles porque el pom.xml
// declara junit-jupiter con scope test: solo se puede usar aquí,
// en src/test/java, no en src/main/java.
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

/**
 * S03-1 Demo 2: Test de Formateador
 *
 * Objetivo: comprobar con JUnit que capitalizar() funciona con distintas
 * formas de entrada, y ver dónde se puede y dónde no se puede usar JUnit.
 *
 * Lo que hace este ejemplo:
 *   - Verifica capitalizar() con texto en mayúsculas y en minúsculas
 *
 * Concepto clave: esta clase existe solo gracias al scope test de
 * junit-jupiter en el pom.xml. Si el scope fuera compile, JUnit acompañaría
 * también al código de producción, algo que no interesa.
 */
class FormateadorTest {

    // JUnit crea una nueva instancia de la clase de test por cada @Test,
    // por lo que este campo se reinicia automáticamente entre tests.
    private final Formateador formateador = new Formateador();

    @Test
    void capitalizaTextoEnMayusculas() {
        assertEquals("Juan", formateador.capitalizar("JUAN"));
    }

    @Test
    void capitalizaTextoEnMinusculas() {
        assertEquals("María", formateador.capitalizar("maría"));
    }
}
```

Ejecutamos `mvn test` desde la terminal:

Salida esperada:

<pre>
[INFO] --- surefire:3.2.5:test (default-test) @ s03-1-demos ---
[INFO] Using auto detected provider org.apache.maven.surefire.junitplatform.JUnitPlatformProvider
[INFO]
[INFO] -------------------------------------------------------
[INFO]  T E S T S
[INFO] -------------------------------------------------------
[INFO] Running com.curso.FormateadorTest
[INFO] Tests run: 2, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 0.066 s -- in com.curso.FormateadorTest
[INFO]
[INFO] Results:
[INFO]
[INFO] Tests run: 2, Failures: 0, Errors: 0, Skipped: 0
[INFO]
[INFO] BUILD SUCCESS
</pre>

Los dos tests pasan. JUnit funciona con normalidad dentro de `src/test/java`, que es exactamente para lo que su scope lo habilita.

### Qué pasa si se usa JUnit fuera de src/test/java

Ahora probamos a romper la regla a propósito. Añadimos temporalmente este import al principio de `Formateador.java`, en `src/main/java`:

```java
import org.junit.jupiter.api.Test;
```

Ejecutamos `mvn compile`:

Salida esperada:

<pre>
[ERROR] COMPILATION ERROR :
[INFO] -------------------------------------------------------------
[ERROR] /ruta/s03-1-demos/src/main/java/com/curso/Formateador.java:[8,29] package org.junit.jupiter.api does not exist
[INFO] 1 error
[INFO] -------------------------------------------------------------
[INFO] BUILD FAILURE
</pre>

El compilador dice literalmente que el paquete `org.junit.jupiter.api` no existe, aunque acabamos de comprobar que sí existe y que los tests lo usan sin problema. Lo que ocurre es que, para el código de `src/main/java`, JUnit **no está en el classpath**: el scope `test` hace que Maven ni siquiera se lo ofrezca al compilador cuando compila producción. No es una restricción de estilo ni una convención que se pueda saltar con cuidado: el compilador físicamente no encuentra las clases.

Quitamos el import y volvemos a compilar para dejar el proyecto en su estado correcto:

<pre>
[INFO] BUILD SUCCESS
</pre>

Esta es la razón por la que en S02-2 JUnit llevaba scope `test` desde el principio: sin él, cada `.jar` que se genera con `mvn package` incluiría de regalo una librería de testing que nadie necesita en producción, aumentando su tamaño y sus dependencias sin ningún beneficio.

---

## Demo 3: Árbol de dependencias y repositorios corporativos

### Las dependencias transitivas

Cuando se añade una dependencia al `pom.xml`, casi nunca se descarga un único JAR. La mayoría de librerías, para funcionar, usan a su vez otras librerías: son sus **dependencias transitivas**. JUnit, por ejemplo, no es una sola pieza: `junit-jupiter` (lo que hemos declarado) usa por debajo otras librerías propias del proyecto JUnit para funcionar, y Maven las descarga todas sin que se le pida explícitamente ninguna de ellas.

El comando `mvn dependency:tree`, ejecutado desde la terminal en el proyecto, muestra ese árbol completo: qué hemos declarado nosotros y qué ha traído cada dependencia por su cuenta.

Salida esperada:

<pre>
[INFO] com.curso:s03-1-demos:jar:1.0-SNAPSHOT
[INFO] +- org.apache.commons:commons-lang3:jar:3.17.0:compile
[INFO] \- org.junit.jupiter:junit-jupiter:jar:5.11.0:test
[INFO]    +- org.junit.jupiter:junit-jupiter-api:jar:5.11.0:test
[INFO]    |  +- org.opentest4j:opentest4j:jar:1.3.0:test
[INFO]    |  +- org.junit.platform:junit-platform-commons:jar:1.11.0:test
[INFO]    |  \- org.apiguardian:apiguardian-api:jar:1.1.2:test
[INFO]    +- org.junit.jupiter:junit-jupiter-params:jar:5.11.0:test
[INFO]    \- org.junit.jupiter:junit-jupiter-engine:jar:5.11.0:test
[INFO]       \- org.junit.platform:junit-platform-engine:jar:1.11.0:test
</pre>

Se lee de arriba abajo con indentación, igual que un árbol de carpetas. Las dos líneas de primer nivel (`+-` y `\-`) son las dos dependencias que hemos declarado nosotros mismos en el `pom.xml`: `commons-lang3` y `junit-jupiter`. Todo lo que cuelga por debajo de `junit-jupiter`, con más indentación, son dependencias transitivas: `opentest4j`, `junit-platform-commons`, `apiguardian-api`... ninguna de ellas aparece en nuestro `pom.xml`, pero las tiene descargadas en `~/.m2` porque `junit-jupiter` las necesita para funcionar. `commons-lang3`, en cambio, no trae ninguna dependencia propia: es una librería sin dependencias transitivas, así que no tiene nada debajo en el árbol.

Este mecanismo es el que hace viable usar librerías grandes: cuando en S05 se añada Spring, una sola línea en el `pom.xml` descargará decenas de JARs transitivos sin que haya que localizarlos y declararlos uno a uno. También es la causa de los conflictos de versión entre dependencias transitivas, que se resuelven en la Práctica 3 de esta misma parte.

### Repositorios corporativos

Hasta ahora, toda dependencia del curso se ha descargado de **Maven Central**, el repositorio público del ecosistema Java. En una empresa real esto no es siempre así.

Una empresa con varios proyectos internos suele tener código común entre ellos: por ejemplo, clases de validación, conexión a sus propios servicios, o utilidades compartidas. En lugar de copiar y pegar ese código en cada proyecto, lo empaquetan como una librería `.jar` propia, con su `groupId`, `artifactId` y `version` igual que cualquier otra, y la publican en su repositorio interno. Así, cualquier otro proyecto de la empresa la añade al `pom.xml` exactamente igual que hemos añadido `commons-lang3` en esta demo, solo que Maven la descarga de ese servidor interno en lugar de Maven Central, porque esa librería nunca se ha publicado públicamente: no tendría sentido, es código propio de la empresa, no algo pensado para que lo use cualquiera fuera de ahí.

Para eso existen los **repositorios corporativos**: un servidor propio de la empresa, gestionado con herramientas como **Nexus** o **Artifactory**, que funciona igual que Maven Central pero solo es accesible dentro de la organización.

Para que Maven busque también en uno de estos repositorios, además de en Maven Central, se añade una entrada `<repository>` al `pom.xml`:

```xml
<repositories>
    <repository>
        <id>empresa-nexus</id>
        <name>Repositorio interno de la empresa</name>
        <url>https://nexus.empresa.com/repository/maven-releases/</url>
    </repository>
</repositories>
```

No añadimos esta entrada al proyecto real del curso porque no existe ningún servidor `nexus.empresa.com` al que conectarse: es solo un ejemplo de la sintaxis. Lo importante es entender la arquitectura resultante: cuando Maven necesita una dependencia, primero mira en el **repositorio local** (`~/.m2`, la caché de la propia máquina); si no la tiene, la busca en los repositorios remotos configurados, en el orden en que aparecen en el `pom.xml` o en el `settings.xml` (habitualmente el repositorio corporativo primero, y Maven Central como respaldo para las librerías públicas). Esta es la razón por la que, en muchas empresas, sin conexión a la VPN corporativa `mvn` deja de funcionar: no es que Maven Central esté caído, es que el repositorio interno donde están las librerías propias de la empresa no es accesible desde fuera de la red corporativa.

**Para qué sirve este proyecto**: el conjunto de esta parte (añadir una dependencia, entender su scope, y ver su árbol de dependencias transitivas) es la secuencia que se repetirá cada vez que el curso incorpore una librería nueva y grande, empezando por Spring en S05. Sin haberlo hecho antes con una librería pequeña y familiar como `commons-lang3`, el `pom.xml` de un proyecto Spring resultaría una lista larga de líneas sin sentido aparente.
