# S03-2 Soluciones

## Práctica 1: Análisis del JAR

`Etiqueta` es una clase que usa `commons-lang3`, la librería externa que ya se añadió al proyecto en S03-1. Esa dependencia es la que hace visible, en esta práctica, la diferencia entre lo que contiene un JAR generado por Maven y lo que necesita ese JAR para ejecutarse por sí solo.

```java
package com.curso;

// Importamos StringUtils de la librería commons-lang3, la misma que se usó
// en S03-1. Maven la ha descargado automáticamente al guardar el pom.xml.
// Sin Maven habría que buscar el JAR, descargarlo y añadirlo al classpath a mano.
import org.apache.commons.lang3.StringUtils;

/**
 * S03-2 Práctica 1: Análisis del JAR
 *
 * Objetivo: tener una clase que use una librería externa (commons-lang3)
 * para comprobar qué falta en el JAR que genera Maven y qué hace falta
 * para poder ejecutarlo con java -jar.
 *
 * Lo que hace este ejemplo:
 *   - Genera el código de etiqueta de un producto a partir de su número
 *
 * Concepto clave: el JAR que genera mvn package solo contiene las clases
 * propias del proyecto. Las dependencias, como commons-lang3, no se incluyen
 * dentro del JAR: hay que dárselas al comando java por separado.
 */
public class Etiqueta {

    // Prefijo fijo que llevan todos los códigos de producto del curso.
    private static final String PREFIJO = "PRD-";

    /**
     * Genera el código de etiqueta de un producto a partir de su número.
     *
     * Ejemplo:
     *   generar(42)    →  "PRD-00042"
     *   generar(7)     →  "PRD-00007"
     *
     * @param numeroProducto el número identificador del producto
     * @return el código de etiqueta completo
     */
    public String generar(int numeroProducto) {
        // leftPad() rellena por la izquierda hasta la longitud indicada con el
        // carácter de relleno que se le pasa. String.valueOf(42) da "42";
        // leftPad("42", 5, '0') da "00042".
        String numeroConCeros = StringUtils.leftPad(String.valueOf(numeroProducto), 5, '0');

        // Unimos el prefijo fijo con el número ya rellenado con ceros.
        return PREFIJO + numeroConCeros;
    }

    // main() permite ejecutar esta clase directamente desde IntelliJ (▶)
    // y, más adelante en esta parte, también empaquetada en un JAR.
    public static void main(String[] args) {
        // Creamos una instancia de Etiqueta para poder llamar a generar().
        Etiqueta etiqueta = new Etiqueta();

        // Probamos con distintos números para ver que el relleno con ceros
        // funciona igual independientemente de la longitud del número.
        System.out.println(etiqueta.generar(42));    // → PRD-00042
        System.out.println(etiqueta.generar(7));      // → PRD-00007
        System.out.println(etiqueta.generar(10000));  // → PRD-10000
    }
}
```

El `pom.xml` de partida, antes de configurar ningún plugin, declara solo la dependencia:

```xml
<dependencies>
    <dependency>
        <groupId>org.apache.commons</groupId>
        <artifactId>commons-lang3</artifactId>
        <version>3.17.0</version>
    </dependency>
</dependencies>
```

### Primer intento: `mvn package` y `jar tf`

```bash
mvn package
jar tf target/s03-2-practicas-1.0-SNAPSHOT.jar
```

Salida esperada:

<pre>
META-INF/
META-INF/MANIFEST.MF
com/
com/curso/
META-INF/maven/
META-INF/maven/com.curso/
META-INF/maven/com.curso/s03-2-practicas/
com/curso/Etiqueta.class
META-INF/maven/com.curso/s03-2-practicas/pom.xml
META-INF/maven/com.curso/s03-2-practicas/pom.properties
</pre>

El JAR contiene `Etiqueta.class`, el manifiesto y una copia del propio `pom.xml` con fines informativos. No contiene ninguna clase de `commons-lang3`: Maven no mete las dependencias dentro del JAR por defecto, solo las clases del proyecto.

### Primer fallo: sin `Main-Class`

```bash
java -jar target/s03-2-practicas-1.0-SNAPSHOT.jar
```

Salida esperada:

<pre>
no main manifest attribute, in target/s03-2-practicas-1.0-SNAPSHOT.jar
</pre>

`java -jar` necesita saber qué clase ejecutar, y esa información va en el atributo `Main-Class` del manifiesto (`META-INF/MANIFEST.MF`). Por defecto, el `maven-jar-plugin` genera un manifiesto sin ese atributo: Maven no puede adivinar cuál de las clases del proyecto tiene el `main()` que hay que ejecutar.

### Configurar el `Main-Class`

Añadimos la configuración del `maven-jar-plugin` que fija el `Main-Class`:

```xml
<build>
    <plugins>
        <plugin>
            <artifactId>maven-jar-plugin</artifactId>
            <version>3.4.1</version>
            <configuration>
                <archive>
                    <manifest>
                        <mainClass>com.curso.Etiqueta</mainClass>
                    </manifest>
                </archive>
            </configuration>
        </plugin>
    </plugins>
</build>
```

Comprobamos el manifiesto generado:

```bash
mvn clean package
unzip -p target/s03-2-practicas-1.0-SNAPSHOT.jar META-INF/MANIFEST.MF
```

Salida esperada:

<pre>
Manifest-Version: 1.0
Created-By: Maven JAR Plugin 3.4.1
Build-Jdk-Spec: 21
Main-Class: com.curso.Etiqueta
</pre>

### Segundo fallo: dependencia ausente

```bash
java -jar target/s03-2-practicas-1.0-SNAPSHOT.jar
```

Salida esperada:

<pre>
Exception in thread "main" java.lang.NoClassDefFoundError: org/apache/commons/lang3/StringUtils
	at com.curso.Etiqueta.generar(Etiqueta.java:41)
	at com.curso.Etiqueta.main(Etiqueta.java:55)
Caused by: java.lang.ClassNotFoundException: org.apache.commons.lang3.StringUtils
	at java.base/jdk.internal.loader.BuiltinClassLoader.loadClass(BuiltinClassLoader.java:641)
	at java.base/jdk.internal.loader.ClassLoaders$AppClassLoader.loadClass(ClassLoaders.java:188)
	at java.base/java.lang.ClassLoader.loadClass(ClassLoader.java:526)
	... 2 more
</pre>

Ahora `java` sí sabe qué clase ejecutar, pero al llegar a la línea que usa `StringUtils` no la encuentra: `commons-lang3` no está dentro del JAR ni en ningún otro sitio del classpath que `java -jar` usa por defecto, que es únicamente el propio JAR. `NoClassDefFoundError` es distinto de un error de compilación: el código compiló sin problema porque, al compilar, Maven sí tenía la dependencia disponible; el fallo ocurre en tiempo de ejecución, cuando la JVM intenta cargar una clase que no encuentra.

**Decisiones tomadas**

- `StringUtils.leftPad` en lugar de escribir el relleno con ceros a mano: es el mismo principio que ya se aplicó en S03-1 con `Formateador`, usar una librería probada en lugar de reimplementar una utilidad de texto.
- Dejar los dos fallos sin resolver con `maven-jar-plugin`: la solución de este plugin (fijar el `Main-Class`) resuelve el primer problema pero no el segundo. Eso es deliberado: demuestra que el JAR que genera Maven por defecto es un artefacto mínimo, con las clases propias y nada más, y que ejecutarlo con `java -jar` exige gestionar el classpath de las dependencias por separado. La forma de resolver el segundo fallo es la Práctica 2.

---

## Práctica 2: Plugin de ejecución

En lugar de seguir ajustando el JAR y el comando `java -jar`, usamos `exec-maven-plugin` para que sea Maven quien ejecute la aplicación, con el classpath completo del proyecto (clases propias y dependencias) ya resuelto.

```xml
<build>
    <plugins>
        <plugin>
            <artifactId>maven-jar-plugin</artifactId>
            <version>3.4.1</version>
            <configuration>
                <archive>
                    <manifest>
                        <mainClass>com.curso.Etiqueta</mainClass>
                    </manifest>
                </archive>
            </configuration>
        </plugin>
        <plugin>
            <groupId>org.codehaus.mojo</groupId>
            <artifactId>exec-maven-plugin</artifactId>
            <version>3.4.1</version>
            <configuration>
                <mainClass>com.curso.Etiqueta</mainClass>
            </configuration>
        </plugin>
    </plugins>
</build>
```

```bash
mvn exec:java
```

Salida esperada:

<pre>
[INFO] Scanning for projects...
[INFO] 
[INFO] ---------------------< com.curso:s03-2-practicas >----------------------
[INFO] Building s03-2-practicas 1.0-SNAPSHOT
[INFO]   from pom.xml
[INFO] --------------------------------[ jar ]---------------------------------
[INFO] 
[INFO] --- exec:3.4.1:java (default-cli) @ s03-2-practicas ---
PRD-00042
PRD-00007
PRD-10000
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
</pre>

Esta vez funciona sin ningún error: la salida del programa (`PRD-00042`, `PRD-00007`, `PRD-10000`) aparece directamente en la consola de Maven. `exec:java` no genera ni usa el JAR: ejecuta la clase directamente sobre las clases compiladas en `target/classes`, con un classpath que Maven construye a partir de las dependencias resueltas del `pom.xml`, incluida `commons-lang3`.

**Decisiones tomadas**

- `<groupId>org.codehaus.mojo</groupId>` explícito: a diferencia de `maven-compiler-plugin` o `maven-jar-plugin`, que son plugins oficiales de Maven y usan por defecto el grupo `org.apache.maven.plugins`, `exec-maven-plugin` pertenece a otra organización (Mojohaus). Sin el `groupId`, Maven no sabe dónde buscarlo.
- Mantener también el `maven-jar-plugin` de la Práctica 1: no estorba, y deja el proyecto en un estado en el que tanto `mvn package` (para producir un JAR con el `Main-Class` correcto, aunque siga sin llevar las dependencias) como `mvn exec:java` (para ejecutar con las dependencias resueltas) funcionan, cada uno para el propósito que resuelve.
- `exec:java` en lugar de `java -jar` como forma habitual de ejecutar una aplicación durante el desarrollo: no hace falta empaquetar en cada prueba, y Maven se encarga de que el classpath esté completo. `java -jar` (u otra forma de generar un artefacto autocontenido) sigue siendo necesario cuando la aplicación se distribuye o se despliega fuera del proyecto Maven.
