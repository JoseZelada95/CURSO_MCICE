# S03-2 Prácticas

## Objetivos

Se aplica lo aprendido en las demos: el ciclo de vida de Maven y la configuración de plugins en el `pom.xml`. En estas prácticas se examina el JAR que produce `mvn package`, se descubre qué le falta para ejecutarse por sí solo con `java -jar`, y se corrige con dos plugins distintos: primero configurando el propio JAR, después ejecutando la aplicación directamente con Maven.

---

## Práctica 1: Análisis del JAR

Se crea un proyecto Maven nuevo con la clase `Etiqueta`, que usa la librería externa `commons-lang3` (la misma de S03-1) para generar el código de un producto. Se empaqueta el proyecto, se examina el contenido del JAR generado y se intenta ejecutarlo con `java -jar`, corrigiendo los problemas que vayan apareciendo.

**Pasos**

1. Creamos un nuevo proyecto Maven en IntelliJ desde `File > New > Project`, con `Java` seleccionado en el panel izquierdo: Name `s03-2-practicas`, Build system `Maven`, JDK `21` y **Add sample code** desmarcada. En `Advanced Settings`, usamos `com.curso` como GroupId y `s03-2-practicas` como ArtifactId.
2. Creamos el paquete `com.curso`: clic derecho sobre `src/main/java`, `New > Package`, escribimos `com.curso` y pulsamos Enter.
3. Añadimos `commons-lang3` como dependencia en el `pom.xml`, dentro de `<dependencies>`, con `groupId` `org.apache.commons`, `artifactId` `commons-lang3` y `version` `3.17.0`. Sin `scope`: la necesitamos en el código de producción, no solo en los tests.
4. Creamos la clase `Etiqueta` en el paquete `com.curso`, con una constante `PREFIJO` de valor `"PRD-"` y un método `generar(int numeroProducto)` que devuelva el prefijo seguido del número relleno con ceros hasta cinco cifras, usando `StringUtils.leftPad` de `commons-lang3`.
5. Añadimos un `main()` que cree una instancia de `Etiqueta` y llame a `generar()` con varios números, incluyendo uno de una sola cifra y otro de cinco.
6. Desde el terminal integrado, ejecutamos `mvn package` y localizamos el JAR generado en `target/`.
7. Examinamos el contenido del JAR con `jar tf` y comprobamos qué contiene y qué no.
8. Intentamos ejecutar el JAR con `java -jar` y anotamos el error exacto.
9. Añadimos al `pom.xml` la configuración del `maven-jar-plugin` necesaria para indicar la clase principal del JAR (el `Main-Class` del manifiesto).
10. Repetimos `mvn package` y `java -jar`. Anotamos si el error cambia y por qué.

**Pistas**

- `StringUtils.leftPad(texto, longitud, caracter)` rellena `texto` por la izquierda con `caracter` hasta que alcanza `longitud`. Hay que convertir el número a `String` antes de pasarlo (`String.valueOf(numero)`).
- `jar tf archivo.jar` lista las entradas del JAR sin extraerlo. Compara lo que ves con lo que hay en `src/main/java` y con las dependencias del `pom.xml`.
- El **manifiesto** (`META-INF/MANIFEST.MF`) es un fichero de metadatos dentro de todo JAR. Uno de sus atributos, `Main-Class`, le dice a `java -jar` qué clase contiene el método `main()` que hay que ejecutar. Sin ese atributo, `java -jar` no sabe por dónde empezar.
- La configuración del `maven-jar-plugin` para fijar el `Main-Class` va dentro de `<configuration><archive><manifest>`, con una etiqueta `<mainClass>` que indica la clase completa (con el paquete).
- Si tras configurar el `Main-Class` el programa sigue sin funcionar, el mensaje de error (`NoClassDefFoundError` o similar) indica qué clase falta. Compara el nombre de esa clase con las dependencias declaradas en el `pom.xml` y con lo que viste en el `jar tf` del paso 7.

---

## Práctica 2: Plugin de ejecución

En el mismo proyecto, se añade el `exec-maven-plugin` para ejecutar `Etiqueta` directamente con Maven, sin pasar por `java -jar`, y se compara el resultado con la Práctica 1.

**Pasos**

1. Añadimos al `pom.xml`, dentro de `<build><plugins>`, el plugin `exec-maven-plugin`, con `mainClass` apuntando a `com.curso.Etiqueta`.
2. Ejecutamos `mvn exec:java` desde el terminal.
3. Comprobamos que la aplicación se ejecuta correctamente y compara el resultado con el intento de la Práctica 1 con `java -jar`.

**Pistas**

- `maven-compiler-plugin` y `maven-jar-plugin`, usados hasta ahora, son plugins oficiales de Maven (`org.apache.maven.plugins`), el grupo que Maven asume por defecto cuando no se indica `<groupId>`. `exec-maven-plugin` no es un plugin oficial: pertenece a otra organización (Mojohaus) y por eso necesita su propio `<groupId>` explícito en la declaración del plugin.
- El goal que ejecuta una clase Java es `exec:java`, donde `exec` es el nombre corto del plugin (el `artifactId` sin el sufijo `-maven-plugin`) y `java` es el goal.
- Piensa en qué classpath usa cada forma de ejecutar la aplicación: el de `java -jar`, que solo ve lo que hay dentro del JAR, y el que construye Maven al ejecutar `exec:java`, que conoce las dependencias declaradas en el `pom.xml`.
