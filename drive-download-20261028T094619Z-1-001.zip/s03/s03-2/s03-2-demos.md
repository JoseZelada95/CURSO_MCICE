# S03-2 Demos

## Objetivos

En esta parte dejamos de usar Maven solo para compilar desde IntelliJ y aprendemos a manejarlo desde la terminal, entendiendo qué hace cada comando. Maven organiza su trabajo en fases ordenadas: compilar, testear, empaquetar. Cada fase ejecuta las anteriores, así que `mvn package` no solo genera el JAR: antes compila el código y ejecuta los tests. Detrás de cada fase hay un plugin que hace el trabajo real; los plugins son el mecanismo de extensión de Maven y se pueden configurar en el `pom.xml` para cambiar su comportamiento por defecto.

Al terminar esta parte los alumnos son capaces de:
- Explicar qué es una fase y qué es el ciclo de vida de Maven.
- Ejecutar `mvn compile`, `mvn test`, `mvn package` y `mvn clean` desde la terminal y explicar qué produce cada uno en el directorio `target`.
- Saltar la ejecución de los tests con `-DskipTests`.
- Configurar el `maven-compiler-plugin` en el `pom.xml` para fijar la versión de Java con `release`.
- Explicar la diferencia entre `release` y `source`/`target`.
- Interpretar las advertencias del compilador activadas con `-Xlint:all`.

---

## Demo 1: Ciclo de vida desde la terminal

Hasta ahora hemos ejecutado el código siempre desde IntelliJ, con el botón ▶. Por debajo, IntelliJ está invocando a Maven: cuando pulsamos ▶, compila el proyecto igual que si ejecutáramos un comando en la terminal. En esta demo hacemos ese comando explícito.

Maven organiza la construcción de un proyecto en un **ciclo de vida**: una secuencia fija de **fases**, cada una con un nombre y un propósito. Las tres fases principales, en orden, son:

- `compile`: compila el código de `src/main/java` y genera los `.class` en `target/classes`.
- `test`: ejecuta `compile` y, además, compila el código de `src/test/java` y ejecuta los tests.
- `package`: ejecuta `test` y, además, empaqueta las clases compiladas en un JAR.

Esta es la razón por la que decíamos, en S02-2, que "el ciclo de vida completo se ve en S03-2": cada fase incluye automáticamente a las anteriores. No es necesario compilar antes de testear ni testear antes de empaquetar: pedir la fase final es suficiente.

### Crear el proyecto

Vamos a `File > New > Project`. En el panel izquierdo, dentro de `New Project`, seleccionamos `Java`.

Rellenamos los campos:

- **Name**: `s03-2-demos`.
- **Location**: la carpeta donde guardamos los proyectos del curso.
- **Create Git repository**: desmarcada.
- **Build system**: `Maven`.
- **JDK**: `21`.
- **Add sample code**: desmarcada. A partir de S02-1 esta opción solo se marca en el primer proyecto del curso; en todos los demás creamos los paquetes y las clases a mano.

Desplegamos `Advanced Settings` y rellenamos:

- **GroupId**: `com.curso`.
- **ArtifactId**: `s03-2-demos`.

Hacemos clic en `Create`. Con **Add sample code** desmarcada, `src/main/java` está vacía. Creamos el paquete `com.curso`: clic derecho sobre `src/main/java`, `New > Package`, escribimos `com.curso` y pulsamos Enter.

El `pom.xml` que genera el asistente es el mismo de siempre: `groupId`, `artifactId`, `version` con `1.0-SNAPSHOT`, y las propiedades `maven.compiler.source`, `maven.compiler.target` (`21`) y `project.build.sourceEncoding` (`UTF-8`). No tiene `<dependencies>` ni `<build>`; los añadimos a continuación.

### Añadir JUnit

Sobre `com.curso` en `src/main/java`, creamos la clase `Descuento` (`New > Java Class`). Sobre `com.curso` en `src/test/java` (lo creamos igual que el de `main`, con `New > Package`), creamos la clase `DescuentoTest`.

Para que `DescuentoTest` pueda usar `@Test` y `assertEquals`, añadimos JUnit al `pom.xml`, igual que en S02-2 y S03-1: dentro de un bloque `<dependencies>`, con scope `test` para que la librería no llegue al código de producción.

```xml
<dependencies>
    <dependency>
        <groupId>org.junit.jupiter</groupId>
        <artifactId>junit-jupiter</artifactId>
        <version>5.11.0</version>
        <scope>test</scope>
    </dependency>
</dependencies>
```

### Código: Descuento

```java
package com.curso;

/**
 * S03-2 Demo 1: Ciclo de vida desde la terminal
 *
 * Objetivo: tener una clase sencilla con la que recorrer las fases del
 * ciclo de vida de Maven (compile, test, package) desde la terminal.
 *
 * Lo que hace este ejemplo:
 *   - Define la clase Descuento en el paquete com.curso
 *   - Implementa el método aplicar(precio, porcentajeDescuento) que calcula
 *     el precio final tras aplicar un descuento porcentual
 *
 * Concepto clave: esta clase no introduce ningún concepto de Java nuevo
 * (el patrón paquete, clase, método viene de S02-1). Su función en esta parte
 * es servir de proyecto real sobre el que ejecutar mvn compile, mvn test
 * y mvn package y observar qué produce cada fase en el directorio target.
 */
public class Descuento {

    /**
     * Calcula el precio final tras aplicar un descuento porcentual.
     *
     * Ejemplo:
     *   aplicar(100, 10)  →  90.0
     *   aplicar(50, 25)   →  37.5
     *
     * @param precio precio original, antes del descuento
     * @param porcentajeDescuento porcentaje a descontar, por ejemplo 10 para un 10%
     * @return el precio final, ya con el descuento aplicado
     */
    public double aplicar(double precio, double porcentajeDescuento) {
        // Calculamos el importe que se descuenta: el precio por el porcentaje
        // dividido entre 100. Por ejemplo, el 10% de 100 es 100 * (10 / 100) = 10.
        double importeDescuento = precio * (porcentajeDescuento / 100);

        // El precio final es el precio original menos el importe descontado.
        return precio - importeDescuento;
    }

    // main() permite ejecutar esta clase directamente desde IntelliJ (▶)
    // sin necesidad de un framework. Útil para probar el método antes de
    // ejecutarlo con Maven desde la terminal.
    public static void main(String[] args) {
        // Creamos una instancia de Descuento para poder llamar al método aplicar().
        // No es un método static: necesita un objeto sobre el que operar.
        Descuento descuento = new Descuento();

        // Probamos con distintos precios y porcentajes para ver que el cálculo
        // funciona igual en todos los casos.
        System.out.println(descuento.aplicar(100, 10));  // → 90.0
        System.out.println(descuento.aplicar(50, 25));   // → 37.5
        System.out.println(descuento.aplicar(200, 0));   // → 200.0
    }
}
```

### Código: DescuentoTest

```java
package com.curso;

// Importamos assertEquals y la anotación @Test de JUnit 5, la librería de tests
// que se añadió al pom.xml en S02-2. Maven la ha descargado de Maven Central
// al guardar el pom.xml, igual que cualquier otra dependencia.
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

/**
 * S03-2 Demo 1: Ciclo de vida desde la terminal (test)
 *
 * Objetivo: tener tests reales sobre Descuento para que la fase test
 * del ciclo de vida de Maven tenga algo que ejecutar.
 *
 * Lo que hace este ejemplo:
 *   - Verifica que aplicar() calcula correctamente el precio con descuento
 *   - Verifica el caso límite de un descuento del 0%
 *
 * Concepto clave: mvn test compila primero el código de src/main/java y
 * src/test/java y después ejecuta estos tests. Si un test falla, mvn test
 * termina con BUILD FAILURE y detiene el ciclo de vida antes de empaquetar.
 */
public class DescuentoTest {

    // JUnit crea una nueva instancia de la clase de test por cada @Test,
    // por lo que este campo se reinicia automáticamente entre tests.
    private final Descuento descuento = new Descuento();

    @Test
    public void aplicaDiezPorCientoSobreCien() {
        // El 10% de 100 son 10, así que el precio final es 90.
        assertEquals(90.0, descuento.aplicar(100, 10));
    }

    @Test
    public void aplicaVeinticincoPorCientoSobreCincuenta() {
        // El 25% de 50 son 12.5, así que el precio final es 37.5.
        assertEquals(37.5, descuento.aplicar(50, 25));
    }

    @Test
    public void sinDescuentoDevuelveElMismoPrecio() {
        // Un porcentaje de descuento de 0 no debe cambiar el precio original.
        assertEquals(200.0, descuento.aplicar(200, 0));
    }
}
```

### `mvn compile`

Abrimos el terminal integrado de IntelliJ (`View > Tool Windows > Terminal`), situados en la raíz del proyecto, y ejecutamos:

```bash
mvn compile
```

Salida esperada:

<pre>
[INFO] Scanning for projects...
[INFO] 
[INFO] -----------------------< com.curso:s03-2-demos >------------------------
[INFO] Building s03-2-demos 1.0-SNAPSHOT
[INFO]   from pom.xml
[INFO] --------------------------------[ jar ]---------------------------------
[INFO] 
[INFO] --- resources:3.3.1:resources (default-resources) @ s03-2-demos ---
[INFO] skip non existing resourceDirectory /ruta/s03-2-demos/src/main/resources
[INFO] 
[INFO] --- compiler:3.13.0:compile (default-compile) @ s03-2-demos ---
[INFO] Recompiling the module because of changed source code.
[INFO] Compiling 1 source file with javac [debug target 21] to target/classes
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
</pre>

Dos líneas merecen atención. La primera, `--- resources:3.3.1:resources (default-resources) @ s03-2-demos ---`, tiene el formato `plugin:versión:goal (id de la ejecución) @ artifactId`. Un **goal** es una tarea concreta que un plugin sabe hacer; un plugin puede ofrecer varios goals distintos. Aquí, el plugin `resources` ejecuta su goal `resources` (copiar ficheros de `src/main/resources` a `target/classes`), y como esa carpeta no existe todavía, no hay nada que copiar. La segunda, `--- compiler:3.13.0:compile (default-compile) @ s03-2-demos ---`, es el plugin `compiler` ejecutando su goal `compile`: el que realmente invoca a `javac`. Este formato `plugin:goal` se repite en cada línea de la salida de Maven y es la forma de identificar, ante un fallo, qué plugin y qué goal han fallado.

Comprobamos qué ha generado la fase en el directorio `target`:

<pre>
target/
└── classes/
    └── com/
        └── curso/
            └── Descuento.class
</pre>

`target/classes` contiene el `.class` compilado, con la misma estructura de paquetes que `src/main/java`. `DescuentoTest.class` no aparece: `mvn compile` solo compila `src/main/java`, no `src/test/java`.

### `mvn test`

```bash
mvn test
```

Salida esperada:

<pre>
[INFO] Scanning for projects...
[INFO] 
[INFO] -----------------------< com.curso:s03-2-demos >------------------------
[INFO] Building s03-2-demos 1.0-SNAPSHOT
[INFO]   from pom.xml
[INFO] --------------------------------[ jar ]---------------------------------
[INFO] 
[INFO] --- resources:3.3.1:resources (default-resources) @ s03-2-demos ---
[INFO] skip non existing resourceDirectory /ruta/s03-2-demos/src/main/resources
[INFO] 
[INFO] --- compiler:3.13.0:compile (default-compile) @ s03-2-demos ---
[INFO] Nothing to compile - all classes are up to date.
[INFO] 
[INFO] --- resources:3.3.1:testResources (default-testResources) @ s03-2-demos ---
[INFO] skip non existing resourceDirectory /ruta/s03-2-demos/src/test/resources
[INFO] 
[INFO] --- compiler:3.13.0:testCompile (default-testCompile) @ s03-2-demos ---
[INFO] Recompiling the module because of changed source code.
[INFO] Compiling 1 source file with javac [debug target 21] to target/test-classes
[INFO] 
[INFO] --- surefire:3.2.5:test (default-test) @ s03-2-demos ---
[INFO] Using auto detected provider org.apache.maven.surefire.junitplatform.JUnitPlatformProvider
[INFO] 
[INFO] -------------------------------------------------------
[INFO]  T E S T S
[INFO] -------------------------------------------------------
[INFO] Running com.curso.DescuentoTest
[INFO] Tests run: 3, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 0.073 s -- in com.curso.DescuentoTest
[INFO] 
[INFO] Results:
[INFO] 
[INFO] Tests run: 3, Failures: 0, Errors: 0, Skipped: 0
[INFO] 
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
</pre>

Dos detalles. Primero, `compiler:3.13.0:compile` dice ahora "Nothing to compile - all classes are up to date": Maven no vuelve a compilar `Descuento.java` porque no ha cambiado desde el `mvn compile` anterior; solo compila lo nuevo, `DescuentoTest.java`, con el goal `testCompile`. Segundo, aparece un plugin nuevo, `surefire`, con su goal `test`: es el plugin que ejecuta los tests de JUnit y produce el resumen `Tests run: 3, Failures: 0, Errors: 0, Skipped: 0`.

`target` tiene ahora una carpeta más:

<pre>
target/
├── classes/
│   └── com/curso/Descuento.class
├── test-classes/
│   └── com/curso/DescuentoTest.class
└── surefire-reports/
    ├── com.curso.DescuentoTest.txt
    └── TEST-com.curso.DescuentoTest.xml
</pre>

`target/test-classes` contiene el `.class` del test, separado de `target/classes` para que nunca llegue al JAR final. `target/surefire-reports` contiene el resultado de cada test en dos formatos: un `.txt` legible y un `.xml` que herramientas externas (como Jenkins, en el módulo siguiente) pueden leer para mostrar gráficas de resultados.

### `mvn package`

```bash
mvn package
```

Salida esperada (se omiten las fases ya vistas):

<pre>
...
[INFO] --- jar:3.4.1:jar (default-jar) @ s03-2-demos ---
[INFO] Building jar: /ruta/s03-2-demos/target/s03-2-demos-1.0-SNAPSHOT.jar
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
</pre>

Antes de este goal, Maven ha vuelto a ejecutar `compile`, `testCompile` y `test`: `package` no se salta ninguna fase anterior. El plugin `jar`, con su goal `jar`, empaqueta el contenido de `target/classes` en `target/s03-2-demos-1.0-SNAPSHOT.jar`. El nombre del JAR combina el `artifactId` y la `version` del `pom.xml`.

### `mvn clean`

Con el tiempo, `target` acumula compilaciones antiguas. `mvn clean` invoca al plugin `clean` para borrarlo por completo:

```bash
mvn clean
```

Salida esperada:

<pre>
[INFO] --- clean:3.2.0:clean (default-clean) @ s03-2-demos ---
[INFO] Deleting /ruta/s03-2-demos/target
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
</pre>

Tras ejecutarlo, `target` ya no existe. `clean` no forma parte del ciclo de vida `compile → test → package`: es un ciclo de vida propio, con una única fase relevante, y por eso se combina con las demás fases en un mismo comando: `mvn clean package` limpia y después construye desde cero, sin arrastrar clases compiladas de una ejecución anterior.

### `mvn package -DskipTests`

A veces interesa generar el JAR sin ejecutar los tests, por ejemplo para probar rápido un cambio que no afecta a la lógica probada. La opción `-D` define una propiedad del sistema desde la línea de comandos; `skipTests` es una propiedad que reconocen tanto el plugin `compiler` (para no compilar `src/test/java`... en realidad sí lo compila, pero no lo ejecuta) como el plugin `surefire`:

```bash
mvn package -DskipTests
```

Salida esperada (se omiten las fases ya vistas):

<pre>
...
[INFO] --- surefire:3.2.5:test (default-test) @ s03-2-demos ---
[INFO] Tests are skipped.
[INFO] 
[INFO] --- jar:3.4.1:jar (default-jar) @ s03-2-demos ---
[INFO] Building jar: /ruta/s03-2-demos/target/s03-2-demos-1.0-SNAPSHOT.jar
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
</pre>

El goal `surefire:test` se sigue ejecutando (aparece en la lista de fases), pero internamente no ejecuta ningún test: se limita a informar de que los ha saltado. El JAR se genera igual.

---

## Demo 2: Configuración del compiler plugin

### Qué es compilar

**Compilar** es el proceso por el que `javac` (el compilador de Java) transforma el código fuente que escribimos, los ficheros `.java`, en bytecode: ficheros `.class` que la JVM puede ejecutar. El código fuente es texto legible para nosotros; el bytecode es un formato binario intermedio que la JVM interpreta. Sin compilar, un `.java` no se puede ejecutar.

### Qué es un build

**Build** es una palabra inglesa que significa "construcción", y así se usa en el mundo del desarrollo de software: es el proceso completo que convierte el código fuente que escribimos en algo que se puede ejecutar o distribuir. No es lo mismo que compilar: compilar es solo un paso dentro del build (el que convierte `.java` en `.class`), pero un build puede incluir muchos más pasos: compilar, ejecutar tests, empaquetar, copiar recursos, generar documentación...

En Maven, cada vez que ejecutamos un comando como `mvn compile`, `mvn test` o `mvn package`, estamos lanzando un build. Ya vimos en la Demo 1 que Maven organiza esos pasos en fases (`compile`, `test`, `package`), y que cada fase ejecuta automáticamente las anteriores. Un build, entonces, es exactamente eso: la ejecución completa de todos los pasos necesarios para llegar hasta la fase que le hemos pedido a Maven, con todos los plugins y goals que intervienen por el camino (`resources:resources`, `compiler:compile`, `surefire:test`...).

Al terminar, Maven siempre da un veredicto final sobre ese build entero, en mayúsculas y muy visible al final de la salida:

- **`BUILD SUCCESS`**: todos los pasos se han completado sin errores. El build ha llegado hasta el final.
- **`BUILD FAILURE`**: algún paso ha fallado (por ejemplo, un error de compilación, o un test que no pasa) y Maven ha parado ahí mismo, sin continuar con los pasos siguientes.

Es la primera línea que hay que mirar en cualquier salida de Maven, antes de leer nada más: dice si el build, en conjunto, ha ido bien o mal. Cuando decimos "ha fallado el build" o "el build ha ido bien", nos referimos exactamente a esto: al resultado de una ejecución completa de Maven, no solo a si el código ha compilado.

### Qué es una versión de Java (y por qué hay tres cosas que fijar, no una)

Cuando decimos "Java 21" o "Java 17", en realidad estamos hablando de tres cosas distintas que suelen cambiar juntas, pero que Maven permite fijar por separado:

1. **La sintaxis del lenguaje**: qué construcciones puede usar el código fuente que escribimos (por ejemplo, ciertos tipos de `switch` solo existen a partir de una versión concreta). Esto lo controla `maven.compiler.source`.
2. **El bytecode generado**: la versión mínima de la JVM que hace falta para ejecutar el `.class` resultante. Esto lo controla `maven.compiler.target`.
3. **La API estándar disponible**: qué clases y métodos de la biblioteca de Java (`List`, `String`, etc.) puede usar el código. Esta es la parte importante de esta demo, y **no** la controla ni `source` ni `target`.

El JDK que tenemos instalado (la versión 21, en nuestro caso) siempre trae la API completa de su propia versión. El problema es que `source` y `target` no le dicen al compilador "no dejes usar API más nueva que esta versión": solo afectan a la sintaxis y al bytecode. Así que es posible fijar `source` y `target` en `17` y, aun así, compilar sin ningún error un método que solo existe en la API de Java 21, porque el compilador nunca comprueba ese límite. El resultado es un `.class` que compila perfectamente en nuestra máquina (con JDK 21) pero que fallaría en cuanto se ejecutase en un servidor con Java 17, con un error que no se ve hasta ese momento.

`release` es la solución: es una única propiedad que fija las tres cosas a la vez (sintaxis, bytecode y API disponible) a la versión indicada. Con `release 17`, el compilador rechaza cualquier uso de API que no exista en Java 17, aunque el JDK instalado sea más moderno. Vamos a comprobarlo con un caso real.

### Una API que solo existe en Java 21

Java 21 introdujo la interfaz `SequencedCollection`, que añade a `List` (y a otras colecciones con orden) métodos como `getFirst()` y `getLast()` para acceder al primer o último elemento sin usar `get(0)` o `get(size() - 1)`. Vamos a usar `getFirst()` para comprobar, de forma práctica, qué controla `release`.

Creamos la clase `HistorialPrecios` en el paquete `com.curso` del mismo proyecto `s03-2-demos`.

```java
package com.curso;

import java.util.ArrayList;
import java.util.List;

/**
 * S03-2 Demo 2: Configuración del compiler plugin
 *
 * Objetivo: usar una API que solo existe en Java 21 para comprobar, de forma
 * práctica, qué controla la etiqueta release del maven-compiler-plugin.
 *
 * Lo que hace este ejemplo:
 *   - Guarda una lista de precios con addPrecio()
 *   - Devuelve el primer precio guardado con primero(), usando getFirst()
 *
 * Concepto clave: List.getFirst() pertenece a la interfaz SequencedCollection,
 * que Java introdujo en la versión 21. Compilar este código con release 17
 * falla, aunque el proyecto use el JDK 21 instalado: release le dice al
 * compilador qué versión de la API de Java puede usar el código, no solo
 * qué versión de bytecode generar.
 */
public class HistorialPrecios {

    // Lista mutable donde se van guardando los precios en el orden en que llegan.
    private final List<Double> precios = new ArrayList<>();

    /**
     * Añade un precio al historial.
     *
     * @param precio el precio a guardar
     */
    public void addPrecio(double precio) {
        precios.add(precio);
    }

    /**
     * Devuelve el primer precio guardado en el historial.
     *
     * Ejemplo:
     *   addPrecio(100); addPrecio(90); primero()  →  100.0
     *
     * @return el primer precio añadido
     */
    public double primero() {
        // getFirst() devuelve el primer elemento de la lista sin necesidad de
        // usar get(0). Es un método de SequencedCollection, disponible desde
        // Java 21: con una versión de Java anterior no existe este método.
        return precios.getFirst();
    }

    // main() permite ejecutar esta clase directamente desde IntelliJ (▶)
    // sin necesidad de un framework.
    public static void main(String[] args) {
        // Creamos el historial y añadimos varios precios en orden.
        HistorialPrecios historial = new HistorialPrecios();
        historial.addPrecio(100);
        historial.addPrecio(90);
        historial.addPrecio(80);

        // El primero() devuelve el primero que se añadió, no el más pequeño.
        System.out.println(historial.primero());  // → 100.0

        // List sin el tipo entre los símbolos < > es un "raw type": una lista
        // sin ninguna comprobación de tipos en tiempo de compilación. Compila,
        // pero es un error frecuente en código antiguo o escrito con prisa.
        // Esta línea existe solo para que -Xlint:all, configurado en el pom.xml,
        // tenga una advertencia real que mostrar; no es una práctica a imitar.
        List sinTipo = new ArrayList();
        sinTipo.add("cualquier cosa entra aquí, incluso mezclado con números");
        System.out.println(sinTipo.get(0));  // → cualquier cosa entra aquí, incluso mezclado con números
    }
}
```

### Paso 1: configuramos `release 17` y provocamos el fallo

Para cambiar el comportamiento de un plugin hay que declararlo explícitamente dentro de `<build><plugins>` en el `pom.xml`, con la configuración que queramos darle. Añadimos el `maven-compiler-plugin` con `release` fijado a `17`, un valor menor que el JDK 21 instalado:

```xml
<build>
    <plugins>
        <plugin>
            <artifactId>maven-compiler-plugin</artifactId>
            <configuration>
                <release>17</release>
            </configuration>
        </plugin>
    </plugins>
</build>
```

Nótese que no hace falta declarar `<groupId>`: `maven-compiler-plugin` es un plugin oficial de Maven (`org.apache.maven.plugins`), el grupo que Maven usa por defecto cuando no se indica ninguno. Ejecutamos:

```bash
mvn clean compile
```

Salida esperada:

<pre>
...
[INFO] --- compiler:3.13.0:compile (default-compile) @ s03-2-demos ---
[INFO] Recompiling the module because of changed source code.
[INFO] Compiling 2 source files with javac [debug release 17] to target/classes
[INFO] -------------------------------------------------------------
[ERROR] COMPILATION ERROR : 
[INFO] -------------------------------------------------------------
[ERROR] /ruta/s03-2-demos/src/main/java/com/curso/HistorialPrecios.java:[48,23] cannot find symbol
  symbol:   method getFirst()
  location: variable precios of type java.util.List&lt;java.lang.Double&gt;
[INFO] 1 error
[INFO] -------------------------------------------------------------
[INFO] ------------------------------------------------------------------------
[INFO] BUILD FAILURE
[INFO] ------------------------------------------------------------------------
</pre>

Leemos el error línea a línea: `symbol: method getFirst()` dice qué falta (el método); `location: variable precios of type List<Double>` dice dónde se buscó y no se encontró (en el tipo de la variable `precios`). El compilador no dice "esto es de Java 21": simplemente no encuentra el método, porque con `release 17` está limitado a la API de esa versión, sin importar que el JDK instalado sea el 21. `BUILD FAILURE` confirma que el build se ha detenido aquí: no ha llegado a generar ningún `.class`.

### Paso 2: corregimos a `release 21`

Cambiamos el valor de `release` a `21`, la versión que usa todo el curso. Aprovechamos también para añadir una configuración más al mismo plugin: `-Xlint:all` activa todas las advertencias del compilador `javac`. Antes de verlo, distingamos dos tipos de aviso del compilador:

- Un **error** detiene el build: sin corregirlo, no hay `.class` ni build correcto. Es lo que acabamos de ver.
- Una **advertencia** (`WARNING`) no detiene nada: el build sigue terminando en `BUILD SUCCESS`. Es un aviso de que el código compila y funcionará, pero tiene una forma de escribirse que suele esconder problemas.

Por defecto, Maven no pasa este flag a `javac`, así que muchas advertencias quedan ocultas. Para pasar argumentos adicionales al compilador se usa `<compilerArgs>`, una lista de argumentos que se envían tal cual a `javac`:

```xml
<build>
    <plugins>
        <plugin>
            <artifactId>maven-compiler-plugin</artifactId>
            <version>3.13.0</version>
            <configuration>
                <release>21</release>
                <compilerArgs>
                    <arg>-Xlint:all</arg>
                </compilerArgs>
            </configuration>
        </plugin>
    </plugins>
</build>
```

Aprovechamos también para fijar la `<version>` del plugin de forma explícita. Sin ella, Maven avisa con un `WARNING` de que la versión no está fijada y de que el build podría no ser reproducible en otra máquina: dos desarrolladores podrían obtener una versión distinta del plugin según cuándo lo descargaran.

Ejecutamos de nuevo:

```bash
mvn clean compile
```

Salida esperada:

<pre>
...
[INFO] --- compiler:3.13.0:compile (default-compile) @ s03-2-demos ---
[INFO] Recompiling the module because of changed source code.
[INFO] Compiling 2 source files with javac [debug release 21] to target/classes
[WARNING] /ruta/s03-2-demos/src/main/java/com/curso/HistorialPrecios.java:[68,9] found raw type: java.util.List
  missing type arguments for generic class java.util.List&lt;E&gt;
[WARNING] /ruta/s03-2-demos/src/main/java/com/curso/HistorialPrecios.java:[68,28] found raw type: java.util.ArrayList
  missing type arguments for generic class java.util.ArrayList&lt;E&gt;
[WARNING] /ruta/s03-2-demos/src/main/java/com/curso/HistorialPrecios.java:[69,20] unchecked call to add(E) as a member of the raw type java.util.List
[INFO] ------------------------------------------------------------------------
[INFO] BUILD SUCCESS
[INFO] ------------------------------------------------------------------------
</pre>

Ahora compila (`BUILD SUCCESS`), pero `-Xlint:all` ha encontrado las tres advertencias que la línea `List sinTipo = new ArrayList();` del código provoca: usar `List` y `ArrayList` sin indicar el tipo que contienen (`List<String>`, por ejemplo) es un **raw type**, una forma de escribir colecciones sin ninguna comprobación de tipos por parte del compilador. Compila y funciona, pero renuncia a la seguridad de tipos que ofrecen los genéricos: cualquier tipo de objeto podría añadirse a la lista sin que el compilador lo impida, y un error de tipos que antes se detectaba al compilar solo aparecería en tiempo de ejecución.

Ejecutamos la clase desde IntelliJ (▶ junto al `main()`):

Salida esperada:

<pre>
100.0
cualquier cosa entra aquí, incluso mezclado con números
</pre>

El programa funciona igual que si `sinTipo` estuviera bien tipada: las advertencias de `-Xlint` no impiden la ejecución, solo avisan de un riesgo. En un proyecto real, revisar y corregir las advertencias antes de que se acumulen es una buena práctica: cuantas más haya, más difícil es distinguir una advertencia importante de las que no lo son.
