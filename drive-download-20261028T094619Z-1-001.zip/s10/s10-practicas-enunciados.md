# S10 Prácticas

## Objetivos

Se aplica lo aprendido en las demos del gimnasio sobre otro dominio: la cartelera de un cine, que ya conocemos de S07 y S08-1. Se construye una API REST completa de películas reutilizando las entidades de S08-1, se prueba con una colección de Postman, se añade una segunda API de sesiones con una ruta anidada y una búsqueda, y por último se lleva la misma estructura al proyecto del grupo.

Las prácticas trabajan sobre la base de datos PostgreSQL `cartelera` de S07, con las tablas `director`, `pelicula`, `sala`, `sesion` y `entrada`. El zip `s10-practicas.zip` incluye los scripts de esa base de datos en la carpeta `sql` y la solución completa para comparar al terminar.

---

## Preparación: la base de datos `cartelera`

Si ya tenemos la base de datos `cartelera` de S07, no hay que hacer nada: comprobamos en pgAdmin que tiene sus datos (3 directores, 5 películas, 2 salas, 4 sesiones y 3 entradas). Si no la tenemos, o queremos empezar desde cero:

1. En pgAdmin, clic derecho sobre `postgres` > `Query Tool`. Ejecutamos el contenido de `sql/01-crear-base-de-datos.sql` (una única sentencia, `create database cartelera`).
2. Clic derecho sobre `Databases` > `Refresh`. Clic derecho sobre `cartelera` > `Query Tool`. Ejecutamos `sql/02-tablas-y-datos.sql`, que es el script de S07 sin cambios.

---

## Práctica 1: CRUD REST de Película

Se crea un proyecto Spring Boot nuevo y se implementa la API de películas con las cuatro operaciones y los códigos de estado correctos.

**Pasos**

1. Creamos el proyecto con `File > New > Project > Spring Boot` (Generators): Name y Artifact `s10-practicas`, Type `Maven`, Group y Package `com.curso`, Java `21`, Packaging `Jar`, Configuration `Properties`. Dependencias: `Spring Web`, `Spring Data JPA` y `PostgreSQL Driver`. Renombramos la clase principal a `Aplicacion`.
2. Configuramos `application.properties` para la base de datos `cartelera`, con la contraseña en la variable de entorno `POSTGRES_PASSWORD`, `ddl-auto=validate`, `open-in-view=false` y `show-sql=true`.
3. Creamos los paquetes `model`, `repository` y `controller`.
4. Copiamos de S08-1 las entidades `Director` y `Pelicula` (con su `@ManyToOne` y la lista `peliculas` del lado inverso) y los repositorios `DirectorRepository` y `PeliculaRepository`. Las adaptamos a la API: `@JsonIgnore` en `Director.peliculas`, `setId()` en `Director`, setters en `Pelicula` y `@JsonCreator` en su constructor vacío.
5. Comprobamos que `GET /api/peliculas` falla con un 500 si quitamos `@JsonIgnore` y que funciona al ponerlo. Anotamos qué dice la consola.
6. Creamos `PeliculaController` en `/api/peliculas` con estos métodos:
   - `GET /api/peliculas`: lista todas (200).
   - `GET /api/peliculas/{id}`: devuelve una (200, o 404 si no existe).
   - `POST /api/peliculas`: crea una (201; 400 si el director no viene o no existe).
   - `PUT /api/peliculas/{id}`: modifica una (200; 404 si no existe la película; 400 si el director no es válido).
   - `DELETE /api/peliculas/{id}`: borra una (204, o 404 si no existe).
7. Arrancamos la aplicación y probamos cada método con Postman. Anotamos qué respuesta da `DELETE /api/peliculas/3` y por qué.

**Pistas**

- Las entidades son las de S08-1; no se vuelven a escribir. Lo que se añade es lo que se hizo con `Monitor` y `Clase` en las demos (setters, `@JsonIgnore`, `@JsonCreator`).
- El director viaja en el JSON como `"director": {"id": 1}`. Hay que buscarlo con `directorRepository.findById()` y asignarlo a la película antes de guardar, igual que el monitor en la Demo 2.
- En el `POST`, construir una `Pelicula` nueva con el constructor de S08-1 evita que un `id` enviado por el cliente convierta el `insert` en un `update`.
- Si `GET /api/peliculas` da `500` con `Cannot lazily initialize collection` en la consola, falta `@JsonIgnore` en `Director.peliculas`.
- Si un `POST` da `400` sin llegar al controlador y la consola dice `Cannot map null into type int`, falta `@JsonCreator` en el constructor vacío de `Pelicula`.
- El `DELETE` de una película con sesiones (la 1, por ejemplo) da `500`: la clave foránea lo impide. Es el comportamiento esperado en esta parte.

---

## Práctica 2: Colección de Postman de la cartelera

Se guarda la prueba de la Práctica 1 en una colección con variables y comprobaciones.

**Pasos**

1. Creamos en Postman una colección `S10 Cartelera` con la variable `baseUrl` (`http://localhost:8080`) y la variable `peliculaId` (vacía).
2. Añadimos estas peticiones, todas con la dirección `{{baseUrl}}/api/peliculas...`:
   1. Listar películas (200).
   2. Obtener la película 1 (200).
   3. Obtener una película que no existe (404).
   4. Crear una película (201), guardando su `id` en `peliculaId`.
   5. Crear una película con un director que no existe (400).
   6. Actualizar la película creada, con `{{peliculaId}}` (200).
   7. Eliminar la película creada (204).
3. En cada petición escribimos en `Scripts` > `Post-response` una comprobación del código de estado con `pm.test`.
4. Ejecutamos la colección con `Run collection`. Deben salir todas las comprobaciones correctas.
5. Ejecutamos la colección una segunda vez y comprobamos que sigue pasando.

**Pistas**

- La variable que se rellena sola se guarda con `pm.collectionVariables.set("peliculaId", pm.response.json().id)`, en la petición que crea la película.
- La petición 7 borra lo que creó la 4: por eso la colección se puede repetir sin ensuciar los datos.
- El orden de las peticiones en el Runner es la que muestra el panel izquierdo; se puede reordenar arrastrándolas.
- Un cuerpo `POST` válido: `{"titulo": "Prueba", "anio": 2024, "duracionMin": 90, "genero": "Drama", "director": {"id": 1}}`.
- Los nombres de los campos del JSON son los de la entidad Java (`duracionMin`), no los de la columna.
- Para comprobar el título de una película concreta, `pm.expect(pm.response.json().titulo).to.eql("El laberinto del fauno")`.

---

## Práctica 3: API de Sesión con ruta anidada y búsqueda

En el mismo proyecto se añaden las sesiones, y se amplía la API de películas con una búsqueda y las sesiones de cada película.

**Pasos**

1. Copiamos de S08-1 las entidades `Sala` y `Sesion` y sus repositorios. `Sesion` tiene dos `@ManyToOne` (película y sala) y los campos `fechaHora` (`LocalDateTime`), `precio` (`BigDecimal`) y `plazasLibres`. Añadimos `setId()` a `Sala` y los setters de `Sesion`.
2. Añadimos a `SesionRepository` el método derivado `findByPeliculaId`.
3. Añadimos a `PeliculaRepository` el método derivado `findByTituloContainingIgnoreCase`.
4. Añadimos a `PeliculaController`:
   - `GET /api/peliculas/buscar?titulo=...`: películas cuyo título contiene el texto, sin distinguir mayúsculas (200, lista vacía si no hay resultados).
   - `GET /api/peliculas/{id}/sesiones`: sesiones de una película (200, o 404 si la película no existe).
5. Creamos `SesionController` en `/api/sesiones` con listar, obtener por id, crear y eliminar. En `crear` se valida que la película y la sala existan: si falla cualquiera de las dos, respuesta 400. Una sesión nueva no tiene entradas vendidas: sus `plazasLibres` son el aforo de su sala, y el cliente no las envía.
6. Probamos con Postman: `?titulo=la` debe devolver `El laberinto del fauno`, `La forma del agua` y `Lady Bird`; `/api/peliculas/1/sesiones` debe devolver la sesión de `Todo sobre mi madre`; `/api/peliculas/999/sesiones` debe dar 404. `DELETE /api/sesiones/1` da 500, porque tiene entradas vendidas.
7. Añadimos a la colección de la Práctica 2 las peticiones nuevas, con su comprobación de estado.

**Pistas**

- `findByPeliculaId` se lee por partes: `find` + `By` + `Pelicula` (el campo de `Sesion`) + `Id` (el campo `id` de la película).
- `/buscar` y `/{id}` pueden convivir: Spring prefiere la ruta de texto fijo.
- Sin comprobar antes que la película existe, una película inexistente y una película sin sesiones dan la misma lista vacía (la película 2, `Volver`, no tiene sesiones).
- Para el `precio`, `BigDecimal` conserva los decimales de la columna `numeric(6,2)`. La respuesta mostrará `8.50`.
- En el JSON, `fechaHora` sale como `"2026-11-06T18:00:00"`.
- Dos `@ManyToOne` obligan a dos comprobaciones: encadenar dos `Optional` con `map` dentro de `map`, como en la actualización de la Práctica 1.
- Para `crear`, el cuerpo es `{"pelicula": {"id": 3}, "sala": {"id": 1}, "fechaHora": "2026-11-09T21:00:00", "precio": 8.50}`. La respuesta trae `plazasLibres` igual a 80, el aforo de la `Sala 1`.

---

## Práctica 4: La API de nuestro proyecto en grupo

Cada grupo aplica la misma estructura a la entidad principal de su proyecto.

**Pasos**

1. En el proyecto del grupo, elegimos la entidad principal y creamos su `@RestController` con listar, obtener, crear, actualizar y eliminar, con los códigos de estado de la Práctica 1.
2. Si la entidad tiene una relación `@ManyToOne`, validamos en `crear` y `actualizar` que el registro relacionado existe, y respondemos 400 si no.
3. Añadimos una búsqueda por texto con un método derivado y `@RequestParam`.
4. Si hay una relación uno a muchos, añadimos la ruta anidada correspondiente, con 404 si el recurso padre no existe.
5. Creamos una colección de Postman con una petición por cada método y una comprobación de estado en cada una.
6. Repartimos el trabajo: cada integrante prueba una parte con Postman y anota las respuestas que no esperaba.

**Pistas**

- Se parte del código de la Práctica 1 y se cambian los nombres; no se escribe desde cero.
- Si la entidad tiene la lista del lado inverso de una relación (S08-1), lleva `@JsonIgnore`; si no, el JSON falla.
- Si la entidad tiene constructor con parámetros además del vacío, el constructor vacío lleva `@JsonCreator`.
- Decidid en grupo qué rutas y qué códigos de estado devuelve cada método antes de escribir el controlador.
- Los errores `500` por restricciones de la base de datos son esperables hasta S11-1; conviene anotarlos para tratarlos entonces.
