# S10 Demos

## Objetivos

En S09 construimos una API REST completa sobre la base de datos de una tienda: `@RestController`, los verbos HTTP, los códigos de estado, el JSON y Postman. En esta parte aplicamos ese mismo patrón a algo que ya conocemos de S07 y S08-1: la base de datos `gimnasio`, con sus entidades `Monitor`, `Clase`, `Socio` e `Inscripcion`. No repetimos lo aprendido en S09; nos centramos en lo que una API real añade cuando las entidades tienen relaciones en los dos sentidos.

Empezamos por la lectura de las clases y por el primer problema de reutilizar las entidades de S08-1 en una API: el JSON falla por las listas del lado inverso (Demo 1). Seguimos con la escritura, donde aparecen los setters que S07 anunció y un detalle de Jackson 3 con el constructor (Demo 2). Después añadimos las búsquedas que una API necesita: las inscripciones de una clase en una ruta anidada y la búsqueda por nombre con un método que Spring Data JPA deduce de su nombre (Demo 3). Terminamos organizando las peticiones en una colección de Postman con variables y comprobaciones automáticas (Demo 4).

Al terminar esta parte los alumnos son capaces de:
- Reutilizar entidades JPA con relaciones bidireccionales en una API, evitando el fallo del JSON con `@JsonIgnore`.
- Añadir a una entidad los setters que Jackson necesita para leer un `POST` o un `PUT`.
- Exponer una relación con una ruta anidada y una búsqueda con un parámetro de consulta.
- Escribir el nombre de un método de repositorio para que Spring Data JPA genere la consulta.
- Guardar las peticiones en una colección de Postman con variables y comprobaciones, y ejecutarla de una vez.

---

## Preparación: la base de datos `gimnasio`

Esta parte usa la base de datos `gimnasio` de S07-1, con sus cuatro tablas (`monitor`, `clase`, `socio` e `inscripcion`) y los mismos datos. **Si ya la tenemos, no hay que hacer nada**: comprobamos en pgAdmin, con clic derecho sobre `gimnasio` > `Query Tool`, que tiene las filas de siempre:

```sql
select (select count(*) from monitor)     as monitores,
       (select count(*) from clase)       as clases,
       (select count(*) from socio)       as socios,
       (select count(*) from inscripcion) as inscripciones;
```

El resultado tiene que ser 3 monitores, 5 clases, 6 socios y 8 inscripciones. Si faltan datos porque hemos probado cosas en S08-1 (por ejemplo, el experimento de `cascade`), repetimos el script desde cero. Si no tenemos la base de datos, la creamos con los dos scripts de la carpeta `sql` del zip, que son los de S07-1 sin cambios.

**Paso 1: crear la base de datos.** En pgAdmin, clic derecho sobre `postgres` > `Query Tool`. Pegamos esta única sentencia y pulsamos ▶:

```sql
-- S10 Demos: paso 1 de 2. Crear la base de datos del gimnasio.
--
-- Se ejecuta conectado a la base de datos "postgres" (la que PostgreSQL trae de serie),
-- en la Query Tool de pgAdmin, y SOLO esta sentencia: CREATE DATABASE no se puede
-- ejecutar dentro de una transacción, y pgAdmin envuelve en una los scripts con varias sentencias.
--
-- Si ya tenemos la base de datos "gimnasio" de S07-1, se reutiliza: se salta este paso y el siguiente.

create database gimnasio;
```

**Paso 2: crear las tablas y cargar los datos.** Si `gimnasio` no aparece, clic derecho sobre `Databases` > `Refresh`. Clic derecho sobre `gimnasio` > `Query Tool`. Pegamos el contenido de `sql/02-tablas-y-datos.sql` y pulsamos ▶. El script crea las tablas con sus restricciones (`check`, `unique`, claves foráneas) y carga las filas; está explicado línea a línea en S07-1.

---

## Demo 1: Entidades de S08-1 en una API: lectura

### Crear el proyecto

Creamos el proyecto igual que en S09, con el asistente de Spring Boot de IntelliJ: `Name` y `Artifact` `s10-demos`, `Group` `com.curso`, `Package name` `com.curso`, `Type` Maven, Java 21, Spring Boot `4.1.1` y las tres dependencias `Spring Web`, `Spring Data JPA` y `PostgreSQL Driver`. Renombramos la clase principal a `Aplicacion` y el test a `AplicacionTests` con `Shift+F6`. El `pom.xml` es el de S09 cambiando el nombre; de referencia:

<pre>
&amp;lt;?xml version="1.0" encoding="UTF-8"?&amp;gt;
&amp;lt;project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
		 xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd"&amp;gt;
	&amp;lt;modelVersion&amp;gt;4.0.0&amp;lt;/modelVersion&amp;gt;
	&amp;lt;parent&amp;gt;
		&amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
		&amp;lt;artifactId&amp;gt;spring-boot-starter-parent&amp;lt;/artifactId&amp;gt;
		&amp;lt;version&amp;gt;4.1.1&amp;lt;/version&amp;gt;
		&amp;lt;relativePath/&amp;gt; &amp;lt;!-- lookup parent from repository --&amp;gt;
	&amp;lt;/parent&amp;gt;
	&amp;lt;groupId&amp;gt;com.curso&amp;lt;/groupId&amp;gt;
	&amp;lt;artifactId&amp;gt;s10-demos&amp;lt;/artifactId&amp;gt;
	&amp;lt;version&amp;gt;0.0.1-SNAPSHOT&amp;lt;/version&amp;gt;
	&amp;lt;name&amp;gt;s10-demos&amp;lt;/name&amp;gt;
	&amp;lt;description&amp;gt;S10 Demos: API REST del gimnasio con Spring Boot&amp;lt;/description&amp;gt;
	&amp;lt;url/&amp;gt;
	&amp;lt;licenses&amp;gt;
		&amp;lt;license/&amp;gt;
	&amp;lt;/licenses&amp;gt;
	&amp;lt;developers&amp;gt;
		&amp;lt;developer/&amp;gt;
	&amp;lt;/developers&amp;gt;
	&amp;lt;scm&amp;gt;
		&amp;lt;connection/&amp;gt;
		&amp;lt;developerConnection/&amp;gt;
		&amp;lt;tag/&amp;gt;
		&amp;lt;url/&amp;gt;
	&amp;lt;/scm&amp;gt;
	&amp;lt;properties&amp;gt;
		&amp;lt;java.version&amp;gt;21&amp;lt;/java.version&amp;gt;
	&amp;lt;/properties&amp;gt;
	&amp;lt;dependencies&amp;gt;
		&amp;lt;dependency&amp;gt;
			&amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
			&amp;lt;artifactId&amp;gt;spring-boot-starter-data-jpa&amp;lt;/artifactId&amp;gt;
		&amp;lt;/dependency&amp;gt;
		&amp;lt;dependency&amp;gt;
			&amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
			&amp;lt;artifactId&amp;gt;spring-boot-starter-webmvc&amp;lt;/artifactId&amp;gt;
		&amp;lt;/dependency&amp;gt;

		&amp;lt;dependency&amp;gt;
			&amp;lt;groupId&amp;gt;org.postgresql&amp;lt;/groupId&amp;gt;
			&amp;lt;artifactId&amp;gt;postgresql&amp;lt;/artifactId&amp;gt;
			&amp;lt;scope&amp;gt;runtime&amp;lt;/scope&amp;gt;
		&amp;lt;/dependency&amp;gt;
		&amp;lt;dependency&amp;gt;
			&amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
			&amp;lt;artifactId&amp;gt;spring-boot-starter-data-jpa-test&amp;lt;/artifactId&amp;gt;
			&amp;lt;scope&amp;gt;test&amp;lt;/scope&amp;gt;
		&amp;lt;/dependency&amp;gt;
		&amp;lt;dependency&amp;gt;
			&amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
			&amp;lt;artifactId&amp;gt;spring-boot-starter-webmvc-test&amp;lt;/artifactId&amp;gt;
			&amp;lt;scope&amp;gt;test&amp;lt;/scope&amp;gt;
		&amp;lt;/dependency&amp;gt;
	&amp;lt;/dependencies&amp;gt;

	&amp;lt;build&amp;gt;
		&amp;lt;plugins&amp;gt;
			&amp;lt;plugin&amp;gt;
				&amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
				&amp;lt;artifactId&amp;gt;spring-boot-maven-plugin&amp;lt;/artifactId&amp;gt;
			&amp;lt;/plugin&amp;gt;
		&amp;lt;/plugins&amp;gt;
	&amp;lt;/build&amp;gt;

&amp;lt;/project&amp;gt;
</pre>

### Configurar la conexión

Es el `application.properties` de S08-1 con otra cosa: la API no devuelve páginas, así que no hay plantillas. La contraseña sigue en la variable de entorno `POSTGRES_PASSWORD`, que definimos en `Edit Configurations...` > `Aplicacion` > `Environment variables`:

```properties
# Nombre de la aplicación (aparece entre corchetes en cada línea del log).
spring.application.name=s10-demos

# Conexión a la base de datos "gimnasio" del PostgreSQL instalado en este ordenador.
# La dirección y el usuario se escriben aquí; la contraseña NO: se lee de la variable de
# entorno POSTGRES_PASSWORD, igual que en S07, para que no quede en ningún fichero del proyecto.
spring.datasource.url=jdbc:postgresql://localhost:5432/gimnasio
spring.datasource.username=postgres
spring.datasource.password=${POSTGRES_PASSWORD}

# Las tablas son las de S07-1 (script sql/02-tablas-y-datos.sql), no las crea Hibernate.
# validate: al arrancar, Hibernate comprueba que cada entidad coincide con su tabla
# y detiene la aplicación si falta una tabla o una columna.
spring.jpa.hibernate.ddl-auto=validate

# Hibernate escribe en la consola cada sentencia SQL que envía a PostgreSQL.
spring.jpa.show-sql=true

# La sesión de Hibernate se cierra al terminar el repositorio (desactivado como en S08).
spring.jpa.open-in-view=false
```

Hay que dejar `spring.jpa.open-in-view=false`: con la sesión de Hibernate cerrada al salir del repositorio, la API se comporta como en S08-1 y el fallo de esta demo es el mismo que ya conocemos.

La clase principal es la de siempre, en el paquete raíz `com.curso`:

```java
package com.curso;

// Importamos SpringApplication y @SpringBootApplication de Spring Boot.
// Las trae el starter spring-boot-starter-webmvc; Maven las ha descargado sin que las pidamos.
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * S10 Demo 1: Arranque de la API del gimnasio
 *
 * Objetivo: arrancar la aplicación Spring Boot que sirve la API REST de la tienda.
 *
 * Lo que hace este ejemplo:
 *   - Marca la clase de arranque con @SpringBootApplication
 *   - Arranca el contenedor de Spring, Hibernate y el servidor Tomcat embebido
 *
 * Concepto clave: la clase de arranque es igual que la de S06-1. Una API REST no
 * cambia cómo arranca la aplicación: lo único nuevo está en los controladores.
 */
// @SpringBootApplication activa el escaneo del paquete com.curso y de sus subpaquetes
// (model, repository, controller), por lo que Spring encuentra solo los controladores
// y los repositorios. Por eso esta clase tiene que estar en el paquete raíz.
@SpringBootApplication
public class Aplicacion {

    // main() es el punto de entrada: IntelliJ (▶) y "mvn spring-boot:run" empiezan aquí.
    public static void main(String[] args) {
        // run() crea el contenedor de Spring, lee application.properties, conecta con
        // PostgreSQL, comprueba las tablas con Hibernate y arranca Tomcat en el puerto 8080.
        // La aplicación no termina al acabar main(): Tomcat se queda esperando peticiones.
        SpringApplication.run(Aplicacion.class, args);
    }
}
```

### Copiar las entidades y los repositorios de S08-1

Creamos los paquetes `model`, `repository` y `controller`. No escribimos las entidades de nuevo: copiamos desde el proyecto de S08-1 `Monitor`, `Clase`, `Socio` e `Inscripcion` al paquete `model`, tal como las tenemos, y `MonitorRepository` e `InscripcionRepository` al paquete `repository`. Creamos también `ClaseRepository`, una interfaz vacía que extiende `JpaRepository<Clase, Long>` (el método que lleva en el zip se explica en la Demo 3).

### El controlador: listar y obtener

El patrón es el de S09. Clic derecho sobre `controller` > `New > Java Class` > `ClaseController`:

```java
@RestController
@RequestMapping("/api/clases")
public class ClaseController {

    private final ClaseRepository claseRepository;

    public ClaseController(ClaseRepository claseRepository) {
        this.claseRepository = claseRepository;
    }

    @GetMapping
    public List<Clase> listar() {
        return claseRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Clase> obtener(@PathVariable Long id) {
        return claseRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}
```

Es exactamente el `CategoriaController` de S09 con otra entidad. Arrancamos con ▶ junto al `main()` de `Aplicacion` y, en Postman, enviamos `GET` a `http://localhost:8080/api/clases/1`. Respuesta: **`500 Internal Server Error`**, con el cuerpo genérico de Spring (`timestamp`, `status`, `error` y `path`). Esta vez la causa no es la base de datos. En la consola de IntelliJ:

<pre>
WARN ... DefaultHandlerExceptionResolver : Resolved [org.springframework.http.converter.HttpMessageNotWritableException: Could not write JSON: Cannot lazily initialize collection of role 'com.curso.model.Monitor.clases' with key '1' (no session)]
</pre>

### Por qué falla y cómo se arregla

Jackson escribe el JSON llamando a los getters. Al convertir la clase 1 llega a `getMonitor()`, que sí está cargado (un `@ManyToOne` es `EAGER`), y escribe el monitor. El monitor tiene `getClases()`, la lista del lado inverso de S08-1, y Jackson intenta escribirla también. Esa lista es `LAZY` (S08-1) y todavía no se ha leído; como `open-in-view=false`, la sesión ya está cerrada y Hibernate no puede leerla: es la `LazyInitializationException` de S08-1, que aquí sale envuelta en un `HttpMessageNotWritableException` ("no se pudo escribir el JSON").

Si la lista estuviera cargada, el resultado sería peor: la clase escribe su monitor, el monitor escribe sus clases, cada clase escribe de nuevo su monitor, y así sin fin, hasta desbordar la pila. Es el mismo bucle que evita el `toString()` de S08-1, que no incluía el lado inverso.

La solución es decirle a Jackson que ignore el lado inverso: la lista de clases no es un dato del monitor, es solo la forma de navegar la relación al revés. La anotación es `@JsonIgnore`, de la librería de Jackson (viene con el starter web, no hace falta ninguna dependencia nueva). La ponemos en `Monitor.clases` y en `Socio.inscripciones`, que son las dos listas inversas del modelo:

```java
    // Lado inverso de la relación (S08-1): la columna monitor_id está en la tabla clase.
    // @JsonIgnore le dice a Jackson que NO escriba este campo en el JSON ni lo lea de él.
    // Sin esta anotación, convertir una clase a JSON falla (se ve en la Demo 1).
    @JsonIgnore
    @OneToMany(mappedBy = "monitor")
    private List<Clase> clases = new ArrayList<>();
```

```java
    // Lado inverso (S08-1): carga diferida y cascade = ALL. @JsonIgnore evita que Jackson la escriba.
    @JsonIgnore
    @OneToMany(mappedBy = "socio", cascade = CascadeType.ALL)
    private List<Inscripcion> inscripciones = new ArrayList<>();
```

Con la anotación, Jackson ignora el campo al escribir el JSON y al leerlo. Añadimos el `import com.fasterxml.jackson.annotation.JsonIgnore;` en cada clase. `Inscripcion` y `Clase` no necesitan nada: no tienen lista inversa. Reiniciamos y repetimos el `GET`. Respuesta: `200 OK`.

<pre>
{
    "aforo": 12,
    "diaSemana": "LUNES",
    "duracionMin": 60,
    "hora": "09:00:00",
    "id": 1,
    "monitor": {
        "email": "laura.gomez@gimnasio.test",
        "especialidad": "Yoga",
        "fechaAlta": "2022-09-01",
        "id": 1,
        "nombre": "Laura Gómez"
    },
    "nombre": "Yoga matinal",
    "plazasLibres": 10
}
</pre>

El JSON lleva el monitor completo, porque `Clase` tiene el `@ManyToOne`, y no lleva sus clases. Los campos salen en orden alfabético, que no importa al cliente porque los lee por su nombre. Dos tipos nuevos respecto a S09: `LocalTime` sale como `"09:00:00"` y `LocalDate` como `"2022-09-01"`, ambos en el formato estándar de fechas, y `diaSemana` es el texto que guarda la tabla: `LUNES`, sin tilde, como pide el `check` de S07.

En la consola, Hibernate escribe el SQL de la consulta. Para una sola clase usa un `left join` con el monitor; al listar todas, una consulta para las clases y otra por cada monitor distinto (el mismo efecto que vimos en S08-1 con la carga inmediata):

<pre>
Hibernate: select c1_0.id,c1_0.aforo,c1_0.dia_semana,c1_0.duracion_min,c1_0.hora,c1_0.monitor_id,c1_0.nombre,c1_0.plazas_libres from clase c1_0
Hibernate: select m1_0.id,m1_0.email,m1_0.especialidad,m1_0.fecha_alta,m1_0.nombre from monitor m1_0 where m1_0.id=?
</pre>

Con `GET` a `/api/clases/999` la respuesta es `404 Not Found` con el cuerpo vacío, como en S09.

---

## Demo 2: `POST`, `PUT` y `DELETE` con las entidades del gimnasio

La mecánica es la de S09 (`@PostMapping`, `@RequestBody`, `ResponseEntity`, `201`, `204`, `400`, `404`). Esta demo se centra en lo que cambia porque las entidades vienen de S08-1. El constructor del controlador crece: ahora necesita también `MonitorRepository`, para comprobar que el monitor recibido existe, y `InscripcionRepository`, que usaremos en la Demo 3. Se añaden como campos `private final` y como parámetros del constructor, igual que `claseRepository`.

### Los setters que S07 anunció

Al leer el JSON de un `POST`, Jackson crea el objeto con el constructor vacío y rellena sus campos con los setters (S09). Las entidades de S08-1 no tienen setters: S07 dijo que se añadirían cuando hubiera que crear o modificar objetos, y este es el momento. En `Clase` añadimos un setter por campo (menos el `id`, que genera la base de datos y nadie cambia desde fuera) y en `Monitor` solo `setId()`, porque el cliente envía `"monitor": { "id": 3 }`:

```java
    // Jackson usa los setters para rellenar el objeto al leer un JSON (S09).
    // Aquí solo hace falta el del id: el cliente envía "monitor": {"id": 3}.
    public void setId(Long id) {
        this.id = id;
    }
```

```java
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDiaSemana() {
        return diaSemana;
    }

    public void setDiaSemana(String diaSemana) {
        this.diaSemana = diaSemana;
    }

    public LocalTime getHora() {
        return hora;
    }

    public void setHora(LocalTime hora) {
        this.hora = hora;
    }
```

(El resto de setters de `Clase` tienen la misma forma; están en el fichero completo del zip.)

### Un detalle de Jackson 3: el constructor

`Clase` tiene dos constructores, el vacío y el que recibe todos los datos. Si dejamos `Clase` solo con los setters, un `POST` al que le falte un campo numérico, por ejemplo `plazasLibres`, responde `400 Bad Request` sin que el controlador haya llegado a ejecutarse, y la consola dice:

<pre>
HttpMessageNotReadableException: JSON parse error: Cannot map `null` into type `int` (set `DeserializationFeature.FAIL_ON_NULL_FOR_PRIMITIVES` to 'false' to allow)
</pre>

La causa es que Jackson 3 elige por su cuenta el constructor con parámetros para crear el objeto, y un `int` que no viene en el JSON no puede ser `null`. Para que use el constructor vacío y los setters, como con el resto de entidades, marcamos el constructor vacío con `@JsonCreator`:

```java
    // Jackson 3 usa por su cuenta el constructor con parámetros para leer un JSON, y entonces
    // un campo int que no venga en la petición es un error. @JsonCreator le indica que use este
    // constructor vacío y los setters, que es lo que hace con el resto de las entidades.
    @JsonCreator
    public Clase() {
    }
```

Con esto un `POST` solo necesita los datos que el cliente conoce.

### Crear: `POST`

```java
    /**
     * Crea una clase nueva con un monitor existente.
     *
     * Ejemplo:
     *   POST /api/clases  {"nombre":"Zumba","diaSemana":"MARTES","hora":"18:00","duracionMin":50,
     *                      "aforo":25,"monitor":{"id":3}}   →  201 {"id":6,"nombre":"Zumba",...}
     *   POST /api/clases  sin monitor, o con un monitor que no existe  →  400 (sin cuerpo)
     */
    @PostMapping
    public ResponseEntity<Clase> crear(@RequestBody Clase datos) {
        if (datos.getMonitor() == null || datos.getMonitor().getId() == null) {
            return ResponseEntity.badRequest().build();
        }
        return monitorRepository.findById(datos.getMonitor().getId())
                .map(monitor -> {
                    // Construimos una Clase nueva con los datos recibidos, en lugar de guardar
                    // el objeto del JSON: así su id es siempre null y save() siempre inserta.
                    // Una clase nueva no tiene inscritos: todas las plazas están libres,
                    // y por eso plazasLibres vale lo mismo que el aforo, diga lo que diga el JSON.
                    Clase nueva = new Clase(datos.getNombre(), datos.getDiaSemana(), datos.getHora(),
                            datos.getDuracionMin(), datos.getAforo(), datos.getAforo(), monitor);
                    return ResponseEntity.status(HttpStatus.CREATED).body(claseRepository.save(nueva));
                })
                .orElse(ResponseEntity.badRequest().build());
    }
```

Dos decisiones propias del dominio del gimnasio:

- **Se construye una `Clase` nueva** con los datos recibidos, en lugar de guardar el objeto que llega en el JSON. Así su `id` es siempre `null` y `save()` siempre inserta (en S09 conseguíamos lo mismo con `setId(null)`).
- **`plazasLibres` vale lo mismo que `aforo`.** Una clase nueva no tiene inscritos, así que todas sus plazas están libres. Lo decide el servidor: si el cliente envía otro valor, se ignora. Es el `check` de la tabla (`plazas_libres <= aforo`) llevado al código antes de que lo tenga que rechazar la base de datos.

En Postman: `POST` a `http://localhost:8080/api/clases`, `Body` > `raw` > `JSON`:

```json
{
  "nombre": "Zumba",
  "diaSemana": "MARTES",
  "hora": "18:00",
  "duracionMin": 50,
  "aforo": 25,
  "monitor": { "id": 3 }
}
```

Respuesta: `201 Created`.

<pre>
{
    "aforo": 25,
    "diaSemana": "MARTES",
    "duracionMin": 50,
    "hora": "18:00:00",
    "id": 6,
    "monitor": {
        "email": "marta.sanz@gimnasio.test",
        "especialidad": "Entrenamiento funcional",
        "fechaAlta": "2023-01-09",
        "id": 3,
        "nombre": "Marta Sanz"
    },
    "nombre": "Zumba",
    "plazasLibres": 25
}
</pre>

Sin `"monitor"`, o con `"monitor": { "id": 99 }`, la respuesta es `400 Bad Request`.

### Actualizar: `PUT`

```java
    /**
     * Modifica nombre, día, hora, duración y monitor de una clase existente.
     * El aforo y las plazas libres no se tocan: dependen de las inscripciones.
     *
     * Ejemplo:
     *   PUT /api/clases/1    {"nombre":"Yoga 2","diaSemana":"LUNES","hora":"10:00",
     *                         "duracionMin":60,"monitor":{"id":1}}   →  200 {"id":1,"nombre":"Yoga 2",...}
     *   PUT /api/clases/999  {...}                                   →  404 (sin cuerpo)
     */
    @PutMapping("/{id}")
    public ResponseEntity<Clase> actualizar(@PathVariable Long id, @RequestBody Clase datos) {
        if (datos.getMonitor() == null || datos.getMonitor().getId() == null) {
            return ResponseEntity.badRequest().build();
        }
        return claseRepository.findById(id)
                .map(existente -> monitorRepository.findById(datos.getMonitor().getId())
                        .map(monitor -> {
                            existente.setNombre(datos.getNombre());
                            existente.setDiaSemana(datos.getDiaSemana());
                            existente.setHora(datos.getHora());
                            existente.setDuracionMin(datos.getDuracionMin());
                            existente.setMonitor(monitor);
                            return ResponseEntity.ok(claseRepository.save(existente));
                        })
                        .orElse(ResponseEntity.badRequest().<Clase>build()))
                .orElse(ResponseEntity.notFound().build());
    }
```

Igual que el `PUT` de S09: se busca la clase (404 si no existe), después su monitor (400 si no existe) y se copian los campos nuevos sobre la clase leída. Aquí solo se copian cinco; **`aforo` y `plazasLibres` no se tocan**, porque dependen de las inscripciones que ya tiene la clase (si cambiáramos el aforo sin ajustar las plazas libres, podríamos romper el `check`). En Postman: `PUT` a `http://localhost:8080/api/clases/6`:

```json
{
  "nombre": "Zumba avanzada",
  "diaSemana": "MARTES",
  "hora": "19:00",
  "duracionMin": 55,
  "monitor": { "id": 2 }
}
```

Respuesta: `200 OK` con la clase modificada (nombre, hora, duración y monitor nuevos, y el mismo aforo y plazas):

<pre>
{
    "aforo": 25,
    "diaSemana": "MARTES",
    "duracionMin": 55,
    "hora": "19:00:00",
    "id": 6,
    "monitor": {
        "email": "carlos.ruiz@gimnasio.test",
        "especialidad": "Spinning",
        "fechaAlta": "2021-03-15",
        "id": 2,
        "nombre": "Carlos Ruiz"
    },
    "nombre": "Zumba avanzada",
    "plazasLibres": 25
}
</pre>

### Borrar: `DELETE`

```java
    /**
     * Borra una clase.
     *
     * Ejemplo:
     *   DELETE /api/clases/6    →  204 (sin cuerpo)
     *   DELETE /api/clases/999  →  404 (sin cuerpo)
     *   DELETE /api/clases/1    →  500 (tiene inscripciones: la clave foránea impide borrarla)
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (!claseRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        claseRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
```

`DELETE` a `http://localhost:8080/api/clases/6` responde `204 No Content`, y repetirlo `404 Not Found`, como en S09.

### Lo que la API no prevé: el 500

Dos peticiones que rechaza la base de datos y el controlador no ha previsto. `DELETE` a `/api/clases/1`: la clase 1 tiene inscripciones y la clave foránea de S07 impide borrarla. `POST` con `"diaSemana": "FUNDAY"`: el `check` de la tabla lo rechaza. Las dos responden `500 Internal Server Error` y la consola de IntelliJ nombra la restricción que se ha violado:

<pre>
ERROR: update or delete on table "clase" violates foreign key constraint "fk_inscripcion_clase" on table "inscripcion"
ERROR: new row for relation "clase" violates check constraint "ck_clase_dia"
</pre>

Son las mismas restricciones que probamos en pgAdmin en S07-1, ahora desde una API. La base de datos protege los datos aunque el controlador no los valide. En S11-1 centralizamos estos errores para responder con un código y un mensaje claros; por ahora el 500 es el comportamiento por defecto.

---

## Demo 3: Ruta anidada y búsquedas con métodos derivados

Una API tiene que permitir buscar. Dos casos habituales: ver lo que "cuelga" de un recurso (las inscripciones de una clase) y filtrar por un texto (las clases cuyo nombre contiene "yoga"). Spring Data JPA resuelve los dos con **métodos derivados del nombre**: se escribe en la interfaz del repositorio el nombre del método y Spring genera la consulta. En S08-1 usamos uno, `findByClaseId`, como adelanto; aquí los estudiamos.

### `findByClaseId`

Ya lo tenemos en `InscripcionRepository`, copiado de S08-1:

```java
package com.curso.repository;

import com.curso.model.Inscripcion;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * S10 Demo 3: Repositorio de inscripciones
 *
 * Objetivo: buscar las inscripciones de una clase a partir de su identificador.
 *
 * Lo que hace este ejemplo:
 *   - Declara el método findByClaseId, cuyo nombre indica qué buscar
 *
 * Concepto clave: el nombre del método puede recorrer una relación. "Clase" es el campo
 * de Inscripcion que apunta a la clase, e "Id" es el campo id de esa clase.
 */
public interface InscripcionRepository extends JpaRepository<Inscripcion, Long> {

    /**
     * Devuelve las inscripciones de la clase con el identificador indicado.
     *
     * Ejemplo:
     *   findByClaseId(1)    →  las inscripciones de Yoga matinal
     *   findByClaseId(999)  →  lista vacía (no hay error si no existe)
     */
    // find + By + Clase + Id  →  inscripcion.clase.id = ?
    // SQL generado: select ... from inscripcion where clase_id = ?
    List<Inscripcion> findByClaseId(Long claseId);
}
```

El nombre se lee por partes: `find` (buscar), `By` (por), `Clase` (el campo `clase` de `Inscripcion`) e `Id` (el campo `id` de esa clase). Spring genera la consulta equivalente a `inscripcion.clase.id = ?`, sin SQL ni HQL escritos.

### `findByNombreContainingIgnoreCase`

Lo añadimos a `ClaseRepository`:

```java
package com.curso.repository;

import com.curso.model.Clase;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * S10 Demo 1 y Demo 3: Repositorio de clases
 *
 * Objetivo: acceder a la tabla clase y buscar clases por parte de su nombre.
 *
 * Lo que hace este ejemplo:
 *   - Hereda findAll, findById, existsById, save y deleteById (Demo 1 y Demo 2)
 *   - Declara un método cuyo nombre indica qué buscar: findByNombreContainingIgnoreCase (Demo 3)
 *
 * Concepto clave: Spring Data JPA lee el nombre del método y escribe la consulta.
 * El nombre es un pequeño lenguaje con reglas, no magia.
 */
public interface ClaseRepository extends JpaRepository<Clase, Long> {

    /**
     * Busca las clases cuyo nombre contiene un texto, sin distinguir mayúsculas.
     *
     * Ejemplo:
     *   findByNombreContainingIgnoreCase("yoga")  →  Yoga matinal, Yoga vespertino
     *   findByNombreContainingIgnoreCase("SPIN")  →  Spinning, Spinning avanzado
     */
    // find + By + Nombre  →  busca por el campo nombre de la entidad
    // Containing          →  contiene el texto (like '%texto%')
    // IgnoreCase          →  sin distinguir mayúsculas de minúsculas
    // SQL generado: select ... from clase where upper(nombre) like upper(?) escape '\'
    // Si el campo no existiera en Clase (por ejemplo, findByTitulo...), la aplicación fallaría al arrancar.
    List<Clase> findByNombreContainingIgnoreCase(String nombre);
}
```

Cada palabra del nombre cambia el SQL:

| Parte del nombre | Qué hace |
|---|---|
| `findBy` | Buscar filas |
| `Nombre` | Filtrar por el campo `nombre` de la entidad |
| `Containing` | Que contenga el texto (`like '%texto%'`) |
| `IgnoreCase` | Sin distinguir mayúsculas de minúsculas |

En la consola de IntelliJ vemos el SQL que Spring ha escrito:

<pre>
Hibernate: select c1_0.id,c1_0.aforo,c1_0.dia_semana,c1_0.duracion_min,c1_0.hora,c1_0.monitor_id,c1_0.nombre,c1_0.plazas_libres from clase c1_0 where upper(c1_0.nombre) like upper(?) escape '\'
</pre>

Las reglas del nombre son estrictas: si el campo no existe en la entidad (por ejemplo, `findByTituloContainingIgnoreCase` en `Clase`), la aplicación falla al arrancar con un mensaje que nombra la propiedad que no encuentra.

### La ruta anidada

```java
    /**
     * Devuelve las inscripciones de una clase, cada una con su socio.
     *
     * Ejemplo:
     *   GET /api/clases/1/inscripciones    →  200 [{"id":1,"socio":{"nombre":"Ana Pérez",...},...}, ...]
     *   GET /api/clases/999/inscripciones  →  404 (sin cuerpo)
     */
    // Ruta anidada: las inscripciones "cuelgan" de una clase, igual que en la base de datos
    // la clave foránea clase_id cuelga de la tabla clase.
    @GetMapping("/{id}/inscripciones")
    public ResponseEntity<List<Inscripcion>> inscripciones(@PathVariable Long id) {
        // Distinguimos una clase sin inscritos (200 con lista vacía) de una clase que no existe (404).
        if (!claseRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(inscripcionRepository.findByClaseId(id));
    }
```

Una **ruta anidada** hace que un recurso "cuelgue" de otro: `/api/clases/2/inscripciones` se lee "las inscripciones de la clase 2". Es la forma habitual de exponer una relación, y refleja la clave foránea `clase_id` de la tabla. El método comprueba primero que la clase existe: sin esa comprobación, una clase sin inscritos y una clase que no existe darían la misma lista vacía, y el cliente no podría distinguirlas.

En Postman: `GET` a `http://localhost:8080/api/clases/2/inscripciones`. Respuesta: `200 OK` con las tres inscripciones de Spinning (la clase llena de S07-1). Cada una lleva dentro su socio y su clase, y la clase lleva su monitor. La primera:

<pre>
{
    "socio": {
        "nombre": "Ana Pérez",
        "email": "ana.perez@correo.test",
        "fechaAlta": "2024-01-10",
        "id": 1
    },
    "clase": {
        "aforo": 3,
        "diaSemana": "MARTES",
        "duracionMin": 45,
        "hora": "18:30:00",
        "id": 2,
        "monitor": {
            "email": "carlos.ruiz@gimnasio.test",
            "especialidad": "Spinning",
            "fechaAlta": "2021-03-15",
            "id": 2,
            "nombre": "Carlos Ruiz"
        },
        "nombre": "Spinning",
        "plazasLibres": 0
    },
    "fechaInscripcion": "2025-09-15",
    "id": 3
}
</pre>

Aquí se ve por qué `Socio` también necesitaba `@JsonIgnore`: sin él, cada socio arrastraría la lista de todas sus inscripciones. Con `/api/clases/4/inscripciones` (Yoga vespertino, sin inscritos) la respuesta es `200 OK` con una lista vacía `[]`, y con `/api/clases/999/inscripciones` es `404 Not Found`.

### La búsqueda con `@RequestParam`

```java
    /**
     * Busca clases cuyo nombre contiene un texto, sin distinguir mayúsculas.
     *
     * Ejemplo:
     *   GET /api/clases/buscar?nombre=yoga  →  200 [Yoga matinal, Yoga vespertino]
     *   GET /api/clases/buscar?nombre=zzz   →  200 []
     */
    // La ruta /buscar es un texto fijo y /{id} es un patrón: Spring prefiere siempre el texto fijo,
    // así que /api/clases/buscar no se confunde con una clase de id "buscar".
    @GetMapping("/buscar")
    // @RequestParam lee el parámetro de consulta, la parte de la URL tras el "?" (?nombre=yoga).
    // A diferencia de {id}, no forma parte de la ruta: sirve para filtrar, y se pueden combinar varios.
    // Si el parámetro no viene en la URL, Spring responde 400 automáticamente.
    public List<Clase> buscar(@RequestParam String nombre) {
        return claseRepository.findByNombreContainingIgnoreCase(nombre);
    }
```

- **`@RequestParam`** lee un **parámetro de consulta**: la parte de la URL que va tras el signo `?`, como en `?nombre=yoga`. A diferencia de `{id}`, no forma parte de la ruta: sirve para filtrar y se pueden combinar varios (`?nombre=yoga&dia=LUNES`).
- **`/buscar` frente a `/{id}`.** Una ruta es un texto fijo y la otra un patrón. Spring prefiere siempre el texto fijo, así que `/api/clases/buscar` nunca se confunde con una clase de id "buscar".
- Sin el parámetro, Spring responde `400 Bad Request` automáticamente.

En Postman: `GET` a `http://localhost:8080/api/clases/buscar?nombre=yoga`. Postman muestra el parámetro en la pestaña `Params`. Respuesta: `200 OK` con `Yoga matinal` y `Yoga vespertino`. Con `?nombre=SPIN` salen `Spinning` y `Spinning avanzado` (no distingue mayúsculas), y con `?nombre=zzz` sale una lista vacía `[]` con estado 200: una búsqueda sin resultados no es un error.

### El controlador completo

Así queda `ClaseController` al terminar la demo:

```java
package com.curso.controller;

import com.curso.model.Clase;
import com.curso.model.Inscripcion;
import com.curso.repository.ClaseRepository;
import com.curso.repository.InscripcionRepository;
import com.curso.repository.MonitorRepository;
// Las mismas clases de Spring MVC que en S09.
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * S10 Demo 1, Demo 2 y Demo 3: Controlador REST de clases
 *
 * Objetivo: exponer las clases del gimnasio con las operaciones de S09, más una búsqueda
 * por nombre y la lista de inscritos de cada clase.
 *
 * Lo que hace este ejemplo:
 *   - Lista las clases y recupera una por su id, con 404 si no existe (Demo 1)
 *   - Crea, actualiza y borra clases validando el monitor (Demo 2)
 *   - Busca clases por nombre con un parámetro de consulta y lista las inscripciones
 *     de una clase en una ruta anidada (Demo 3)
 *
 * Concepto clave: el patrón es el de S09 (@RestController, ResponseEntity, Optional).
 * Lo nuevo es una entidad con relaciones inversas, una ruta anidada y un @RequestParam.
 */
@RestController
@RequestMapping("/api/clases")
public class ClaseController {

    private final ClaseRepository claseRepository;
    // Además del repositorio de clases, hacen falta el de monitores (comprobar que el monitor
    // recibido existe) y el de inscripciones (ruta anidada de la Demo 3).
    private final MonitorRepository monitorRepository;
    private final InscripcionRepository inscripcionRepository;

    public ClaseController(ClaseRepository claseRepository,
                           MonitorRepository monitorRepository,
                           InscripcionRepository inscripcionRepository) {
        this.claseRepository = claseRepository;
        this.monitorRepository = monitorRepository;
        this.inscripcionRepository = inscripcionRepository;
    }

    /**
     * Devuelve todas las clases, cada una con su monitor.
     *
     * Ejemplo:
     *   GET /api/clases  →  200 [{"aforo":12,"diaSemana":"LUNES","duracionMin":60,"hora":"09:00:00",
     *                             "id":1,"monitor":{...},"nombre":"Yoga matinal","plazasLibres":10}, ...]
     */
    @GetMapping
    public List<Clase> listar() {
        return claseRepository.findAll();
    }

    /**
     * Devuelve una clase por su identificador.
     *
     * Ejemplo:
     *   GET /api/clases/1    →  200 {"id":1,"nombre":"Yoga matinal",...}
     *   GET /api/clases/999  →  404 (sin cuerpo)
     */
    @GetMapping("/{id}")
    public ResponseEntity<Clase> obtener(@PathVariable Long id) {
        return claseRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Crea una clase nueva con un monitor existente.
     *
     * Ejemplo:
     *   POST /api/clases  {"nombre":"Zumba","diaSemana":"MARTES","hora":"18:00","duracionMin":50,
     *                      "aforo":25,"monitor":{"id":3}}   →  201 {"id":6,"nombre":"Zumba",...}
     *   POST /api/clases  sin monitor, o con un monitor que no existe  →  400 (sin cuerpo)
     */
    @PostMapping
    public ResponseEntity<Clase> crear(@RequestBody Clase datos) {
        if (datos.getMonitor() == null || datos.getMonitor().getId() == null) {
            return ResponseEntity.badRequest().build();
        }
        return monitorRepository.findById(datos.getMonitor().getId())
                .map(monitor -> {
                    // Construimos una Clase nueva con los datos recibidos, en lugar de guardar
                    // el objeto del JSON: así su id es siempre null y save() siempre inserta.
                    // Una clase nueva no tiene inscritos: todas las plazas están libres,
                    // y por eso plazasLibres vale lo mismo que el aforo, diga lo que diga el JSON.
                    Clase nueva = new Clase(datos.getNombre(), datos.getDiaSemana(), datos.getHora(),
                            datos.getDuracionMin(), datos.getAforo(), datos.getAforo(), monitor);
                    return ResponseEntity.status(HttpStatus.CREATED).body(claseRepository.save(nueva));
                })
                .orElse(ResponseEntity.badRequest().build());
    }

    /**
     * Modifica nombre, día, hora, duración y monitor de una clase existente.
     * El aforo y las plazas libres no se tocan: dependen de las inscripciones.
     *
     * Ejemplo:
     *   PUT /api/clases/1    {"nombre":"Yoga 2","diaSemana":"LUNES","hora":"10:00",
     *                         "duracionMin":60,"monitor":{"id":1}}   →  200 {"id":1,"nombre":"Yoga 2",...}
     *   PUT /api/clases/999  {...}                                   →  404 (sin cuerpo)
     */
    @PutMapping("/{id}")
    public ResponseEntity<Clase> actualizar(@PathVariable Long id, @RequestBody Clase datos) {
        if (datos.getMonitor() == null || datos.getMonitor().getId() == null) {
            return ResponseEntity.badRequest().build();
        }
        return claseRepository.findById(id)
                .map(existente -> monitorRepository.findById(datos.getMonitor().getId())
                        .map(monitor -> {
                            existente.setNombre(datos.getNombre());
                            existente.setDiaSemana(datos.getDiaSemana());
                            existente.setHora(datos.getHora());
                            existente.setDuracionMin(datos.getDuracionMin());
                            existente.setMonitor(monitor);
                            return ResponseEntity.ok(claseRepository.save(existente));
                        })
                        .orElse(ResponseEntity.badRequest().<Clase>build()))
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Borra una clase.
     *
     * Ejemplo:
     *   DELETE /api/clases/6    →  204 (sin cuerpo)
     *   DELETE /api/clases/999  →  404 (sin cuerpo)
     *   DELETE /api/clases/1    →  500 (tiene inscripciones: la clave foránea impide borrarla)
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (!claseRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        claseRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    /**
     * Busca clases cuyo nombre contiene un texto, sin distinguir mayúsculas.
     *
     * Ejemplo:
     *   GET /api/clases/buscar?nombre=yoga  →  200 [Yoga matinal, Yoga vespertino]
     *   GET /api/clases/buscar?nombre=zzz   →  200 []
     */
    // La ruta /buscar es un texto fijo y /{id} es un patrón: Spring prefiere siempre el texto fijo,
    // así que /api/clases/buscar no se confunde con una clase de id "buscar".
    @GetMapping("/buscar")
    // @RequestParam lee el parámetro de consulta, la parte de la URL tras el "?" (?nombre=yoga).
    // A diferencia de {id}, no forma parte de la ruta: sirve para filtrar, y se pueden combinar varios.
    // Si el parámetro no viene en la URL, Spring responde 400 automáticamente.
    public List<Clase> buscar(@RequestParam String nombre) {
        return claseRepository.findByNombreContainingIgnoreCase(nombre);
    }

    /**
     * Devuelve las inscripciones de una clase, cada una con su socio.
     *
     * Ejemplo:
     *   GET /api/clases/1/inscripciones    →  200 [{"id":1,"socio":{"nombre":"Ana Pérez",...},...}, ...]
     *   GET /api/clases/999/inscripciones  →  404 (sin cuerpo)
     */
    // Ruta anidada: las inscripciones "cuelgan" de una clase, igual que en la base de datos
    // la clave foránea clase_id cuelga de la tabla clase.
    @GetMapping("/{id}/inscripciones")
    public ResponseEntity<List<Inscripcion>> inscripciones(@PathVariable Long id) {
        // Distinguimos una clase sin inscritos (200 con lista vacía) de una clase que no existe (404).
        if (!claseRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(inscripcionRepository.findByClaseId(id));
    }
}
```

---

## Demo 4: Colección de Postman con variables y comprobaciones

En S09 enviamos las peticiones una a una. Probar a mano cada vez que se cambia algo no escala: una **colección** de Postman guarda las peticiones, y con **variables** y **comprobaciones** automáticas se convierte en una prueba que se repite con un clic.

### Crear la colección

1. En el panel izquierdo, `Collections` > `+` (o `New` > `Collection`). Nombre: `S10 Gimnasio`.
2. Abrimos la colección y entramos en la pestaña `Variables`. Añadimos la variable `baseUrl` con el valor `http://localhost:8080` (en las columnas del valor inicial y del valor actual). La usamos en todas las peticiones: para probar contra otro servidor basta cambiarla en un sitio.
3. Dentro de la colección, `Add request`. Nombre: `1. Listar clases`. Método `GET`, dirección `{{baseUrl}}/api/clases`. Las llaves dobles indican que se sustituye por el valor de la variable.

### Añadir una comprobación

En la petición, pestaña `Scripts` (en versiones anteriores de Postman se llama `Tests`) > `Post-response`. Escribimos:

```javascript
pm.test("Estado 200", function () {
    pm.response.to.have.status(200);
});

pm.test("Devuelve una lista", function () {
    pm.expect(pm.response.json()).to.be.an("array");
});
```

Estas líneas se ejecutan después de recibir la respuesta. `pm.test` define una comprobación con un nombre, y `pm.expect` comprueba una condición sobre la respuesta. Si no se cumple, la comprobación aparece en rojo. Pulsamos **Send** y, en la pestaña `Test Results` del panel de respuesta, vemos las dos comprobaciones en verde.

### Una variable que se rellena sola

Una variable también puede cambiar durante la ejecución. Creamos la petición `4. Crear una clase`: `POST` a `{{baseUrl}}/api/clases`, con el cuerpo `raw` > `JSON` de la Demo 2. En `Scripts` > `Post-response`:

```javascript
pm.test("Estado 201", function () {
    pm.response.to.have.status(201);
});

pm.test("Guarda el id de la clase creada", function () {
    pm.collectionVariables.set("claseId", pm.response.json().id);
});

pm.test("Una clase nueva tiene todas las plazas libres", function () {
    pm.expect(pm.response.json().plazasLibres).to.eql(25);
});
```

La segunda comprobación guarda en la variable `claseId` el `id` que la API acaba de generar. Las peticiones siguientes (actualizar y borrar) usan la dirección `{{baseUrl}}/api/clases/{{claseId}}`, de modo que siempre trabajan con la clase recién creada, sea cual sea su `id`. Para que exista la variable hay que declararla antes en la pestaña `Variables` de la colección, con el valor vacío. La tercera comprobación verifica la regla de negocio de la Demo 2: `plazasLibres` igual al aforo.

### La colección completa

En el zip, la carpeta `postman` incluye la colección terminada: `gimnasio.postman_collection.json`. Para cargarla: botón `Import` (arriba a la izquierda) > seleccionamos el fichero. Contiene diez peticiones en este orden, cada una con sus comprobaciones:

| Petición | Resultado esperado |
|---|---|
| 1. Listar clases | 200 |
| 2. Obtener la clase 1 | 200 |
| 3. Obtener una clase que no existe | 404 |
| 4. Crear una clase | 201 (guarda `claseId`) |
| 5. Crear una clase sin monitor | 400 |
| 6. Actualizar la clase creada | 200 |
| 7. Buscar clases por nombre (`?nombre=yoga`) | 200 |
| 8. Inscripciones de la clase 1 | 200 |
| 9. Inscripciones de una clase que no existe | 404 |
| 10. Eliminar la clase creada | 204 |

### Ejecutar toda la colección

Clic en los tres puntos de la colección > `Run collection` > `Run`. El **Collection Runner** envía las diez peticiones en orden y marca cada comprobación. Resultado esperado con la API en marcha y la base de datos de S07-1 sin modificar: 10 peticiones y 17 comprobaciones, todas correctas. Si cambiamos algo en el código y alguna falla, el Runner dice cuál: es la forma de comprobar en un minuto que la API sigue funcionando. Como la petición 4 crea una clase y la 10 la borra, la colección se puede ejecutar todas las veces que queramos sin ensuciar los datos.

---

## Resumen

| Método Java | HTTP | Ruta | Éxito | Errores |
|---|---|---|---|---|
| `listar` | GET | `/api/clases` | 200 | |
| `obtener` | GET | `/api/clases/{id}` | 200 | 404 |
| `crear` | POST | `/api/clases` | 201 | 400 sin monitor válido; 500 si la base de datos rechaza un dato |
| `actualizar` | PUT | `/api/clases/{id}` | 200 | 404; 400 sin monitor válido |
| `eliminar` | DELETE | `/api/clases/{id}` | 204 | 404; 500 si tiene inscripciones |
| `buscar` | GET | `/api/clases/buscar?nombre=...` | 200 | 400 sin el parámetro |
| `inscripciones` | GET | `/api/clases/{id}/inscripciones` | 200 | 404 |

### Problemas frecuentes

| Síntoma | Causa |
|---|---|
| `password authentication failed` al arrancar | Falta la variable de entorno `POSTGRES_PASSWORD` en la configuración de ejecución, o la contraseña es incorrecta |
| `Schema validation: missing table` | No existe la base de datos `gimnasio` con las tablas de S07-1 (scripts de la carpeta `sql`) |
| `Port 8080 was already in use` | Queda otra copia en marcha: ■ en todas las pestañas de **Run** |
| `500` al pedir una clase, con `Cannot lazily initialize collection` en la consola | Falta `@JsonIgnore` en `Monitor.clases` o en `Socio.inscripciones` |
| `400` en un `POST` con `Cannot map null into type int` en la consola | Falta `@JsonCreator` en el constructor vacío de `Clase` |
| `415 Unsupported Media Type` en un `POST` | En Postman, `Body` no está en `raw` > `JSON` |
| `400` en un `POST` de clase | El JSON no lleva `"monitor": { "id": ... }` o ese monitor no existe |
| `500` en un `POST` de clase | El `diaSemana` no es `LUNES`...`DOMINGO` en mayúsculas y sin tilde, o la duración o el aforo no son mayores que cero |
| La aplicación no arranca con `No property 'xxx' found for type 'Clase'` | El nombre de un método derivado nombra un campo que no existe en la entidad |

