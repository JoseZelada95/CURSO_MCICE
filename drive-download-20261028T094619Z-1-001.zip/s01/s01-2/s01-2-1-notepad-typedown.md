# S01-2 Guía 1: Notepad++ y Typedown

## Objetivos

Antes de instalar ninguna herramienta de desarrollo dejamos preparados dos editores que usaremos todo el curso. **Notepad++** es un editor de texto para abrir y modificar ficheros de configuración y de código de forma rápida. **Typedown** es un lector y editor de ficheros Markdown: los documentos de cada sesión están escritos en ese formato y con Typedown se ven con su aspecto final, con títulos, listas y bloques de código.

Los dos son gratuitos. Notepad++ tiene que estar instalado antes que Git, porque en la guía de Git lo elegiremos como editor predeterminado.

Al terminar esta guía tenemos:

- Notepad++ instalado y configurado para guardar los ficheros en UTF-8.
- Typedown instalado desde la Microsoft Store.
- Un fichero de prueba abierto con cada uno de los dos editores.

---

## 1. Por qué dos editores

Un **editor de texto** guarda únicamente caracteres, sin tipos de letra, colores ni imágenes. A ese contenido se le llama **texto plano**. Los ficheros de un proyecto Java (`.java`, `.xml`, `.properties`, `.md`) son texto plano.

Un editor de texto plano es la herramienta adecuada cuando queremos ver exactamente qué contiene un fichero, sin ningún añadido. Es lo que hace Notepad++.

**Markdown** es un formato de texto plano en el que algunos símbolos indican cómo debe mostrarse el contenido. Por ejemplo, una línea que empieza por `#` es un título, y una palabra entre dos pares de asteriscos (`**así**`) se muestra en negrita. Un fichero Markdown tiene la extensión `.md`. Un programa como Typedown interpreta esos símbolos y enseña el resultado ya formateado.

Por tanto, el mismo fichero `.md` se puede abrir de dos maneras:

<pre>
Notepad++  →  el texto plano, con los símbolos visibles (para editar con precisión)
Typedown   →  el texto formateado, con títulos y listas (para leer con comodidad)
</pre>

---

# Parte A: Notepad++

## 2. Descargar Notepad++

Entramos en la web oficial:

```text
https://notepad-plus-plus.org/downloads/
```

Descargamos la versión más reciente, en su instalador de 64 bits:

- **Tipo:** Installer (`.exe`).
- **Arquitectura:** x64.

Descargamos siempre desde la web oficial. En las páginas de descarga de terceros es frecuente encontrar anuncios que imitan el botón de descarga y llevan a otros programas.

---

## 3. Instalar Notepad++

Ejecutamos el instalador descargado. Si Windows solicita permisos de administrador, los aceptamos.

En la primera pantalla el instalador pide elegir el idioma de la instalación. Podemos dejar el que aparece por defecto o elegir español.

Después dejamos todas las opciones con sus valores por defecto, incluida la carpeta de destino:

```text
C:\Program Files\Notepad++
```

Esta ruta es importante. En la guía de Git le diremos a Git dónde está Notepad++ usando exactamente esa carpeta, así que no la cambiamos.

Al terminar, dejamos marcada la opción de ejecutar Notepad++ y pulsamos `Finish`.

---

## 4. Configurar UTF-8 como codificación por defecto

La **codificación** de un fichero de texto es la tabla que relaciona cada carácter con los números (bytes) que se guardan en el disco. **UTF-8** es la codificación estándar actual y permite escribir tildes, eñes y cualquier otro carácter sin problemas. Es la misma que declara Maven en sus proyectos.

Si un fichero se guarda con una codificación y se lee con otra, las letras con tilde aparecen como símbolos extraños. Es un fallo silencioso: el programa no da ningún error, pero el texto queda estropeado. Lo veremos en una sesión posterior con un caso real. Para evitarlo, configuramos Notepad++ desde el principio.

Vamos a `Settings > Preferences` y, en el panel izquierdo, seleccionamos `New Document`. En la interfaz en español el recorrido es `Configuración > Preferencias > Documento nuevo`.

En el apartado **Encoding** seleccionamos:

```text
UTF-8
```

Dejamos marcada la casilla `Apply to opened ANSI files`, que hace que los ficheros sin codificación reconocible se abran también como UTF-8. Pulsamos `Close`.

---

## 5. Mostrar los saltos de línea

Cada vez que pulsamos Enter, el fichero guarda un carácter invisible de **salto de línea**. Windows usa dos caracteres, llamados **CRLF**, y Linux y macOS usan uno solo, llamado **LF**. En la guía de Git veremos que Git convierte entre ambos.

Para ver esos caracteres invisibles vamos a `View > Show Symbol > Show All Characters` (en español, `Ver > Mostrar símbolo > Mostrar todos los caracteres`). Notepad++ dibuja al final de cada línea las marcas `CR` y `LF`.

Volvemos a elegir la misma opción para ocultarlos cuando no los necesitemos.

---

## 6. Comprobar Notepad++

Creamos un fichero de prueba:

1. Pulsamos `Ctrl + N` para crear un documento nuevo.
2. Escribimos una línea con tildes y eñes: `Prueba de Notepad++: acción, año, canción`.
3. Pulsamos `Ctrl + S` y guardamos el fichero como `prueba.txt` en la carpeta `Documentos`.
4. Cerramos Notepad++ y lo volvemos a abrir. Abrimos `prueba.txt` con `Ctrl + O`.

Debe verse la misma línea, con las tildes y la eñe correctas. En la barra de estado, en la parte inferior de la ventana, debe aparecer `UTF-8`.

Para comprobar la versión instalada vamos a `?` > `About Notepad++`.

---

# Parte B: Typedown

## 7. Descargar Typedown

Typedown se instala desde la **Microsoft Store**, la tienda de aplicaciones de Windows.

1. Abrimos la Microsoft Store desde `Inicio`.
2. Escribimos `Typedown` en el buscador.
3. Elegimos la aplicación **Typedown**, descrita como editor de Markdown ligero para Windows.
4. Pulsamos `Obtener` (o `Instalar`).

Es gratuita y funciona en Windows 10 (versión 1903 o posterior) y en Windows 11.

Existe otra herramienta llamada Typedown que es una extensión para Visual Studio Code y no tiene relación con esta. Nos aseguramos de instalar la que aparece en la Microsoft Store.

---

## 8. Comprobar Typedown

Vamos a comprobar que Typedown interpreta el formato Markdown. Creamos un fichero con Notepad++:

1. Abrimos Notepad++ y pulsamos `Ctrl + N`.
2. Pegamos el siguiente texto:

```markdown
# Mi primer documento

Este texto tiene una palabra en **negrita** y otra en *cursiva*.

Lista de herramientas del curso:

- Notepad++
- Typedown
- JDK 21
```

3. Guardamos el fichero con `Ctrl + S`, con el nombre `prueba.md` en la carpeta `Documentos`. Al guardar, elegimos `All types (*.*)` en el desplegable de tipo de fichero, para que Notepad++ no le añada la extensión `.txt`.

Ahora abrimos el mismo fichero con Typedown. En el Explorador de archivos hacemos clic derecho sobre `prueba.md` y seleccionamos `Abrir con` > `Elegir otra aplicación` > `Typedown` (en Windows 11 puede estar en `Mostrar más opciones`). Pulsamos `Aceptar`.

Typedown debe mostrar un título grande, la palabra **negrita** en negrita, la palabra *cursiva* en cursiva y una lista con tres elementos, sin los símbolos `#`, `**` ni `-` visibles.

Si en el diálogo de `Abrir con` marcamos `Usar siempre esta aplicación`, Typedown pasa a ser el programa que abre los ficheros `.md` con doble clic. Para editar un fichero con Notepad++ usamos entonces el clic derecho y la opción `Edit with Notepad++`, que el instalador de Notepad++ añade al menú contextual.

---

## Punto de control

Antes de continuar con la instalación del JDK comprobamos:

| Comprobación | Resultado esperado |
|---|---|
| Notepad++ se abre y `prueba.txt` conserva las tildes y la eñe | Sí, con `UTF-8` en la barra de estado |
| Ruta de instalación de Notepad++ | `C:\Program Files\Notepad++` |
| Typedown se abre desde el menú Inicio | Sí |
| `prueba.md` en Typedown | Título, negrita, cursiva y lista formateados |

Con los dos editores listos, el siguiente paso es instalar el JDK.
