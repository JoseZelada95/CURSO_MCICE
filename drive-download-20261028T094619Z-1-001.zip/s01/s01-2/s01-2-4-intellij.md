# S01-2 Guía 4: IntelliJ IDEA en Windows

## Objetivos

Instalar **IntelliJ IDEA** y dejarlo preparado para trabajar durante el curso con Java 21 (Eclipse Temurin), Git y el terminal integrado. Al final creamos un proyecto de prueba para comprobar que el JDK compila y ejecuta código dentro del IDE.

Un **IDE** (*Integrated Development Environment*, entorno de desarrollo integrado) es un programa que reúne en una sola ventana el editor de código, el compilador, la ejecución de programas y la conexión con otras herramientas como Git o Maven. IntelliJ IDEA es el IDE que usaremos en todas las sesiones.

La edición gratuita incluye lo necesario para trabajar con Java, Maven y Git. Durante los primeros 30 días pueden estar disponibles también funciones de pago; cuando termina la prueba, IntelliJ sigue funcionando con las funciones gratuitas.

Para este curso el entorno queda así:

<pre>
JDK:                   Eclipse Temurin 21
IDE:                   IntelliJ IDEA
Control de versiones:  Git
Editor auxiliar:       Notepad++
</pre>

---

## 1. Descargar IntelliJ IDEA

Entramos en la web oficial de JetBrains:

```text
https://www.jetbrains.com/idea/
```

Descargamos la versión estable para Windows, arquitectura x64, en formato `.exe`.

---

## 2. Ejecutar el instalador

Ejecutamos el fichero descargado, cuyo nombre tendrá esta forma:

```text
idea-2026.x.x.exe
```

Si Windows solicita permisos de administrador, los aceptamos. Seguimos hasta la pantalla `Installation Options`.

---

## 3. Installation Options

Marcamos estas cuatro casillas:

<pre>
☑ IntelliJ IDEA
☑ Add "bin" folder to the PATH
☑ Add "Open Folder as Project"
☑ .java
</pre>

Cada una hace lo siguiente:

- **IntelliJ IDEA:** crea un acceso directo al IDE en el escritorio.
- **Add "bin" folder to the PATH:** añade los ejecutables de IntelliJ al `PATH` de Windows, la lista de carpetas en la que Windows busca los programas al escribir un comando.
- **Add "Open Folder as Project":** añade al menú contextual de Windows (clic derecho sobre una carpeta) una opción para abrirla directamente como proyecto de IntelliJ.
- **.java:** asocia los ficheros `.java` con IntelliJ IDEA.

Dejamos sin marcar las asociaciones `.gradle`, `.groovy`, `.kt`, `.kts` y `.pom`, que no necesitamos.

---

## 4. Menú Inicio

En `Choose Start Menu Folder` dejamos la carpeta `JetBrains` y no marcamos `Do not create shortcuts`. Pulsamos `Install` y esperamos a que termine.

---

## 5. Primer arranque

Abrimos IntelliJ IDEA desde `Inicio > JetBrains > IntelliJ IDEA`.

Si aparece la pregunta por el idioma, elegimos **English**. La documentación, los menús y los mensajes de error de JetBrains están en inglés, y así todas las capturas y nombres de menú de las sesiones coinciden con lo que veremos en pantalla.

Si el programa pregunta por importar configuraciones anteriores, elegimos `Do not import settings`, para partir de un entorno limpio.

---

## 6. IntelliJ y Java no son lo mismo

IntelliJ usa su propio runtime interno para ejecutarse a sí mismo. Nuestros programas Java, en cambio, se compilan y se ejecutan con el JDK que instalamos para el curso:

<pre>
Runtime de IntelliJ  →  ejecuta el IDE
Temurin 21           →  compila y ejecuta nuestros programas Java
</pre>

---

## 7. Comprobar que IntelliJ detecta Temurin 21

En la pantalla inicial pulsamos `New Project` y, en el panel izquierdo, seleccionamos `Java`. Miramos el campo **JDK**. Debe aparecer:

<pre>
Eclipse Temurin 21.0.x
</pre>

con una ruta parecida a `C:\Program Files\Eclipse Adoptium\...`. Si aparece Temurin 21, IntelliJ ha detectado el JDK.

Si no aparece, desplegamos el campo `JDK` y elegimos `Add JDK from disk...`; seleccionamos la carpeta `C:\Program Files\Eclipse Adoptium\jdk-21...`.

---

## 8. Comprobar Git dentro de IntelliJ

Desde la pantalla inicial abrimos `Options Menu > Settings` (o pulsamos `Ctrl + Alt + S`). Vamos a `Version Control > Git`. En el campo `Path to Git executable` debe aparecer:

```text
C:\Program Files\Git\cmd\git.exe
```

Pulsamos `Test`. El resultado debe indicar una versión válida de Git:

<pre>
Git version is 2.x.x
</pre>

Con ese mensaje, Git funciona dentro de IntelliJ. Pulsamos `OK`.

---

## 9. Crear un proyecto de prueba

Vamos a crear un proyecto solo para comprobar que el JDK compila y ejecuta código. No es un proyecto del curso y podremos borrarlo después: los proyectos del curso se crean con Maven a partir de la siguiente sesión.

Vamos a `New Project`, seleccionamos `Java` en el panel izquierdo y rellenamos:

- **Name:** `prueba-intellij`.
- **Build system:** `IntelliJ`. El **sistema de construcción** (*build system*) es la herramienta que compila y empaqueta el proyecto. `IntelliJ` es el sistema propio del IDE, el más sencillo, y basta para esta prueba.
- **JDK:** `Eclipse Temurin 21`.
- **Add sample code:** marcada. IntelliJ añade una clase de ejemplo para poder ejecutar algo nada más crear el proyecto.
- **Create Git repository:** desmarcada. Validamos primero Java por separado y activamos Git después.

Pulsamos `Create`.

---

## 10. Ejecutar el código Java

IntelliJ crea una clase de ejemplo. Abrimos `Main.java` desde el panel de proyecto y pulsamos el triángulo verde (▶) que aparece junto al método `main`. **`main`** es el método por el que empieza a ejecutarse un programa Java.

En la ventana de consola, en la parte inferior, debe aparecer una salida de ejemplo y, al final:

<pre>
Process finished with exit code 0
</pre>

**`exit code 0`** significa que IntelliJ ha compilado el programa, Java lo ha ejecutado y el programa ha terminado sin errores. Cualquier otro número indica un fallo. Con esto confirmamos que Java funciona dentro de IntelliJ.

---

## 11. Activar Git en el proyecto

Con el proyecto abierto, vamos a `Main Menu (☰) > Git > Enable Version Control Integration...`. Si el menú se llama `VCS`, es la misma opción. Seleccionamos `Git` en el desplegable y pulsamos `OK`.

IntelliJ crea el repositorio Git del proyecto. Es equivalente a ejecutar `git init` en la carpeta del proyecto, como hicimos en la guía de Git.

---

## 12. Primer commit desde IntelliJ

Abrimos la ventana de commit con `Ctrl + K` (o `Git > Commit`). Seleccionamos los ficheros que queremos incluir, escribimos el mensaje:

```text
Primer commit desde IntelliJ
```

y pulsamos `Commit`.

---

## 13. Aviso sobre CRLF

En Windows puede aparecer un aviso sobre **CRLF**, los saltos de línea de Windows que vimos en las guías anteriores. IntelliJ propone la opción `Fix and Commit`. La usamos, porque coincide con la configuración de Git que hicimos al instalarlo:

<pre>
Windows / local  →  CRLF
Repositorio      →  LF
</pre>

---

## 14. Abrir el terminal integrado

El terminal integrado es una consola dentro de la ventana de IntelliJ, que se abre directamente en la carpeta del proyecto. Se abre y se oculta con:

```text
Alt + F12
```

También se puede abrir desde `View > Tool Windows > Terminal`. Para cerrar la sesión del terminal escribimos `exit`. Durante el curso usaremos normalmente `Alt + F12` para mostrarlo y ocultarlo.

---

## 15. Comprobar el repositorio desde el terminal

IntelliJ no sustituye a Git: cuando usamos `Enable Version Control` o `Commit`, IntelliJ ejecuta Git por debajo. Por eso podemos comprobar desde el terminal lo que hemos hecho con la interfaz gráfica.

Con el terminal abierto (`Alt + F12`), ejecutamos:

```bash
git branch --show-current
git ls-files
git status
```

Salida esperada:

<pre>
main
(lista de ficheros del proyecto, entre ellos src/Main.java)
On branch main
nothing to commit, working tree clean
</pre>

- `git branch --show-current` muestra la rama activa, que debe ser `main`.
- `git ls-files` muestra los ficheros que Git sigue. La lista exacta depende de la versión de IntelliJ y de los ficheros que hayamos incluido en el commit, pero debe aparecer `src/Main.java`.
- `git status` debe indicar `working tree clean`: no hay cambios pendientes.

---

## 16. Maven en IntelliJ

IntelliJ puede trabajar con proyectos Maven en su edición gratuita: entiende el `pom.xml`, las dependencias y los comandos de Maven. Instalaremos Maven en la siguiente guía y comprobaremos cómo lo ve IntelliJ.

---

## 17. Si el equipo va justo de memoria

IntelliJ usa bastante memoria en el primer arranque, durante la **indexación** (el análisis que hace del JDK y del proyecto para poder ofrecer autocompletado) y al crear cachés. En un equipo con 8 GB de RAM puede producirse un consumo alto de CPU, el ventilador al máximo y cierta lentitud. Una vez terminada la indexación inicial, el consumo suele estabilizarse.

Para consultar la memoria asignada a IntelliJ, vamos a `Help > Change Memory Settings` (o pulsamos `Ctrl + Shift + A` y escribimos `Change Memory Settings`). Un valor de `Maximum Heap Size` de 2048 MB es razonable para un equipo de 8 GB. No conviene reducirlo sin comprobar antes que hay un problema real.

Si IntelliJ bloquea el equipo, comprobamos primero en `Administrador de tareas > Rendimiento > Memoria` la RAM utilizada y disponible. Como medida de contingencia, podemos ampliar la memoria virtual de Windows (un espacio del disco que Windows usa como RAM adicional cuando se agota la física):

1. Pulsamos `Win + R`, escribimos `sysdm.cpl` y pulsamos Enter.
2. Vamos a `Opciones avanzadas > Rendimiento > Configuración > Opciones avanzadas > Memoria virtual`.
3. Establecemos un tamaño inicial de 4096 MB y un tamaño máximo de 8192 MB.

Esto no sustituye a la RAM física, pero evita que el sistema se quede sin margen.

No desactivamos plugins de IntelliJ salvo que comprobemos un problema real de rendimiento, y conservamos siempre los necesarios para Java, Maven y Git.

---

## 18. Problemas frecuentes

| Problema | Qué comprobamos |
|---|---|
| IntelliJ no detecta el JDK | `New Project > Java > JDK` debe mostrar `Eclipse Temurin 21`; si no, `Add JDK from disk...` |
| IntelliJ no detecta Git | `Settings > Version Control > Git`, ruta `C:\Program Files\Git\cmd\git.exe` y botón `Test` |
| El proyecto no está bajo control de versiones | `Git > Enable Version Control Integration...` y elegir `Git` |
| No sabemos en qué rama estamos | En el terminal, `git branch --show-current` (debe devolver `main`) |
| No sabemos qué ficheros sigue Git | En el terminal, `git ls-files` |
| No sabemos si hay cambios pendientes | En el terminal, `git status` |

---

## Punto de control

Antes de continuar con la instalación de Maven comprobamos:

| Comprobación | Resultado esperado |
|---|---|
| JDK en `New Project > Java` | `Eclipse Temurin 21.0.x` |
| Programa de prueba | Termina con `Process finished with exit code 0` |
| Git en `Settings` | Ruta `C:\Program Files\Git\cmd\git.exe` y `Test` correcto |
| `git branch --show-current` | `main` |
| `git status` | `working tree clean` |

## Resumen conceptual

<pre>
Temurin 21     →  JDK que usamos para desarrollar Java
IntelliJ IDEA  →  IDE
Git            →  control de versiones
Commit         →  guarda cambios en el historial local
Alt + F12      →  abre y oculta el terminal de IntelliJ
</pre>

IntelliJ no oculta Git: las acciones gráficas de IntelliJ son las mismas operaciones de Git que ya conocemos, y si algo falla podemos comprobarlo desde el terminal con `git status`, `git branch --show-current` o `git log --oneline`.
