# S01-2 Guía 2: JDK 21 con Eclipse Temurin en Windows

## Objetivos

Instalar **JDK 21 LTS** con **Eclipse Temurin** y comprobar que Java queda correctamente configurado en Windows.

El **JDK** (*Java Development Kit*) es el kit de desarrollo de Java: contiene el compilador, que transforma el código que escribimos en un formato ejecutable, y la máquina virtual de Java, que lo ejecuta. **Eclipse Temurin** es una distribución gratuita y de código abierto del JDK, mantenida por el proyecto Eclipse Adoptium. **LTS** (*Long Term Support*) indica que esa versión recibe actualizaciones de seguridad durante años, por lo que es la que se usa en proyectos profesionales.

Al terminar esta guía deben funcionar estos tres comandos:

```bash
java -version
javac -version
echo %JAVA_HOME%
```

Estos comandos se ejecutan en el Símbolo del sistema de Windows (CMD).

---

## 1. Descargar Eclipse Temurin JDK 21

Entramos en la web oficial de **Eclipse Adoptium**:

```text
https://adoptium.net/temurin/releases/?version=21
```

Seleccionamos:

- **Version:** JDK 21 - LTS
- **Operating System:** Windows
- **Architecture:** x64
- **Package Type:** JDK
- **JVM:** HotSpot
- **Installer:** MSI

Si aparecen varias revisiones de Java 21, elegimos la **más reciente**. Su número tendrá esta forma:

```text
21.0.x
```

No es necesario que todos los equipos tengan exactamente la misma revisión `21.0.x`, pero sí la misma **versión mayor**: Java 21.

---

## 2. Ejecutar el instalador

Ejecutamos el archivo `.msi` descargado. Si Windows solicita permisos de administrador, los aceptamos.

Para un ordenador personal o de aula en el que tengamos permisos de administrador, podemos elegir la opción **Install for all users of this machine**. De esta forma el JDK queda instalado para todos los usuarios del equipo.

Normalmente se instalará en una ruta como:

```text
C:\Program Files\Eclipse Adoptium\jdk-21...
```

---

## 3. Revisar las opciones de instalación

En la pantalla **Custom Setup** aparecen varias características. Prestamos atención a estas tres.

### Add to PATH

Debe quedar activada. El **PATH** es una lista de carpetas que Windows recorre cada vez que escribimos un comando en la consola. Con esta opción, la carpeta del JDK entra en esa lista y podemos ejecutar `java` y `javac` desde cualquier carpeta del Símbolo del sistema.

Sin esta opción tendríamos que escribir la ruta completa al ejecutable cada vez que quisiéramos usarlo.

### Set or update JAVA_HOME variable

Esta opción puede aparecer **desactivada por defecto**. La activamos manualmente seleccionando **Se instalará en la unidad de disco duro local** (en inglés, *Will be installed on local hard drive*).

Con ello, el instalador crea o actualiza la variable de entorno `JAVA_HOME`.

### Associate .jar

Podemos dejar esta opción activada. Hace que Windows asocie los ficheros `.jar` con Java, de modo que algunos programas Java empaquetados como `.jar` se pueden ejecutar con doble clic. Un **JAR** (*Java ARchive*) es un fichero que agrupa código Java ya compilado. No afecta al funcionamiento de IntelliJ, Git ni al desarrollo normal.

---

## 4. Qué es JAVA_HOME

`JAVA_HOME` es una **variable de entorno de Windows**: un valor con nombre, guardado en el sistema, que cualquier programa puede consultar. Su función es indicar a otras aplicaciones dónde está instalado el JDK. Por ejemplo, puede contener:

```text
C:\Program Files\Eclipse Adoptium\jdk-21.0.x.x-hotspot
```

Podemos imaginarla como un cartel que dice: «El JDK de Java está instalado aquí».

Muchas herramientas de desarrollo leen esta variable para localizar Java:

- Maven, que instalaremos en esta misma parte.
- Gradle y otras herramientas de construcción.
- Servidores de aplicaciones.
- Scripts de compilación.

IntelliJ IDEA puede localizar un JDK por otros mecanismos, así que `JAVA_HOME` no siempre es estrictamente necesario para IntelliJ. Aun así, Maven sí la necesita, y por eso la configuramos ahora.

---

## 5. JAVA_HOME y PATH no son lo mismo

Conviene distinguir las dos cosas.

`JAVA_HOME` indica **dónde está instalado el JDK**:

```text
JAVA_HOME=C:\Program Files\Eclipse Adoptium\jdk-21...
```

`PATH` permite **ejecutar programas desde la consola** sin escribir su ruta completa. Gracias al `PATH` escribimos:

```bash
java
```

en lugar de algo como:

```bash
"C:\Program Files\Eclipse Adoptium\jdk-21...\bin\java.exe"
```

En resumen:

<pre>
JAVA_HOME  →  indica dónde está Java
PATH       →  permite ejecutar Java desde cualquier carpeta
</pre>

---

## 6. Finalizar la instalación

Continuamos con el instalador, pulsamos `Install`, esperamos a que termine y cerramos el asistente.

---

# Comprobación de la instalación

Abrimos un **Símbolo del sistema nuevo** después de instalar. Una ventana que estuviera abierta antes de la instalación no conoce todavía los cambios en las variables de entorno.

## 7. Comprobar `java -version`

Abrimos `Inicio`, escribimos `cmd` y pulsamos Enter sobre `Símbolo del sistema`. Ejecutamos:

```bash
java -version
```

Este comando muestra la versión del entorno de ejecución de Java que Windows encuentra al escribir `java`.

Salida esperada:

<pre>
openjdk version "21.0.x" ...
OpenJDK Runtime Environment Temurin-21...
OpenJDK 64-Bit Server VM Temurin-21...
</pre>

Lo importante es que aparezca `21` y la palabra `Temurin`. Si el comando funciona, Windows encuentra el ejecutable de Java.

---

## 8. Comprobar `javac -version`

Ejecutamos:

```bash
javac -version
```

Salida esperada:

<pre>
javac 21.0.x
</pre>

`javac` es el **compilador de Java**. **Compilar** es transformar nuestros ficheros de código fuente (`.java`) en ficheros de **bytecode** (`.class`), un formato que la máquina virtual de Java sabe ejecutar:

<pre>
Hola.java
    ↓
  javac
    ↓
Hola.class
</pre>

Esta comprobación es especialmente importante. Si funciona `java -version` pero no `javac -version`, puede que solo tengamos instalado un entorno de ejecución, sin el compilador, o que haya un problema con la configuración del JDK. Para desarrollar necesitamos que funcionen **ambos** comandos.

---

## 9. Diferencia entre `java` y `javac`

De forma simplificada:

<pre>
javac  →  compila el programa
java   →  ejecuta el programa
</pre>

Si tuviéramos un fichero `Hola.java`, lo compilaríamos con:

```bash
javac Hola.java
```

Esto generaría `Hola.class`, que se ejecutaría con:

```bash
java Hola
```

Durante el curso usaremos IntelliJ IDEA para hacer estas operaciones de forma más cómoda, pero por debajo IntelliJ usa estas mismas herramientas del JDK.

---

## 10. Comprobar JAVA_HOME

Ejecutamos:

```bash
echo %JAVA_HOME%
```

Salida esperada:

<pre>
C:\Program Files\Eclipse Adoptium\jdk-21.0.x.x-hotspot
</pre>

Esto confirma que la variable `JAVA_HOME` está correctamente configurada. Si el comando devuelve literalmente `%JAVA_HOME%`, o una ruta que no existe, la variable no se ha configurado bien.

---

## Punto de control

No continuamos con **Git** ni con **IntelliJ IDEA** hasta que las tres comprobaciones sean correctas:

| Comando | Qué comprobamos |
|---|---|
| `java -version` | Que Java puede ejecutarse y usamos Java 21 |
| `javac -version` | Que tenemos el compilador del JDK 21 |
| `echo %JAVA_HOME%` | Que Windows conoce la ubicación del JDK |

El ordenador debe quedar así:

<pre>
Windows
   │
   └── Eclipse Temurin JDK 21
          │
          ├── java
          ├── javac
          ├── PATH
          └── JAVA_HOME
</pre>

Superado este punto de control, continuamos con la instalación de Git.
