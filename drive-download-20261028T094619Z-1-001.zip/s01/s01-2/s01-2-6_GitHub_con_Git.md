# GitHub con Git en Windows

## Objetivo

Conectar correctamente **Git** con **GitHub** y comprender los dos recorridos básicos que utilizaremos durante el curso:

```
A. Proyecto local → GitHub
B. GitHub → copia local
```

&nbsp;

Al terminar esta guía debemos saber:

- qué diferencia hay entre Git y GitHub;  
- qué es un repositorio remoto;  
- qué significa `origin`;  
- cómo hacer un `push`;  
- cómo hacer un `clone`;  
- cómo funciona la autenticación mediante Git Credential Manager;  
- cómo comprobar que Windows ha guardado correctamente la autenticación.

---

# 1\. Git y GitHub no son lo mismo

Antes de empezar conviene separar claramente ambos conceptos.

## Git

Git es un **sistema de control de versiones**.

Nos permite:

- crear repositorios;  
- guardar cambios mediante commits;  
- consultar el historial;  
- trabajar con ramas;  
- comparar versiones;  
- recuperar estados anteriores.

Git puede utilizarse completamente en local, sin conexión a Internet y sin GitHub.

## GitHub

GitHub es un **servicio en Internet para alojar repositorios Git**.

Nos permite:

- guardar una copia remota de un repositorio;  
- compartir proyectos;  
- colaborar con otras personas;  
- clonar repositorios;  
- hacer `push` y `pull`;  
- trabajar con ramas remotas.

Podemos resumirlo así:

```
Git     → controla versiones
GitHub  → aloja repositorios Git en remoto
```

&nbsp;

---

# 2\. Conceptos mínimos antes de empezar

## Repositorio local

Es el repositorio que tenemos en nuestro ordenador.

Ejemplo:

```
C:\Users\Alumno\Desktop\mi-proyecto
```

&nbsp;

## Repositorio remoto

Es el repositorio alojado en GitHub.

Ejemplo:

```
https://github.com/usuario/mi-proyecto
```

&nbsp;

## `origin`

`origin` es el nombre que normalmente damos al repositorio remoto principal.

Por ejemplo:

```sh
git remote add origin https://github.com/usuario/mi-proyecto.git
```

&nbsp;

Aquí:

```
origin
```

&nbsp;

es simplemente un nombre corto que Git utiliza para referirse al repositorio remoto.

## `main`

Durante el curso utilizaremos:

```
main
```

&nbsp;

como rama principal.

La idea es mantener la misma rama principal tanto en local como en GitHub.

## `push`

Envía commits desde nuestro repositorio local al remoto.

```
LOCAL → GITHUB
```

&nbsp;

Ejemplo:

```sh
git push
```

&nbsp;

## `pull`

Descarga cambios del repositorio remoto y los integra en nuestra rama local.

```
GITHUB → LOCAL
```

&nbsp;

Lo utilizaremos más adelante.

## `clone`

Crea una copia local completa de un repositorio remoto.

```
GITHUB → NUEVO REPOSITORIO LOCAL
```

&nbsp;

Ejemplo:

```sh
git clone https://github.com/usuario/proyecto.git
```

&nbsp;

---

# 3\. Identidad Git y autenticación GitHub

Es muy importante no confundir ambas cosas.

## Identidad Git

Se configura con:

```cmd
git config --global user.name "Nombre Apellidos"
git config --global user.email "correo@ejemplo.com"
```

&nbsp;

Estos datos se guardan en los commits.

Sirven para indicar:

```
quién ha creado el commit
```

&nbsp;

## Autenticación GitHub

La autenticación sirve para demostrar a GitHub:

```
quién tiene permiso para acceder o modificar un repositorio
```

&nbsp;

No es lo mismo que:

```
user.name
user.email
```

&nbsp;

Podemos resumirlo así:

```
user.name / user.email
→ identidad del autor de los commits

Git Credential Manager
→ autenticación con GitHub
```

&nbsp;

---

# 4\. Git Credential Manager

Durante la instalación de Git for Windows dejamos seleccionado:

```
Git Credential Manager
```

&nbsp;

Esta herramienta facilita la autenticación con GitHub.

Comprobamos si está configurado:

```cmd
git config --global --get credential.helper
```

&nbsp;

El resultado esperado es:

```
manager
```

&nbsp;

Si no aparece nada, lo configuramos manualmente:

```cmd
git config --global credential.helper manager
```

&nbsp;

Y comprobamos otra vez:

```cmd
git config --global --get credential.helper
```

&nbsp;

Debe devolver:

```
manager
```

&nbsp;

---

# 5\. RECORRIDO A · Tenemos un proyecto local y queremos subirlo a GitHub

El flujo será:

```
Repositorio local
      ↓
git init
      ↓
crear archivos
      ↓
git add
      ↓
git commit
      ↓
crear repositorio vacío en GitHub
      ↓
git remote add origin
      ↓
git push
```

&nbsp;

---

# 6\. Crear el repositorio local

Desde Git Bash:

```sh
cd ~/Desktop
mkdir prueba-github
cd prueba-github
```

&nbsp;

Inicializamos Git:

```sh
git init
```

&nbsp;

Comprobamos:

```sh
git status
```

&nbsp;

Debemos ver algo similar a:

```
On branch main

No commits yet
```

&nbsp;

---

# 7\. Crear un archivo y hacer el primer commit

Creamos un README:

```sh
echo "Repositorio de prueba para GitHub" > README.md
```

&nbsp;

Comprobamos:

```sh
git status
```

&nbsp;

El archivo aparecerá como:

```
Untracked
```

&nbsp;

Lo añadimos al staging area:

```sh
git add README.md
```

&nbsp;

Comprobamos:

```sh
git status
```

&nbsp;

Ahora debería aparecer en:

```
Changes to be committed
```

&nbsp;

Creamos el commit:

```sh
git commit -m "Primer commit"
```

&nbsp;

---

# 8\. Crear el repositorio remoto en GitHub

Entramos en GitHub y creamos un repositorio nuevo.

Por ejemplo:

```
Repository name: prueba-github
```

&nbsp;

Puede ser:

```
Public
```

&nbsp;

o:

```
Private
```

&nbsp;

según lo que queramos hacer.

## Importante

Como el proyecto **ya existe localmente**, creamos el repositorio remoto vacío.

No marcamos:

```
Add a README file
Add .gitignore
Choose a license
```

&nbsp;

La razón es sencilla: ya tenemos contenido e historial local.

Si GitHub crea también un README o un commit inicial, tendremos dos historiales diferentes desde el principio y complicaremos innecesariamente la primera sincronización.

---

# 9\. Conectar el repositorio local con GitHub

GitHub nos mostrará una URL parecida a:

```
https://github.com/USUARIO/prueba-github.git
```

&nbsp;

Desde Git Bash ejecutamos:

```sh
git remote add origin https://github.com/USUARIO/prueba-github.git
```

&nbsp;

---

# 10\. ¿Qué significa `origin`?

`origin` es el nombre convencional que Git utiliza para referirse al repositorio remoto principal.

Podemos imaginarlo así:

```
origin = "mi repositorio en GitHub"
```

&nbsp;

Podríamos haber usado otro nombre, pero `origin` es el estándar habitual y el que utilizaremos durante el curso.

---

# 11\. Comprobar el remoto

Ejecutamos:

```sh
git remote -v
```

&nbsp;

Debemos ver algo parecido a:

```
origin  https://github.com/USUARIO/prueba-github.git (fetch)
origin  https://github.com/USUARIO/prueba-github.git (push)
```

&nbsp;

## `fetch`

Indica la dirección desde la que Git puede obtener información y cambios remotos.

## `push`

Indica la dirección a la que Git enviará nuestros commits.

---

# 12\. Primer `push`

Ejecutamos:

```sh
git push -u origin main
```

&nbsp;

Aquí estamos diciendo:

```
git push
→ envía commits al remoto

origin
→ repositorio remoto

main
→ rama que queremos subir

-u
→ establece la relación entre main local y origin/main
```

&nbsp;

La opción:

```
-u
```

&nbsp;

hace que Git recuerde esta relación.

Después podremos utilizar simplemente:

```sh
git push
```

&nbsp;

sin tener que escribir siempre:

```
git push origin main
```

&nbsp;

---

# 13\. Primer inicio de sesión en GitHub

La primera vez que ejecutemos el `push`, Git Credential Manager puede pedir autenticación.

El flujo habitual será:

```
git push
   ↓
Git Credential Manager
   ↓
Sign in with your browser
   ↓
navegador
   ↓
GitHub
   ↓
Authentication succeeded
```

&nbsp;

Para el curso seleccionaremos:

```
Sign in with your browser
```

&nbsp;

---

# 14\. ¿Por qué quizá GitHub no pide usuario y contraseña?

Si ya tenemos una sesión abierta en GitHub en el navegador, puede ocurrir que GitHub reconozca esa sesión.

En ese caso:

```
Git Credential Manager
→ abre navegador
→ GitHub detecta sesión iniciada
→ autenticación correcta
```

&nbsp;

No significa que Git esté usando nuestra contraseña directamente.

Git Credential Manager gestiona la autorización por nosotros.

---

# 15\. Credencial guardada en Windows

Después de autenticarnos correctamente, Windows puede guardar la autorización utilizada por Git Credential Manager.

Podemos comprobarlo en:

```
Panel de control
→ Administrador de credenciales
→ Credenciales de Windows
```

&nbsp;

Debería aparecer alguna entrada relacionada con GitHub.

La idea importante es:

```
Git config
→ guarda identidad y preferencias de Git

Credential Manager
→ guarda autenticación para GitHub
```

&nbsp;

---

# 16\. Comprobar el resultado en GitHub

Volvemos al navegador y actualizamos el repositorio.

Debemos ver:

- `README.md`;  
- el commit;  
- la rama `main`.

Esto confirma que el flujo:

```
LOCAL → GITHUB
```

&nbsp;

ha funcionado.

---

# 17\. RECORRIDO B · Tenemos un repositorio en GitHub y queremos traerlo al ordenador

Ahora probamos el recorrido contrario:

```
GitHub
  ↓
git clone
  ↓
repositorio local
```

&nbsp;

Para que la prueba sea clara, crearemos un repositorio distinto directamente en GitHub.

---

# 18\. Crear un repositorio directamente en GitHub

Creamos, por ejemplo:

```
prueba-clon
```

&nbsp;

Esta vez sí podemos marcar:

```
Add a README file
```

&nbsp;

Así GitHub creará:

- el repositorio;  
- la rama `main`;  
- `README.md`;  
- un primer commit.

No hace falta añadir `.gitignore` ni licencia para esta prueba.

---

# 19\. Clonar el repositorio

Desde Git Bash:

```sh
cd ~/Desktop
```

&nbsp;

Ejecutamos:

```sh
git clone https://github.com/USUARIO/prueba-clon.git
```

&nbsp;

Git creará automáticamente una carpeta llamada:

```
prueba-clon
```

&nbsp;

Entramos:

```sh
cd prueba-clon
```

&nbsp;

---

# 20\. ¿Qué hace realmente `git clone`?

`git clone` hace varias cosas automáticamente:

```
1. Crea una carpeta local.
2. Descarga los archivos.
3. Descarga el historial de commits.
4. Descarga la información de ramas.
5. Configura el remoto origin.
6. Deja preparada la rama principal.
```

&nbsp;

Es decir, `clone` no descarga simplemente archivos.

Crea un repositorio Git local completo.

---

# 21\. Comprobar el clon

Ejecutamos:

```sh
git status
```

&nbsp;

Debemos ver algo parecido a:

```
On branch main
Your branch is up to date with 'origin/main'.

nothing to commit, working tree clean
```

&nbsp;

Esto significa:

```
main
→ rama local

origin/main
→ rama main del repositorio remoto
```

&nbsp;

Y ambas están sincronizadas.

---

# 22\. Comprobar el remoto del repositorio clonado

Ejecutamos:

```sh
git remote -v
```

&nbsp;

Debemos ver automáticamente:

```
origin  https://github.com/USUARIO/prueba-clon.git (fetch)
origin  https://github.com/USUARIO/prueba-clon.git (push)
```

&nbsp;

No hemos tenido que ejecutar:

```sh
git remote add origin ...
```

&nbsp;

porque `git clone` lo ha configurado automáticamente.

---

# 23\. Comprobar el historial

Ejecutamos:

```sh
git log --oneline
```

&nbsp;

Debemos ver el commit que GitHub creó al inicializar el repositorio con README.

Esto demuestra que `clone` también descarga el historial del proyecto.

---

# 24\. Los dos recorridos juntos

Ahora podemos ver claramente las dos situaciones principales.

## Proyecto creado primero en local

```
LOCAL
  │
  ├── git init
  ├── git add
  ├── git commit
  │
  └──── push ─────────────► GITHUB
```

&nbsp;

## Proyecto creado o existente en GitHub

```
GITHUB
  │
  └──── clone ────────────► LOCAL
```

&nbsp;

---

# 25\. `clone` no es lo mismo que `pull`

## `clone`

Se utiliza normalmente la primera vez.

```
No tengo el repositorio local
        ↓
git clone
        ↓
obtengo una copia completa
```

&nbsp;

## `pull`

Se utiliza cuando ya tenemos una copia local.

```
Ya tengo el repositorio
        ↓
GitHub tiene cambios nuevos
        ↓
git pull
```

&nbsp;

Durante esta guía solo necesitamos comprender la diferencia.

---

# 26\. Problemas frecuentes

## 26.1. Git pide usuario y contraseña directamente

Si aparece una ventana simple solicitando usuario y contraseña, puede que Git Credential Manager no esté configurado.

Comprobamos:

```cmd
git config --global --get credential.helper
```

&nbsp;

Si no aparece nada:

```cmd
git config --global credential.helper manager
```

&nbsp;

---

## 26.2. `main` no es la rama inicial

Comprobamos:

```cmd
git config --global --get init.defaultBranch
```

&nbsp;

Si no devuelve:

```
main
```

&nbsp;

ejecutamos:

```cmd
git config --global init.defaultBranch main
```

&nbsp;

---

## 26.3. El repositorio remoto ya tiene un README

Si tenemos un proyecto local con commits y además creamos en GitHub un README, estaremos creando dos historiales diferentes.

Para la primera subida desde local preferimos:

```
repositorio remoto vacío
```

&nbsp;

---

## 26.4. `origin` ya existe

Si ejecutamos:

```sh
git remote add origin ...
```

&nbsp;

y Git responde que `origin` ya existe, comprobamos:

```sh
git remote -v
```

&nbsp;

Antes de modificar nada debemos verificar a qué URL está apuntando.

---

## 26.5. Credencial antigua de GitHub

Si el equipo ya se había utilizado anteriormente con GitHub, puede haber una credencial antigua guardada en Windows.

Podemos revisarla en:

```
Panel de control
→ Administrador de credenciales
→ Credenciales de Windows
```

&nbsp;

Si sabemos que pertenece a una configuración anterior y queremos rehacer la autenticación, podemos eliminar esa entrada.

La próxima operación que requiera autenticación volverá a lanzar Git Credential Manager.

---

# 27\. Dejar GitHub limpio si había una configuración anterior

Si estamos preparando un equipo de prácticas y queremos asegurarnos de que el flujo de autenticación se realiza desde cero:

1. Revisamos el Administrador de credenciales de Windows.  
2. Localizamos posibles entradas antiguas relacionadas con GitHub.  
3. Eliminamos únicamente las credenciales que sepamos que corresponden a configuraciones anteriores.  
4. Ejecutamos de nuevo:

```sh
git push
```

5. Git Credential Manager volverá a solicitar autenticación.  
6. Elegimos:

```
Sign in with your browser
```

---

# 28\. Punto de control final

Antes de continuar con IntelliJ IDEA, debemos tener comprobado lo siguiente.

## Git Credential Manager

```cmd
git config --global --get credential.helper
```

&nbsp;

Debe devolver:

```
manager
```

&nbsp;

## Repositorio local conectado con GitHub

```sh
git remote -v
```

&nbsp;

Debe mostrar `origin`.

## `push`

Debe funcionar:

```sh
git push
```

&nbsp;

## `clone`

Debe funcionar:

```sh
git clone https://github.com/USUARIO/REPOSITORIO.git
```

&nbsp;

## Rama principal

Debemos trabajar en:

```
main
```

&nbsp;

## Autenticación

Debe haberse completado correctamente con Git Credential Manager.

---

# 29\. Resumen conceptual final

```
Git
→ sistema de control de versiones

GitHub
→ servicio que aloja repositorios Git

Repositorio local
→ copia que tenemos en nuestro ordenador

Repositorio remoto
→ copia alojada en GitHub

origin
→ nombre habitual del remoto principal

main
→ rama principal utilizada en el curso

push
→ envía commits de local a GitHub

pull
→ trae e integra cambios desde GitHub

clone
→ crea una nueva copia local completa del repositorio remoto

Git Credential Manager
→ gestiona la autenticación con GitHub

Administrador de credenciales de Windows
→ almacena la autorización utilizada por Git Credential Manager
```

&nbsp;

---

# 30\. Idea clave antes de pasar a IntelliJ

Hasta este punto hemos utilizado Git y GitHub sin ningún IDE.

Eso es importante porque nos permite entender qué hace realmente IntelliJ más adelante.

Cuando IntelliJ nos ofrezca botones como:

```
Commit
Push
Pull
Clone
```

&nbsp;

no estará haciendo nada mágico.

Simplemente estará ejecutando, de forma gráfica, operaciones de Git que ya conocemos.