# S01-2 Guía 5: Maven en Windows

## Objetivos

Instalar **Apache Maven 3.9** en `C:\Maven`, configurar las variables de entorno necesarias y comprobar que funciona desde la terminal y desde IntelliJ.

**Maven** es una herramienta de construcción y gestión de proyectos Java: organiza el código en una estructura estándar, descarga las librerías que un proyecto necesita y automatiza tareas como compilar, probar y empaquetar. En la siguiente sesión crearemos el primer proyecto Maven; ahora nos limitamos a dejar la herramienta instalada y verificada.

A diferencia de las herramientas anteriores, Maven **no tiene instalador**: se descarga como un fichero comprimido, se descomprime en una carpeta y se le indica a Windows dónde está. Eso es lo que hacemos en esta guía.

Requisito previo: el JDK 21 tiene que estar instalado y con la variable `JAVA_HOME` configurada (guía 2). Maven usa esa variable para encontrar Java.

---

## 1. Descargar Maven

Entramos en la web oficial:

```text
https://maven.apache.org/download.cgi
```

En el apartado **Apache Maven 3.9.x**, descargamos el fichero **Binary zip archive**, cuyo nombre tiene esta forma:

```text
apache-maven-3.9.x-bin.zip
```

Descargamos la versión de la rama 3.9 que ofrezca la página, sin usar las versiones marcadas como *Preview* (4.x o 3.10). Las versiones preview son pruebas de la próxima generación de Maven y no son las que usa el curso.

El fichero `-bin.zip` es el programa ya listo para usar. El fichero `-src.zip` contiene el código fuente de Maven y no lo necesitamos.

---

## 2. Descomprimir Maven en `C:\Maven`

1. Abrimos el Explorador de archivos y entramos en la unidad `C:`.
2. Creamos la carpeta `Maven` (clic derecho > `Nuevo` > `Carpeta`). Si Windows pide permisos de administrador, los aceptamos.
3. Hacemos clic derecho sobre el fichero `.zip` descargado y elegimos `Extraer todo...`. Lo extraemos en una carpeta cualquiera, por ejemplo `Descargas`.
4. Abrimos la carpeta extraída, que se llama `apache-maven-3.9.x`. Seleccionamos **todo su contenido** (`Ctrl + A`) y lo copiamos dentro de `C:\Maven`.

Copiamos el contenido y no la carpeta `apache-maven-3.9.x` completa, para que la ruta de Maven no incluya el número de versión. Así, al actualizar Maven en el futuro, la ruta y las variables de entorno no cambian.

El resultado debe ser este:

<pre>
C:\Maven\
├── bin\
├── boot\
├── conf\
├── lib\
├── LICENSE
├── NOTICE
└── README.txt
</pre>

La carpeta que nos interesa es `bin`: contiene el ejecutable `mvn.cmd`, el comando que escribiremos en la terminal.

---

## 3. Crear la variable de entorno `MAVEN_HOME`

Igual que `JAVA_HOME` indica dónde está el JDK, `MAVEN_HOME` indica dónde está Maven. Una **variable de entorno** es un valor con nombre, guardado en el sistema, que cualquier programa puede consultar.

1. Pulsamos `Inicio`, escribimos `variables de entorno` y abrimos **Editar las variables de entorno del sistema**.
2. En la ventana `Propiedades del sistema`, pulsamos `Variables de entorno...`.
3. En la sección inferior, **Variables del sistema**, pulsamos `Nueva...`.
4. Rellenamos los dos campos:
   - **Nombre de la variable:** `MAVEN_HOME`
   - **Valor de la variable:** `C:\Maven`
5. Pulsamos `Aceptar`.

Si no tenemos permisos de administrador, creamos la variable en la sección superior, **Variables de usuario**, con los mismos valores. Funciona igual, pero solo para nuestro usuario de Windows.

Algunas guías antiguas usan el nombre `M2_HOME`. Es un nombre en desuso: en este curso usamos `MAVEN_HOME`.

---

## 4. Añadir Maven al `PATH`

El **PATH** es la lista de carpetas en las que Windows busca los programas al escribir un comando. Para poder escribir `mvn` desde cualquier carpeta, añadimos la carpeta `bin` de Maven a esa lista.

1. En la misma ventana `Variables de entorno`, dentro de **Variables del sistema**, seleccionamos la variable `Path` y pulsamos `Editar...`.
2. Pulsamos `Nuevo` y escribimos:

```text
%MAVEN_HOME%\bin
```

3. Pulsamos `Aceptar` en las tres ventanas abiertas (`Editar variable de entorno`, `Variables de entorno` y `Propiedades del sistema`).

`%MAVEN_HOME%` es la forma de escribir en Windows «el valor de la variable `MAVEN_HOME`». Windows lo sustituye por `C:\Maven`, de modo que la entrada del `PATH` acaba siendo `C:\Maven\bin`. Si escribiéramos la ruta completa funcionaría igual, pero con la variable solo hay que cambiar un sitio si Maven cambia de carpeta.

No borramos ni modificamos ninguna otra entrada del `PATH`: en ella ya están las carpetas del JDK y de Git, añadidas por sus instaladores.

---

## 5. Comprobar la instalación

Abrimos un **Símbolo del sistema nuevo**. Una ventana abierta antes de los cambios no conoce las variables nuevas.

Comprobamos primero las dos variables:

```bash
echo %MAVEN_HOME%
echo %JAVA_HOME%
```

Salida esperada:

<pre>
C:\Maven
C:\Program Files\Eclipse Adoptium\jdk-21.0.x.x-hotspot
</pre>

Ejecutamos ahora Maven:

```bash
mvn -version
```

Salida esperada:

<pre>
Apache Maven 3.9.x (...)
Maven home: C:\Maven
Java version: 21.0.x, vendor: Eclipse Adoptium, runtime: C:\Program Files\Eclipse Adoptium\jdk-21.0.x.x-hotspot
Default locale: es_ES, platform encoding: ...
OS name: "windows 11", version: "10.0", arch: "amd64", family: "windows"
</pre>

Las líneas que importan son las tres primeras:

- **`Apache Maven 3.9.x`:** la versión de Maven instalada. Debe empezar por `3.9`.
- **`Maven home`:** la carpeta que Maven ha localizado. Debe ser `C:\Maven`, sin `bin` al final.
- **`Java version`:** la versión de Java con la que Maven trabaja. Debe ser `21.0.x`, con `vendor: Eclipse Adoptium`, y el `runtime` debe apuntar a la carpeta del JDK. Esto confirma que Maven usa el JDK de Temurin a través de `JAVA_HOME`.

Los valores de `Default locale`, `platform encoding` y `OS name` dependen de cada equipo y no hay que revisarlos.

---

## 6. Comprobar Maven en IntelliJ

IntelliJ trae su propio Maven incluido, y por defecto usa ese. Para que el IDE y la terminal trabajen con **la misma versión** de Maven, le indicamos que use el que acabamos de instalar.

1. Abrimos IntelliJ. En la pantalla inicial pulsamos `Options Menu > Settings` (o `Ctrl + Alt + S`).
2. Vamos a `Build, Execution, Deployment > Build Tools > Maven`.
3. En el campo **Maven home path** desplegamos las opciones y seleccionamos `C:\Maven`.
4. Debajo del campo, IntelliJ muestra la versión de Maven detectada. Debe ser `3.9.x`.
5. Pulsamos `OK`.

Si estamos dentro de un proyecto, la ventana de `Settings` se abre para ese proyecto; podemos hacer el cambio también desde la pantalla inicial, sin proyecto abierto, para que valga para todos los proyectos futuros.

---

## 7. Problemas frecuentes

| Mensaje o síntoma | Causa probable | Qué hacemos |
|---|---|---|
| `'mvn' no se reconoce como un comando interno o externo` | `C:\Maven\bin` no está en el `PATH`, o la ventana de CMD es anterior al cambio | Repasamos el apartado 4 y abrimos un CMD nuevo |
| `The JAVA_HOME environment variable is not defined correctly` | `JAVA_HOME` no existe, apunta a una carpeta que no existe, o termina en `\bin` | Comprobamos `echo %JAVA_HOME%`; debe ser la carpeta del JDK, sin `\bin` |
| `mvn -version` muestra otra versión de Java | Otro JDK anterior en el `PATH` o en `JAVA_HOME` | Comprobamos `java -version` y `echo %JAVA_HOME%` |
| `Maven home` aparece como `C:\Maven\apache-maven-3.9.x` | Se copió la carpeta completa y no su contenido | Funciona igual, pero `MAVEN_HOME` debe apuntar a esa misma carpeta |
| `echo %MAVEN_HOME%` devuelve literalmente `%MAVEN_HOME%` | La variable no se ha creado, o el CMD es anterior al cambio | Repasamos el apartado 3 y abrimos un CMD nuevo |

---

## Punto de control

Con la instalación de Maven termina la preparación del entorno. Comprobamos que todo funciona a la vez:

| Comprobación | Comando o lugar | Resultado esperado |
|---|---|---|
| Java | `java -version` | `21.0.x` con `Temurin` |
| Compilador | `javac -version` | `javac 21.0.x` |
| Git | `git --version` | `git version 2.x.x.windows.x` |
| Maven | `mvn -version` | `Apache Maven 3.9.x`, `Maven home: C:\Maven`, `Java version: 21.0.x` |
| IntelliJ | `Settings > Build Tools > Maven` | `Maven home path` en `C:\Maven`, versión `3.9.x` |

El entorno completo queda así:

<pre>
Windows
   │
   ├── Notepad++ y Typedown  →  editores
   ├── Eclipse Temurin 21    →  java, javac, JAVA_HOME
   ├── Git                   →  control de versiones (rama main)
   ├── IntelliJ IDEA         →  IDE
   └── Maven 3.9 (C:\Maven)  →  mvn, MAVEN_HOME
</pre>

En la siguiente sesión creamos el primer proyecto Maven desde IntelliJ.
