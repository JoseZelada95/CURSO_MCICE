# S02-1 Demos

## Objetivos

En esta parte aprendemos a crear un proyecto Java con Maven desde IntelliJ y a entender qué genera. Partimos de la estructura que Maven impone (`src/main/java`, `src/test/java`, `pom.xml`) y la justificamos elemento a elemento. A continuación añadimos una clase propia con un método que recibe un parámetro y devuelve un valor, estableciendo el patrón paquete-clase-método que se usará en todo el curso. Por último, creamos un segundo proyecto a partir de una plantilla de Maven (un archetype) y lo comparamos con el primero, para ver qué decide una plantilla por nosotros.

Al terminar esta parte los alumnos son capaces de:
- Crear un proyecto Maven desde el asistente de IntelliJ.
- Explicar para qué sirve cada carpeta de la estructura generada.
- Leer el `pom.xml` e identificar cada elemento.
- Crear una clase en el paquete `com.curso` con un método que recibe un parámetro y devuelve un valor.
- Explicar qué es un archetype y en qué se diferencia un proyecto creado con `maven-archetype-quickstart` de uno creado con el asistente de IntelliJ.

---

## Demo 1: Proyecto Maven desde IntelliJ

Maven es una herramienta de construcción y gestión de proyectos Java. Su función es triple: organiza el código en una estructura estándar que todos los frameworks del curso conocen (Spring, Hibernate, JUnit), gestiona las librerías que el proyecto necesita descargándolas automáticamente desde Internet, y automatiza las tareas de compilar, testear y empaquetar el código en un fichero ejecutable.

Cualquier proyecto en el que trabajemos en este curso comenzará de la misma manera: creando un proyecto Maven.

### Crear el proyecto

Vamos a `File > New > Project`. En el panel izquierdo, dentro de `New Project`, seleccionamos `Java`.

Rellenamos los campos:

- **Name**: `s02-1-demos` — el nombre del proyecto tal como aparece en IntelliJ.
- **Location**: la carpeta donde guardamos los proyectos del curso. IntelliJ muestra debajo la ruta completa donde creará el proyecto.
- **Create Git repository**: desmarcada.
- **Build system**: `Maven`. El **sistema de construcción** es la herramienta que compila, testea y empaqueta el proyecto. `IntelliJ` usaría el sistema propio del IDE, que solo funciona dentro de IntelliJ; `Maven` genera un proyecto que cualquier herramienta del ecosistema Java sabe construir, también fuera del IDE.
- **JDK**: `21`.
- **Add sample code**: marcada. Con esta opción IntelliJ añade una clase de ejemplo para poder ejecutar algo nada más crear el proyecto.

Desplegamos `Advanced Settings` y rellenamos:

- **GroupId**: `com.curso` — identifica la organización. Sigue el convenio de dominio invertido: `com.curso` en lugar de `curso.com`. Este mismo valor se usará como nombre base del paquete Java de todas las clases del proyecto.
- **ArtifactId**: `s02-1-demos` — el nombre del artefacto que Maven produce. Un **artefacto** es el resultado del proceso de construcción: en este caso, un fichero `.jar`. Maven usa el `artifactId` para nombrar ese fichero. Habitualmente coincide con el `Name` del proyecto.

Hacemos clic en `Create`.

Esta es la única vez en el curso que marcamos **Add sample code**. En los siguientes proyectos la dejaremos desmarcada y crearemos a mano los paquetes y las clases: así la estructura de paquetes la decidimos nosotros y no la plantilla del IDE.

### Estructura del proyecto

Una vez creado, el proyecto tiene esta estructura:

<pre>
s02-1-demos/
├── .idea/
├── .mvn/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/
│   │   │       └── curso/
│   │   │           └── Main.java
│   │   └── resources/
│   └── test/
│       └── java/
├── .gitignore
└── pom.xml
</pre>

Cada carpeta de `src` tiene un propósito fijo que Maven impone:

- `src/main/java` es donde va el **código de producción**: las clases que forman la aplicación, las que en un proyecto real llegarían a los usuarios.
- `src/main/resources` es donde van los ficheros que la aplicación necesita pero que no son código Java, como ficheros de configuración. Ahora está vacía; se usa a partir de S04-1.
- `src/test/java` es donde van los **tests**: clases que verifican automáticamente que el código de producción funciona correctamente. Un test llama a un método con una entrada conocida y comprueba que el resultado es el esperado. Ahora está vacía; los primeros tests se escriben en S02-2.
- `pom.xml` es el fichero de configuración del proyecto: qué versión de Java se usa, qué librerías necesita y cómo se llama el proyecto.

Esta separación no es opcional. Maven la requiere para localizar el código al compilar, al testear y al empaquetar. Si colocamos una clase fuera de estas carpetas, Maven no la procesa.

El resto de elementos no forman parte del código: `.idea` guarda la configuración de IntelliJ para este proyecto, `.mvn` es una carpeta de configuración de Maven para el proyecto que no vamos a usar, y `.gitignore` indica qué ficheros no deben guardarse en un repositorio de código. Ninguno de los tres se toca durante el curso.

En el panel de proyecto, IntelliJ muestra `com.curso` como un único nodo. En el disco son dos carpetas anidadas, `com/curso`, como se ve en el árbol anterior.

### El fichero pom.xml

**POM** son las siglas de *Project Object Model*. El `pom.xml` describe el proyecto en su totalidad: su identidad, la versión de Java que necesita y las librerías de las que depende. Es el fichero que Maven lee antes de hacer cualquier cosa.

Abrimos el `pom.xml` y recorremos cada sección:

<pre>
&amp;lt;?xml version="1.0" encoding="UTF-8"?&amp;gt;
&amp;lt;project ...&amp;gt;
    &amp;lt;!-- modelVersion: versión del formato de este fichero pom.xml.
         Siempre es 4.0.0 para proyectos Maven modernos. No hay que cambiarlo nunca. --&amp;gt;
    &amp;lt;modelVersion&amp;gt;4.0.0&amp;lt;/modelVersion&amp;gt;

    &amp;lt;!-- groupId: identifica la organización o el proyecto raíz.
         Sigue el convenio de nombre de paquete Java invertido.
         com.curso es el paquete base que usaremos en todo el curso. --&amp;gt;
    &amp;lt;groupId&amp;gt;com.curso&amp;lt;/groupId&amp;gt;

    &amp;lt;!-- artifactId: nombre de este proyecto concreto.
         Maven usa este nombre para nombrar el fichero .jar que genera al compilar.
         No hay etiqueta packaging: sin ella, Maven empaqueta el proyecto como jar. --&amp;gt;
    &amp;lt;artifactId&amp;gt;s02-1-demos&amp;lt;/artifactId&amp;gt;

    &amp;lt;!-- version: versión actual del proyecto.
         SNAPSHOT indica que el proyecto está en desarrollo y puede cambiar. --&amp;gt;
    &amp;lt;version&amp;gt;1.0-SNAPSHOT&amp;lt;/version&amp;gt;

    &amp;lt;properties&amp;gt;
        &amp;lt;!-- Versión de Java que usa el compilador para leer y generar el código.
             Tiene que coincidir con el JDK instalado en el sistema. --&amp;gt;
        &amp;lt;maven.compiler.source&amp;gt;21&amp;lt;/maven.compiler.source&amp;gt;
        &amp;lt;maven.compiler.target&amp;gt;21&amp;lt;/maven.compiler.target&amp;gt;

        &amp;lt;!-- Codificación de los ficheros fuente.
             UTF-8 es el estándar actual y permite usar tildes y caracteres especiales. --&amp;gt;
        &amp;lt;project.build.sourceEncoding&amp;gt;UTF-8&amp;lt;/project.build.sourceEncoding&amp;gt;
    &amp;lt;/properties&amp;gt;

&amp;lt;/project&amp;gt;
</pre>

Tres elementos merecen una aclaración adicional:

**`version` y SNAPSHOT**: IntelliJ asigna `1.0-SNAPSHOT` como versión inicial sin preguntarla. **SNAPSHOT** indica que el proyecto está en desarrollo activo y su contenido puede cambiar. Cuando el proyecto esté listo para distribuirse, se elimina el sufijo y se deja solo `1.0`.

**JAR**: el `pom.xml` no indica en ningún sitio qué tipo de fichero debe producir Maven. Cuando no se indica, Maven empaqueta el proyecto como **JAR** (*Java ARchive*), el formato estándar de un proyecto Java compilado: contiene todas las clases compiladas (ficheros `.class`) comprimidas en un único archivo. Es el resultado final que Maven produce cuando ejecutamos `mvn package`. En este curso no necesitamos ejecutar ese comando manualmente por ahora: IntelliJ compila el proyecto cada vez que lo ejecutamos.

**`maven.compiler.source` vs `maven.compiler.target`**: `source` indica la versión de Java con que está escrito el código fuente; `target` indica la versión mínima de la JVM en que se ejecutará el `.jar` generado. Cuando ambos son iguales (como en nuestro caso, `21`), el compilador usa Java 21 para leer el código y genera bytecode que requiere Java 21 para ejecutarse. IntelliJ ha tomado ese `21` del JDK que elegimos al crear el proyecto.

Este `pom.xml` todavía no declara ninguna librería. Cuando lo haga, Maven descargará cada librería de **Maven Central**, el repositorio público donde se publican las librerías y herramientas del ecosistema Java. La descarga ocurre solo la primera vez: Maven guarda una copia en una caché local en el disco (`~/.m2`) y las veces siguientes la usa sin necesidad de conexión. Es el mismo mecanismo que usará Maven para descargar Spring o Hibernate en sesiones posteriores.

### Código: Main.java

Esta es la clase que IntelliJ genera al marcar **Add sample code**. Su código no lo hemos escrito nosotros: IntelliJ lo incluye para poder ejecutar algo nada más crear el proyecto. Los comentarios originales son consejos de uso del IDE en inglés; en la versión del curso los hemos sustituido por comentarios que explican el código, pero el código es exactamente el generado.

Dos detalles del código generado. El primero es `printf()`: igual que `println()`, imprime un texto por consola, pero **no añade un salto de línea** al final, así que lo siguiente que se imprima aparece pegado en la misma línea. El segundo es el bucle `for`, que repite un bloque de código varias veces; aquí lo hace cinco veces, con `i` valiendo de 1 a 5. Los bucles se explican en detalle en S02-2.

```java
package com.curso;

/**
 * S02-1 Demo 1: Proyecto Maven desde IntelliJ
 *
 * Objetivo: comprobar que el proyecto recién creado compila y se ejecuta
 * antes de escribir ningún código propio.
 *
 * Lo que hace este ejemplo:
 *   - Es la clase de ejemplo que IntelliJ genera con la opción Add sample code
 *   - Imprime un mensaje de bienvenida y cinco líneas numeradas
 *
 * Concepto clave: este código no lo hemos escrito nosotros. IntelliJ lo genera
 * para verificar, nada más crear el proyecto, que el JDK, Maven y el IDE
 * funcionan juntos. El código es exactamente el generado; solo se han sustituido
 * los comentarios originales, que eran consejos de uso de IntelliJ en inglés.
 */
public class Main {

    // main() permite ejecutar esta clase directamente desde IntelliJ (▶)
    // sin necesidad de ningún framework. Es el punto de entrada del programa.
    public static void main(String[] args) {
        // printf() imprime el texto pero, a diferencia de println(), no añade
        // un salto de línea al final. Por eso lo siguiente que se imprima
        // aparece pegado a este mensaje, en la misma línea.
        System.out.printf("Hello and welcome!");  // → Hello and welcome! (sin salto de línea)

        // El bucle for repite el bloque entre llaves cinco veces,
        // con i valiendo 1, 2, 3, 4 y 5. Se explica en detalle en S02-2.
        for (int i = 1; i <= 5; i++) {
            // println() sí añade el salto de línea: cada valor de i queda en su propia línea.
            // La primera vuelta se imprime pegada al mensaje anterior: "Hello and welcome!i = 1".
            System.out.println("i = " + i);  // → i = 1, i = 2, i = 3, i = 4, i = 5
        }
    }
}
```

Hacemos clic en ▶ junto al `main()`.

Salida esperada:

<pre>
Hello and welcome!i = 1
i = 2
i = 3
i = 4
i = 5
</pre>

La primera línea sale pegada, `Hello and welcome!i = 1`, precisamente por el `printf()` sin salto de línea. Lo importante es que el programa se ejecuta: el JDK, Maven e IntelliJ funcionan juntos y el proyecto está listo para escribir código propio.

---

## Demo 2: Clase Saludo

Una **clase** es una plantilla que define qué operaciones puede realizar un tipo de objeto. Un **método** es una de esas operaciones: tiene un nombre, puede recibir datos de entrada (parámetros) y puede devolver un resultado. Este patrón (paquete, clase, método) es la unidad de trabajo en Java y en todos los frameworks que veremos en el curso.

La clase `Saludo` tiene un único método, `saludar(nombre)`, que recibe un nombre como parámetro y devuelve un `String` con el mensaje de saludo.

### Crear la clase en IntelliJ

El paquete `com.curso` ya existe (IntelliJ lo generó junto con `Main.java`). Sobre `com.curso` en el panel de proyecto, hacemos clic derecho y seleccionamos `New > Java Class`. Escribimos `Saludo` y pulsamos Enter.

IntelliJ crea el fichero `Saludo.java` con la declaración de clase vacía. Añadimos el método `saludar` y el `main()` para probarlo.

### El paquete

La primera línea de toda clase Java es la declaración de paquete: `package com.curso;`. Un **paquete** agrupa clases relacionadas bajo un espacio de nombres propio, igual que una carpeta agrupa ficheros. Sin paquete, todas las clases del proyecto comparten el mismo espacio global y pueden colisionar con clases de librerías externas que tengan el mismo nombre. `com.curso` sigue el mismo convenio de dominio invertido que el `groupId` del `pom.xml`.

En el disco, el paquete se traduce directamente en carpetas: `com/curso/` dentro de `src/main/java`. IntelliJ crea esas carpetas automáticamente al crear el paquete.

### El tipo String

`String` es el tipo de dato que representa cadenas de texto en Java. A diferencia de `int` o `double`, que son tipos primitivos, `String` es un objeto: tiene métodos propios que permiten manipular el texto (`length()`, `toUpperCase()`, `indexOf()`...). En Java, cualquier texto entre comillas dobles (`"Hola"`) es un `String`.

### El método y el tipo de retorno

El método `saludar` está definido como `public String saludar(String nombre)`. Cada parte tiene un significado:

- `public`: el método es accesible desde cualquier otra clase.
- `String`: el **tipo de retorno**. El método produce un `String` cuando termina de ejecutarse y lo devuelve a quien lo llamó. Si el método no devuelve nada, se escribe `void`.
- `saludar`: el nombre del método. En Java los métodos se nombran en **camelCase**: la primera palabra en minúsculas y cada palabra siguiente empieza en mayúscula (`saludar`, `calcularTotal`, `esEmailValido`).
- `String nombre`: el parámetro de entrada. El método necesita un nombre para construir el saludo.

El cuerpo del método (`return "Hola, " + nombre + "!"`) usa el operador `+` para concatenar cadenas. Cuando `+` opera sobre `String`, no suma números: une los textos en el orden en que aparecen. `return` devuelve el resultado al código que llamó al método y termina su ejecución.

### La instancia

Para llamar a `saludar()` necesitamos crear una **instancia** de `Saludo`: `new Saludo()`. La palabra clave `new` reserva espacio en memoria para el objeto, inicializa sus datos y devuelve una referencia a ese objeto. Esa referencia se guarda en la variable `saludo`. A partir de ese momento, `saludo.saludar("Juan")` ejecuta el método sobre ese objeto concreto.

`saludar()` es un método de instancia porque necesita un objeto sobre el que operar. Si fuera `static`, pertenecería a la clase y podría llamarse sin crear ningún objeto.

### Código

```java
package com.curso;

/**
 * S02-1 Demo 2: Clase Saludo
 *
 * Objetivo: crear una clase Java con un método de instancia que recibe un parámetro
 * y devuelve un String.
 *
 * Lo que hace este ejemplo:
 *   - Define la clase Saludo en el paquete com.curso
 *   - Implementa el método saludar(nombre) que construye y devuelve un mensaje
 *
 * Concepto clave: el patrón paquete → clase → método que se establece aquí
 * es el mismo que se usará en todo el curso. Una clase es una plantilla;
 * un método es una operación que esa plantilla puede realizar.
 * El método recibe datos (nombre), los procesa y devuelve un resultado.
 */
public class Saludo {

    /**
     * Devuelve un saludo personalizado con el nombre recibido.
     *
     * Ejemplo:
     *   saludar("Juan")   →  "Hola, Juan!"
     *   saludar("María")  →  "Hola, María!"
     *
     * @param nombre el nombre de la persona a saludar
     * @return el mensaje de saludo completo
     */
    public String saludar(String nombre) {
        // Concatenamos el texto fijo del saludo con el nombre recibido como parámetro.
        // El operador + une los dos String en un único String de resultado.
        // Cada llamada al método puede recibir un nombre diferente y produce un saludo diferente.
        return "Hola, " + nombre + "!";
    }

    // main() permite ejecutar esta clase directamente desde IntelliJ (▶)
    // sin necesidad de un framework. Útil para probar el método antes de escribir tests.
    public static void main(String[] args) {
        // Creamos una instancia de Saludo para poder llamar al método saludar().
        // Sin instancia no es posible llamar al método porque no es estático:
        // necesita que exista un objeto de tipo Saludo sobre el que operar.
        Saludo saludo = new Saludo();

        // Probamos con distintas entradas para verificar que el método funciona
        // independientemente de cómo venga el nombre.
        System.out.println(saludo.saludar("Juan"));   // → Hola, Juan!
        System.out.println(saludo.saludar("María"));  // → Hola, María!
        System.out.println(saludo.saludar("PEDRO"));  // → Hola, PEDRO!
    }
}
```

Hacemos clic en ▶ junto al `main()`.

Salida esperada:

<pre>
Hola, Juan!
Hola, María!
Hola, PEDRO!
</pre>

---

## Demo 3: Comparación con el archetype quickstart

El asistente de IntelliJ no es la única forma de crear un proyecto Maven. Maven tiene su propio mecanismo de plantillas: los archetypes. Un **archetype** es una plantilla de proyecto Maven: un proyecto modelo que Maven copia y adapta a los datos que le damos (`groupId`, `artifactId`, paquete). Hay archetypes para distintos tipos de proyecto: aplicación web, librería, plugin de Maven... `maven-archetype-quickstart` es el más básico: genera un proyecto Java mínimo con una clase de ejemplo y un test.

En esta demo creamos un segundo proyecto con ese archetype y lo comparamos con el de la Demo 1. El objetivo no es cambiar de método, sino ver qué decide una plantilla por nosotros.

### Crear el proyecto

Vamos a `File > New > Project`. En el panel izquierdo, dentro de `Generators`, seleccionamos `Maven Archetype`.

En la parte superior, IntelliJ muestra el aviso *"To create a general Maven project, go to the Java page"*: para un proyecto Maven normal, el propio IDE recomienda el asistente `Java` que usamos en la Demo 1. Aquí seguimos adelante con el archetype precisamente para ver en qué se diferencia.

Los tres primeros campos son los mismos que en la Demo 1:

- **Name**: `s02-1-demos-quickstart`.
- **Location**: la misma carpeta que en la Demo 1.
- **JDK**: `21`.

Los tres siguientes (**Catalog**, **Archetype** y **Version**) son propios de los archetypes y necesitan una explicación antes de rellenarlos.

#### El catálogo

Un archetype se publica igual que cualquier librería de Java: en un repositorio, identificado por un `groupId` (la organización que lo publica), un `artifactId` (su nombre) y una versión. Para que IntelliJ pueda ofrecer una lista de archetypes entre los que elegir, necesita un **catálogo**: un fichero que enumera los archetypes disponibles, con el `groupId`, el `artifactId`, la versión y una descripción de cada uno. El campo **Catalog** decide qué lista se usa, y la lista que aparece en el campo **Archetype** depende completamente de esa elección.

- **`Internal`** es el catálogo que viene seleccionado por defecto. Es una lista fija que IntelliJ trae incorporada y que no se actualiza. Contiene solo diez archetypes, todos publicados por el propio proyecto Maven (`groupId` `org.apache.maven.archetypes`): `maven-archetype-archetype`, `maven-archetype-j2ee-simple`, `maven-archetype-plugin`, `maven-archetype-plugin-site`, `maven-archetype-portlet`, `maven-archetype-profiles`, `maven-archetype-quickstart`, `maven-archetype-site`, `maven-archetype-site-simple` y `maven-archetype-webapp`. Además, de cada uno ofrece una única versión antigua: el quickstart solo aparece en la versión `1.1`.
- **`Maven Central`** es el catálogo que publica **Maven Central**, el repositorio público donde se publican las librerías y herramientas del ecosistema Java. Recoge los archetypes que publican organizaciones de todo el mundo: más de 3.700 distintos, y de cada uno todas sus versiones. Los diez archetypes de Maven siguen estando, pero junto a miles más. Como es un fichero grande, IntelliJ tarda unos segundos en cargarlo la primera vez.

El enlace `Manage catalogs...`, junto al campo, permite añadir otros catálogos. Las empresas lo usan para ofrecer a sus equipos las plantillas internas de su propio repositorio; en el curso no lo necesitamos.

Seleccionamos **Catalog**: `Maven Central`.

#### El archetype

Con el catálogo `Maven Central`, el desplegable **Archetype** es demasiado largo para recorrerlo: escribimos `quickstart` en el campo para filtrar la lista. Aun así aparecen más de 180 resultados, porque muchas organizaciones publican sus propias plantillas con `quickstart` en el nombre. Cada entrada se muestra como `groupId:artifactId`: lo que va antes de los dos puntos es la organización y lo que va después es el nombre del archetype. Elegimos exactamente:

- **Archetype**: `org.apache.maven.archetypes:maven-archetype-quickstart`.

#### La versión

El campo **Version** es la versión de la **plantilla**, no la de nuestro proyecto ni la de Java. Quien mantiene un archetype lo actualiza con el tiempo, igual que cualquier librería, y cada versión genera un proyecto distinto. Del quickstart hay publicadas nueve versiones, desde la `1.0-alpha-1` hasta la `1.5`, que es la más reciente. La diferencia entre la versión que ofrece el catálogo `Internal` y la actual es grande:

| | Versión `1.1` (catálogo `Internal`) | Versión `1.5` (catálogo `Maven Central`) |
|---|---|---|
| Librería de tests | JUnit 3.8.1, con una forma de escribir tests que ya no se usa | JUnit 5, la que se usa en el curso desde S02-2 |
| Versión de Java | No la fija: Maven usa su valor por defecto | Java 17 |
| Plugins | No declara ninguno | Fija la versión de nueve plugins |

Por eso hemos cambiado el catálogo: con `Internal` obtendríamos un proyecto con más de veinte años de antigüedad.

- **Version**: `1.5`. Si no aparece seleccionada, la elegimos en el desplegable.

El campo **Additional Properties** lo dejamos vacío: sirve para dar valores extra a plantillas que los piden, y el quickstart no necesita ninguno.

Por último, desplegamos `Advanced Settings` y rellenamos **GroupId** con `com.curso` y **ArtifactId** con `s02-1-demos-quickstart`, igual que en la Demo 1.

Hacemos clic en `Create`.

IntelliJ descarga el archetype de Maven Central y lo guarda en la caché local `~/.m2`, igual que hará Maven con cualquier librería. Después, Maven genera el proyecto a partir de la plantilla.

### Estructura del proyecto

<pre>
s02-1-demos-quickstart/
├── .idea/
├── .mvn/
├── src/
│   ├── main/
│   │   └── java/
│   │       └── com/
│   │           └── curso/
│   │               └── App.java
│   └── test/
│       └── java/
│           └── com/
│               └── curso/
│                   └── AppTest.java
└── pom.xml
</pre>

Las carpetas `src/main/java` y `src/test/java` son las mismas que en la Demo 1: es la estructura que Maven impone, la genere quien la genere. Lo que cambia es el contenido que la plantilla deja dentro.

### El pom.xml de la plantilla

<pre>
&amp;lt;?xml version="1.0" encoding="UTF-8"?&amp;gt;
&amp;lt;project ...&amp;gt;
  &amp;lt;modelVersion&amp;gt;4.0.0&amp;lt;/modelVersion&amp;gt;

  &amp;lt;groupId&amp;gt;com.curso&amp;lt;/groupId&amp;gt;
  &amp;lt;artifactId&amp;gt;s02-1-demos-quickstart&amp;lt;/artifactId&amp;gt;
  &amp;lt;version&amp;gt;1.0-SNAPSHOT&amp;lt;/version&amp;gt;

  &amp;lt;!-- name y url: datos descriptivos del proyecto. No afectan a la compilación.
       La plantilla pone una dirección de ejemplo que habría que cambiar. --&amp;gt;
  &amp;lt;name&amp;gt;s02-1-demos-quickstart&amp;lt;/name&amp;gt;
  &amp;lt;url&amp;gt;http://www.example.com&amp;lt;/url&amp;gt;

  &amp;lt;properties&amp;gt;
    &amp;lt;project.build.sourceEncoding&amp;gt;UTF-8&amp;lt;/project.build.sourceEncoding&amp;gt;
    &amp;lt;!-- maven.compiler.release: versión de Java en una sola propiedad, en lugar de
         maven.compiler.source y maven.compiler.target. La plantilla fija Java 17,
         no el 21 que usa el curso. --&amp;gt;
    &amp;lt;maven.compiler.release&amp;gt;17&amp;lt;/maven.compiler.release&amp;gt;
  &amp;lt;/properties&amp;gt;

  &amp;lt;!-- dependencyManagement: fija de una vez las versiones de todas las librerías
       de JUnit 5. Se trabaja en S03-1. --&amp;gt;
  &amp;lt;dependencyManagement&amp;gt;
    &amp;lt;dependencies&amp;gt;
      &amp;lt;dependency&amp;gt;
        &amp;lt;groupId&amp;gt;org.junit&amp;lt;/groupId&amp;gt;
        &amp;lt;artifactId&amp;gt;junit-bom&amp;lt;/artifactId&amp;gt;
        &amp;lt;version&amp;gt;5.11.0&amp;lt;/version&amp;gt;
        &amp;lt;type&amp;gt;pom&amp;lt;/type&amp;gt;
        &amp;lt;scope&amp;gt;import&amp;lt;/scope&amp;gt;
      &amp;lt;/dependency&amp;gt;
    &amp;lt;/dependencies&amp;gt;
  &amp;lt;/dependencyManagement&amp;gt;

  &amp;lt;!-- dependencies: librerías que el proyecto necesita. La plantilla ya incluye
       JUnit 5 para escribir tests. scope test: solo está disponible en src/test/java.
       Las dependencias se trabajan a partir de S02-2. --&amp;gt;
  &amp;lt;dependencies&amp;gt;
    &amp;lt;dependency&amp;gt;
      &amp;lt;groupId&amp;gt;org.junit.jupiter&amp;lt;/groupId&amp;gt;
      &amp;lt;artifactId&amp;gt;junit-jupiter-api&amp;lt;/artifactId&amp;gt;
      &amp;lt;scope&amp;gt;test&amp;lt;/scope&amp;gt;
    &amp;lt;/dependency&amp;gt;
    &amp;lt;!-- Opcional: soporte para tests parametrizados (un mismo test con varios datos). --&amp;gt;
    &amp;lt;dependency&amp;gt;
      &amp;lt;groupId&amp;gt;org.junit.jupiter&amp;lt;/groupId&amp;gt;
      &amp;lt;artifactId&amp;gt;junit-jupiter-params&amp;lt;/artifactId&amp;gt;
      &amp;lt;scope&amp;gt;test&amp;lt;/scope&amp;gt;
    &amp;lt;/dependency&amp;gt;
  &amp;lt;/dependencies&amp;gt;

  &amp;lt;!-- build y pluginManagement: fijan la versión de cada plugin de Maven para que
       el proyecto se construya igual en cualquier máquina. Los plugins son las piezas
       que hacen el trabajo de Maven (compilar, ejecutar tests, empaquetar...).
       Se trabajan en S03-2. --&amp;gt;
  &amp;lt;build&amp;gt;
    &amp;lt;pluginManagement&amp;gt;
      &amp;lt;plugins&amp;gt;
        &amp;lt;plugin&amp;gt;
          &amp;lt;artifactId&amp;gt;maven-clean-plugin&amp;lt;/artifactId&amp;gt;
          &amp;lt;version&amp;gt;3.4.0&amp;lt;/version&amp;gt;
        &amp;lt;/plugin&amp;gt;
        &amp;lt;plugin&amp;gt;
          &amp;lt;artifactId&amp;gt;maven-resources-plugin&amp;lt;/artifactId&amp;gt;
          &amp;lt;version&amp;gt;3.3.1&amp;lt;/version&amp;gt;
        &amp;lt;/plugin&amp;gt;
        &amp;lt;plugin&amp;gt;
          &amp;lt;artifactId&amp;gt;maven-compiler-plugin&amp;lt;/artifactId&amp;gt;
          &amp;lt;version&amp;gt;3.13.0&amp;lt;/version&amp;gt;
        &amp;lt;/plugin&amp;gt;
        &amp;lt;plugin&amp;gt;
          &amp;lt;artifactId&amp;gt;maven-surefire-plugin&amp;lt;/artifactId&amp;gt;
          &amp;lt;version&amp;gt;3.3.0&amp;lt;/version&amp;gt;
        &amp;lt;/plugin&amp;gt;
        &amp;lt;plugin&amp;gt;
          &amp;lt;artifactId&amp;gt;maven-jar-plugin&amp;lt;/artifactId&amp;gt;
          &amp;lt;version&amp;gt;3.4.2&amp;lt;/version&amp;gt;
        &amp;lt;/plugin&amp;gt;
        &amp;lt;plugin&amp;gt;
          &amp;lt;artifactId&amp;gt;maven-install-plugin&amp;lt;/artifactId&amp;gt;
          &amp;lt;version&amp;gt;3.1.2&amp;lt;/version&amp;gt;
        &amp;lt;/plugin&amp;gt;
        &amp;lt;plugin&amp;gt;
          &amp;lt;artifactId&amp;gt;maven-deploy-plugin&amp;lt;/artifactId&amp;gt;
          &amp;lt;version&amp;gt;3.1.2&amp;lt;/version&amp;gt;
        &amp;lt;/plugin&amp;gt;
        &amp;lt;plugin&amp;gt;
          &amp;lt;artifactId&amp;gt;maven-site-plugin&amp;lt;/artifactId&amp;gt;
          &amp;lt;version&amp;gt;3.12.1&amp;lt;/version&amp;gt;
        &amp;lt;/plugin&amp;gt;
        &amp;lt;plugin&amp;gt;
          &amp;lt;artifactId&amp;gt;maven-project-info-reports-plugin&amp;lt;/artifactId&amp;gt;
          &amp;lt;version&amp;gt;3.6.1&amp;lt;/version&amp;gt;
        &amp;lt;/plugin&amp;gt;
      &amp;lt;/plugins&amp;gt;
    &amp;lt;/pluginManagement&amp;gt;
  &amp;lt;/build&amp;gt;
&amp;lt;/project&amp;gt;
</pre>

El `pom.xml` generado por la plantilla es bastante más largo que el de la Demo 1. Los comentarios en español son del curso; la plantilla trae los suyos en inglés, que hemos sustituido. Lo que añade la plantilla:

- **`name` y `url`**: datos descriptivos. La `url` es una dirección de ejemplo que habría que cambiar o borrar.
- **`maven.compiler.release` con valor `17`**: la plantilla fija Java 17 en una sola propiedad, en lugar de `maven.compiler.source` y `maven.compiler.target`. El proyecto compila con nuestro JDK 21, pero el código queda limitado a Java 17. En la Demo 1, IntelliJ tomó la versión del JDK que elegimos; aquí la decide la plantilla.
- **JUnit 5**: la plantilla declara ya la librería de tests JUnit, con la que está escrito `AppTest`. Maven la descarga de Maven Central al crear el proyecto. Las dependencias y JUnit se trabajan en S02-2.
- **`pluginManagement`**: fija la versión de nueve plugins de Maven. Los plugins son las piezas que hacen el trabajo de Maven (compilar, ejecutar tests, empaquetar...). Se trabajan en S03-2.

### El código de la plantilla

`App` es la clase de ejemplo del archetype. Igual que con `Main`, el código es exactamente el generado y solo se han sustituido los comentarios:

```java
package com.curso;

/**
 * S02-1 Demo 3: Proyecto Maven con el archetype quickstart
 *
 * Objetivo: ver la clase de ejemplo que genera el archetype quickstart
 * para compararla con la que genera el asistente de IntelliJ (Main, Demo 1).
 *
 * Lo que hace este ejemplo:
 *   - Es la clase que maven-archetype-quickstart crea con el nombre App
 *   - Imprime un único mensaje de comprobación
 *
 * Concepto clave: un archetype es una plantilla. Todo lo que contiene este
 * proyecto lo decidió quien escribió la plantilla, no nosotros. El código es
 * exactamente el generado; solo se ha sustituido el javadoc original,
 * que decía "Hello world!".
 */
public class App {

    // main() permite ejecutar esta clase directamente desde IntelliJ (▶)
    // sin necesidad de ningún framework. Es el punto de entrada del programa.
    public static void main(String[] args) {
        // A diferencia del Main de la Demo 1, aquí se usa println():
        // el mensaje termina con salto de línea.
        System.out.println("Hello World!");  // → Hello World!
    }
}
```

`AppTest` es el test que la plantilla deja en `src/test/java`. No prueba nada de la aplicación: comprueba que `true` es `true`, así que siempre pasa. Es un marcador de posición que en un proyecto real se borra o se sustituye por tests de verdad.

```java
package com.curso;

// Importamos assertTrue y la anotación @Test de JUnit 5, la librería de tests de Java.
// Están disponibles porque el pom.xml de la plantilla ya declara JUnit como dependencia:
// Maven la ha descargado sin que nadie la pidiera. JUnit se trabaja en detalle en S02-2.
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * S02-1 Demo 3: Proyecto Maven con el archetype quickstart (test generado)
 *
 * Objetivo: ver el test de ejemplo que el archetype quickstart deja en
 * src/test/java y que el asistente de IntelliJ no genera.
 *
 * Lo que hace este ejemplo:
 *   - Define un único test que comprueba que true es true
 *   - Pasa siempre: no verifica nada de la aplicación
 *
 * Concepto clave: la plantilla prepara el sitio de los tests y la librería
 * para escribirlos, pero el test en sí no prueba nada real. Es un marcador
 * de posición que en un proyecto de verdad se borra o se sustituye.
 */
public class AppTest {

    // @Test marca el método como un test que JUnit debe ejecutar.
    // assertTrue(true) siempre se cumple, así que este test nunca falla.
    @Test
    public void shouldAnswerWithTrue() {
        assertTrue(true);
    }
}
```

Hacemos clic en ▶ junto al `main()` de `App`.

Salida esperada:

<pre>
Hello World!
</pre>

### Comparación

| | Asistente de IntelliJ (Demo 1) | Archetype quickstart (Demo 3) |
|---|---|---|
| Dónde se elige | `New Project > Java`, Build system `Maven` | `Generators > Maven Archetype` |
| Clase de ejemplo | `Main` (opcional, con Add sample code) | `App` (siempre) |
| `src/main/resources` | Sí, vacía | No |
| `src/test/java` | Vacía | Con `AppTest` |
| Versión de Java | La del JDK elegido (21) | Fijada por la plantilla (17) |
| Dependencias | Ninguna | JUnit 5 |
| Plugins | Ninguno declarado | Nueve, con su versión fijada |

Ninguno de los dos proyectos es incorrecto. La diferencia está en quién decide. Con el asistente de IntelliJ partimos de un `pom.xml` mínimo y añadimos solo lo que necesitamos, entendiendo cada línea: es lo que haremos en el resto del curso. Un archetype tiene sentido cuando la plantilla ahorra mucho trabajo de configuración repetitiva, como ocurre con proyectos web o con los de algunos frameworks. En la lista `Generators` de IntelliJ aparecen otros generadores de proyecto con la misma idea, como el de Spring Boot, que se verá cuando lleguemos a Spring.
