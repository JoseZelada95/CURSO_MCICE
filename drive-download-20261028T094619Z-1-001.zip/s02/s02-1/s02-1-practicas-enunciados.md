# S02-1 Prácticas

## Objetivos

Se aplica lo aprendido en las demos: se crea un proyecto Maven propio y se implementan clases con métodos que reciben parámetros y devuelven resultados. Cada práctica añade una clase nueva al mismo proyecto, reforzando el patrón paquete-clase-método visto en las demos.

---

## Práctica 1: Clase Calculadora

Se crea un proyecto Maven nuevo y se implementa la clase `Calculadora` con dos métodos aritméticos básicos.

**Pasos**

1. Creamos un nuevo proyecto Maven en IntelliJ desde `File > New > Project`, con `Java` seleccionado en el panel izquierdo: Name `s02-1-practicas`, Build system `Maven`, JDK `21` y **Add sample code** desmarcada. En `Advanced Settings`, usamos `com.curso` como GroupId y `s02-1-practicas` como ArtifactId.
2. Creamos el paquete `com.curso`: clic derecho sobre `src/main/java`, `New > Package`, escribimos `com.curso` y pulsamos Enter.
3. Creamos la clase `Calculadora` en el paquete `com.curso`.
4. Añadimos el método `sumar(double a, double b)` que devuelva la suma de los dos parámetros.
5. Añadimos el método `restar(double a, double b)` que devuelva la diferencia entre el primero y el segundo.
6. Añadimos un `main()` que cree una instancia de `Calculadora` y llame a los dos métodos con distintos valores. Comprobamos que los resultados son los esperados.

**Pistas**

- Sin **Add sample code**, `src/main/java` está vacía: hay que crear el paquete antes que la clase. Si la clase se crea directamente sobre `src/main/java`, queda sin paquete.
- Los dos métodos devuelven `double`.
- Para llamar a `sumar()` y `restar()` hay que crear una instancia: `new Calculadora()`.
- Si el resultado esperado de `restar(2, 5)` es `-3.0` y se obtiene algo distinto, hay que revisar el orden de los parámetros en la operación de resta.

---

## Práctica 2: Clase Conversor

En el mismo proyecto que `Calculadora`, se añade la clase `Conversor` que convierte cantidades entre euros y dólares usando un tipo de cambio fijo.

**Pasos**

1. Creamos la clase `Conversor` en el paquete `com.curso` del mismo proyecto que `Calculadora`.
2. Definimos una constante `TIPO_CAMBIO_EUR_USD` con el valor `1.09`.
3. Añadimos el método `euroADolar(double cantidad)` que devuelva el equivalente en dólares.
4. Añadimos el método `dolarAEuro(double cantidad)` que devuelva el equivalente en euros.
5. Añadimos un `main()` que pruebe los dos métodos con distintas cantidades.

**Pistas**

- Los dos métodos devuelven `double`.
- Para convertir de EUR a USD se multiplica por el tipo de cambio. Para la operación inversa se divide.
- Es normal que algunos resultados muestren decimales de más (por ejemplo, `109.00000000000001` en lugar de `109.0`). No es un error del código: se explica en S02-2.
- La constante se declara como `private static final double`: `static` porque pertenece a la clase y no a cada instancia; `final` porque su valor no puede cambiar una vez asignado.

---

## Práctica 3: Clase Validador

En el mismo proyecto, se añade la clase `Validador` que comprueba si una edad o un email cumplen ciertos criterios.

**Pasos**

1. Creamos la clase `Validador` en el paquete `com.curso` del mismo proyecto.
2. Añadimos el método `esMayorDeEdad(int edad)` que devuelva `true` si la edad es 18 o superior.
3. Añadimos el método `esEmailValido(String email)` que devuelva `true` si el email contiene `@` y al menos un `.` después del `@`.
4. Añadimos un `main()` que pruebe los dos métodos con distintos valores, incluyendo casos límite: exactamente 18 años, un email sin `@`, un email con `@` pero sin `.` a continuación.

**Pistas**

- Los dos métodos devuelven `boolean`.
- Para `esMayorDeEdad`, el operador `>=` ya devuelve `true` o `false` directamente: se puede escribir `return edad >= 18` sin necesidad de un `if`.
- Para `esEmailValido`, el método `String.indexOf(char)` devuelve la posición del carácter dentro de la cadena, o `-1` si no lo encuentra.
- `indexOf` tiene una versión con dos parámetros: `indexOf(char, fromIndex)` que empieza a buscar desde la posición indicada. Útil para buscar el `.` solo en la parte que hay después del `@`.
