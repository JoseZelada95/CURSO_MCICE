# S02-1 Soluciones

## Práctica 1: Clase Calculadora

`Calculadora` implementa dos métodos aritméticos con tipo de retorno `double`. La elección de `double` en lugar de `int` es deliberada: los enteros truncan la parte decimal en divisiones y producen resultados incorrectos cuando se encadenan operaciones. Usar `double` desde el principio evita ese problema.

Los métodos `sumar` y `restar` son de instancia, no estáticos. En Spring y Hibernate todas las clases de negocio se instancian antes de llamar a sus métodos, así que el patrón `new Calculadora().sumar(...)` que practicamos aquí es exactamente el que se usará con los servicios y repositorios de sesiones posteriores.

```java
package com.curso;

/**
 * S02-1 Práctica 1: Clase Calculadora
 *
 * Objetivo: crear un proyecto Maven propio e implementar una clase con métodos
 * que realizan operaciones aritméticas y devuelven el resultado.
 *
 * Aplica las técnicas de S02-1:
 *   1. Crear un proyecto Maven desde IntelliJ sin código de ejemplo y el paquete com.curso a mano
 *   2. Definir una clase con métodos que reciben parámetros y devuelven un valor
 *
 * Concepto clave: los métodos con valor de retorno permiten usar el resultado
 * donde se necesite. Una calculadora que no devuelve el resultado no tiene utilidad:
 * el tipo de retorno define lo que el método aporta a quien lo llama.
 */
public class Calculadora {

    /**
     * Suma dos números y devuelve el resultado.
     *
     * Ejemplo:
     *   sumar(3, 4)   →  7.0
     *   sumar(-1, 5)  →  4.0
     *
     * @param a primer operando
     * @param b segundo operando
     * @return la suma de a y b
     */
    public double sumar(double a, double b) {
        // Sumamos los dos operandos con el operador +.
        // El tipo double permite trabajar con números decimales, no solo enteros.
        // Devolvemos el resultado directamente con return.
        return a + b;
    }

    /**
     * Resta el segundo número al primero y devuelve el resultado.
     *
     * Ejemplo:
     *   restar(10, 3)  →  7.0
     *   restar(2, 5)   →  -3.0
     *
     * @param a minuendo (el número del que se resta)
     * @param b sustraendo (el número que se resta)
     * @return la diferencia entre a y b
     */
    public double restar(double a, double b) {
        // Restamos b de a con el operador -.
        // Si b es mayor que a, el resultado es negativo.
        return a - b;
    }

    // main() permite ejecutar esta clase directamente desde IntelliJ (▶)
    // sin necesidad de un framework. Útil para verificar que los cálculos son correctos.
    public static void main(String[] args) {
        // Creamos una instancia de Calculadora para poder llamar a sus métodos.
        // sumar() y restar() son métodos de instancia: necesitan un objeto sobre el que operar.
        Calculadora calc = new Calculadora();

        // Probamos la suma con distintas combinaciones para ver el comportamiento
        System.out.println(calc.sumar(3, 4));    // → 7.0
        System.out.println(calc.sumar(-1, 5));   // → 4.0

        // Probamos la resta, incluido el caso en que el resultado es negativo
        System.out.println(calc.restar(10, 3));  // → 7.0
        System.out.println(calc.restar(2, 5));   // → -3.0
    }
}
```

**Decisiones tomadas**

- `double` en lugar de `int`: los enteros pierden la parte decimal. Usar `double` desde el principio evita bugs sutiles cuando las operaciones se encadenan o cuando los parámetros llegan como valores decimales.
- Métodos de instancia en lugar de estáticos: en Spring y Hibernate todas las clases de negocio se instancian. Acostumbrarse al patrón `new Clase().metodo()` es parte del objetivo de esta práctica.
- Variable auxiliar `calc`: en lugar de `new Calculadora().sumar(...)` en cada línea, creamos la instancia una vez y la reutilizamos. Es más legible y muestra que el mismo objeto puede llamar a distintos métodos.

---

## Práctica 2: Clase Conversor

`Conversor` introduce el concepto de constante de clase (`private static final`). La tasa de cambio se define una sola vez porque su valor es único para toda la clase y no cambia durante la ejecución. Si el valor cambia en el futuro, solo hay que modificarlo en un lugar. Escribirlo directamente en el cuerpo de cada método (lo que se llama un "magic number") haría el código menos legible y más difícil de mantener.

```java
package com.curso;

/**
 * S02-1 Práctica 2: Clase Conversor
 *
 * Objetivo: implementar métodos que convierten cantidades entre monedas
 * y devuelven el resultado como double.
 *
 * Aplica las técnicas de S02-1:
 *   1. Añadir una clase a un proyecto Maven existente en el mismo paquete
 *   2. Diseñar métodos con valor de retorno de tipo double
 *
 * Concepto clave: los métodos de conversión devuelven un double.
 * Un conversor que no devuelve el resultado no tiene sentido:
 * el tipo de retorno define lo que el método aporta a quien lo llama.
 */
public class Conversor {

    // Tipo de cambio EUR → USD.
    // Definirlo como constante (static final) en lugar de escribirlo directamente
    // en el cuerpo del método permite cambiarlo en un solo lugar si varía.
    // static: pertenece a la clase, no a cada instancia.
    // final: su valor no puede cambiar una vez asignado.
    private static final double TIPO_CAMBIO_EUR_USD = 1.09;

    /**
     * Convierte una cantidad en euros a dólares estadounidenses.
     *
     * Ejemplo:
     *   euroADolar(100)  →  109.00000000000001
     *   euroADolar(50)   →  54.50000000000001
     *
     * @param cantidad importe en euros
     * @return el equivalente en dólares
     */
    public double euroADolar(double cantidad) {
        // Multiplicamos los euros por el tipo de cambio para obtener dólares.
        // Si 1 euro equivale a 1.09 dólares, 100 euros equivalen a 109 dólares.
        return cantidad * TIPO_CAMBIO_EUR_USD;
    }

    /**
     * Convierte una cantidad en dólares estadounidenses a euros.
     *
     * Ejemplo:
     *   dolarAEuro(109)  →  99.99999999999999
     *   dolarAEuro(50)   →  45.871559633027516
     *
     * @param cantidad importe en dólares
     * @return el equivalente en euros
     */
    public double dolarAEuro(double cantidad) {
        // Dividimos los dólares por el tipo de cambio para obtener euros.
        // Es la operación inversa a euroADolar: si multiplicar convierte de EUR a USD,
        // dividir convierte de USD a EUR.
        return cantidad / TIPO_CAMBIO_EUR_USD;
    }

    // main() permite ejecutar esta clase directamente desde IntelliJ (▶)
    // sin necesidad de un framework. Útil para comprobar que las conversiones son correctas.
    public static void main(String[] args) {
        // Creamos una instancia de Conversor para poder llamar a sus métodos.
        Conversor conversor = new Conversor();

        // Probamos la conversión de euros a dólares.
        // Los resultados no son exactos (109.00000000000001 en lugar de 109.0) porque
        // un double no puede guardar exactamente todos los decimales. Se explica en S02-2.
        System.out.println(conversor.euroADolar(100));  // → 109.00000000000001
        System.out.println(conversor.euroADolar(50));   // → 54.50000000000001

        // Probamos la conversión inversa de dólares a euros
        System.out.println(conversor.dolarAEuro(109));  // → 99.99999999999999
        System.out.println(conversor.dolarAEuro(50));   // → 45.871559633027516
    }
}
```

**Decisiones tomadas**

- `private static final double TIPO_CAMBIO_EUR_USD`: `static` porque el tipo de cambio es único para toda la clase, no varía de instancia en instancia; `final` porque no puede reasignarse; `private` porque es un detalle de implementación que no necesita exponerse. Definirlo como constante nombrada hace el código más legible y más fácil de actualizar.
- División en `dolarAEuro` como operación inversa a la multiplicación de `euroADolar`: si `EUR × tasa = USD`, entonces `USD / tasa = EUR`. No se necesita una segunda constante.
- Resultados reales en los comentarios `→`: `euroADolar(100)` devuelve `109.00000000000001` y no `109.0`, porque un `double` no puede guardar exactamente todos los decimales. Anotamos la salida real para que coincida con lo que se ve al ejecutar; el motivo se explica en S02-2.

---

## Práctica 3: Clase Validador

`Validador` introduce el tipo de retorno `boolean` y la lógica condicional. El punto más importante de esta práctica es la validación de email con `indexOf`: muestra cómo resolver un problema de búsqueda de caracteres usando solo métodos básicos de `String`, sin necesidad de expresiones regulares.

```java
package com.curso;

/**
 * S02-1 Práctica 3: Clase Validador
 *
 * Objetivo: implementar métodos de validación que aplican lógica condicional
 * y devuelven un boolean.
 *
 * Aplica las técnicas de S02-1:
 *   1. Añadir una clase al proyecto Maven existente en el mismo paquete
 *   2. Usar estructuras condicionales (if) para evaluar una condición y devolver boolean
 *
 * Concepto clave: los métodos de validación devuelven boolean: true si la condición
 * se cumple, false si no. Esta es la forma estándar de comprobar condiciones en Java.
 * La lógica de validación aparece en cualquier aplicación real: un sistema siempre
 * comprueba los datos antes de procesarlos.
 */
public class Validador {

    /**
     * Comprueba si una persona es mayor de edad (18 años o más).
     *
     * Ejemplo:
     *   esMayorDeEdad(18)  →  true
     *   esMayorDeEdad(17)  →  false
     *   esMayorDeEdad(25)  →  true
     *
     * @param edad edad de la persona en años
     * @return true si la edad es 18 o superior, false en caso contrario
     */
    public boolean esMayorDeEdad(int edad) {
        // El operador >= devuelve true si edad es igual o mayor que 18, false si es menor.
        // Devolvemos directamente el resultado de la comparación sin necesidad de un if.
        return edad >= 18;
    }

    /**
     * Comprueba si una cadena tiene el formato básico de un email.
     * Un email válido contiene "@" y al menos un "." después del "@".
     *
     * Ejemplo:
     *   esEmailValido("user@email.com")  →  true
     *   esEmailValido("noesvalido")      →  false
     *   esEmailValido("sin@punto")       →  false
     *
     * @param email cadena a validar
     * @return true si contiene "@" y "." después del "@", false en caso contrario
     */
    public boolean esEmailValido(String email) {
        // indexOf busca la posición de un carácter dentro de la cadena.
        // Devuelve -1 si no lo encuentra.
        int posicionArroba = email.indexOf("@");

        // Si no hay "@", el email no puede ser válido. Salimos enseguida con false.
        if (posicionArroba == -1) {
            return false;
        }

        // Buscamos un "." en la parte que hay después del "@".
        // Pasamos posicionArroba como segundo argumento para que indexOf
        // empiece a buscar desde esa posición y no encuentre un "." que estuviera antes.
        int posicionPunto = email.indexOf(".", posicionArroba);

        // Si hay un "." después del "@", posicionPunto será distinto de -1.
        // Devolvemos true o false según ese resultado.
        return posicionPunto != -1;
    }

    // main() permite ejecutar esta clase directamente desde IntelliJ (▶)
    // sin necesidad de un framework. Útil para comprobar que las validaciones son correctas.
    public static void main(String[] args) {
        // Creamos una instancia de Validador para poder llamar a sus métodos.
        Validador validador = new Validador();

        // Probamos esMayorDeEdad con el límite exacto y con valores por encima y por debajo
        System.out.println(validador.esMayorDeEdad(18));  // → true
        System.out.println(validador.esMayorDeEdad(17));  // → false
        System.out.println(validador.esMayorDeEdad(25));  // → true

        // Probamos esEmailValido con un email correcto y con casos inválidos
        System.out.println(validador.esEmailValido("user@email.com"));  // → true
        System.out.println(validador.esEmailValido("noesvalido"));      // → false
        System.out.println(validador.esEmailValido("sin@punto"));       // → false
    }
}
```

**Decisiones tomadas**

- `return edad >= 18` sin `if`: el operador `>=` ya produce un `boolean`. Escribir `if (edad >= 18) return true; else return false;` sería equivalente pero más verboso y menos idiomático en Java.
- `indexOf("@")` antes de `indexOf(".", posicionArroba)`: la búsqueda se hace en dos pasos porque el `.` debe aparecer después del `@`. Usar `indexOf(".")` directamente aceptaría como válido un email como `.usuario@dominio` (con punto antes de la arroba), que no es correcto.
- Retorno anticipado cuando no hay `@`: el `return false` dentro del `if` evita entrar en el segundo `indexOf` cuando ya sabemos que el email no es válido. Este patrón (early return) hace la lógica más fácil de leer que un `else` anidado.
