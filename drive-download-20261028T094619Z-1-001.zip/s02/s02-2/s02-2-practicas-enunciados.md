# S02-2 Prácticas

## Objetivos

Se aplica lo aprendido en las demos: se añade JUnit a un proyecto propio, se escriben tests sobre una clase ya existente y se implementa una clase nueva junto con sus tests, usando arrays y un bucle `for` para recorrerlos.

---

## Práctica 1: Tests de Conversor

Se crea un proyecto Maven nuevo con la clase `Conversor` de S02-1 y se añaden tests que comprueban las conversiones entre euros y dólares, incluyendo la conversión inversa.

**Pasos**

1. Creamos un nuevo proyecto Maven en IntelliJ desde `File > New > Project`, con `Java` seleccionado en el panel izquierdo: Name `s02-2-practicas`, Build system `Maven`, JDK `21` y **Add sample code** desmarcada. En `Advanced Settings`, usamos `com.curso` como GroupId y `s02-2-practicas` como ArtifactId.
2. Creamos el paquete `com.curso` en `src/main/java` (clic derecho, `New > Package`) y añadimos la clase `Conversor` de S02-1, con su constante `TIPO_CAMBIO_EUR_USD` y sus métodos `euroADolar` y `dolarAEuro`.
3. Añadimos la dependencia de JUnit 5 al `pom.xml`, igual que en la Demo 1: `groupId` `org.junit.jupiter`, `artifactId` `junit-jupiter`, `version` `5.11.0`, `scope` `test`. Hacemos clic en el icono de recarga de Maven tras guardar.
4. Creamos el paquete `com.curso` en `src/test/java` y, dentro, la clase `ConversorTest`.
5. Escribimos un test que compruebe `euroADolar` con al menos dos cantidades distintas.
6. Escribimos un test que compruebe `dolarAEuro` con al menos dos cantidades distintas.
7. Escribimos un test que convierta una cantidad de euros a dólares y el resultado de vuelta a euros, comprobando que se recupera el valor original.
8. Ejecutamos los tests desde IntelliJ y con `mvn test` desde la terminal, y comprobamos que los tres pasan.

**Pistas**

- Comparar dos `double` con `assertEquals(esperado, real)` puede fallar por una diferencia mínima de redondeo, aunque el resultado sea correcto (ya se vio en S02-1 que `100 * 1.09` no da exactamente `109.0`). `assertEquals` tiene una versión con un tercer parámetro, `delta`, que acepta el resultado si la diferencia con el valor esperado es menor que ese margen: `assertEquals(esperado, real, delta)`.
- Un margen como `0.0001` es suficiente para absorber el error de redondeo sin dejar de detectar un error real de cálculo.
- Para el test de la conversión inversa, primero se llama a `euroADolar` con una cantidad conocida y el resultado se pasa a `dolarAEuro`; el valor final debe coincidir (con el margen de tolerancia) con la cantidad de partida.

---

## Práctica 2: Clase Estadísticas con tests

En el mismo proyecto, se implementa la clase `Estadisticas`, con métodos que calculan la media, el máximo y el mínimo de un array de `double`, junto con los tests que verifican su comportamiento en los casos límite: array de un solo elemento, valores negativos y array vacío.

**Pasos**

1. Creamos la clase `Estadisticas` en el paquete `com.curso` de `src/main/java`.
2. Añadimos el método `media(double[] valores)` que devuelva la media aritmética de los valores del array.
3. Añadimos el método `maximo(double[] valores)` que devuelva el mayor valor del array.
4. Añadimos el método `minimo(double[] valores)` que devuelva el menor valor del array.
5. En los tres métodos, si el array recibido está vacío, se lanza una excepción `IllegalArgumentException` con un mensaje descriptivo, en lugar de devolver un número.
6. Creamos la clase `EstadisticasTest` en `src/test/java/com/curso`.
7. Escribimos un test de `media` con varios valores, comprobando el resultado general.
8. Para cada uno de los tres métodos, escribimos un test con un array de un único elemento y otro con valores negativos.
9. Para cada uno de los tres métodos, escribimos un test que compruebe que se lanza `IllegalArgumentException` cuando el array está vacío.
10. Ejecutamos todos los tests y comprobamos que pasan.

**Pistas**

- Los tres métodos reciben un `double[]` y devuelven `double`. Para comprobar si el array está vacío se compara `valores.length` con `0`.
- Para recorrer el array y acumular la suma (necesaria en `media`), se declara un acumulador `double` antes del bucle `for`, inicializado a `0.0`, y se le suma `valores[i]` en cada vuelta.
- Para `maximo` y `minimo`, una estrategia habitual es tomar `valores[0]` como valor provisional antes del bucle y comparar el resto de posiciones (empezando en el índice `1`) para ver si hay que sustituirlo.
- Para comprobar que un método lanza una excepción, JUnit ofrece `assertThrows(TipoDeExcepcion.class, () -> codigoQueDeberiaLanzarla())`. El segundo argumento es una expresión lambda: un trozo de código que se ejecuta dentro de `assertThrows` para comprobar que efectivamente lanza la excepción indicada.
- El mínimo de un conjunto de valores negativos es el número con mayor valor absoluto (por ejemplo, el mínimo entre `-5`, `-1` y `-9` es `-9`), y el máximo es el más cercano a cero (`-1` en ese mismo ejemplo). Conviene comprobarlo con un test explícito porque es un caso donde la intuición falla con más frecuencia.
