# S02-2 Demos

## Objetivos

En esta parte damos el salto de escribir código y comprobar el resultado a simple vista, a verificarlo de forma automática. Añadimos JUnit 5 al proyecto como primera dependencia externa real y escribimos los primeros tests sobre las clases `Calculadora` y `Validador` de S02-1. De paso, introducimos los arrays y el bucle `for` que la práctica de esta parte necesita para trabajar con conjuntos de valores.

Al terminar esta parte los alumnos son capaces de:
- Añadir una dependencia al `pom.xml` y explicar qué hace el scope `test`.
- Escribir un test con `@Test` y verificar un resultado con `assertEquals`.
- Ejecutar los tests desde IntelliJ y desde la terminal con `mvn test`.
- Diseñar tests que cubran casos límite, no solo el caso correcto.
- Declarar un array, recorrerlo con un bucle `for` y acumular un resultado.

---

## Demo 1: Añadir JUnit al pom.xml

Hasta ahora el proyecto no dependía de ninguna librería externa: todo el código de `Calculadora`, `Conversor` y `Validador` usaba solo lo que trae el JDK. Vamos a añadir la primera **dependencia**: JUnit 5, la librería de tests de Java. Una dependencia se declara en el `pom.xml` con tres coordenadas —`groupId`, `artifactId` y `version`— que ya conocemos de S02-1: son las mismas que identifican nuestro propio proyecto. Al guardar el fichero, Maven busca esa librería en Maven Central, la descarga y la añade al proyecto, sin que haya que buscar ningún JAR a mano.

### Añadir la dependencia

Abrimos el `pom.xml` y añadimos, después de `</properties>`, un bloque `<dependencies>` con la dependencia de JUnit:

```xml
<dependencies>
    <!-- JUnit 5: la librería de tests de Java. Maven la descarga de Maven Central
         en cuanto se guarda el pom.xml, sin necesidad de buscar ni instalar nada
         a mano. El scope test asegura que JUnit solo está disponible en
         src/test/java: no llega al código de producción ni al JAR final. -->
    <dependency>
        <groupId>org.junit.jupiter</groupId>
        <artifactId>junit-jupiter</artifactId>
        <version>5.11.0</version>
        <scope>test</scope>
    </dependency>
</dependencies>
```

`groupId` y `artifactId` identifican la librería igual que identifican nuestro proyecto: `org.junit.jupiter` es la organización (el proyecto JUnit), `junit-jupiter` es el artefacto concreto que agrupa lo necesario para escribir y ejecutar tests con JUnit 5. `version` fija qué versión exacta se descarga, para que el proyecto se construya igual en cualquier máquina.

El elemento nuevo es `scope`. El **scope** de una dependencia indica en qué parte del proyecto está disponible. Con `scope` `test`, las clases de JUnit solo se pueden usar dentro de `src/test/java`; si se intenta importar `org.junit.jupiter.api.Test` desde una clase de `src/main/java`, no compila. Esto tiene sentido: JUnit sirve para escribir tests, no para el código que llega a producción, y el scope lo garantiza en lugar de dejarlo a la disciplina de quien programa. El curso volverá sobre los distintos scopes con más detalle en S03-1.

Al guardar el `pom.xml`, IntelliJ detecta el cambio y muestra un icono de recarga (dos flechas circulares) en la esquina superior derecha del editor, con el texto "Load Maven Changes". Hacemos clic en él para que Maven vuelva a resolver las dependencias del proyecto: descarga el JAR de JUnit y sus dependencias transitivas de Maven Central y las añade al classpath.

### Recuperar la clase que vamos a testear

`s02-2-demos` es un proyecto Maven nuevo, distinto del `s02-1-demos` de la sesión anterior: no continuamos sobre aquel proyecto, sino que arrancamos uno propio para esta parte. Por eso, antes de escribir el test, creamos el paquete `com.curso` en `src/main/java` (clic derecho sobre `src/main/java`, `New > Package`, escribimos `com.curso`) y copiamos dentro la clase `Calculadora` de S02-1, con el mismo contenido y los mismos comentarios: no se cambia nada, es la clase que vamos a verificar con el test.

### Escribir el primer test

Los tests van en `src/test/java`, la carpeta que Maven reserva para ellos y que hasta ahora estaba vacía. Igual que en `src/main/java`, hay que crear primero el paquete: clic derecho sobre `src/test/java`, `New > Package`, escribimos `com.curso` y pulsamos Enter. Sobre ese paquete, clic derecho, `New > Java Class`, escribimos `CalculadoraTest` y pulsamos Enter.

Una clase de test es una clase normal, sin nada especial en su declaración. Lo que la convierte en un test es la anotación `@Test` sobre cada método: le indica a JUnit que ese método debe ejecutarse como una verificación independiente. Dentro del método, `assertEquals(esperado, real)` compara el valor que se espera con el que produce el código; si no coinciden, el test falla y JUnit lo señala.

```java
package com.curso;

// Importamos @Test y assertEquals de JUnit 5, la librería de tests de Java.
// Maven la ha descargado automáticamente al añadir la dependencia junit-jupiter
// al pom.xml. Sin Maven habría que buscar el JAR de JUnit, descargarlo
// y añadirlo al classpath a mano.
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

/**
 * S02-2 Demo 1: Tests de Calculadora
 *
 * Objetivo: escribir los primeros tests JUnit sobre una clase ya implementada
 * en S02-1, verificando su comportamiento sin necesidad de ejecutar el programa.
 *
 * Lo que hace este ejemplo:
 *   - Prueba los métodos sumar y restar de Calculadora
 *   - Usa @Test y assertEquals para comprobar automáticamente el resultado
 *
 * Concepto clave: un test llama al método con una entrada conocida y compara
 * el resultado con el valor que se espera. JUnit ejecuta cada método marcado
 * con @Test y avisa si alguna comprobación falla, sin que nadie tenga que
 * mirar la consola para comprobarlo a simple vista.
 */
public class CalculadoraTest {

    // JUnit crea una nueva instancia de la clase de test por cada @Test,
    // por lo que este campo se reinicia automáticamente entre tests.
    private final Calculadora calculadora = new Calculadora();

    // @Test marca el método como un test que JUnit debe ejecutar.
    // El nombre del método describe qué se está comprobando: no hace falta
    // llamarlo test1, test2... el propio nombre documenta el caso.
    @Test
    void sumarDevuelveLaSumaDeLosDosOperandos() {
        // assertEquals(esperado, real) compara los dos valores y hace fallar
        // el test si son distintos. El primer argumento es siempre el valor
        // esperado; el segundo, el que produce el código bajo prueba.
        assertEquals(7.0, calculadora.sumar(3, 4));
        assertEquals(4.0, calculadora.sumar(-1, 5));
    }

    @Test
    void restarDevuelveLaDiferenciaEntreLosDosOperandos() {
        assertEquals(7.0, calculadora.restar(10, 3));
        // Incluimos también el caso en que el resultado es negativo:
        // un test que solo prueba resultados positivos no cubre todo el comportamiento del método.
        assertEquals(-3.0, calculadora.restar(2, 5));
    }
}
```

### Ejecutar los tests

Hay dos formas de ejecutar este test, y las dos usan exactamente el mismo mecanismo por debajo.

Desde IntelliJ, hacemos clic en el icono ▶ que aparece junto a la declaración de la clase `CalculadoraTest` (o junto a cada método `@Test` para ejecutarlo por separado) y seleccionamos `Run 'CalculadoraTest'`. IntelliJ abre el panel `Run` en la parte inferior con el resultado de cada test.

Desde la terminal, situados en la carpeta del proyecto, ejecutamos:

```bash
mvn test
```

Maven compila el proyecto, ejecuta todos los tests de `src/test/java` y muestra un resumen.

Salida esperada (terminal):

<pre>
[INFO] -------------------------------------------------------
[INFO]  T E S T S
[INFO] -------------------------------------------------------
[INFO] Running com.curso.CalculadoraTest
[INFO] Tests run: 2, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 0.067 s -- in com.curso.CalculadoraTest
[INFO]
[INFO] Results:
[INFO]
[INFO] Tests run: 2, Failures: 0, Errors: 0, Skipped: 0
[INFO]
[INFO] BUILD SUCCESS
</pre>

En IntelliJ, el panel `Run` muestra los dos métodos de test con una marca verde junto a cada uno y el texto "Tests passed: 2 of 2 tests". Si `assertEquals` fallara en algún método, esa marca sería roja y el panel mostraría qué valor se esperaba y cuál se obtuvo realmente.

Este mecanismo —declarar la dependencia con `groupId`, `artifactId` y `version`, y que Maven la descargue sola— es exactamente el que se usará en S05 para añadir Spring y en S07 para añadir Hibernate. Nada cambia salvo el nombre de la librería.

---

## Demo 2: Tests de casos límite

El test de `CalculadoraTest` prueba el caso correcto: unos números de entrada razonables y un resultado esperado. Pero un test que solo cubre ese caso no detecta los errores que aparecen cuando los datos de entrada no son los esperados. Un **caso límite** es una entrada que está en el borde de lo válido o que directamente no lo es: la ausencia de un carácter necesario, un valor justo en el umbral, una cadena vacía. Diseñar tests para esos casos, además del caso feliz, es una habilidad que se practica desde el principio del curso.

Igual que con `Calculadora`, copiamos primero la clase `Validador` de S02-1 en el paquete `com.curso` de `src/main/java`, sin cambios. Después creamos la clase `ValidadorTest` en `src/test/java/com/curso` (mismo procedimiento que `CalculadoraTest`: clic derecho sobre el paquete, `New > Java Class`) y escribimos tres tests sobre `esEmailValido`: uno con un email correcto, y dos con emails que fallan por motivos distintos.

```java
package com.curso;

// Importamos @Test, assertTrue y assertFalse de JUnit 5. Igual que en
// CalculadoraTest, Maven ya ha descargado JUnit por la dependencia del pom.xml.
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * S02-2 Demo 2: Tests de casos límite
 *
 * Objetivo: escribir tests que cubran no solo el caso correcto, sino también
 * los casos en los que el dato de entrada no es válido.
 *
 * Lo que hace este ejemplo:
 *   - Prueba esEmailValido con un email correcto (con "@" y ".")
 *   - Prueba esEmailValido con dos emails incorrectos: sin "@", y con "@" pero sin "." después
 *
 * Concepto clave: un test que solo comprueba el caso feliz (el email correcto)
 * no detecta los errores que aparecen en producción. Diseñar casos de prueba
 * para los límites y los casos negativos —lo que falta, lo que sobra, lo que
 * está mal formado— es una habilidad que se practica desde el principio del curso.
 */
public class ValidadorTest {

    private final Validador validador = new Validador();

    @Test
    void emailConArrobaYPuntoEsValido() {
        // Caso feliz: el formato es correcto y el método debe devolver true.
        assertTrue(validador.esEmailValido("user@email.com"));
    }

    @Test
    void emailSinArrobaNoEsValido() {
        // Sin "@" no hay separación entre usuario y dominio: no puede ser un email válido.
        assertFalse(validador.esEmailValido("noesvalido"));
    }

    @Test
    void emailConArrobaPeroSinPuntoDespuesNoEsValido() {
        // Tiene "@", pero no hay ningún "." después: el dominio está incompleto.
        // Este es el caso límite que un test superficial (solo el caso feliz) no detectaría.
        assertFalse(validador.esEmailValido("sin@punto"));
    }
}
```

`assertTrue` y `assertFalse` son variantes de `assertEquals` especializadas en valores `boolean`: en lugar de escribir `assertEquals(true, ...)`, se lee mejor `assertTrue(...)`. Hacen exactamente la misma comprobación.

Ejecutamos con clic en ▶ junto a la clase, o con `mvn test` desde la terminal.

Salida esperada (terminal):

<pre>
[INFO] Running com.curso.ValidadorTest
[INFO] Tests run: 3, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 0.006 s -- in com.curso.ValidadorTest
</pre>

Los tres tests pasan. Si `esEmailValido` tuviera el error de buscar el primer `.` de toda la cadena en lugar de buscarlo después del `@`, el segundo y tercer test seguirían pasando pero un caso como `.usuario@dominio` (con un punto antes de la arroba) se aceptaría incorrectamente como válido: ese es justo el tipo de fallo que un caso límite bien elegido pone de manifiesto.

---

## Demo 3: Arrays y bucle for

La práctica de esta parte (`Estadisticas`) necesita trabajar con un conjunto de números, no con uno o dos valores sueltos como hasta ahora. Para eso hacen falta dos herramientas nuevas: el array, que guarda varios valores en una sola variable, y el bucle `for`, que permite recorrerlos todos sin repetir código.

Un **array** es una estructura que guarda varias posiciones de un mismo tipo bajo un único nombre. Su tamaño se decide en el momento de crearlo y no puede cambiar después: si se necesitan más posiciones, hay que crear un array nuevo. Cada posición se identifica por un **índice**, un número entero que empieza en `0` para la primera posición. Un array de 7 elementos tiene índices válidos del `0` al `6`; `array.length` (sin paréntesis, porque es un campo, no un método) devuelve cuántas posiciones tiene.

El **bucle `for`** ya apareció, sin explicarse, en el código generado de `Main.java` en S02-1. Su sintaxis tiene tres partes separadas por `;`: una inicialización que se ejecuta una sola vez al empezar (`int i = 0`), una condición que se comprueba antes de cada vuelta (`i < array.length`) y una actualización que se ejecuta al final de cada vuelta (`i++`). Mientras la condición sea `true`, el bloque entre llaves se repite; en cuanto es `false`, el bucle termina.

Creamos la clase `Temperaturas` en el paquete `com.curso` de `src/main/java` (clic derecho sobre `com.curso`, `New > Java Class`).

```java
package com.curso;

/**
 * S02-2 Demo 3: Arrays y bucle for
 *
 * Objetivo: declarar un array de tipo primitivo, recorrerlo con un bucle for
 * clásico y acumular un resultado a partir de sus elementos.
 *
 * Lo que hace este ejemplo:
 *   - Declara un array con las temperaturas registradas durante una semana
 *   - Recorre el array con un for clásico, imprimiendo cada valor junto a su índice
 *   - Acumula la suma de todos los valores para calcular el total
 *
 * Concepto clave: un array guarda varios valores del mismo tipo en una única
 * variable, con un tamaño fijo que queda decidido al crearlo. Cada elemento
 * se accede por su posición (índice), empezando siempre en 0. El bucle for
 * permite recorrer todas las posiciones sin repetir el código de acceso para cada una.
 */
public class Temperaturas {

    // main() permite ejecutar esta clase directamente desde IntelliJ (▶)
    // sin necesidad de un framework. Útil para ver el recorrido del array paso a paso.
    public static void main(String[] args) {
        // Un array de double con siete posiciones: una temperatura por día de la semana.
        // El tamaño (7) queda fijado en el momento de crear el array y no puede cambiar después:
        // un array no puede crecer ni encogerse una vez creado.
        double[] temperaturas = {21.5, 23.0, 19.8, 22.3, 24.1, 20.6, 18.9};

        // temperaturas.length devuelve el número de posiciones del array.
        // No lleva paréntesis porque length es un campo del array, no un método.
        System.out.println("Número de días registrados: " + temperaturas.length);  // → 7

        // Declaramos el acumulador antes del bucle, inicializado a 0.0.
        // Tiene que estar fuera del bucle porque necesita conservar su valor
        // entre una vuelta y la siguiente; si estuviera dentro, se reiniciaría en cada vuelta.
        double suma = 0.0;

        // El bucle for clásico tiene tres partes separadas por ";":
        //   - int i = 0                 → variable de control; empieza en la primera posición (índice 0)
        //   - i < temperaturas.length   → condición de continuación: sigue mientras i sea una posición válida
        //   - i++                       → al final de cada vuelta, incrementa i en 1
        // Con un array de 7 elementos, i toma los valores 0, 1, 2, 3, 4, 5 y 6: nunca llega a 7,
        // porque en ese momento la condición i < 7 deja de cumplirse y el bucle termina.
        for (int i = 0; i < temperaturas.length; i++) {
            // temperaturas[i] accede al elemento que ocupa la posición i del array.
            System.out.println("Día " + i + ": " + temperaturas[i] + "ºC");

            // Vamos sumando cada temperatura al acumulador en cada vuelta del bucle.
            suma += temperaturas[i];
        }

        // Tras el bucle, suma contiene el total acumulado de las siete temperaturas.
        System.out.println("Suma total: " + suma);
    }
}
```

Hacemos clic en ▶ junto al `main()`.

Salida esperada:

<pre>
Número de días registrados: 7
Día 0: 21.5ºC
Día 1: 23.0ºC
Día 2: 19.8ºC
Día 3: 22.3ºC
Día 4: 24.1ºC
Día 5: 20.6ºC
Día 6: 18.9ºC
Suma total: 150.2
</pre>

`suma += temperaturas[i]` es una forma abreviada de `suma = suma + temperaturas[i]`: toma el valor actual del acumulador, le suma el elemento de esa vuelta y guarda el resultado en la misma variable. Esta combinación —un acumulador declarado antes del bucle y actualizado en cada vuelta— es el patrón que usaremos en la práctica de `Estadisticas` para calcular la media, y con una variante (comparar en lugar de sumar) para el máximo y el mínimo.
