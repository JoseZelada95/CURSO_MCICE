# S08-1 Demos

## Objetivos

Las tablas del gimnasio se relacionan mediante claves foráneas: cada clase apunta a su monitor con la columna `monitor_id`, y cada inscripción apunta a un socio y a una clase. En esta parte aprendemos a expresar esas relaciones en Java. En la base de datos una clave foránea es un número; en Java es una referencia a otro objeto. JPA ofrece anotaciones (`@ManyToOne`, `@OneToMany`, `@JoinColumn`) con las que Hibernate traduce de uno a otro, de modo que navegamos de una clase a su monitor sin escribir ningún `JOIN`.

Las relaciones traen además una decisión que afecta al rendimiento y que produce uno de los errores más conocidos de Hibernate: cuándo se leen de la base de datos los datos relacionados. La vemos con un caso real, en la aplicación web, con el error incluido, y la resolvemos. Cerramos con la última propiedad de una relación, `cascade`, que decide si guardar o borrar un objeto arrastra también a los relacionados.

Las tres demos construyen un único proyecto, `s08-1-demos`, sobre la base de datos `gimnasio` de S07-1:

- **Demo 1:** `Clase` con su monitor (`@ManyToOne`) y `Monitor` con la lista de sus clases (`@OneToMany`).
- **Demo 2:** `Socio` e `Inscripcion`: la relación de muchos a muchos con una entidad intermedia.
- **Demo 3:** carga diferida, `LazyInitializationException` y `cascade`.

Al terminar esta parte los alumnos son capaces de:
- Declarar una relación `@ManyToOne` con `@JoinColumn` y su inversa `@OneToMany(mappedBy = ...)`.
- Explicar qué lado de una relación es el propietario y qué ocurre si se rellena solo el otro.
- Modelar una relación de muchos a muchos con datos propios mediante una entidad intermedia.
- Explicar qué es la carga diferida, reconocer una `LazyInitializationException` y resolverla.
- Explicar qué hace `cascade = CascadeType.ALL` al guardar y al borrar.

### Antes de empezar

- El servidor de PostgreSQL está en marcha y la base de datos `gimnasio` de S07-1 existe, con sus cuatro tablas (`monitor`, `clase`, `socio` e `inscripcion`) y sus datos de ejemplo: tres monitores, seis socios, cinco clases y ocho inscripciones. Lo comprobamos en pgAdmin: clic derecho sobre la base de datos `gimnasio`, `Query Tool`, escribimos la consulta y pulsamos ▶.

```sql
select count(*) from inscripcion;
```

Salida esperada:

<pre>
count
-----
    8
</pre>

- Si la base de datos se ha modificado, se vuelve a crear ejecutando de nuevo el script SQL de S07-1 en la `Query Tool`.
- La contraseña de PostgreSQL no aparece en ningún fichero del proyecto: va en la variable de entorno `POSTGRES_PASSWORD`. Las cuatro salvedades de esa variable (la terminal con `$env:POSTGRES_PASSWORD`, el ▶ de `@Test` que usa su propia configuración JUnit, que es propia de cada proyecto y que no viaja en el zip) están explicadas en `s07-1-demos.md`; aquí solo las recordamos cuando toca.

---

## Demo 1: `@ManyToOne` y `@OneToMany`

### Qué es una relación en JPA

En la base de datos, la tabla `clase` tiene una columna `monitor_id` con una clave foránea hacia `monitor.id`: en cada fila hay un número que dice a qué monitor pertenece la clase. En Java no queremos manejar números, queremos manejar objetos: de una `Clase` queremos poder llegar a su `Monitor` y pedirle el nombre. Una **relación** es la declaración, en la clase Java, de esa correspondencia:

| Base de datos | Java |
|---|---|
| Columna `clase.monitor_id` (un número) | Campo `monitor` de la clase `Clase` (un objeto `Monitor`) |
| Una fila de `clase` apunta a una fila de `monitor` | Un objeto `Clase` guarda una referencia a un objeto `Monitor` |
| Varias filas de `clase` pueden apuntar a la misma fila de `monitor` | Varios objetos `Clase` pueden referenciar al mismo `Monitor` |

JPA nombra las relaciones por su **cardinalidad** (cuántos objetos hay a cada lado), leída siempre desde la clase en la que se escribe la anotación. Muchas clases tienen un mismo monitor: desde `Clase` es una relación de muchos a uno, `@ManyToOne`. Un monitor tiene muchas clases: desde `Monitor` es una relación de uno a muchos, `@OneToMany`. Son las dos caras de una misma clave foránea, y las dos anotaciones aparecen en esta demo.

### Crear el proyecto

Como en S06-1, los proyectos de Spring Boot se crean con el generador de IntelliJ. Vamos a `File > New > Project`. En el panel izquierdo, dentro de `Generators`, seleccionamos `Spring Boot`.

Rellenamos los campos de la primera pantalla:

- **Name**: `s08-1-demos`.
- **Location**: la carpeta donde guardamos los proyectos del curso.
- **Create Git repository**: desmarcada.
- **Language**: `Java`.
- **Type**: `Maven`. Si viene seleccionado `Gradle - Groovy`, lo cambiamos.
- **Group**: `com.curso`.
- **Artifact**: `s08-1-demos`.
- **Package name**: `com.curso`. El campo se recalcula cada vez que se cambia otro, así que lo escribimos al final.
- **JDK**: `21`.
- **Java**: `21`. Si viene `17`, lo cambiamos.
- **Packaging**: `Jar`.
- **Configuration**: `Properties`.

Hacemos clic en `Next`. En la segunda pantalla elegimos **Spring Boot**: `4.1.1` y añadimos, con el botón `Add` o el buscador de dependencias, solo dos:

- `Spring Data JPA` (categoría SQL): trae Spring Data JPA, Hibernate y HikariCP.
- `PostgreSQL Driver` (categoría SQL): el controlador que permite hablar con PostgreSQL, el mismo de S07-1.

Hacemos clic en `Create`.

El generador no incluye los dos starters que necesita la parte web de la aplicación. Los añadimos a mano al `pom.xml`, dentro del bloque `<dependencies>`, justo debajo de `spring-boot-starter-data-jpa`. Son los mismos de S06-1: el primero trae Spring MVC y el Tomcat embebido, y el segundo, el motor de plantillas Thymeleaf.

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-webmvc</artifactId>
</dependency>
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-thymeleaf</artifactId>
</dependency>
```

IntelliJ avisa de que el `pom.xml` ha cambiado. Hacemos clic en **Load Maven Changes** (el icono `m` que aparece en el editor, o `Ctrl+Shift+O`) para que Maven descargue las librerías nuevas.

La clase principal que ha generado IntelliJ tiene un nombre largo que termina en `Application`. La renombramos: clic derecho sobre ella, `Refactor > Rename` (o `Shift+F6`), escribimos `Aplicacion` y pulsamos Enter. Si IntelliJ ofrece renombrar también la clase de test, aceptamos, para que quede `AplicacionTests`.

Creamos ahora los cuatro paquetes por capas, igual que en S06-1: clic derecho sobre `src/main/java`, `New > Package`, y escribimos `com.curso.model`; repetimos con `com.curso.repository`, `com.curso.config` y `com.curso.controller`. Las clases con las que trabajamos cuelgan de `com.curso` para que el escaneo de Spring las encuentre (el escaneo solo mira hacia abajo).

Esta es la clase principal, tal como queda tras el cambio de nombre y con los comentarios del curso:

```java
package com.curso;

// Importamos las dos clases de Spring Boot que arrancan la aplicación.
// Vienen con el starter de Spring Boot que Maven ha descargado al leer el pom.xml.
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * S08-1 Demo 1: Clase principal del proyecto
 *
 * Objetivo: arrancar la aplicación web del gimnasio con Spring Boot.
 *
 * Lo que hace este ejemplo:
 *   - Marca esta clase como punto de arranque con @SpringBootApplication
 *   - Escanea com.curso y sus subpaquetes (model, repository, config, controller)
 *   - Arranca Tomcat y conecta con la base de datos gimnasio de PostgreSQL
 *
 * Concepto clave: la clase generada por IntelliJ se ha renombrado a Aplicacion
 * y vive en el paquete raíz com.curso, para que el escaneo alcance todos los
 * subpaquetes (el escaneo solo mira hacia abajo).
 */
@SpringBootApplication
public class Aplicacion {

    // main() es el punto de entrada: run() crea el contenedor de Spring, escanea
    // los paquetes, crea los beans, lee application.properties y arranca Tomcat.
    // Como hay servidor web, la aplicación no termina hasta pulsar ■ en IntelliJ.
    public static void main(String[] args) {
        SpringApplication.run(Aplicacion.class, args);
    }
}
```

### Configurar la conexión

Abrimos `src/main/resources/application.properties`, que el generador ha creado con una sola línea (`spring.application.name`), y lo dejamos así:

```properties
spring.application.name=s08-1-demos

# Conexión a la base de datos gimnasio del PostgreSQL local (creada en S07-1).
# La contraseña NO se escribe aquí: Spring la lee de la variable de entorno
# POSTGRES_PASSWORD, que se define en la configuración de ejecución de IntelliJ.
spring.datasource.url=jdbc:postgresql://localhost:5432/gimnasio
spring.datasource.username=postgres
spring.datasource.password=${POSTGRES_PASSWORD}

# Las tablas ya existen (las crea el script SQL): Hibernate no las toca.
spring.jpa.hibernate.ddl-auto=none
# Muestra en la consola cada sentencia SQL que genera Hibernate.
spring.jpa.show-sql=true
# Desactivada desde S06-1: la sesión con la base de datos se cierra al salir del
# controlador, así que la plantilla no puede cargar datos diferidos (Demo 3).
spring.jpa.open-in-view=false
```

Cada línea tiene su razón:

- Las tres propiedades `spring.datasource.*` son la dirección de la base de datos `gimnasio`, el usuario y la contraseña, como en S07-1. La contraseña es `${POSTGRES_PASSWORD}`: Spring la lee de la variable de entorno.
- `spring.jpa.hibernate.ddl-auto=none` hace que Hibernate no cree ni toque las tablas, porque ya las creó el script SQL.
- `spring.jpa.show-sql=true` hace que Hibernate escriba en la consola cada sentencia SQL que ejecuta, precedida de `Hibernate:`. En esta parte lo leemos mucho: es la forma de ver qué consultas cuesta cada relación.
- `spring.jpa.open-in-view=false` es la opción que desactivamos en S06-1. En esta parte descubrimos su consecuencia (Demo 3).

**Variable de entorno en este proyecto nuevo.** La variable `POSTGRES_PASSWORD` es propia de cada proyecto de IntelliJ y no viaja con el código, así que hay que definirla otra vez en `s08-1-demos`. Si todavía no existe la configuración de ejecución `Aplicacion`, se crea al pulsar ▶ junto al `main()` de la clase principal; ese primer arranque falla porque falta la contraseña, y es lo esperado. Después vamos a `Run > Edit Configurations...`, seleccionamos `Aplicacion` y, en `Modify options`, activamos `Environment variables`. En el campo que aparece escribimos `POSTGRES_PASSWORD=` seguido de la contraseña que elegimos al instalar PostgreSQL, sin espacios ni comillas, y pulsamos `OK`.

### Monitor y MonitorRepository, de S07-1

La entidad `Monitor` y su repositorio no se escriben de nuevo: ya existen de S07-1. Los copiamos tal cual desde el proyecto de S07-1 al proyecto nuevo, `Monitor` en el paquete `model` y `MonitorRepository` en el paquete `repository`. Son la entidad de siempre (`@Entity`, `@Id`, `@GeneratedValue`, constructor sin argumentos, getters y `toString()`) y una interfaz vacía que extiende `JpaRepository`.

Este es `MonitorRepository`, sin cambios:

```java
package com.curso.repository;

import com.curso.model.Monitor;

// JpaRepository es la interfaz de Spring Data JPA que ya conocemos de S06-1.
// Llega con spring-boot-starter-data-jpa.
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * S08-1 Demo 1: Repositorio de Monitor (copiado de S07-1)
 *
 * Objetivo: guardar y buscar monitores sin escribir SQL.
 *
 * Lo que hace este ejemplo:
 *   - Es la misma interfaz que se creó en S07-1, copiada tal cual al proyecto nuevo
 *   - Hereda save(), findAll(), findById(), count() y deleteById()
 *
 * Concepto clave: una interfaz vacía basta. Spring Data genera la clase que la
 * implementa al arrancar y la registra como bean.
 */
public interface MonitorRepository extends JpaRepository<Monitor, Long> {
}
```

A `Monitor` le añadiremos más abajo la lista de sus clases. De momento la dejamos como está.

### La entidad Clase y `@ManyToOne`

Creamos la clase `Clase` en el paquete `model` (clic derecho sobre `com.curso.model`, `New > Java Class`). Mapea la tabla `clase`, y la novedad es el campo `monitor`:

- `@ManyToOne` indica que muchas clases tienen un mismo monitor.
- `@JoinColumn(name = "monitor_id")` indica el nombre de la columna que guarda la clave foránea en la tabla de esta clase. Hibernate la habría llamado `monitor_id` por su cuenta (nombre del campo, guion bajo e `id`), pero escribirla deja explícito el vínculo con el esquema SQL.
- El tipo del campo es `Monitor`, no `Long`: en Java guardamos el objeto, y Hibernate se encarga de convertirlo en el número de la columna al escribir y de convertir el número en el objeto al leer.

El resto de campos siguen las reglas de S07-1: `diaSemana` se traduce a `dia_semana`, `duracionMin` a `duracion_min` y `plazasLibres` a `plazas_libres`; `hora` es un `LocalTime`, que se corresponde con la columna `time`. El constructor con datos es para crear clases nuevas en el código (lo usamos en el experimento de más abajo).

```java
package com.curso.model;

// Anotaciones de JPA. Vienen con spring-boot-starter-data-jpa.
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

// LocalTime (hora sin fecha) es del JDK y se corresponde con la columna time de PostgreSQL.
import java.time.LocalTime;

/**
 * S08-1 Demo 1: Clase con su monitor (@ManyToOne)
 *
 * Objetivo: expresar en Java la clave foránea clase.monitor_id.
 *
 * Lo que hace este ejemplo:
 *   - Mapea la tabla clase (nombre, día, hora, duración, aforo, plazas libres)
 *   - Declara el campo monitor con @ManyToOne y @JoinColumn(name = "monitor_id")
 *
 * Concepto clave: Clase es el lado propietario de la relación, porque la columna
 * monitor_id está en su tabla. En la base de datos hay un número (monitor_id);
 * en Java hay un objeto Monitor completo, y Hibernate hace la traducción.
 */
@Entity
public class Clase {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;

    // Texto en mayúsculas sin tildes (LUNES ... DOMINGO): lo exige un check de la tabla.
    // Hibernate lo traduce a la columna dia_semana.
    private String diaSemana;

    private LocalTime hora;

    // duracionMin <-> duracion_min, plazasLibres <-> plazas_libres.
    private int duracionMin;
    private int aforo;
    private int plazasLibres;

    // Muchas clases tienen un mismo monitor: @ManyToOne.
    // @JoinColumn indica el nombre de la columna de la clave foránea en la tabla clase.
    // Por defecto Hibernate la habría llamado monitor_id igualmente (campo + _id),
    // pero escribirla deja explícito el vínculo con el esquema SQL.
    // Por defecto un @ManyToOne se carga de forma inmediata (EAGER): al leer una
    // clase, Hibernate lee también su monitor.
    @ManyToOne
    @JoinColumn(name = "monitor_id")
    private Monitor monitor;

    // Constructor sin argumentos que Hibernate necesita para reconstruir objetos.
    public Clase() {
    }

    // Constructor con todos los datos salvo el id, que lo genera la base de datos.
    public Clase(String nombre, String diaSemana, LocalTime hora, int duracionMin,
                 int aforo, int plazasLibres, Monitor monitor) {
        this.nombre = nombre;
        this.diaSemana = diaSemana;
        this.hora = hora;
        this.duracionMin = duracionMin;
        this.aforo = aforo;
        this.plazasLibres = plazasLibres;
        this.monitor = monitor;
    }

    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDiaSemana() {
        return diaSemana;
    }

    public LocalTime getHora() {
        return hora;
    }

    public int getDuracionMin() {
        return duracionMin;
    }

    public int getAforo() {
        return aforo;
    }

    public int getPlazasLibres() {
        return plazasLibres;
    }

    public Monitor getMonitor() {
        return monitor;
    }

    // toString() sin el monitor, para que imprimir una clase sea corto y no cargue nada más.
    @Override
    public String toString() {
        return "Clase{id=" + id + ", nombre='" + nombre + "', diaSemana='" + diaSemana
                + "', hora=" + hora + ", plazasLibres=" + plazasLibres + "/" + aforo + "}";
    }
}
```

Dos detalles del código merecen una explicación. El primero es el **lado propietario**: en una relación entre dos tablas, la columna de la clave foránea está en una sola de ellas, y la clase que corresponde a esa tabla es el lado propietario de la relación. Aquí es `Clase`, porque `monitor_id` está en `clase`. Es el lado que escribe la columna. El segundo es la carga: un `@ManyToOne` se carga por defecto de forma **inmediata** (`EAGER`, "ansiosa"): al leer una clase, Hibernate lee también su monitor, sin que nadie se lo pida. Esta decisión, y su alternativa, se estudian en la Demo 3.

### Repositorio, controlador y plantilla

El repositorio de `Clase` es una interfaz vacía, como los de S06-1 y S07-1. Observamos lo que dice su comentario: el repositorio no sabe nada de las relaciones, las resuelve el mapeo de la entidad.

```java
package com.curso.repository;

import com.curso.model.Clase;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * S08-1 Demo 1: Repositorio de Clase
 *
 * Objetivo: leer y guardar clases.
 *
 * Lo que hace este ejemplo:
 *   - Declara el repositorio de Clase con clave primaria de tipo Long
 *   - No añade ningún método: findAll() y save() heredados bastan
 *
 * Concepto clave: el repositorio no sabe nada de las relaciones. Al leer una
 * Clase, Hibernate lee también su Monitor porque el mapeo @ManyToOne se lo indica.
 */
public interface ClaseRepository extends JpaRepository<Clase, Long> {
}
```

Creamos el controlador `ClaseController` en el paquete `controller`. En esta demo solo usa `ClaseRepository`: un campo `private final`, un constructor que lo recibe (la inyección por constructor de S06-1) y el método `listar()`. El fichero completo, con la parte de la Demo 2 incluida, es el que viene en el zip y aparece en la Demo 2. Este es el método de esta demo:

```java
    // Demo 1: lista todas las clases. findAll() lee las clases y, por ser @ManyToOne
    // de carga inmediata, también el monitor de cada una. La plantilla clases.html
    // usa clase.monitor.nombre.
    @GetMapping("/clases")
    public String listar(Model model) {
        model.addAttribute("clases", claseRepository.findAll());
        return "clases";
    }
```

La plantilla `clases.html` va en `src/main/resources/templates` (la carpeta `templates` se crea con clic derecho sobre `resources`, `New > Directory`; el fichero, con clic derecho sobre `templates`, `New > File`). La línea que muestra la relación es `${clase.monitor.nombre}`: Thymeleaf llama a `getMonitor()` y después a `getNombre()` sobre el resultado, como si fueran objetos normales. La última columna, `Inscripciones`, es un enlace: `@{/clases/{id}/inscripciones(id=${clase.id})}` es una **expresión de enlace** de Thymeleaf, que construye la dirección sustituyendo `{id}` por el valor entre paréntesis. Ese enlace apunta a la página de la Demo 2, así que hasta entonces da error.

```html
<!DOCTYPE html>
<html lang="es" xmlns:th="http://www.thymeleaf.org">
<head>
    <meta charset="UTF-8">
    <title>Clases del gimnasio</title>
</head>
<body>
<!--/*
    S08-1 Demo 1: lista de clases con el nombre de su monitor.
    th:each repite la fila una vez por cada clase del modelo.
    ${clase.monitor.nombre} llama a getMonitor().getNombre(): se navega la
    relación @ManyToOne como si fueran objetos normales.
    Este comentario es de Thymeleaf y no llega al navegador.
*/-->
<h1>Clases del gimnasio</h1>

<table border="1" cellpadding="6">
    <thead>
    <tr>
        <th>Clase</th>
        <th>Día</th>
        <th>Hora</th>
        <th>Plazas libres</th>
        <th>Monitor</th>
        <th>Inscripciones</th>
    </tr>
    </thead>
    <tbody>
    <tr th:each="clase : ${clases}">
        <td th:text="${clase.nombre}">Yoga matutino</td>
        <td th:text="${clase.diaSemana}">LUNES</td>
        <td th:text="${clase.hora}">09:00</td>
        <td th:text="${clase.plazasLibres} + ' de ' + ${clase.aforo}">10 de 12</td>
        <td th:text="${clase.monitor.nombre}">Laura Gómez</td>
        <td><a th:href="@{/clases/{id}/inscripciones(id=${clase.id})}">ver</a></td>
    </tr>
    </tbody>
</table>
</body>
</html>
```

### Primera ejecución

Pulsamos ▶ junto al `main()` de `Aplicacion`. Si la variable `POSTGRES_PASSWORD` está bien definida, el arranque termina con las líneas habituales de S06-1 y S07-1 (`Tomcat started on port 8080`, `Started Aplicacion in ...`). Abrimos en el navegador `http://localhost:8080/clases` y vemos:

| Clase | Día | Hora | Plazas libres | Monitor | Inscripciones |
|---|---|---|---|---|---|
| Yoga matutino | LUNES | 09:00 | 10 de 12 | Laura Gómez | ver |
| Spinning | MIERCOLES | 19:00 | 0 de 3 | Carlos Ruiz | ver |
| Pilates | MARTES | 10:30 | 8 de 10 | Laura Gómez | ver |
| Yoga vespertino | JUEVES | 20:00 | 12 de 12 | Marta Soler | ver |
| Zumba | VIERNES | 18:30 | 19 de 20 | Marta Soler | ver |

El nombre del monitor sale de otra tabla y no hemos escrito ningún `JOIN`. La consola de IntelliJ enseña qué ha hecho Hibernate para conseguirlo:

<pre>
Hibernate: select c1_0.id,c1_0.aforo,c1_0.dia_semana,c1_0.duracion_min,c1_0.hora,c1_0.monitor_id,c1_0.nombre,c1_0.plazas_libres from clase c1_0
Hibernate: select m1_0.id,m1_0.email,m1_0.especialidad,m1_0.fecha_alta,m1_0.nombre from monitor m1_0 where m1_0.id=?
Hibernate: select m1_0.id,m1_0.email,m1_0.especialidad,m1_0.fecha_alta,m1_0.nombre from monitor m1_0 where m1_0.id=?
Hibernate: select m1_0.id,m1_0.email,m1_0.especialidad,m1_0.fecha_alta,m1_0.nombre from monitor m1_0 where m1_0.id=?
</pre>

Primero una consulta lee las cinco clases (con `monitor_id`, pero sin los datos del monitor), y después Hibernate lanza una consulta por cada monitor distinto. Son tres y no cinco porque dos clases comparten monitor y Hibernate no vuelve a leer uno que ya tiene en memoria. Anotamos esta cuenta (una consulta más una por monitor), porque en la Demo 3 sirve para entender el coste de la carga inmediata.

### El lado inverso: `@OneToMany(mappedBy = ...)`

Hasta ahora podemos ir de una clase a su monitor. Para ir en sentido contrario, de un monitor a sus clases, añadimos a `Monitor` una lista. En la base de datos no hay ninguna columna nueva: la clave foránea sigue siendo `clase.monitor_id`, y la lista es solo el reflejo, visto desde el monitor, de esa misma clave. Es el **lado inverso** de la relación.

La anotación es `@OneToMany(mappedBy = "monitor")`. El atributo `mappedBy` dice: "esta relación ya la define el campo `monitor` de la clase `Clase`; allí está el lado propietario, el que tiene la columna". Sin `mappedBy`, Hibernate creería que la lista es una relación distinta y buscaría una tabla intermedia que no existe en nuestro esquema. Esto es lo que ocurre si se olvida: la aplicación arranca bien, porque la lista es diferida y nadie la ha pedido todavía, pero la primera vez que algo la lee (por ejemplo, `monitor.getClases().size()` dentro de una transacción) falla con este mensaje de PostgreSQL:

<pre>
ERROR: relation "monitor_clases" does not exist
</pre>

Hibernate ha supuesto una tabla intermedia llamada `monitor_clases` (nombre del monitor, guion bajo y nombre de la lista) y la base de datos no la tiene.

Esta es la clase `Monitor` completa: lo que viene de S07-1 más la lista `clases`, con su `import` de `OneToMany`, `ArrayList` y `List`. Observamos también el comentario del `toString()`: no incluye la lista, porque imprimirla obligaría a cargarla de la base de datos, y `Clase` imprimiría a su vez su monitor y así sucesivamente.

```java
package com.curso.model;

// Importamos las anotaciones de JPA (paquete jakarta.persistence).
// Llegan con spring-boot-starter-data-jpa: Maven las ha descargado junto a Hibernate.
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

// LocalDate (fecha sin hora), ArrayList y List forman parte del JDK: no hace falta ninguna dependencia.
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * S08-1 Demo 1: Monitor con la lista de sus clases
 *
 * Objetivo: añadir a la entidad Monitor de S07-1 el lado inverso de la relación
 * con Clase.
 *
 * Lo que hace este ejemplo:
 *   - Mantiene los campos de S07-1 (id, nombre, email, especialidad, fechaAlta)
 *   - Añade la lista clases con @OneToMany(mappedBy = "monitor")
 *
 * Concepto clave: en la base de datos solo existe la columna clase.monitor_id.
 * La lista de Monitor no es una columna nueva: es el reflejo, visto desde el
 * monitor, de la clave foránea que escribe Clase.
 */
@Entity
public class Monitor {

    // Clave primaria generada por la base de datos (columna identity), como en S07-1.
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;
    private String email;

    // Nullable en la tabla: hay monitores sin especialidad (Marta Soler).
    private String especialidad;

    // Hibernate traduce fechaAlta a la columna fecha_alta sin ninguna anotación.
    private LocalDate fechaAlta;

    // Lado inverso de la relación: un monitor tiene muchas clases.
    // mappedBy = "monitor" significa: "esta relación ya la define el campo monitor
    // de la clase Clase; allí está el lado propietario, el que tiene la columna".
    // Sin mappedBy, Hibernate creería que es una relación distinta y buscaría una
    // tabla intermedia (monitor_clases) que no existe en nuestro esquema.
    // Se inicializa con una lista vacía para no tener nunca null.
    @OneToMany(mappedBy = "monitor")
    private List<Clase> clases = new ArrayList<>();

    // Hibernate necesita un constructor sin argumentos: crea un objeto vacío
    // y después rellena sus campos con los datos de la fila.
    public Monitor() {
    }

    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEmail() {
        return email;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public LocalDate getFechaAlta() {
        return fechaAlta;
    }

    public List<Clase> getClases() {
        return clases;
    }

    // toString() NO incluye la lista de clases: imprimirla obligaría a cargarla
    // de la base de datos, y Clase imprime a su vez su monitor (bucle infinito).
    @Override
    public String toString() {
        return "Monitor{id=" + id + ", nombre='" + nombre + "', especialidad='" + especialidad + "'}";
    }
}
```

### Experimento: el lado propietario es el que escribe

Hay una consecuencia práctica de la diferencia entre los dos lados que conviene comprobar con un caso real: quien escribe la clave foránea es siempre el lado propietario. La lista de `Monitor` es solo un reflejo para leer; rellenarla no guarda nada.

`ExperimentoLadoPropietario` es un `CommandLineRunner` (S06-1) que intenta guardar una clase dejando el monitor sin asignar y después la guarda asignándolo en `Clase`, que es el lado propietario. Fíjate en dos detalles del código: `DataIntegrityViolationException` es la excepción de Spring que envuelve los errores de restricciones de la base de datos (`not null`, `unique`, claves foráneas), y `getMostSpecificCause()` llega hasta el mensaje original de PostgreSQL. Al final, el experimento borra la clase de prueba para dejar la tabla como estaba.

La clase trae `@Component` y su `import` comentados con `//`, para que el proyecto no ejecute el experimento sin que se lo pidamos. Para ejecutarlo quitamos las dos barras de la línea `// @Component` y de la línea del `import org.springframework.stereotype.Component;`.

```java
package com.curso.config;

import com.curso.model.Clase;
import com.curso.model.Monitor;
import com.curso.repository.ClaseRepository;
import com.curso.repository.MonitorRepository;

// DataIntegrityViolationException es la excepción de Spring que envuelve los errores
// de restricciones de la base de datos (not null, unique, clave foránea...).
import org.springframework.boot.CommandLineRunner;
import org.springframework.dao.DataIntegrityViolationException;
// import org.springframework.stereotype.Component;

import java.time.LocalTime;

/**
 * S08-1 Demo 1: Experimento del lado propietario
 *
 * Objetivo: comprobar qué lado de la relación escribe la clave foránea.
 *
 * Lo que hace este ejemplo:
 *   - Intenta guardar una clase sin asignarle monitor: la base de datos la rechaza
 *   - Guarda otra clase asignándole el monitor desde el lado propietario: funciona
 *   - Borra la clase creada para dejar la base de datos como estaba
 *
 * Concepto clave: la columna monitor_id la escribe el campo monitor de Clase
 * (lado propietario). La lista Monitor.clases es solo el reflejo de esa columna:
 * no se guarda nada por rellenarla.
 *
 * Para ejecutarlo hay que quitar las dos barras de la línea @Component (y la del
 * import). Sin @Component, Spring no crea este bean y el runner no se ejecuta.
 */
// @Component
public class ExperimentoLadoPropietario implements CommandLineRunner {

    private final MonitorRepository monitorRepository;
    private final ClaseRepository claseRepository;

    public ExperimentoLadoPropietario(MonitorRepository monitorRepository, ClaseRepository claseRepository) {
        this.monitorRepository = monitorRepository;
        this.claseRepository = claseRepository;
    }

    @Override
    public void run(String... args) {
        Monitor monitor = monitorRepository.findById(1L).orElseThrow();

        // Intento 1: clase nueva sin monitor (el campo monitor queda a null).
        // Hibernate envía monitor_id = null y la base de datos lo rechaza
        // porque la columna es not null.
        Clase sinMonitor = new Clase("Boxeo", "SABADO", LocalTime.of(11, 0), 50, 15, 15, null);
        try {
            claseRepository.save(sinMonitor);
            System.out.println("Intento 1: guardada (no debería ocurrir)");
        } catch (DataIntegrityViolationException e) {
            // getMostSpecificCause() llega hasta el error original de PostgreSQL.
            System.out.println("Intento 1 rechazado: " + e.getMostSpecificCause().getMessage());
        }

        // Intento 2: el mismo objeto, pero asignando el monitor en el lado propietario.
        Clase conMonitor = new Clase("Boxeo", "SABADO", LocalTime.of(11, 0), 50, 15, 15, monitor);
        claseRepository.save(conMonitor);
        // El id es 7, no 6: el INSERT rechazado del intento 1 ya consumió el 6.
        // Los números de una columna identity no se reutilizan (S07-1).
        System.out.println("Intento 2 guardada: " + conMonitor);  // → Clase{id=7, ...}
        System.out.println("Su monitor: " + conMonitor.getMonitor());  // → Monitor{id=1, ...}

        // Limpieza: borramos la clase de prueba para no dejar datos de más.
        claseRepository.deleteById(conMonitor.getId());
        System.out.println("Clases en la tabla tras la limpieza: " + claseRepository.count());  // → 5
    }
}
```

Pulsamos ▶. En la consola de IntelliJ, después de la línea `Started Aplicacion`, vemos:

<pre>
Hibernate: select m1_0.id,m1_0.email,m1_0.especialidad,m1_0.fecha_alta,m1_0.nombre from monitor m1_0 where m1_0.id=?
Hibernate: insert into clase (aforo,dia_semana,duracion_min,hora,monitor_id,nombre,plazas_libres) values (?,?,?,?,?,?,?)
Intento 1 rechazado: ERROR: null value in column "monitor_id" of relation "clase" violates not-null constraint
  Detail: Failing row contains (6, Boxeo, SABADO, 11:00:00, 50, 15, 15, null).
Hibernate: insert into clase (aforo,dia_semana,duracion_min,hora,monitor_id,nombre,plazas_libres) values (?,?,?,?,?,?,?)
Intento 2 guardada: Clase{id=7, nombre='Boxeo', diaSemana='SABADO', hora=11:00, plazasLibres=15/15}
Su monitor: Monitor{id=1, nombre='Laura Gómez', especialidad='Yoga y Pilates'}
Hibernate: select c1_0.id,c1_0.aforo,c1_0.dia_semana,c1_0.duracion_min,c1_0.hora,m1_0.id,m1_0.email,m1_0.especialidad,m1_0.fecha_alta,m1_0.nombre,c1_0.nombre,c1_0.plazas_libres from clase c1_0 left join monitor m1_0 on m1_0.id=c1_0.monitor_id where c1_0.id=?
Hibernate: delete from clase where id=?
Hibernate: select count(*) from clase c1_0
Clases en la tabla tras la limpieza: 5
</pre>

Se leen tres cosas:

- **Intento 1.** El campo `monitor` de la clase está vacío, así que Hibernate envía `monitor_id` como `null` y la base de datos lo rechaza, porque la columna es `not null`. El resultado es el mismo que si hubiéramos añadido la clase a la lista `monitor.getClases()` y nada más: Hibernate ignora el lado inverso al escribir, y la clave foránea queda vacía. La base de datos hace cumplir su restricción y avisa en el `Detail` de qué fila falló.
- **Intento 2.** Con el monitor asignado en `Clase`, el `insert` funciona. El `id` que recibe es el 7, y no el 6: el `insert` rechazado del intento 1 ya consumió el 6, y los números de una columna `identity` no se reutilizan (S07-1).
- **Limpieza.** La clase de prueba se borra y la tabla vuelve a tener cinco clases.

Si repetimos el experimento, el `id` de la clase de prueba sube en cada ejecución. Es normal. Volvemos a comentar las dos líneas (`// @Component` y el `import`) para que no se ejecute más.

Salida esperada, si lo comprobamos en pgAdmin tras el experimento:

```sql
select count(*) from clase;
```

<pre>
count
-----
    5
</pre>

### El test generado

El generador de Spring Boot deja en `src/test/java/com/curso` un test con el método `contextLoads()` vacío (S05-1). Lo hemos dejado tal cual, solo con comentarios:

```java
package com.curso;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * S08-1 Demo 1: Test generado por IntelliJ
 *
 * Objetivo: comprobar que la aplicación arranca.
 *
 * Lo que hace este ejemplo:
 *   - Es el test que genera el asistente de Spring Boot, sin cambios
 *   - contextLoads() está vacío: pasa si el contenedor arranca sin errores
 *
 * Concepto clave: @SpringBootTest arranca la aplicación completa, también la
 * conexión a PostgreSQL. Por eso este test necesita la variable de entorno
 * POSTGRES_PASSWORD en su propia configuración JUnit (ver s07-1-demos.md).
 */
@SpringBootTest
class AplicacionTests {

    @Test
    void contextLoads() {
    }
}
```

`@SpringBootTest` arranca la aplicación completa, y eso incluye conectar con PostgreSQL. Por eso el test necesita la variable de entorno en **su propia configuración JUnit**: el ▶ que hay junto a `@Test` crea una configuración distinta de la de `Aplicacion`, y una variable definida en una no pasa a la otra (salvedad 2 de S07-1). La definimos en `Run > Edit Configurations...`, en la configuración de `AplicacionTests`, igual que antes. Con la variable, el test pasa. Desde la terminal, en PowerShell, la definimos para esa ventana antes de lanzar Maven:

```bash
$env:POSTGRES_PASSWORD="tu-contraseña"
mvn test
```

Resultado en la terminal:

<pre>
[INFO] Tests run: 1, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 7.046 s -- in com.curso.AplicacionTests
[INFO] Tests run: 1, Failures: 0, Errors: 0, Skipped: 0
[INFO] BUILD SUCCESS
</pre>

Sin la variable, el test falla y el mensaje de PostgreSQL localiza el motivo:

<pre>
Caused by: org.postgresql.util.PSQLException: FATAL: password authentication failed for user "postgres"
[ERROR] Tests run: 1, Failures: 0, Errors: 1, Skipped: 0
[INFO] BUILD FAILURE
</pre>

---

## Demo 2: Muchos a muchos con la entidad `Inscripcion`

Un socio puede apuntarse a muchas clases y una clase tiene muchos socios. Es una relación de **muchos a muchos**. En S07-1 la resolvimos en SQL con una tabla intermedia, `inscripcion`, que tiene dos claves foráneas (`socio_id` y `clase_id`). En Java hay dos formas de expresarla. JPA ofrece `@ManyToMany`, que oculta la tabla intermedia, pero solo sirve cuando la relación no tiene datos propios. La nuestra sí los tiene: la fecha en que el socio se apuntó. Por eso la modelamos con una **entidad intermedia**, `Inscripcion`, que mapea la tabla intermedia, y partimos la relación de muchos a muchos en dos relaciones de muchos a uno:

- Muchas inscripciones pertenecen a un mismo socio (`@ManyToOne` hacia `Socio`).
- Muchas inscripciones pertenecen a una misma clase (`@ManyToOne` hacia `Clase`).

Es el patrón más habitual en aplicaciones reales (una matrícula, un pedido, una reserva), y por eso conviene aprenderlo antes que `@ManyToMany`.

### Socio e Inscripcion

Creamos primero `Socio` en el paquete `model`. De momento solo mapea los campos de la tabla `socio` (`id`, `nombre`, `email` y `fechaAlta`), con los mismos elementos de siempre: `@Entity`, `@Id` y `@GeneratedValue`, constructor sin argumentos, getters y `toString()`. En la Demo 3 le añadiremos la lista de sus inscripciones; su versión final, que es la que viene en el zip, se muestra allí.

Creamos después `Inscripcion`. Tiene tres elementos nuevos:

- Dos relaciones `@ManyToOne`, cada una con su `@JoinColumn`. `Inscripcion` es el lado propietario de las dos, porque las columnas `socio_id` y `clase_id` están en su tabla.
- El dato propio de la relación, `fechaInscripcion`, un `LocalDate` que se traduce a la columna `fecha_inscripcion`.
- Un constructor que recibe el socio y la clase y asigna la fecha en Java con `LocalDate.now()`.

Este último punto tiene una razón. La tabla tiene `default current_date` en la columna de la fecha, pero ese valor por defecto solo se aplica cuando el `INSERT` no menciona la columna, y Hibernate incluye todas las columnas de la entidad en el `INSERT`. Si el campo estuviera vacío, Hibernate enviaría `null` y la base de datos lo rechazaría, porque la columna es `not null`. Esto es lo que ocurre si el constructor no asigna la fecha:

<pre>
ERROR: null value in column "fecha_inscripcion" of relation "inscripcion" violates not-null constraint
  Detail: Failing row contains (9, 7, 4, null).
</pre>

```java
package com.curso.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

import java.time.LocalDate;

/**
 * S08-1 Demo 2: Inscripcion, la entidad que une Socio y Clase
 *
 * Objetivo: modelar la relación de muchos a muchos entre socios y clases con
 * una entidad intermedia que tiene un dato propio (la fecha de inscripción).
 *
 * Lo que hace este ejemplo:
 *   - Mapea la tabla inscripcion
 *   - Declara dos relaciones @ManyToOne: hacia Socio (socio_id) y hacia Clase (clase_id)
 *   - Guarda la fecha de inscripción como campo propio
 *
 * Concepto clave: un socio se apunta a muchas clases y una clase tiene muchos
 * socios. Como la relación tiene datos propios, se parte en dos relaciones de
 * muchos a uno con Inscripcion en medio, que es el lado propietario de ambas.
 */
@Entity
public class Inscripcion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Primera clave foránea: muchas inscripciones pertenecen a un mismo socio.
    @ManyToOne
    @JoinColumn(name = "socio_id")
    private Socio socio;

    // Segunda clave foránea: muchas inscripciones pertenecen a una misma clase.
    @ManyToOne
    @JoinColumn(name = "clase_id")
    private Clase clase;

    // Dato propio de la relación: cuándo se apuntó el socio a la clase.
    private LocalDate fechaInscripcion;

    public Inscripcion() {
    }

    // Al crear una inscripción nueva, la fecha se asigna aquí, en Java.
    // El default current_date de la tabla NO se aplicaría: Hibernate incluye todas
    // las columnas en el INSERT, y si el campo fuera null enviaría null a la
    // columna (que además es not null) en lugar de dejar que actúe el default.
    public Inscripcion(Socio socio, Clase clase) {
        this.socio = socio;
        this.clase = clase;
        this.fechaInscripcion = LocalDate.now();
    }

    public Long getId() {
        return id;
    }

    public Socio getSocio() {
        return socio;
    }

    public Clase getClase() {
        return clase;
    }

    public LocalDate getFechaInscripcion() {
        return fechaInscripcion;
    }

    @Override
    public String toString() {
        return "Inscripcion{id=" + id + ", fechaInscripcion=" + fechaInscripcion + "}";
    }
}
```

Fíjate en que `Clase` no tiene una lista de inscripciones. La relación se puede navegar en un solo sentido (de la inscripción a su clase) y solo declaramos el lado inverso cuando alguna página lo necesita. Aquí lo necesitaremos en `Socio`, en la Demo 3.

### Un método derivado del nombre

Para listar las inscripciones de una clase, el repositorio necesita una consulta que filtre por la clase. En lugar de escribir SQL, declaramos en la interfaz un método cuyo nombre describe lo que buscamos, y Spring Data JPA escribe la consulta. `findByClaseId` se lee: "busca (`find`) por (`By`) el campo `clase` y, dentro de él, su `id`". Esto se llama **método derivado del nombre** y se estudia con detalle en S08-2; aquí solo usamos uno.

```java
package com.curso.repository;

import com.curso.model.Inscripcion;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * S08-1 Demo 2: Repositorio de Inscripcion
 *
 * Objetivo: listar las inscripciones de una clase.
 *
 * Lo que hace este ejemplo:
 *   - Declara el repositorio de Inscripcion
 *   - Añade findByClaseId(), una consulta que Spring Data genera a partir del nombre
 *
 * Ejemplo:
 *   findByClaseId(2L)  →  las tres inscripciones de Spinning
 *   findByClaseId(4L)  →  lista vacía (Yoga vespertino no tiene inscritos)
 *
 * Concepto clave: Spring Data lee el nombre del método (buscar por el id de la
 * clase) y escribe la consulta. Los métodos derivados del nombre se estudian en
 * detalle en S08-2; aquí solo se usa uno para listar las inscripciones de una clase.
 */
public interface InscripcionRepository extends JpaRepository<Inscripcion, Long> {

    // "findBy" + "Clase" (el campo clase de Inscripcion) + "Id" (el id de esa clase):
    // genera un select de inscripcion con where clase_id = ?
    List<Inscripcion> findByClaseId(Long claseId);
}
```

### El controlador y la plantilla

Ampliamos `ClaseController` con una segunda página y le añadimos el segundo repositorio al constructor. Este es el fichero completo, tal como viene en el zip:

- `{id}` en la ruta es una **variable de ruta**: en `/clases/2/inscripciones` vale `2`. La anotación `@PathVariable` entrega ese valor como parámetro del método (se estudia en detalle más adelante).
- `orElseThrow()` devuelve la clase, o lanza una excepción si el `id` no existe.

```java
package com.curso.controller;

import com.curso.model.Clase;
import com.curso.repository.ClaseRepository;
import com.curso.repository.InscripcionRepository;

// Controller, GetMapping, PathVariable y Model llegan con spring-boot-starter-webmvc.
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * S08-1 Demo 1 y Demo 2: Controlador de las páginas de clases
 *
 * Objetivo: mostrar en el navegador las clases con el nombre de su monitor y las
 * inscripciones de cada clase.
 *
 * Lo que hace este ejemplo:
 *   - Demo 1: GET /clases lista las clases con el nombre de su monitor
 *   - Demo 2: GET /clases/{id}/inscripciones lista los socios inscritos en una clase
 *
 * Concepto clave: el controlador navega las relaciones como objetos
 * (clase.monitor.nombre) y no escribe ningún JOIN: Hibernate resuelve las claves foráneas.
 */
@Controller
public class ClaseController {

    // Inyección por constructor (S06-1): Spring entrega los dos repositorios al crear el controlador.
    private final ClaseRepository claseRepository;
    private final InscripcionRepository inscripcionRepository;

    public ClaseController(ClaseRepository claseRepository, InscripcionRepository inscripcionRepository) {
        this.claseRepository = claseRepository;
        this.inscripcionRepository = inscripcionRepository;
    }

    // Demo 1: lista todas las clases. findAll() lee las clases y, por ser @ManyToOne
    // de carga inmediata, también el monitor de cada una. La plantilla clases.html
    // usa clase.monitor.nombre.
    @GetMapping("/clases")
    public String listar(Model model) {
        model.addAttribute("clases", claseRepository.findAll());
        return "clases";
    }

    // Demo 2: lista las inscripciones de una clase.
    // {id} es una variable de ruta: en /clases/2/inscripciones vale 2, y
    // @PathVariable la entrega como parámetro del método (se estudia en detalle más adelante).
    @GetMapping("/clases/{id}/inscripciones")
    public String inscripciones(@PathVariable Long id, Model model) {
        // orElseThrow() devuelve la clase o lanza una excepción si el id no existe.
        Clase clase = claseRepository.findById(id).orElseThrow();
        model.addAttribute("clase", clase);
        model.addAttribute("inscripciones", inscripcionRepository.findByClaseId(id));
        return "inscripciones";
    }
}
```

La plantilla `inscripciones.html` tiene dos novedades. La primera es que cada fila navega una relación: `${inscripcion.socio.nombre}` va de la inscripción a su socio. La segunda es que una clase puede no tener inscritos (Yoga vespertino), y en ese caso mostramos un mensaje en lugar de una tabla vacía: `th:if` muestra una etiqueta solo si su condición se cumple, `th:unless` la muestra solo si no se cumple, y `#lists.isEmpty(...)` comprueba si una lista no tiene elementos.

```html
<!DOCTYPE html>
<html lang="es" xmlns:th="http://www.thymeleaf.org">
<head>
    <meta charset="UTF-8">
    <title>Inscripciones de una clase</title>
</head>
<body>
<!--/*
    S08-1 Demo 2: inscripciones de una clase.
    Cada fila es una Inscripcion: su socio (relación @ManyToOne) y su fecha propia.
    th:if muestra el párrafo solo si la lista está vacía (Yoga vespertino).
*/-->
<h1>Inscripciones de <span th:text="${clase.nombre}">Spinning</span></h1>
<p th:text="'Plazas libres: ' + ${clase.plazasLibres} + ' de ' + ${clase.aforo}">Plazas libres: 0 de 3</p>

<p th:if="${#lists.isEmpty(inscripciones)}">Esta clase todavía no tiene inscritos.</p>

<table border="1" cellpadding="6" th:unless="${#lists.isEmpty(inscripciones)}">
    <thead>
    <tr>
        <th>Socio</th>
        <th>Email</th>
        <th>Fecha de inscripción</th>
    </tr>
    </thead>
    <tbody>
    <tr th:each="inscripcion : ${inscripciones}">
        <td th:text="${inscripcion.socio.nombre}">Ana Torres</td>
        <td th:text="${inscripcion.socio.email}">ana.torres@correo.test</td>
        <td th:text="${inscripcion.fechaInscripcion}">2026-09-01</td>
    </tr>
    </tbody>
</table>

<p><a th:href="@{/clases}">Volver a las clases</a></p>
</body>
</html>
```

### Resultado

Reiniciamos la aplicación y, desde `http://localhost:8080/clases`, hacemos clic en `ver` junto a Spinning (o abrimos `http://localhost:8080/clases/2/inscripciones`):

Inscripciones de Spinning. Plazas libres: 0 de 3.

| Socio | Email | Fecha de inscripción |
|---|---|---|
| Ana Torres | ana.torres@correo.test | 2026-09-01 |
| Luis Mora | luis.mora@correo.test | 2026-09-02 |
| Elena Vidal | elena.vidal@correo.test | 2026-09-02 |

La clase Yoga vespertino (`http://localhost:8080/clases/4/inscripciones`) no tiene inscritos y muestra el mensaje:

<pre>
Inscripciones de Yoga vespertino
Plazas libres: 12 de 12
Esta clase todavía no tiene inscritos.
</pre>

En la consola de IntelliJ, la primera página genera estas consultas:

<pre>
Hibernate: select c1_0.id,c1_0.aforo,c1_0.dia_semana,c1_0.duracion_min,c1_0.hora,m1_0.id,m1_0.email,m1_0.especialidad,m1_0.fecha_alta,m1_0.nombre,c1_0.nombre,c1_0.plazas_libres from clase c1_0 left join monitor m1_0 on m1_0.id=c1_0.monitor_id where c1_0.id=?
Hibernate: select i1_0.id,i1_0.clase_id,i1_0.fecha_inscripcion,i1_0.socio_id from inscripcion i1_0 where i1_0.clase_id=?
Hibernate: select s1_0.id,s1_0.email,s1_0.fecha_alta,s1_0.nombre from socio s1_0 where s1_0.id=?
Hibernate: select s1_0.id,s1_0.email,s1_0.fecha_alta,s1_0.nombre from socio s1_0 where s1_0.id=?
Hibernate: select s1_0.id,s1_0.email,s1_0.fecha_alta,s1_0.nombre from socio s1_0 where s1_0.id=?
</pre>

La primera consulta lee la clase junto a su monitor (con un `left join`, porque `findById` trae el `@ManyToOne` en la misma consulta), la segunda es la que ha generado `findByClaseId` (`where i1_0.clase_id=?`) y las tres últimas leen el socio de cada inscripción. Es la misma cuenta de la Demo 1: una consulta para la lista y una más por cada objeto relacionado.

---

## Demo 3: Carga diferida, `LazyInitializationException` y `cascade`

### Carga inmediata y carga diferida

Cuando Hibernate lee un objeto, tiene que decidir qué hacer con los objetos relacionados: leerlos en ese mismo momento o esperar a que alguien los use. Son las dos estrategias de carga de una relación:

- **Carga inmediata (`EAGER`):** al leer el objeto se leen también los relacionados. Es el valor por defecto de `@ManyToOne`, y por eso la Demo 1 mostró el nombre del monitor sin que lo pidiéramos.
- **Carga diferida (`LAZY`):** al leer el objeto, Hibernate no consulta los relacionados. Los consulta más tarde, la primera vez que se usan. Es el valor por defecto de `@OneToMany`.

La carga diferida evita leer datos que quizá nunca se necesiten: leer un socio no debería traer también todas sus inscripciones si la página solo muestra su nombre. Pero tiene un precio: para consultar los datos "más tarde" hace falta que la **sesión** de Hibernate (la conexión de trabajo con la base de datos, en la que Hibernate recuerda los objetos que ha leído) siga abierta. Y con `spring.jpa.open-in-view=false`, la opción que desactivamos en S06-1, la sesión se cierra en cuanto el repositorio devuelve su resultado, antes de que la plantilla empiece a pintar la página.

### La entidad Socio con la lista de inscripciones

Completamos `Socio` con el lado inverso de la relación con `Inscripcion`. Es una lista `@OneToMany(mappedBy = "socio")`, igual que la de `Monitor`: el lado propietario es el campo `socio` de `Inscripcion`. Esta lista es de carga diferida (el valor por defecto de `@OneToMany`), y lleva además `cascade = CascadeType.ALL`, que usamos al final de la demo. Añadimos también un constructor con datos, para crear socios nuevos en el código.

```java
package com.curso.model;

// Anotaciones de JPA. CascadeType se usa en la Demo 3.
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * S08-1 Demo 2 y Demo 3: Socio y sus inscripciones
 *
 * Objetivo: mapear la tabla socio y, en la Demo 3, la lista de sus inscripciones
 * para estudiar la carga diferida y el comportamiento de cascade.
 *
 * Lo que hace este ejemplo:
 *   - Demo 2: mapea los campos de la tabla socio
 *   - Demo 3: añade la lista inscripciones (lado inverso) con carga diferida
 *     y cascade = ALL
 *
 * Concepto clave: una colección @OneToMany se carga de forma diferida por defecto
 * (LAZY): Hibernate no consulta las inscripciones hasta que alguien las usa.
 */
@Entity
public class Socio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;
    private String email;
    private LocalDate fechaAlta;

    // Demo 3. Lado inverso: la columna socio_id está en la tabla inscripcion,
    // y el campo socio de Inscripcion es el lado propietario (mappedBy = "socio").
    // Carga diferida (LAZY, el valor por defecto de @OneToMany): al leer un socio,
    // Hibernate NO lee sus inscripciones. Para comparar, se puede escribir
    // fetch = FetchType.EAGER dentro de la anotación.
    // cascade = CascadeType.ALL: las operaciones que se hacen sobre el socio
    // (guardar, borrar...) se propagan a las inscripciones de su lista.
    @OneToMany(mappedBy = "socio", cascade = CascadeType.ALL)
    private List<Inscripcion> inscripciones = new ArrayList<>();

    public Socio() {
    }

    // Constructor para crear socios nuevos en el código (Demo 3, experimento de cascade).
    public Socio(String nombre, String email, LocalDate fechaAlta) {
        this.nombre = nombre;
        this.email = email;
        this.fechaAlta = fechaAlta;
    }

    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEmail() {
        return email;
    }

    public LocalDate getFechaAlta() {
        return fechaAlta;
    }

    public List<Inscripcion> getInscripciones() {
        return inscripciones;
    }

    // toString() sin la lista de inscripciones: no queremos cargarla al imprimir un socio.
    @Override
    public String toString() {
        return "Socio{id=" + id + ", nombre='" + nombre + "', email='" + email + "'}";
    }
}
```

### Provocar el error

Creamos `SocioController` con dos páginas que muestran la misma plantilla. `/socios/{id}/diferida` lee el socio con `findById()`, que no trae sus inscripciones. `/socios/{id}` lo leerá con un método que sí las trae, y es la que funciona. Empezamos por la primera.

```java
package com.curso.controller;

import com.curso.model.Socio;
import com.curso.repository.SocioRepository;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

/**
 * S08-1 Demo 3: Controlador de la página de un socio
 *
 * Objetivo: provocar la LazyInitializationException con una página real y resolverla.
 *
 * Lo que hace este ejemplo:
 *   - GET /socios/{id}/diferida lee el socio con findById(): la página falla
 *   - GET /socios/{id} lo lee con findConInscripcionesById(): la página funciona
 *
 * Concepto clave: con spring.jpa.open-in-view=false la sesión con la base de datos
 * se cierra al terminar el repositorio. Si la plantilla toca una colección que
 * no se cargó, ya no hay sesión para pedírsela a la base de datos.
 */
@Controller
public class SocioController {

    private final SocioRepository socioRepository;

    public SocioController(SocioRepository socioRepository) {
        this.socioRepository = socioRepository;
    }

    // Versión que falla. findById() lee el socio, pero sus inscripciones son diferidas:
    // Hibernate deja en su lugar un marcador vacío. Cuando la plantilla recorre
    // socio.inscripciones, ese marcador intenta consultar la base de datos y,
    // como la sesión ya está cerrada, lanza LazyInitializationException.
    @GetMapping("/socios/{id}/diferida")
    public String diferida(@PathVariable Long id, Model model) {
        Socio socio = socioRepository.findById(id).orElseThrow();
        model.addAttribute("socio", socio);
        return "socio";
    }

    // Versión que funciona. Aquí el controlador decide qué datos va a necesitar la
    // página (el socio y sus inscripciones) y los pide juntos, mientras la sesión
    // sigue abierta dentro del repositorio.
    @GetMapping("/socios/{id}")
    public String detalle(@PathVariable Long id, Model model) {
        Socio socio = socioRepository.findConInscripcionesById(id).orElseThrow();
        model.addAttribute("socio", socio);
        return "socio";
    }
}
```

La plantilla `socio.html` muestra el nombre del socio y recorre `socio.inscripciones` con `th:each`, mostrando de cada inscripción el nombre y el día de su clase.

```html
<!DOCTYPE html>
<html lang="es" xmlns:th="http://www.thymeleaf.org">
<head>
    <meta charset="UTF-8">
    <title>Ficha de socio</title>
</head>
<body>
<!--/*
    S08-1 Demo 3: ficha de un socio con las clases a las que está apuntado.
    ${socio.inscripciones} es una colección diferida (LAZY): al recorrerla con
    th:each, Hibernate necesita la base de datos. Si el controlador no la cargó
    antes, esta línea es la que lanza LazyInitializationException.
*/-->
<h1 th:text="${socio.nombre}">Ana Torres</h1>
<p th:text="${socio.email}">ana.torres@correo.test</p>

<h2>Clases a las que está apuntado</h2>
<table border="1" cellpadding="6">
    <thead>
    <tr>
        <th>Clase</th>
        <th>Día</th>
        <th>Fecha de inscripción</th>
    </tr>
    </thead>
    <tbody>
    <tr th:each="inscripcion : ${socio.inscripciones}">
        <td th:text="${inscripcion.clase.nombre}">Spinning</td>
        <td th:text="${inscripcion.clase.diaSemana}">MIERCOLES</td>
        <td th:text="${inscripcion.fechaInscripcion}">2026-09-01</td>
    </tr>
    </tbody>
</table>

<p><a th:href="@{/clases}">Volver a las clases</a></p>
</body>
</html>
```

Para que la aplicación compile, el controlador necesita `SocioRepository`. Lo creamos en el paquete `repository` con la forma que tendrá al final de la demo (la explicamos en la sección siguiente):

```java
package com.curso.repository;

import com.curso.model.Socio;

// EntityGraph viene de Spring Data JPA (spring-boot-starter-data-jpa).
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

/**
 * S08-1 Demo 3: Repositorio de Socio con carga de las inscripciones
 *
 * Objetivo: leer un socio junto con sus inscripciones para que la página pueda
 * mostrarlas sin LazyInitializationException.
 *
 * Lo que hace este ejemplo:
 *   - Hereda findById(), que carga el socio sin sus inscripciones (carga diferida)
 *   - Añade findConInscripcionesById(), que las trae en la misma consulta
 *
 * Ejemplo:
 *   findById(1L)                    →  Ana Torres, con inscripciones sin cargar
 *   findConInscripcionesById(1L)    →  Ana Torres, con sus 2 inscripciones cargadas
 *
 * Concepto clave: la carga diferida se resuelve decidiendo, en el momento de
 * preparar la respuesta, qué datos relacionados se van a necesitar.
 */
public interface SocioRepository extends JpaRepository<Socio, Long> {

    // @EntityGraph le dice a Hibernate qué relaciones cargar junto con la entidad.
    // Un grafo de carga funciona como una lista cerrada: lo que se nombra se carga
    // en la misma consulta y lo que no se nombra queda diferido, aunque el mapeo
    // diga EAGER. Por eso hay que nombrar dos rutas:
    //   - "inscripciones": la lista de inscripciones del socio
    //   - "inscripciones.clase": la clase de cada inscripción, porque la página
    //     muestra su nombre. Sin esta ruta, la página falla con otra
    //     LazyInitializationException ("Could not initialize proxy [Clase#2]").
    // El nombre del método sigue el patrón de Spring Data: find + un texto libre
    // (ConInscripciones) + By + el campo por el que se busca (Id).
    @EntityGraph(attributePaths = {"inscripciones", "inscripciones.clase"})
    Optional<Socio> findConInscripcionesById(Long id);
}
```

Reiniciamos. Con los cuatro repositorios ya creados, Spring Data informa de ello en el arranque:

<pre>
Finished Spring Data repository scanning in 52 ms. Found 4 JPA repository interfaces.
</pre>

Abrimos `http://localhost:8080/socios/1/diferida`. El navegador muestra la página de error de Spring Boot (**Whitelabel Error Page**) con el código 500, que significa "error interno del servidor". La causa está en la consola de IntelliJ:

<pre>
org.thymeleaf.TemplateEngine : [THYMELEAF][http-nio-8080-exec-5] Exception processing template "socio": Cannot lazily initialize collection of role 'com.curso.model.Socio.inscripciones' with key '1' (no session)
...
org.hibernate.LazyInitializationException: Cannot lazily initialize collection of role 'com.curso.model.Socio.inscripciones' with key '1' (no session)
</pre>

Este es el error más conocido de Hibernate. Se lee así: "no puedo inicializar de forma diferida la colección `inscripciones` del socio 1, porque no hay sesión". Lo que ha pasado, paso a paso:

1. `findById(1)` lee el socio. Sus inscripciones son diferidas, así que Hibernate no las lee: deja en su lugar un marcador vacío (en lenguaje de Hibernate, un *proxy* o una colección diferida) que sabe cómo ir a buscarlas cuando alguien las pida.
2. El repositorio termina y la sesión se cierra (`open-in-view=false`).
3. La plantilla recorre `socio.inscripciones`. El marcador intenta consultar la base de datos y se encuentra con que ya no hay sesión: lanza `LazyInitializationException`.

El error no está en el mapeo, que es correcto, ni en la base de datos. Está en que se accede a un dato relacionado fuera del momento en que se podía leer.

### Resolver el error con `@EntityGraph`

La solución es decidir, al preparar la respuesta, qué datos relacionados va a necesitar la página, y pedirlos a la vez que el socio, mientras la sesión sigue abierta dentro del repositorio. En Spring Data JPA se hace con `@EntityGraph`, un **grafo de carga** que dice qué relaciones leer junto con la entidad. Es el método `findConInscripcionesById` de `SocioRepository` (el fichero que acabamos de ver). Su nombre sigue el patrón de los métodos derivados: `find`, un texto libre (`ConInscripciones`), `By` y el campo por el que se busca (`Id`).

Un grafo de carga funciona como una lista cerrada: lo que se nombra se carga en la misma consulta, y lo que no se nombra queda diferido, aunque el mapeo diga `EAGER`. Por eso nombramos dos rutas. Si solo nombramos `"inscripciones"`, el socio y sus inscripciones se cargan bien, pero la página sigue necesitando la clase de cada inscripción (`inscripcion.clase.nombre`), que no está en el grafo, y falla con otra `LazyInitializationException`, esta vez sobre la clase:

<pre>
Exception processing template "socio": Exception evaluating SpringEL expression: "inscripcion.clase.nombre" (template: "socio" - line 23, col 13)
Caused by: org.hibernate.LazyInitializationException: Could not initialize proxy [com.curso.model.Clase#2] - no session
</pre>

Se arregla nombrando también `"inscripciones.clase"`, que es lo que ya hace el repositorio del zip. Reiniciamos y abrimos `http://localhost:8080/socios/1`. La página funciona:

Ana Torres (ana.torres@correo.test). Clases a las que está apuntada:

| Clase | Día | Fecha de inscripción |
|---|---|---|
| Yoga matutino | LUNES | 2026-09-03 |
| Spinning | MIERCOLES | 2026-09-01 |

Y la consola muestra una sola consulta, con dos `left join`: uno hacia `inscripcion` y otro hacia `clase`:

<pre>
Hibernate: select s1_0.id,s1_0.email,s1_0.fecha_alta,i1_0.socio_id,i1_0.id,c1_0.id,c1_0.aforo,c1_0.dia_semana,c1_0.duracion_min,c1_0.hora,c1_0.monitor_id,c1_0.nombre,c1_0.plazas_libres,i1_0.fecha_inscripcion,s1_0.nombre from socio s1_0 left join inscripcion i1_0 on s1_0.id=i1_0.socio_id left join clase c1_0 on c1_0.id=i1_0.clase_id where s1_0.id=?
</pre>

El controlador `/socios/{id}` es el que decide: pide `findConInscripcionesById` porque su página necesita las inscripciones, mientras que otra página que solo mostrara el nombre del socio podría seguir usando `findById` y no pagaría esa lectura de más.

### Comparar con la carga inmediata

Podríamos haber evitado el error por otra vía: hacer la lista `EAGER`. Para comprobar qué cambia, escribimos temporalmente `fetch = FetchType.EAGER` dentro de la anotación de `Socio` (y el `import jakarta.persistence.FetchType;`):

```java
    @OneToMany(mappedBy = "socio", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<Inscripcion> inscripciones = new ArrayList<>();
```

Reiniciamos y abrimos de nuevo `http://localhost:8080/socios/1/diferida`. Esta vez la página funciona, sin ningún cambio en el controlador, y la consola muestra una consulta con tres `left join` (inscripciones, clases y monitores):

<pre>
Hibernate: select s1_0.id,s1_0.email,s1_0.fecha_alta,s1_0.nombre,i1_0.socio_id,i1_0.id,c1_0.id,c1_0.aforo,c1_0.dia_semana,c1_0.duracion_min,c1_0.hora,m1_0.id,m1_0.email,m1_0.especialidad,m1_0.fecha_alta,m1_0.nombre,c1_0.nombre,c1_0.plazas_libres,i1_0.fecha_inscripcion from socio s1_0 left join inscripcion i1_0 on s1_0.id=i1_0.socio_id left join clase c1_0 on c1_0.id=i1_0.clase_id left join monitor m1_0 on m1_0.id=c1_0.monitor_id where s1_0.id=?
</pre>

Resumen de las tres variantes con el socio 1:

| Variante | Consultas | Resultado en la página |
|---|---|---|
| Lista `LAZY` y `findById` | 1 (solo el socio) | `LazyInitializationException` |
| Lista `LAZY` y `@EntityGraph` | 1, con 2 `left join` | Funciona |
| Lista `EAGER` y `findById` | 1, con 3 `left join` | Funciona |

La carga inmediata "arregla" el error, pero lo hace siempre: cualquier lugar de la aplicación que lea un socio, aunque solo quiera su nombre, leerá también sus inscripciones, las clases de cada una y los monitores de cada clase. Con la carga diferida y un grafo, el coste se paga solo en la página que necesita los datos. El criterio es: **cargar lo que se va a usar, en el momento en que se prepara la respuesta**. Quitamos el `fetch = FetchType.EAGER` y el `import` para dejar `Socio` como en el zip.

### El coste de las consultas: una más por cada objeto relacionado

La Demo 1 nos dejó una cuenta pendiente: la página `/clases` ejecutaba una consulta para las clases y otra por cada monitor distinto. Con tres monitores son cuatro consultas, y con trescientos serían trescientas una. Es el problema conocido como **N+1**: una consulta para la lista y N más, una por cada elemento relacionado. Nace de la misma decisión que acabamos de ver, la carga inmediata de un `@ManyToOne`, y se detecta igual que aquí: contando las líneas `Hibernate:` en la consola. En las páginas de esta parte el coste es pequeño porque hay pocos datos; lo importante es saber leerlo. En S08-2, con las consultas propias, se verá cómo elegir qué se carga en cada una.

### `cascade`: propagar guardar y borrar

La última propiedad de una relación que estudiamos es `cascade`. Por defecto, cada objeto se guarda por separado: si creamos un socio con dos inscripciones nuevas en su lista y guardamos solo el socio, las inscripciones no se guardan. Con `cascade = CascadeType.ALL`, las operaciones que se hacen sobre el socio (guardar, borrar y otras) se propagan a los objetos de su lista.

`ExperimentoCascade` lo comprueba. Crea un socio nuevo con dos inscripciones en su lista (cada `Inscripcion` lleva el socio, que es el lado propietario, y además la añadimos a la lista del socio para que `cascade` la vea), guarda **solo el socio** y cuenta las filas de la tabla `inscripcion`; después borra solo el socio y vuelve a contar. Como el experimento anterior, trae `// @Component` y el `import` comentados: para ejecutarlo quitamos las dos barras de ambas líneas. Se puede ejecutar varias veces, porque deja la tabla como estaba.

```java
package com.curso.config;

import com.curso.model.Clase;
import com.curso.model.Inscripcion;
import com.curso.model.Socio;
import com.curso.repository.ClaseRepository;
import com.curso.repository.InscripcionRepository;
import com.curso.repository.SocioRepository;

import org.springframework.boot.CommandLineRunner;
// import org.springframework.stereotype.Component;

import java.time.LocalDate;

/**
 * S08-1 Demo 3: Experimento de cascade
 *
 * Objetivo: ver qué hace cascade = CascadeType.ALL al guardar y al borrar un socio.
 *
 * Lo que hace este ejemplo:
 *   - Crea un socio nuevo con dos inscripciones en su lista
 *   - Guarda solo el socio y cuenta las inscripciones de la tabla
 *   - Borra el socio y cuenta de nuevo
 *
 * Concepto clave: con cascade = ALL, guardar o borrar el socio guarda o borra
 * también las inscripciones de su lista, sin llamar a InscripcionRepository.
 * Sin cascade, esas inscripciones no se guardarían.
 *
 * Para ejecutarlo hay que quitar las dos barras de la línea @Component (y la del
 * import). Vuelve a dejar la tabla como estaba: se puede ejecutar varias veces.
 */
// @Component
public class ExperimentoCascade implements CommandLineRunner {

    private final SocioRepository socioRepository;
    private final ClaseRepository claseRepository;
    private final InscripcionRepository inscripcionRepository;

    public ExperimentoCascade(SocioRepository socioRepository, ClaseRepository claseRepository,
                              InscripcionRepository inscripcionRepository) {
        this.socioRepository = socioRepository;
        this.claseRepository = claseRepository;
        this.inscripcionRepository = inscripcionRepository;
    }

    @Override
    public void run(String... args) {
        // Estado inicial: las 8 inscripciones que carga el script SQL.
        System.out.println("Inscripciones antes: " + inscripcionRepository.count());  // → 8

        // Dos clases que existen ya en la base de datos: Yoga vespertino (4) y Zumba (5).
        Clase yoga = claseRepository.findById(4L).orElseThrow();
        Clase zumba = claseRepository.findById(5L).orElseThrow();

        // Socio nuevo, todavía sin guardar, con dos inscripciones nuevas en su lista.
        // Cada Inscripcion lleva el socio (lado propietario, el que escribe socio_id)
        // y además la añadimos a la lista del socio para que cascade las vea.
        Socio socio = new Socio("Prueba Cascade", "cascade@correo.test", LocalDate.now());
        socio.getInscripciones().add(new Inscripcion(socio, yoga));
        socio.getInscripciones().add(new Inscripcion(socio, zumba));

        // Guardamos SOLO el socio. Con cascade = ALL, Hibernate guarda también
        // sus dos inscripciones (primero el socio, para que exista su id).
        socioRepository.save(socio);
        System.out.println("Inscripciones tras guardar el socio: " + inscripcionRepository.count());  // → 10

        // Borramos SOLO el socio: cascade borra antes sus inscripciones
        // (si no, la clave foránea impediría borrar el socio).
        socioRepository.deleteById(socio.getId());
        System.out.println("Inscripciones tras borrar el socio: " + inscripcionRepository.count());  // → 8
    }
}
```

En las salidas siguientes omitimos las dos consultas del principio que leen las clases 4 y 5, que son iguales con y sin `cascade`.

Primero lo ejecutamos **sin** `cascade`: quitamos `cascade = CascadeType.ALL` de la anotación de `Socio`, dejando `@OneToMany(mappedBy = "socio")`. En la consola de IntelliJ:

<pre>
Hibernate: select count(*) from inscripcion i1_0
Inscripciones antes: 8
Hibernate: insert into socio (email,fecha_alta,nombre) values (?,?,?)
Hibernate: select count(*) from inscripcion i1_0
Inscripciones tras guardar el socio: 8
Hibernate: select s1_0.id,s1_0.email,s1_0.fecha_alta,s1_0.nombre from socio s1_0 where s1_0.id=?
Hibernate: delete from socio where id=?
Hibernate: select count(*) from inscripcion i1_0
Inscripciones tras borrar el socio: 8
</pre>

Solo se guarda el socio: las dos inscripciones se pierden, porque nadie las ha guardado. Ahora volvemos a poner `cascade = CascadeType.ALL`, como está en el zip, y repetimos:

<pre>
Hibernate: select count(*) from inscripcion i1_0
Inscripciones antes: 8
Hibernate: insert into socio (email,fecha_alta,nombre) values (?,?,?)
Hibernate: insert into inscripcion (clase_id,fecha_inscripcion,socio_id) values (?,?,?)
Hibernate: insert into inscripcion (clase_id,fecha_inscripcion,socio_id) values (?,?,?)
Hibernate: select count(*) from inscripcion i1_0
Inscripciones tras guardar el socio: 10
Hibernate: select s1_0.id,s1_0.email,s1_0.fecha_alta,s1_0.nombre from socio s1_0 where s1_0.id=?
Hibernate: select i1_0.socio_id,i1_0.id,c1_0.id,c1_0.aforo,c1_0.dia_semana,c1_0.duracion_min,c1_0.hora,m1_0.id,m1_0.email,m1_0.especialidad,m1_0.fecha_alta,m1_0.nombre,c1_0.nombre,c1_0.plazas_libres,i1_0.fecha_inscripcion from inscripcion i1_0 left join clase c1_0 on c1_0.id=i1_0.clase_id left join monitor m1_0 on m1_0.id=c1_0.monitor_id where i1_0.socio_id=?
Hibernate: delete from inscripcion where id=?
Hibernate: delete from inscripcion where id=?
Hibernate: delete from socio where id=?
Hibernate: select count(*) from inscripcion i1_0
Inscripciones tras borrar el socio: 8
</pre>

Con `cascade`, guardar el socio guarda también sus dos inscripciones (`insert into socio` y después dos `insert into inscripcion`, en ese orden, para que el socio ya tenga su `id`). Al borrar, Hibernate lee primero las inscripciones del socio y las borra una a una antes de borrar el socio; si no lo hiciera, la clave foránea `socio_id` impediría borrarlo. Nadie ha llamado a `InscripcionRepository`.

Comprobamos en pgAdmin que el experimento no ha dejado datos de prueba:

```sql
select count(*) from inscripcion;
```

Salida esperada:

<pre>
count
-----
    8
</pre>

Una advertencia sobre cuándo usar `cascade`: `CascadeType.ALL` es cómodo cuando los objetos de la lista no tienen sentido sin su padre, como las inscripciones de un socio. No es adecuado para cualquier relación: si se pusiera en `Inscripcion.clase`, borrar una inscripción intentaría borrar la clase, con todas las demás inscripciones que dependen de ella. Se declara solo donde el padre "es dueño" de sus hijos. Dejamos los dos experimentos otra vez con las líneas comentadas.
