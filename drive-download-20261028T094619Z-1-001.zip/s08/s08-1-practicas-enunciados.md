# S08-1 Prácticas

## Objetivos

En las demos hemos expresado en Java las claves foráneas del gimnasio: `@ManyToOne` y `@OneToMany` para clases y monitores, una entidad intermedia para socios e inscripciones, y la carga diferida con su `LazyInitializationException`. En estas prácticas aplicamos lo mismo a la base de datos `cartelera` que cada persona creó en S07-1: una película tiene un director, una sesión une una película con una sala y una entrada pertenece a una sesión. Después adaptamos el mapeo a una tabla cuyos nombres no coinciden con los de las clases, y por último cada grupo lleva estas técnicas al esquema de su proyecto.

Las cuatro prácticas son:

- **Práctica 1:** `Director` y `Pelicula`, con la relación `@ManyToOne` y su inversa.
- **Práctica 2:** `Sala`, `Sesion` y `Entrada`: una entidad con dos relaciones y una página que las recorre.
- **Práctica 3:** una tabla con nombres propios, mapeada con `@Table` y `@Column`.
- **Práctica 4:** entidades y relaciones del proyecto en grupo.

### Antes de empezar

- El servidor de PostgreSQL está en marcha y la base de datos `cartelera` de S07-1 existe, con sus cinco tablas (`director`, `pelicula`, `sala`, `sesion` y `entrada`) y sus filas de ejemplo: tres directores, cinco películas, dos salas, cuatro sesiones y tres entradas. Se comprueba en pgAdmin con la `Query Tool` de la base de datos `cartelera`:

```sql
select count(*) from sesion;
```

Salida esperada:

<pre>
count
-----
    4
</pre>

- La contraseña de PostgreSQL no aparece en ningún fichero del proyecto: va en la variable de entorno `POSTGRES_PASSWORD`, definida en IntelliJ. Las prácticas que crean un proyecto nuevo (la 1 y la 4) piden definirla otra vez, porque la variable es propia de cada proyecto y no viaja con el código. Las cuatro salvedades de esa variable están explicadas en `s07-1-demos.md`.
- El comportamiento de las relaciones, el lado propietario y la carga diferida se explican en `s08-1-demos.md`.

---

## Práctica 1: Relación Película y Director

La tabla `pelicula` tiene una clave foránea, `director_id`, hacia la tabla `director`. En S07-1 la entidad `Pelicula` dejó esa columna sin mapear. Ahora se completa: se crea la entidad `Director`, se declara en `Pelicula` la relación con su director y en `Director` la lista de sus películas, y se muestra en una página la lista de películas con el nombre de su director.

El proyecto es nuevo, `s08-1-practicas`, y servirá para las prácticas 1 a 3.

**Pasos**

1. Creamos el proyecto con el generador de Spring Boot. Vamos a `File > New > Project` y, en el panel izquierdo, dentro de `Generators`, seleccionamos `Spring Boot`. Rellenamos: **Name** `s08-1-practicas`; **Create Git repository** desmarcada; **Language** `Java`; **Type** `Maven`; **Group** `com.curso`; **Artifact** `s08-1-practicas`; **Package name** `com.curso` (se escribe el último, porque se recalcula al cambiar otros campos); **JDK** `21`; **Java** `21`; **Packaging** `Jar`; **Configuration** `Properties`. Hacemos clic en `Next`, elegimos **Spring Boot** `4.1.1` y añadimos las dependencias `Spring Data JPA` y `PostgreSQL Driver`. Hacemos clic en `Create`.
2. Añadimos a mano al `pom.xml`, dentro de `<dependencies>`, los dos starters de la parte web, y hacemos clic en **Load Maven Changes**:

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-webmvc</artifactId>
</dependency>
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-thymeleaf</artifactId>
</dependency>
```

3. Renombramos la clase principal a `Aplicacion` (clic derecho, `Refactor > Rename` o `Shift+F6`, y aceptamos renombrar también la clase de test) y creamos los paquetes `com.curso.model`, `com.curso.repository`, `com.curso.controller` y `com.curso.config` (clic derecho sobre `src/main/java`, `New > Package`).
4. Dejamos `application.properties` con la conexión a la base de datos `cartelera`, sin escribir la contraseña:

```properties
spring.application.name=s08-1-practicas
spring.datasource.url=jdbc:postgresql://localhost:5432/cartelera
spring.datasource.username=postgres
spring.datasource.password=${POSTGRES_PASSWORD}
spring.jpa.hibernate.ddl-auto=none
spring.jpa.show-sql=true
spring.jpa.open-in-view=false
```

5. **Variable de entorno en este proyecto nuevo.** Pulsamos ▶ junto al `main()` de `Aplicacion` para que IntelliJ cree su configuración de ejecución (el primer arranque falla por la contraseña, y es lo esperado). Vamos a `Run > Edit Configurations...`, seleccionamos `Aplicacion`, y en `Modify options` activamos `Environment variables`. Escribimos `POSTGRES_PASSWORD=` seguido de la contraseña de PostgreSQL, sin espacios ni comillas, y pulsamos `OK`.
6. La entidad `Pelicula` y su repositorio ya existen de S07-1. Los copiamos tal cual desde el proyecto de S07-1 al paquete `model` y al paquete `repository` del proyecto nuevo.
7. Creamos la entidad `Director` en el paquete `model`, con los campos de la tabla `director` (`id`, `nombre`, `nacionalidad` y `anioNacimiento`), y su repositorio.
8. Completamos `Pelicula` con la relación hacia su director y añadimos a `Director` la lista de sus películas. En `Pelicula`, el constructor con datos recibe también el director.
9. Creamos `PeliculaController` con un método para `GET /peliculas` que deja las películas en el modelo, y la plantilla `peliculas.html` en `src/main/resources/templates` con una tabla de cuatro columnas: título, año, género y nombre del director.
10. Arrancamos la aplicación y abrimos `http://localhost:8080/peliculas`. La página debe mostrar:

| Título | Año | Género | Director |
|---|---|---|---|
| Todo sobre mi madre | 1999 | Drama | Pedro Almodóvar |
| Volver | 2006 | Drama | Pedro Almodóvar |
| El laberinto del fauno | 2006 | Fantasía | Guillermo del Toro |
| Los otros | 2001 | Terror | Alejandro Amenábar |
| Mar adentro | 2004 | Drama | Alejandro Amenábar |

11. Contamos las líneas que empiezan por `Hibernate:` que aparecen en la consola al abrir la página. Deben ser cuatro: una consulta para las películas y una más por cada director distinto.
12. Comprobamos el test generado (`AplicacionTests`, `contextLoads()`): hay que definir la variable `POSTGRES_PASSWORD` también en su propia configuración JUnit (`Run > Edit Configurations...`, configuración de `AplicacionTests`) para que pase.

**Pistas**

- En `Pelicula`, el campo `director` es de tipo `Director`, no `Long`, y lleva `@ManyToOne` y `@JoinColumn(name = "director_id")`. Es el lado propietario: la columna está en su tabla.
- En `Director`, la lista de películas lleva `@OneToMany(mappedBy = "director")`. El valor de `mappedBy` es el nombre del campo de `Pelicula` que tiene el `@ManyToOne`, escrito exactamente igual.
- Inicializar la lista con `new ArrayList<>()` evita que valga `null`.
- Los nombres compuestos siguen las reglas de S07-1: `anioNacimiento` se corresponde con `anio_nacimiento` y `duracionMin` con `duracion_min`, sin ninguna anotación.
- Ni el `toString()` de `Director` ni el de `Pelicula` deben incluir la lista de películas ni el director: imprimirlos cargaría datos de más y, entre las dos clases, daría un bucle infinito.
- Si la página falla, el mensaje de la consola suele nombrar la columna o la tabla que no encuentra: comparamos con el script SQL de S07-1.

---

## Práctica 2: Sesiones con dos relaciones

La tabla `sesion` tiene dos claves foráneas: `pelicula_id`, hacia la película que se proyecta, y `sala_id`, hacia la sala. La tabla `entrada` tiene una, `sesion_id`. Se crean las entidades `Sala`, `Sesion` y `Entrada`, se muestra en una página cada sesión con el título de su película y el nombre de su sala, y se lista por consola cada entrada con la película y la sala a las que da acceso.

La práctica continúa en el proyecto `s08-1-practicas`. La variable de entorno ya está definida en su configuración de `Aplicacion`, así que no hay que repetirla.

**Pasos**

1. Creamos la entidad `Sala` con los campos de la tabla `sala` (`id`, `nombre` y `aforo`) y su repositorio.
2. Creamos la entidad `Sesion` con los campos de la tabla `sesion`: dos relaciones `@ManyToOne` (hacia `Pelicula` y hacia `Sala`), la fecha y hora, el precio y las plazas libres. Creamos su repositorio. Los tipos nuevos son `timestamp` y `numeric(6,2)`: el primero se corresponde con `LocalDateTime` y el segundo con `BigDecimal`.
3. Creamos la entidad `Entrada` con los campos de la tabla `entrada`: una relación `@ManyToOne` hacia `Sesion`, el nombre del cliente y la fecha de compra (`timestamp`). Creamos su repositorio.
4. Creamos `SesionController` con un método para `GET /sesiones` y la plantilla `sesiones.html` con una tabla de cinco columnas: película, sala, fecha y hora, precio y plazas libres.
5. Creamos en el paquete `config` un `CommandLineRunner` llamado `ListadoEntradas`, con `@Component` y `@Order(1)`, que escribe por consola la línea `=== Entradas vendidas ===` y después, por cada entrada, el cliente, el título de la película, el nombre de la sala y la fecha y hora de la sesión, separados por ` | `.
6. Reiniciamos. Además de las líneas `Hibernate:`, la consola debe mostrar:

<pre>
=== Entradas vendidas ===
Marta Pérez | Todo sobre mi madre | Sala 1 | 2026-11-06T18:00
Jorge Lara | Todo sobre mi madre | Sala 1 | 2026-11-06T18:00
Irene Campos | El laberinto del fauno | Sala 2 | 2026-11-06T20:30
</pre>

7. Abrimos `http://localhost:8080/sesiones`. La página debe mostrar:

| Película | Sala | Fecha y hora | Precio | Plazas libres |
|---|---|---|---|---|
| Todo sobre mi madre | Sala 1 | 2026-11-06T18:00 | 8.50 | 78 |
| El laberinto del fauno | Sala 2 | 2026-11-06T20:30 | 9.00 | 49 |
| Los otros | Sala 1 | 2026-11-07T22:00 | 9.00 | 80 |
| Mar adentro | Sala 2 | 2026-11-08T17:00 | 7.50 | 50 |

8. Contamos las líneas `Hibernate:` que genera la apertura de la página `/sesiones` (hay que limpiar la consola antes, para no contar las del arranque). Anotamos el número y respondemos: ¿por qué son más que en la Práctica 1?

**Pistas**

- `Sesion` es el lado propietario de sus dos relaciones: cada una lleva `@ManyToOne` y su propio `@JoinColumn` (`pelicula_id` y `sala_id`).
- `fechaHora` se corresponde con la columna `fecha_hora`, y `plazasLibres` con `plazas_libres`.
- Para el precio hay que usar `BigDecimal`, no `double`: la columna `numeric(6,2)` es un decimal exacto.
- `Sala` y `Entrada` no necesitan lista de sus sesiones ni de sus entradas: el lado inverso se declara solo cuando alguna página lo necesita.
- Desde una entrada se llega a la película con tres llamadas encadenadas: entrada, sesión, película. `@Order` fija el orden de ejecución de varios `CommandLineRunner`, de menor a mayor número.
- En la plantilla, las relaciones se navegan igual que en la Práctica 1: `${sesion.pelicula.titulo}` y `${sesion.sala.nombre}`.

---

## Práctica 3: Nombres personalizados con `@Table` y `@Column`

Hasta ahora, los nombres de las tablas y de las columnas coincidían con los de las clases y los campos (con la traducción de `camelCase` a `snake_case`). En las bases de datos reales no siempre ocurre: hay prefijos, abreviaturas y nombres heredados. JPA permite adaptar el mapeo sin renombrar nada en la base de datos ni en el código, con `@Table` para el nombre de la tabla y `@Column` para el de cada columna.

La cartelera recibe una tabla nueva, `tbl_critica`, con las críticas de los espectadores. Sus nombres no siguen la convención. Se mapea con una entidad `Critica` cuyos nombres Java sean claros, y se listan por consola las críticas con la película a la que se refieren.

**Pasos**

1. Ejecutamos el script de la tabla nueva en pgAdmin: clic derecho sobre la base de datos `cartelera`, `Query Tool`, pegamos el script, seleccionamos todo y pulsamos ▶. El mismo script viene en la carpeta `sql` del zip de las prácticas, con el nombre `02-crear-critica.sql`:

```sql
-- S08-1 Práctica 3: tabla de críticas de la cartelera.
-- Se ejecuta en la Query Tool de pgAdmin, conectado a la base de datos cartelera.
-- Los nombres de la tabla y de las columnas NO coinciden con los de la clase
-- y los campos Java: es lo que se practica con @Table y @Column.

drop table if exists tbl_critica;

create table tbl_critica (
    cod_critica  bigint generated by default as identity primary key,
    cod_pelicula bigint       not null,
    nombre_autor varchar(60)  not null,
    puntuacion   integer      not null check (puntuacion between 1 and 10),
    comentario   varchar(300) not null,
    fecha_critica date        not null default current_date,
    constraint fk_critica_pelicula foreign key (cod_pelicula) references pelicula (id)
);

insert into tbl_critica (cod_pelicula, nombre_autor, puntuacion, comentario, fecha_critica) values
    (1, 'Clara Montes', 9, 'Emocionante y muy bien interpretada.', '2026-10-01'),
    (3, 'Rafael Ortega', 10, 'Una fantasía oscura y preciosa.', '2026-10-03'),
    (4, 'Inés Duarte', 8, 'Tensión constante hasta el final.', '2026-10-04');

select * from tbl_critica order by cod_critica;
```

Salida esperada, de la última sentencia (`select`):

<pre>
cod_critica | cod_pelicula | nombre_autor  | puntuacion | comentario                           | fecha_critica
------------+--------------+---------------+------------+--------------------------------------+--------------
          1 |            1 | Clara Montes  |          9 | Emocionante y muy bien interpretada. | 2026-10-01
          2 |            3 | Rafael Ortega |         10 | Una fantasía oscura y preciosa.      | 2026-10-03
          3 |            4 | Inés Duarte   |          8 | Tensión constante hasta el final.    | 2026-10-04
</pre>

2. Este script se ejecuta después del de la cartelera de S07-1, porque la tabla nueva tiene una clave foránea hacia `pelicula`. Si más adelante hace falta volver a crear las tablas de la cartelera con el script de S07-1, hay que borrar antes esta tabla (`drop table if exists tbl_critica;`), o PostgreSQL no dejará borrar `pelicula`.
3. Creamos la entidad `Critica` con los siguientes nombres:

| Columna de `tbl_critica` | Campo de `Critica` | Tipo en Java |
|---|---|---|
| `cod_critica` (clave primaria) | `id` | `Long` |
| `cod_pelicula` (clave foránea) | `pelicula` | `Pelicula` |
| `nombre_autor` | `autor` | `String` |
| `puntuacion` | `nota` | `int` |
| `comentario` | `texto` | `String` |
| `fecha_critica` | `fecha` | `LocalDate` |

4. Creamos `CriticaRepository` y, en el paquete `config`, un `CommandLineRunner` llamado `ListadoCriticas`, con `@Component` y `@Order(2)`, que escribe `=== Críticas ===` y, por cada crítica, el título de la película, el autor, la nota (con `/10` detrás) y el texto, separados por ` | `.
5. Arrancamos. Además de las líneas `Hibernate:`, la consola debe mostrar, tras el listado de entradas de la Práctica 2:

<pre>
=== Críticas ===
Todo sobre mi madre | Clara Montes | 9/10 | Emocionante y muy bien interpretada.
El laberinto del fauno | Rafael Ortega | 10/10 | Una fantasía oscura y preciosa.
Los otros | Inés Duarte | 8/10 | Tensión constante hasta el final.
</pre>

6. Comprobamos qué hace cada anotación quitándola un momento. Sin `@Table`, la aplicación no arranca y el error de PostgreSQL nombra la tabla que Hibernate ha buscado por su cuenta:

<pre>
ERROR: relation "critica" does not exist
</pre>

Con `@Table` pero sin el `name` de `@Column` en la clave primaria, el error cambia de objeto:

<pre>
ERROR: column c1_0.id does not exist
</pre>

Volvemos a poner las anotaciones y comprobamos que la aplicación arranca de nuevo.

**Pistas**

- `@Table(name = "tbl_critica")` va junto a `@Entity`, encima de la clase. Sin ella, Hibernate usa el nombre de la clase.
- `@Column(name = "...")` va sobre cada campo cuya columna tiene un nombre distinto al del campo. Los campos que no tienen anotación siguen la regla de siempre.
- La clave primaria lleva `@Id`, `@GeneratedValue` y también `@Column(name = "cod_critica")`.
- La clave foránea lleva `@ManyToOne` y `@JoinColumn(name = "cod_pelicula")`: en lugar de `pelicula_id`, la columna tiene un nombre propio.
- `@Column` admite más atributos: `nullable = false` describe una columna `not null` y `length` su longitud máxima. Con `ddl-auto=none`, Hibernate no crea la tabla, así que esos dos atributos solo documentan cómo es la columna; tendrían efecto si Hibernate generase el esquema.
- La nota es un `int` porque la columna es `integer not null`.

---

## Práctica 4: Entidades y relaciones del proyecto

En S07-1 cada grupo diseñó el esquema de su proyecto y lo creó en una base de datos propia. Ahora ese esquema recibe sus clases Java: cada tabla se mapea a una entidad, cada clave foránea a una relación, y una página muestra los datos de una entidad junto con los de la relacionada.

Es un proyecto nuevo del grupo, con su propio `pom.xml` y su propia variable de entorno.

**Pasos**

1. Un miembro del grupo crea el proyecto con el generador de Spring Boot de IntelliJ, con las mismas opciones de la Práctica 1 (dependencias `Spring Data JPA` y `PostgreSQL Driver`, y los starters `spring-boot-starter-webmvc` y `spring-boot-starter-thymeleaf` añadidos a mano), con el nombre que el grupo haya elegido para su proyecto. La clase principal se renombra a `Aplicacion` y los paquetes por capas cuelgan de `com.curso`.
2. **Variable de entorno en este proyecto nuevo.** La variable `POSTGRES_PASSWORD` hay que definirla otra vez, en la configuración de ejecución de `Aplicacion` y en la de `AplicacionTests` (`Run > Edit Configurations...`). Cada miembro del grupo que abra el proyecto la define en su propio IntelliJ con la contraseña de su PostgreSQL: no viaja con el código ni con el zip.
3. Se configura `application.properties` con la conexión a la base de datos del grupo, sin escribir la contraseña, y con `ddl-auto=none`, `show-sql=true` y `open-in-view=false`.
4. Se mapea cada tabla del esquema a una entidad, con su repositorio. Cada clave foránea se declara como relación en el lado propietario (`@ManyToOne` y `@JoinColumn`), y se añade el lado inverso (`@OneToMany(mappedBy = ...)`) solo en las relaciones en las que alguna página lo vaya a necesitar. Si alguna relación es de muchos a muchos con datos propios, se modela con una entidad intermedia.
5. Se crea una página con un controlador y una plantilla que muestra los datos de una entidad junto con los de la relacionada (por ejemplo, una lista de elementos con el nombre del elemento al que pertenecen).
6. El grupo revisa cada relación y decide, con el log de SQL a la vista, qué datos relacionados necesita cada página y cuáles se pueden dejar diferidos. Anota la decisión de cada relación: carga inmediata o diferida, y por qué.
7. Se comprueba que la aplicación arranca, que la página muestra los datos y que el test `contextLoads()` pasa.

**Pistas**

- El lado propietario de cada relación es siempre la entidad cuya tabla contiene la clave foránea.
- Los nombres de las columnas que no coinciden con los de los campos se adaptan con `@Column(name = ...)`, y los de las tablas con `@Table(name = ...)`.
- Si una página recorre una colección diferida, hay que cargarla en el repositorio antes de entregarla a la plantilla (`@EntityGraph`, como en la Demo 3). Si no, aparece `LazyInitializationException`.
- Imprimir una entidad con `toString()` no debe cargar sus colecciones ni su otro lado de la relación.
- Conviene empezar por una sola relación completa y comprobarla en el navegador antes de mapear todas las demás.
