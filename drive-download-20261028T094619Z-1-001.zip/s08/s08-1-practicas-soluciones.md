# S08-1 Soluciones

Las soluciones de las prácticas 1 a 3 corresponden al proyecto `s08-1-practicas` del zip. La Práctica 4 no tiene solución: depende del esquema de cada grupo.

---

## Práctica 1: Relación Película y Director

El proyecto se crea con el generador de Spring Boot y las dos dependencias que ofrece (`Spring Data JPA` y `PostgreSQL Driver`), y a mano se añaden los starters `spring-boot-starter-webmvc` y `spring-boot-starter-thymeleaf`. El `pom.xml` resultante es el del zip. La clase principal se llama `Aplicacion`, está en `com.curso` y tiene este contenido:

```java
package com.curso;

// Importamos las dos clases de Spring Boot que arrancan la aplicación.
// Vienen con el starter de Spring Boot que Maven ha descargado al leer el pom.xml.
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * S08-1 Práctica 1: Clase principal del proyecto
 *
 * Objetivo: arrancar la aplicación web de la cartelera con Spring Boot.
 *
 * Aplica las técnicas de S06 y S07:
 *   1. @SpringBootApplication en el paquete raíz com.curso
 *   2. SpringApplication.run() para crear el contenedor y arrancar Tomcat
 *
 * Concepto clave: la clase generada por IntelliJ se ha renombrado a Aplicacion
 * y está en com.curso, para que el escaneo alcance model, repository, config
 * y controller (el escaneo solo mira hacia abajo).
 */
@SpringBootApplication
public class Aplicacion {

    // main() crea el contenedor de Spring, escanea los paquetes, crea los beans,
    // lee application.properties y arranca Tomcat. La aplicación no termina
    // hasta pulsar ■ en IntelliJ.
    public static void main(String[] args) {
        SpringApplication.run(Aplicacion.class, args);
    }
}
```

La conexión apunta a la base de datos `cartelera`. La contraseña no está en el fichero: Spring la lee de la variable de entorno `POSTGRES_PASSWORD`, que hay que definir otra vez en la configuración de ejecución de este proyecto nuevo (`Run > Edit Configurations...`), y también en la del test.

```properties
spring.application.name=s08-1-practicas

# Conexión a la base de datos cartelera del PostgreSQL local (creada en S07).
# La contraseña NO se escribe aquí: Spring la lee de la variable de entorno
# POSTGRES_PASSWORD, que se define en la configuración de ejecución de IntelliJ.
spring.datasource.url=jdbc:postgresql://localhost:5432/cartelera
spring.datasource.username=postgres
spring.datasource.password=${POSTGRES_PASSWORD}

# Las tablas ya existen (las crean los scripts SQL): Hibernate no las toca.
spring.jpa.hibernate.ddl-auto=none
# Muestra en la consola cada sentencia SQL que genera Hibernate.
spring.jpa.show-sql=true
# Desactivada desde S06-1: la sesión con la base de datos se cierra al salir del
# controlador, así que las plantillas solo pueden usar datos ya cargados.
spring.jpa.open-in-view=false
```

La entidad `Pelicula` y su repositorio vienen de S07. Se copian al proyecto nuevo; a `Pelicula` se le añade el campo `director`, con su getter y con el parámetro correspondiente en el constructor con datos. Es el lado propietario de la relación: la columna `director_id` está en su tabla.

```java
package com.curso.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

/**
 * S08-1 Práctica 1: Pelicula con su director (@ManyToOne)
 *
 * Objetivo: completar la entidad de S07 con la relación hacia Director.
 *
 * Aplica las técnicas de S08-1:
 *   1. @ManyToOne para la clave foránea pelicula.director_id
 *   2. @JoinColumn(name = "director_id") para nombrar la columna
 *
 * Concepto clave: en S07 esta entidad dejó sin mapear la columna director_id.
 * Ahora esa columna se expresa como un objeto Director. Pelicula es el lado
 * propietario de la relación: la columna está en su tabla.
 */
@Entity
public class Pelicula {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String titulo;

    // Se escribe anio y no año: los nombres de campo y de columna no llevan eñe.
    private int anio;

    private int duracionMin;
    private String genero;

    // Muchas películas tienen un mismo director. Es el lado propietario: escribe
    // la columna director_id. Por defecto se carga de forma inmediata (EAGER).
    @ManyToOne
    @JoinColumn(name = "director_id")
    private Director director;

    public Pelicula() {
    }

    // Constructor con todos los datos salvo el id, que lo genera la base de datos.
    public Pelicula(String titulo, int anio, int duracionMin, String genero, Director director) {
        this.titulo = titulo;
        this.anio = anio;
        this.duracionMin = duracionMin;
        this.genero = genero;
        this.director = director;
    }

    public Long getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public int getAnio() {
        return anio;
    }

    public int getDuracionMin() {
        return duracionMin;
    }

    public String getGenero() {
        return genero;
    }

    public Director getDirector() {
        return director;
    }

    @Override
    public String toString() {
        return "Pelicula{id=" + id + ", titulo='" + titulo + "', anio=" + anio + ", genero='" + genero + "'}";
    }
}
```

`Director` mapea la tabla `director` y declara el lado inverso: la lista de sus películas con `@OneToMany(mappedBy = "director")`. El `toString()` no la incluye.

```java
package com.curso.model;

// Anotaciones de JPA. Vienen con spring-boot-starter-data-jpa.
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

import java.util.ArrayList;
import java.util.List;

/**
 * S08-1 Práctica 1: Director con la lista de sus películas
 *
 * Objetivo: mapear la tabla director y el lado inverso de la relación con Pelicula.
 *
 * Aplica las técnicas de S08-1:
 *   1. @Entity, @Id y @GeneratedValue sobre una tabla existente
 *   2. @OneToMany(mappedBy = "director") como lado inverso de la relación
 *
 * Concepto clave: la lista peliculas no corresponde a ninguna columna de la tabla
 * director. Es el reflejo, visto desde el director, de la clave foránea
 * pelicula.director_id, que escribe el lado propietario (Pelicula.director).
 */
@Entity
public class Director {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;
    private String nacionalidad;

    // anioNacimiento <-> anio_nacimiento: Hibernate traduce camelCase a snake_case.
    private int anioNacimiento;

    // Lado inverso: mappedBy = "director" apunta al campo director de Pelicula,
    // que es el lado propietario (el que tiene la columna director_id).
    // Es de carga diferida: al leer un director no se leen sus películas.
    @OneToMany(mappedBy = "director")
    private List<Pelicula> peliculas = new ArrayList<>();

    public Director() {
    }

    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public int getAnioNacimiento() {
        return anioNacimiento;
    }

    public List<Pelicula> getPeliculas() {
        return peliculas;
    }

    // toString() sin la lista de películas: no queremos cargarla al imprimir un director.
    @Override
    public String toString() {
        return "Director{id=" + id + ", nombre='" + nombre + "', nacionalidad='" + nacionalidad + "'}";
    }
}
```

Los repositorios son interfaces vacías. `PeliculaRepository` es el de S07, sin cambios:

```java
package com.curso.repository;

import com.curso.model.Pelicula;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * S08-1 Práctica 1: Repositorio de Pelicula (copiado de S07)
 *
 * Objetivo: leer y guardar películas sin escribir SQL.
 *
 * Aplica las técnicas de S06 y S07:
 *   1. Una interfaz vacía que extiende JpaRepository<Entidad, TipoClave>
 *
 * Concepto clave: el repositorio es el mismo de S07. Añadir la relación con
 * Director a la entidad no obliga a cambiarlo: Hibernate resuelve la clave foránea.
 */
public interface PeliculaRepository extends JpaRepository<Pelicula, Long> {
}
```

```java
package com.curso.repository;

import com.curso.model.Director;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * S08-1 Práctica 1: Repositorio de Director
 *
 * Objetivo: leer y guardar directores sin escribir SQL.
 *
 * Aplica las técnicas de S06 y S07:
 *   1. Una interfaz vacía que extiende JpaRepository<Entidad, TipoClave>
 *
 * Concepto clave: Spring Data genera la clase que implementa esta interfaz al
 * arrancar y la registra como bean; no hace falta @Repository.
 */
public interface DirectorRepository extends JpaRepository<Director, Long> {
}
```

El controlador y la plantilla:

```java
package com.curso.controller;

import com.curso.repository.PeliculaRepository;

// Controller, GetMapping y Model llegan con spring-boot-starter-webmvc.
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * S08-1 Práctica 1: Controlador de la página de películas
 *
 * Objetivo: mostrar las películas con el nombre de su director.
 *
 * Aplica las técnicas de S06 y S07:
 *   1. @Controller y @GetMapping para atender GET /peliculas
 *   2. Model para pasar los datos a la plantilla
 *   3. Navegar la relación @ManyToOne desde la plantilla (pelicula.director.nombre)
 *
 * Concepto clave: el controlador no escribe ningún JOIN. Hibernate lee el director
 * de cada película porque el mapeo @ManyToOne se lo indica.
 */
@Controller
public class PeliculaController {

    // Inyección por constructor: Spring entrega el repositorio al crear el controlador.
    private final PeliculaRepository peliculaRepository;

    public PeliculaController(PeliculaRepository peliculaRepository) {
        this.peliculaRepository = peliculaRepository;
    }

    // findAll() lee las películas y, por ser @ManyToOne de carga inmediata,
    // también el director de cada una.
    @GetMapping("/peliculas")
    public String listar(Model model) {
        model.addAttribute("peliculas", peliculaRepository.findAll());
        return "peliculas";
    }
}
```

```html
<!DOCTYPE html>
<html lang="es" xmlns:th="http://www.thymeleaf.org">
<head>
    <meta charset="UTF-8">
    <title>Películas de la cartelera</title>
</head>
<body>
<!--/*
    S08-1 Práctica 1: lista de películas con el nombre de su director.
    ${pelicula.director.nombre} navega la relación @ManyToOne como si fueran
    objetos normales. Este comentario es de Thymeleaf y no llega al navegador.
*/-->
<h1>Películas de la cartelera</h1>

<table border="1" cellpadding="6">
    <thead>
    <tr>
        <th>Título</th>
        <th>Año</th>
        <th>Género</th>
        <th>Director</th>
    </tr>
    </thead>
    <tbody>
    <tr th:each="pelicula : ${peliculas}">
        <td th:text="${pelicula.titulo}">Volver</td>
        <td th:text="${pelicula.anio}">2006</td>
        <td th:text="${pelicula.genero}">Drama</td>
        <td th:text="${pelicula.director.nombre}">Pedro Almodóvar</td>
    </tr>
    </tbody>
</table>
</body>
</html>
```

El test generado se deja con sus comentarios. Pasa solo si `POSTGRES_PASSWORD` está definida en su propia configuración JUnit:

```java
package com.curso;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * S08-1 Práctica 1: Test generado por IntelliJ
 *
 * Objetivo: comprobar que la aplicación arranca.
 *
 * Aplica las técnicas de S05 y S07:
 *   1. @SpringBootTest para arrancar la aplicación completa
 *   2. La variable de entorno POSTGRES_PASSWORD en la configuración JUnit
 *
 * Concepto clave: el test generado no comprueba ninguna operación: pasa si el
 * contenedor arranca, y eso incluye conectar con PostgreSQL. Por eso necesita su
 * propia variable de entorno (ver s07-demos.md).
 */
@SpringBootTest
class AplicacionTests {

    @Test
    void contextLoads() {
    }
}
```

Al abrir `http://localhost:8080/peliculas` aparecen las cinco películas con el nombre de su director. La consola muestra cuatro consultas:

<pre>
Hibernate: select p1_0.id,p1_0.anio,p1_0.director_id,p1_0.duracion_min,p1_0.genero,p1_0.titulo from pelicula p1_0
Hibernate: select d1_0.id,d1_0.anio_nacimiento,d1_0.nacionalidad,d1_0.nombre from director d1_0 where d1_0.id=?
Hibernate: select d1_0.id,d1_0.anio_nacimiento,d1_0.nacionalidad,d1_0.nombre from director d1_0 where d1_0.id=?
Hibernate: select d1_0.id,d1_0.anio_nacimiento,d1_0.nacionalidad,d1_0.nombre from director d1_0 where d1_0.id=?
</pre>

**Decisiones tomadas**

- `Pelicula` es el lado propietario porque la clave foránea `director_id` está en la tabla `pelicula`. `Director` solo lleva el lado inverso, con `mappedBy = "director"`, que es el nombre del campo de `Pelicula`. Si se olvidase `mappedBy`, Hibernate buscaría una tabla intermedia que no existe (en la Demo 1 se vio el error con `monitor_clases`). Y si solo se rellenase la lista de `Director` y no el campo `director` de `Pelicula`, la clave foránea no se escribiría, porque Hibernate ignora el lado inverso al guardar.
- Si se intentase guardar una película sin director, PostgreSQL rechazaría el `insert`: `ERROR: null value in column "director_id" of relation "pelicula" violates not-null constraint`. La base de datos hace cumplir lo que el script SQL declaró, y el mapeo no necesita repetirlo.
- La lista de películas se inicializa con `new ArrayList<>()` para no tener nunca `null`, y es de carga diferida (el valor por defecto de `@OneToMany`): la página de películas no la necesita y no la lee.
- El `@ManyToOne` queda con su carga por defecto, la inmediata, porque la página siempre necesita el director. El coste son las cuatro consultas: una por la lista y una por cada director distinto (tres). Hibernate no vuelve a leer un director que ya tiene en memoria, por eso son tres consultas de director y no cinco.
- Los `toString()` no incluyen la lista ni el director: entre `Director` y `Pelicula` formarían un bucle infinito, y además cargarían datos que quien imprime no ha pedido.
- Los repositorios no se modifican para añadir la relación: el mapeo está en la entidad, no en el repositorio.

---

## Práctica 2: Sesiones con dos relaciones

`Sala` es una entidad sin relaciones: mapea los campos de la tabla `sala`. No declara la lista de sus sesiones porque ninguna página la necesita.

```java
package com.curso.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

/**
 * S08-1 Práctica 2: Sala
 *
 * Objetivo: mapear la tabla sala, que la entidad Sesion usará como destino
 * de una de sus dos relaciones.
 *
 * Aplica las técnicas de S08-1:
 *   1. @Entity, @Id y @GeneratedValue sobre una tabla existente
 *
 * Concepto clave: una entidad sin relaciones es la más sencilla de mapear. Sala
 * no declara la lista de sus sesiones porque ninguna página la necesita: las
 * relaciones inversas se añaden solo cuando hacen falta.
 */
@Entity
public class Sala {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;
    private int aforo;

    public Sala() {
    }

    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public int getAforo() {
        return aforo;
    }

    @Override
    public String toString() {
        return "Sala{id=" + id + ", nombre='" + nombre + "', aforo=" + aforo + "}";
    }
}
```

`Sesion` tiene dos `@ManyToOne`, cada uno con su `@JoinColumn`. Es el lado propietario de las dos relaciones, porque `pelicula_id` y `sala_id` están en su tabla. Introduce dos tipos de dato nuevos: `LocalDateTime` para la columna `timestamp` y `BigDecimal` para `numeric(6,2)`.

```java
package com.curso.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

// BigDecimal (decimal exacto) y LocalDateTime (fecha y hora) forman parte del JDK.
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * S08-1 Práctica 2: Sesion con dos relaciones
 *
 * Objetivo: mapear una tabla con dos claves foráneas, hacia pelicula y hacia sala.
 *
 * Aplica las técnicas de S08-1:
 *   1. Dos @ManyToOne en la misma entidad, cada una con su @JoinColumn
 *   2. Tipos de columna nuevos: timestamp -> LocalDateTime y numeric -> BigDecimal
 *
 * Concepto clave: Sesion es el lado propietario de las dos relaciones, porque
 * las columnas pelicula_id y sala_id están en su tabla. Navegar las dos relaciones
 * desde una página es posible, pero cada una cuesta consultas (se ven en el log).
 */
@Entity
public class Sesion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Primera clave foránea: muchas sesiones proyectan una misma película.
    @ManyToOne
    @JoinColumn(name = "pelicula_id")
    private Pelicula pelicula;

    // Segunda clave foránea: muchas sesiones se celebran en una misma sala.
    @ManyToOne
    @JoinColumn(name = "sala_id")
    private Sala sala;

    // La columna timestamp (fecha y hora) se corresponde con LocalDateTime.
    // fechaHora <-> fecha_hora.
    private LocalDateTime fechaHora;

    // La columna numeric(6,2) es un decimal exacto: en Java se usa BigDecimal,
    // no double (que arrastra el error de decimales visto en S02).
    private BigDecimal precio;

    private int plazasLibres;

    public Sesion() {
    }

    public Long getId() {
        return id;
    }

    public Pelicula getPelicula() {
        return pelicula;
    }

    public Sala getSala() {
        return sala;
    }

    public LocalDateTime getFechaHora() {
        return fechaHora;
    }

    public BigDecimal getPrecio() {
        return precio;
    }

    public int getPlazasLibres() {
        return plazasLibres;
    }

    @Override
    public String toString() {
        return "Sesion{id=" + id + ", fechaHora=" + fechaHora + ", precio=" + precio
                + ", plazasLibres=" + plazasLibres + "}";
    }
}
```

`Entrada` tiene un `@ManyToOne` hacia `Sesion`:

```java
package com.curso.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

import java.time.LocalDateTime;

/**
 * S08-1 Práctica 2: Entrada con su sesión
 *
 * Objetivo: mapear la tabla entrada y su clave foránea hacia sesion.
 *
 * Aplica las técnicas de S08-1:
 *   1. @ManyToOne y @JoinColumn(name = "sesion_id")
 *   2. LocalDateTime para la columna timestamp fecha_compra
 *
 * Concepto clave: una entrada solo necesita saber a qué sesión pertenece. Sesion
 * no declara la lista de sus entradas: la relación se navega en un solo sentido.
 */
@Entity
public class Entrada {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Muchas entradas pertenecen a una misma sesión.
    @ManyToOne
    @JoinColumn(name = "sesion_id")
    private Sesion sesion;

    private String cliente;

    // fechaCompra <-> fecha_compra. La tabla tiene default now(), pero aquí solo
    // se leen entradas ya guardadas por el script SQL.
    private LocalDateTime fechaCompra;

    public Entrada() {
    }

    public Long getId() {
        return id;
    }

    public Sesion getSesion() {
        return sesion;
    }

    public String getCliente() {
        return cliente;
    }

    public LocalDateTime getFechaCompra() {
        return fechaCompra;
    }

    @Override
    public String toString() {
        return "Entrada{id=" + id + ", cliente='" + cliente + "', fechaCompra=" + fechaCompra + "}";
    }
}
```

Los tres repositorios son interfaces vacías:

```java
package com.curso.repository;

import com.curso.model.Sala;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * S08-1 Práctica 2: Repositorio de Sala
 *
 * Objetivo: leer y guardar salas sin escribir SQL.
 *
 * Aplica las técnicas de S06 y S07:
 *   1. Una interfaz vacía que extiende JpaRepository<Entidad, TipoClave>
 *
 * Concepto clave: cada entidad tiene su repositorio, aunque solo se use de forma
 * indirecta (Sesion llega a Sala a través de la relación, no del repositorio).
 */
public interface SalaRepository extends JpaRepository<Sala, Long> {
}
```

```java
package com.curso.repository;

import com.curso.model.Sesion;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * S08-1 Práctica 2: Repositorio de Sesion
 *
 * Objetivo: leer las sesiones con su película y su sala.
 *
 * Aplica las técnicas de S06 y S07:
 *   1. Una interfaz vacía que extiende JpaRepository<Entidad, TipoClave>
 *
 * Concepto clave: findAll() devuelve las sesiones y, por ser @ManyToOne de carga
 * inmediata, también sus películas, sus directores y sus salas. Cuántas consultas
 * cuesta se ve en el log de SQL.
 */
public interface SesionRepository extends JpaRepository<Sesion, Long> {
}
```

```java
package com.curso.repository;

import com.curso.model.Entrada;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * S08-1 Práctica 2: Repositorio de Entrada
 *
 * Objetivo: leer y guardar entradas sin escribir SQL.
 *
 * Aplica las técnicas de S06 y S07:
 *   1. Una interfaz vacía que extiende JpaRepository<Entidad, TipoClave>
 *
 * Concepto clave: en S09-2 este repositorio guardará las entradas vendidas.
 * Aquí solo se leen las tres que carga el script SQL.
 */
public interface EntradaRepository extends JpaRepository<Entrada, Long> {
}
```

El controlador, la plantilla y el listado por consola:

```java
package com.curso.controller;

import com.curso.repository.SesionRepository;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * S08-1 Práctica 2: Controlador de la página de sesiones
 *
 * Objetivo: mostrar cada sesión con el título de su película y el nombre de su sala.
 *
 * Aplica las técnicas de S06 y S07:
 *   1. @Controller y @GetMapping para atender GET /sesiones
 *   2. Navegar dos relaciones @ManyToOne desde la misma plantilla
 *
 * Concepto clave: una sola página recorre dos relaciones (sesion.pelicula y
 * sesion.sala). Lo que parece una consulta cuesta varias, y el log de SQL lo muestra.
 */
@Controller
public class SesionController {

    private final SesionRepository sesionRepository;

    public SesionController(SesionRepository sesionRepository) {
        this.sesionRepository = sesionRepository;
    }

    @GetMapping("/sesiones")
    public String listar(Model model) {
        model.addAttribute("sesiones", sesionRepository.findAll());
        return "sesiones";
    }
}
```

```html
<!DOCTYPE html>
<html lang="es" xmlns:th="http://www.thymeleaf.org">
<head>
    <meta charset="UTF-8">
    <title>Sesiones de la cartelera</title>
</head>
<body>
<!--/*
    S08-1 Práctica 2: sesiones con el título de su película y el nombre de su sala.
    Cada fila navega dos relaciones: sesion.pelicula.titulo y sesion.sala.nombre.
    Este comentario es de Thymeleaf y no llega al navegador.
*/-->
<h1>Sesiones de la cartelera</h1>

<table border="1" cellpadding="6">
    <thead>
    <tr>
        <th>Película</th>
        <th>Sala</th>
        <th>Fecha y hora</th>
        <th>Precio</th>
        <th>Plazas libres</th>
    </tr>
    </thead>
    <tbody>
    <tr th:each="sesion : ${sesiones}">
        <td th:text="${sesion.pelicula.titulo}">Volver</td>
        <td th:text="${sesion.sala.nombre}">Sala 1</td>
        <td th:text="${sesion.fechaHora}">2026-11-06T18:00</td>
        <td th:text="${sesion.precio}">8.50</td>
        <td th:text="${sesion.plazasLibres}">78</td>
    </tr>
    </tbody>
</table>
</body>
</html>
```

```java
package com.curso.config;

import com.curso.model.Entrada;
import com.curso.repository.EntradaRepository;

import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * S08-1 Práctica 2: Listado de entradas por consola
 *
 * Objetivo: comprobar el mapeo de Entrada y de su relación con Sesion.
 *
 * Aplica las técnicas de S06 y S07:
 *   1. CommandLineRunner para ejecutar código al arrancar
 *   2. Navegar relaciones encadenadas: entrada -> sesion -> pelicula y sala
 *
 * Concepto clave: la entrada llega a la película y a la sala pasando por la sesión,
 * sin ninguna consulta escrita a mano.
 */
// @Order fija el orden de los runners: de menor a mayor número (S07).
@Order(1)
@Component
public class ListadoEntradas implements CommandLineRunner {

    private final EntradaRepository entradaRepository;

    public ListadoEntradas(EntradaRepository entradaRepository) {
        this.entradaRepository = entradaRepository;
    }

    @Override
    public void run(String... args) {
        System.out.println("=== Entradas vendidas ===");

        // findAll() lee las entradas; cada una arrastra su sesión, y esta su película y su sala.
        for (Entrada entrada : entradaRepository.findAll()) {
            System.out.println(entrada.getCliente()
                    + " | " + entrada.getSesion().getPelicula().getTitulo()
                    + " | " + entrada.getSesion().getSala().getNombre()
                    + " | " + entrada.getSesion().getFechaHora());
        }
        // → Marta Pérez | Todo sobre mi madre | Sala 1 | 2026-11-06T18:00
        // → Jorge Lara | Todo sobre mi madre | Sala 1 | 2026-11-06T18:00
        // → Irene Campos | El laberinto del fauno | Sala 2 | 2026-11-06T20:30
    }
}
```

La consola del arranque muestra el listado de entradas:

<pre>
=== Entradas vendidas ===
Marta Pérez | Todo sobre mi madre | Sala 1 | 2026-11-06T18:00
Jorge Lara | Todo sobre mi madre | Sala 1 | 2026-11-06T18:00
Irene Campos | El laberinto del fauno | Sala 2 | 2026-11-06T20:30
</pre>

Y la página `http://localhost:8080/sesiones` muestra cada sesión con su película y su sala. Al abrirla, la consola muestra siete consultas:

<pre>
Hibernate: select s1_0.id,s1_0.fecha_hora,s1_0.pelicula_id,s1_0.plazas_libres,s1_0.precio,s1_0.sala_id from sesion s1_0
Hibernate: select p1_0.id,p1_0.anio,d1_0.id,d1_0.anio_nacimiento,d1_0.nacionalidad,d1_0.nombre,p1_0.duracion_min,p1_0.genero,p1_0.titulo from pelicula p1_0 left join director d1_0 on d1_0.id=p1_0.director_id where p1_0.id=?
Hibernate: select s1_0.id,s1_0.aforo,s1_0.nombre from sala s1_0 where s1_0.id=?
Hibernate: select p1_0.id,p1_0.anio,d1_0.id,d1_0.anio_nacimiento,d1_0.nacionalidad,d1_0.nombre,p1_0.duracion_min,p1_0.genero,p1_0.titulo from pelicula p1_0 left join director d1_0 on d1_0.id=p1_0.director_id where p1_0.id=?
Hibernate: select s1_0.id,s1_0.aforo,s1_0.nombre from sala s1_0 where s1_0.id=?
Hibernate: select p1_0.id,p1_0.anio,d1_0.id,d1_0.anio_nacimiento,d1_0.nacionalidad,d1_0.nombre,p1_0.duracion_min,p1_0.genero,p1_0.titulo from pelicula p1_0 left join director d1_0 on d1_0.id=p1_0.director_id where p1_0.id=?
Hibernate: select p1_0.id,p1_0.anio,d1_0.id,d1_0.anio_nacimiento,d1_0.nacionalidad,d1_0.nombre,p1_0.duracion_min,p1_0.genero,p1_0.titulo from pelicula p1_0 left join director d1_0 on d1_0.id=p1_0.director_id where p1_0.id=?
</pre>

**Decisiones tomadas**

- `Sesion` lleva los dos `@ManyToOne` porque es la tabla que contiene las dos claves foráneas. Es el caso general de las tablas de unión y de reserva: una entidad con dos lados propietarios.
- Se usa `BigDecimal` para el precio y no `double`, porque la columna `numeric(6,2)` es un decimal exacto y `double` arrastra el error de decimales visto en S02. `LocalDateTime` es el tipo de JDK que se corresponde con `timestamp`, igual que `LocalDate` con `date`.
- No se añaden las listas inversas (`Sala.sesiones`, `Sesion.entradas`): ninguna página las necesita. Una relación inversa es una lista más que cargar, que imprimir sin bucles y que mantener, y solo compensa cuando se usa. En S09-2, al vender entradas, se guardará una `Entrada` con su `Sesion` desde el lado propietario.
- La página de sesiones cuesta siete consultas: una por la lista de sesiones, cuatro por las películas (la consulta de cada película trae su director con un `left join`) y dos por las salas. Son más que las cuatro de la Práctica 1 porque cada sesión recorre dos relaciones, la película y la sala, y además la película arrastra a su director. Hibernate no repite una consulta por un objeto que ya tiene en memoria, pero la cuenta crece con cada relación de carga inmediata. Este coste es el que motiva elegir qué cargar en cada consulta, como se hizo con `@EntityGraph` en la Demo 3.
- `ListadoEntradas` navega tres relaciones encadenadas desde la entrada (`getSesion().getPelicula().getTitulo()`) sin escribir ningún `JOIN`. Lleva `@Order(1)` para que se ejecute antes que el de la Práctica 3.

---

## Práctica 3: Nombres personalizados con `@Table` y `@Column`

La tabla nueva se crea con el script SQL, ejecutado en la `Query Tool` de pgAdmin sobre la base de datos `cartelera`, después del script de S07. Sus nombres no siguen la convención: `tbl_critica`, `cod_critica`, `cod_pelicula`, `nombre_autor`, `puntuacion`, `comentario` y `fecha_critica`.

```sql
-- S08-1 Práctica 3: tabla de críticas de la cartelera.
-- Se ejecuta en la Query Tool de pgAdmin, conectado a la base de datos cartelera.
-- Los nombres de la tabla y de las columnas NO coinciden con los de la clase
-- y los campos Java: es lo que se practica con @Table y @Column.

drop table if exists tbl_critica;

create table tbl_critica (
    cod_critica  bigint generated by default as identity primary key,
    cod_pelicula bigint       not null,
    nombre_autor varchar(60)  not null,
    puntuacion   integer      not null check (puntuacion between 1 and 10),
    comentario   varchar(300) not null,
    fecha_critica date        not null default current_date,
    constraint fk_critica_pelicula foreign key (cod_pelicula) references pelicula (id)
);

insert into tbl_critica (cod_pelicula, nombre_autor, puntuacion, comentario, fecha_critica) values
    (1, 'Clara Montes', 9, 'Emocionante y muy bien interpretada.', '2026-10-01'),
    (3, 'Rafael Ortega', 10, 'Una fantasía oscura y preciosa.', '2026-10-03'),
    (4, 'Inés Duarte', 8, 'Tensión constante hasta el final.', '2026-10-04');

select * from tbl_critica order by cod_critica;
```

La entidad `Critica` usa `@Table` para el nombre de la tabla y `@Column(name = ...)` para cada columna cuyo nombre difiere del campo. La clave foránea usa `@JoinColumn(name = "cod_pelicula")`.

```java
package com.curso.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import java.time.LocalDate;

/**
 * S08-1 Práctica 3: Critica sobre la tabla tbl_critica
 *
 * Objetivo: mapear una tabla cuyo nombre y cuyas columnas no coinciden con los
 * de la clase y sus campos.
 *
 * Aplica las técnicas de S08-1:
 *   1. @Table(name = "tbl_critica") para el nombre de la tabla
 *   2. @Column(name = ...) para cada columna con nombre distinto
 *   3. @Column(nullable = false, length = 300) para describir una columna not null
 *   4. @JoinColumn(name = "cod_pelicula") para una clave foránea con nombre propio
 *
 * Concepto clave: sin @Table y @Column, Hibernate busca una tabla llamada critica
 * y columnas llamadas como los campos. Con ellas, la clase y los campos conservan
 * nombres claros en Java y la base de datos conserva los suyos.
 */
// Sin @Table, Hibernate usaría el nombre de la clase y buscaría la tabla critica.
@Entity
@Table(name = "tbl_critica")
public class Critica {

    // La clave primaria se llama cod_critica en la tabla y id en Java.
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "cod_critica")
    private Long id;

    // Clave foránea con nombre propio: la columna es cod_pelicula, no pelicula_id.
    @ManyToOne
    @JoinColumn(name = "cod_pelicula")
    private Pelicula pelicula;

    // autor <-> nombre_autor. nullable = false y length = 60 describen la columna
    // (not null, varchar(60)). Con ddl-auto=none Hibernate no crea ni modifica la
    // tabla: estos dos atributos documentan cómo es la columna y solo tendrían
    // efecto si algún día Hibernate generara el esquema.
    @Column(name = "nombre_autor", nullable = false, length = 60)
    private String autor;

    // nota <-> puntuacion (un entero entre 1 y 10, comprobado por un check de la tabla).
    @Column(name = "puntuacion", nullable = false)
    private int nota;

    // texto <-> comentario, varchar(300) not null.
    @Column(name = "comentario", nullable = false, length = 300)
    private String texto;

    // fecha <-> fecha_critica.
    @Column(name = "fecha_critica", nullable = false)
    private LocalDate fecha;

    public Critica() {
    }

    public Long getId() {
        return id;
    }

    public Pelicula getPelicula() {
        return pelicula;
    }

    public String getAutor() {
        return autor;
    }

    public int getNota() {
        return nota;
    }

    public String getTexto() {
        return texto;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    @Override
    public String toString() {
        return "Critica{id=" + id + ", autor='" + autor + "', nota=" + nota + ", fecha=" + fecha + "}";
    }
}
```

El repositorio y el listado por consola:

```java
package com.curso.repository;

import com.curso.model.Critica;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * S08-1 Práctica 3: Repositorio de Critica
 *
 * Objetivo: leer las críticas de la tabla tbl_critica.
 *
 * Aplica las técnicas de S06 y S07:
 *   1. Una interfaz vacía que extiende JpaRepository<Entidad, TipoClave>
 *
 * Concepto clave: el repositorio no sabe nada de nombres de tablas ni de
 * columnas. Todo eso lo resuelve el mapeo de la entidad (@Table y @Column).
 */
public interface CriticaRepository extends JpaRepository<Critica, Long> {
}
```

```java
package com.curso.config;

import com.curso.model.Critica;
import com.curso.repository.CriticaRepository;

import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * S08-1 Práctica 3: Listado de críticas por consola
 *
 * Objetivo: comprobar que Critica se mapea a tbl_critica con sus columnas.
 *
 * Aplica las técnicas de S06 y S07:
 *   1. CommandLineRunner para ejecutar código al arrancar
 *   2. @Table y @Column en la entidad para que la consulta funcione
 *
 * Concepto clave: si el mapeo es correcto, esta clase lista las tres críticas del
 * script SQL. Si falta una anotación, la aplicación falla con un mensaje de
 * PostgreSQL que nombra la tabla o la columna que no encuentra.
 */
// @Order fija el orden de los runners: de menor a mayor número (S07).
@Order(2)
@Component
public class ListadoCriticas implements CommandLineRunner {

    private final CriticaRepository criticaRepository;

    public ListadoCriticas(CriticaRepository criticaRepository) {
        this.criticaRepository = criticaRepository;
    }

    @Override
    public void run(String... args) {
        System.out.println("=== Críticas ===");

        for (Critica critica : criticaRepository.findAll()) {
            System.out.println(critica.getPelicula().getTitulo()
                    + " | " + critica.getAutor()
                    + " | " + critica.getNota() + "/10"
                    + " | " + critica.getTexto());
        }
        // → Todo sobre mi madre | Clara Montes | 9/10 | Emocionante y muy bien interpretada.
        // → El laberinto del fauno | Rafael Ortega | 10/10 | Una fantasía oscura y preciosa.
        // → Los otros | Inés Duarte | 8/10 | Tensión constante hasta el final.
    }
}
```

Tras el listado de entradas, la consola muestra:

<pre>
=== Críticas ===
Todo sobre mi madre | Clara Montes | 9/10 | Emocionante y muy bien interpretada.
El laberinto del fauno | Rafael Ortega | 10/10 | Una fantasía oscura y preciosa.
Los otros | Inés Duarte | 8/10 | Tensión constante hasta el final.
</pre>

Los dos errores que aparecen al quitar las anotaciones son:

<pre>
Sin @Table:
ERROR: relation "critica" does not exist

Con @Table, pero sin @Column(name = "cod_critica") en la clave primaria:
ERROR: column c1_0.id does not exist
</pre>

**Decisiones tomadas**

- Los campos conservan nombres claros en Java (`autor`, `nota`, `texto`, `fecha`) y la base de datos conserva los suyos. El mapeo es el único sitio que conoce los dos nombres, y ni la tabla ni el resto del código tienen que cambiar.
- Cada error nombra el elemento que falta: `relation "critica"` es la tabla (sin `@Table`, Hibernate usa el nombre de la clase), y `column c1_0.id` es la columna (sin `@Column(name = ...)`, usa el nombre del campo). Con `ddl-auto=none`, Hibernate no comprueba el esquema al arrancar: el error aparece cuando ejecuta la primera consulta contra esa tabla.
- `@Column(nullable = false, length = ...)` se escribe para documentar cómo es cada columna (`not null`, `varchar(60)` o `varchar(300)`), pero con `ddl-auto=none` no tiene efecto: la restricción real la tiene la tabla. Tendría efecto solo si Hibernate generase el esquema.
- La fecha se mapea como `LocalDate`, el tipo de JDK que se corresponde con `date`. El `default current_date` de la tabla no interviene aquí, porque las críticas se leen y no se guardan desde Java (ver el caso de `Inscripcion` en `s08-1-demos.md`).
- La nota es un `int` y no un `Integer`, porque la columna es `not null`. El `check (puntuacion between 1 and 10)` lo hace cumplir la base de datos.
- La clave primaria sigue siendo `@GeneratedValue(strategy = GenerationType.IDENTITY)` aunque se llame `cod_critica`: lo que cambia es el nombre de la columna, no cómo la genera la base de datos (`generated by default as identity`).
- Antes de volver a ejecutar el script de la cartelera de S07 hay que borrar `tbl_critica`, porque su clave foránea impide borrar `pelicula`. El script de la práctica ya empieza con `drop table if exists tbl_critica;` para poder repetirse.

---

## Práctica 4: Entidades y relaciones del proyecto

Esta práctica no tiene solución: depende del esquema y del proyecto de cada grupo.
