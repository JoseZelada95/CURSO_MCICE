# S16-1 Teoría: imágenes, capas, etiquetas y Dockerfile

## Objetivos

Esta primera parte de S16-1 no usa el ordenador. Sirve para entender los conceptos que luego se manejan en las demos y que aparecen en el cuestionario de Docker y Kubernetes (preguntas 1 a 4).

Docker Desktop ya está instalado (S15-2), pero todavía no hemos ejecutado nada con él: aquí se explica todo desde cero.

| Al terminar sabremos explicar... | Apartado |
|---|---|
| Qué problema resuelve Docker | 1 |
| Qué es una imagen y qué es un contenedor | 2 |
| En qué se diferencia un contenedor de una máquina virtual | 3 |
| Qué ventajas tiene Docker (y qué no resuelve) | 4 |
| Qué son las capas y por qué ahorran espacio y tiempo | 5 |
| Cómo se identifica una imagen: nombre y etiqueta | 6 |
| Qué es un `Dockerfile` y qué hace cada instrucción | 7 |
| De dónde salen las imágenes | 8 |
| Qué hace cada comando de Docker, con todas sus partes | 9 |

---

## 1. El problema: "en mi equipo funciona"

Una compañera nos pasa la API de contactos. Para que funcione en nuestro equipo hace falta:

| Requisito | Qué puede fallar |
|---|---|
| JDK 21 | Tenemos el 17 o el 25 |
| `JAVA_HOME` bien apuntada | Apunta a otra carpeta |
| PostgreSQL 17 en marcha, con usuario y base de datos | No está instalado o es otra versión |
| Puerto 8080 libre | Lo ocupa Jenkins |
| Variables de entorno con las credenciales | Faltan o están mal escritas |

Todo esto se suele escribir en un `README.md` y en un fichero de dependencias (`pom.xml` en Maven, `requirements.txt` en Python). Funciona, pero tiene tres problemas:

| Problema | Por qué ocurre |
|---|---|
| **Las instrucciones se interpretan, no se ejecutan** | Una persona las lee y las aplica a su manera; si se salta un paso, falla y el error no dice por qué |
| **Solo describen una parte** | El `pom.xml` fija las librerías de Java, pero no el JDK, el sistema operativo ni la base de datos. El `README` lo dice con palabras, y las palabras envejecen ("PostgreSQL 15" cuando ya hace falta la 17) |
| **Cada equipo es distinto** | Lo que hay instalado de antes interfiere. Es el clásico **"en mi equipo funciona"** |

```
 SIN DOCKER                                CON DOCKER

 README con instrucciones                  Entorno ya preparado
        │                                  + aplicación, en un paquete
        ▼                                         │
 cada persona prepara su entorno                  ▼
        │                                  se ejecuta tal cual
        ▼
 resultados distintos
```

> **Idea clave:** Docker no entrega *instrucciones para preparar un entorno*, entrega *el entorno ya preparado*, empaquetado con la aplicación. Quien lo recibe no instala el JDK ni configura nada: lo ejecuta y funciona igual que en el equipo de origen.

---

## 2. Imagen y contenedor

Son los dos términos base de Docker y se confunden con mucha facilidad.

| | Imagen | Contenedor |
|---|---|---|
| **Qué es** | Paquete con todo lo necesario para ejecutar un programa | Una imagen **en ejecución** |
| **Contiene** | El programa, sus librerías, el entorno de ejecución (el JRE de Java) y los ficheros básicos de un Linux | Lo de la imagen, más una capa propia donde puede escribir |
| **¿Cambia?** | No: es de **solo lectura**. Para cambiarla se crea otra nueva | Sí: tiene estado (en marcha, parado) |
| **¿Consume memoria?** | No: son ficheros guardados en disco | Sí, mientras está en marcha |
| **Cómo se obtiene** | Se descarga o se construye | Se crea con `docker run` |

Un contenedor, además, está **aislado**: ve su propio sistema de ficheros, su propia red y sus propios procesos, y no ve los del resto del equipo.

### La comparación con la programación orientada a objetos

| En programación | En Docker |
|---|---|
| Clase (`class Contacto`) | Imagen (`nginx`) |
| Objeto (`new Contacto()`) | Contenedor |
| Una clase, muchos objetos | Una imagen, muchos contenedores |
| La clase no cambia al crear objetos | La imagen no cambia al crear contenedores |
| Cada objeto tiene sus propios valores | Cada contenedor tiene sus propios datos |

```
                  ┌── contenedor "web"   (puerto 8081)
 imagen nginx ────┼── contenedor "web2"  (puerto 8082)
                  └── contenedor "web3"  (puerto 8083)
```

### Dos consecuencias importantes

1. **De una imagen salen tantos contenedores como queramos**, todos independientes.
2. **Borrar un contenedor no borra la imagen**, y **no se puede borrar una imagen mientras algún contenedor la use** (aunque esté parado).

### La capa de escritura

Al arrancar un contenedor, Docker añade sobre la imagen una **capa de escritura** propia, donde se guardan los cambios que hace mientras vive (por ejemplo, los datos que inserta una base de datos).

```
 ┌───────────────────────────────┐
 │ capa de escritura (contenedor)│ ← desaparece al borrar el contenedor
 ├───────────────────────────────┤
 │ capas de la imagen            │ ← solo lectura, no cambian
 └───────────────────────────────┘
```

> **Consecuencia:** al borrar un contenedor, los datos que guardó se pierden. En S16-2 veremos los **volúmenes**, que son la forma de conservarlos.

---

## 3. Contenedor frente a máquina virtual

### Qué es cada cosa

| Máquina virtual | Contenedor |
|---|---|
| Un ordenador simulado dentro de otro | Un proceso normal del sistema, con límites y aislamiento |
| Un programa llamado **hipervisor** (VirtualBox, VMware, Hyper-V) reparte procesador, memoria y disco | El motor de Docker lo aísla del resto |
| Lleva un **sistema operativo completo**, con su propio **núcleo** (*kernel*: la parte del sistema que habla con el hardware) | **Comparte el núcleo** del sistema que lo ejecuta; solo lleva los ficheros que necesita la aplicación |
| Ejemplo: Windows dentro de VirtualBox | Ejemplo: nginx dentro de Docker |

### Las capas de cada modelo, de abajo arriba

```
 MÁQUINA VIRTUAL (cada una)        CONTENEDOR (todos a la vez)

   Aplicación                        Aplicación
   Librerías                         Librerías
   Sistema operativo invitado   ◄─── no existe: se comparte el núcleo
   ─────────────────────────         ─────────────────────────
   Hipervisor                        Motor de Docker
   Sistema operativo del equipo      Sistema operativo del equipo (núcleo)
   Hardware                          Hardware
```

La diferencia está en el "sistema operativo invitado": la máquina virtual lo lleva, el contenedor no.

### Consecuencias prácticas (órdenes de magnitud)

| Aspecto | Máquina virtual | Contenedor |
|---|---|---|
| Tamaño | Gigabytes (un sistema operativo entero) | Decenas o cientos de megabytes |
| Arranque | Decenas de segundos o minutos | Segundos o menos |
| Memoria | Reserva la asignada, la use o no | Usa la que necesita el programa |
| Cuántas caben en un equipo | Pocas | Decenas |
| Aislamiento | Muy fuerte (núcleos distintos) | Fuerte, pero menor (núcleo compartido) |
| Qué se puede ejecutar | Cualquier sistema operativo | Programas que funcionen con el núcleo del equipo |

> **Matiz para Windows:** los contenedores que usamos son **Linux** y necesitan un núcleo de Linux. Windows no lo tiene, así que Docker Desktop ejecuta una pequeña máquina virtual Linux muy ligera (WSL2) y los contenedores comparten el núcleo **de esa máquina**. Para nosotros es transparente y no cambia la idea: dentro de WSL2 todos los contenedores comparten un único núcleo.

**Cuándo gana la máquina virtual:** cuando hace falta aislamiento total o ejecutar un sistema operativo distinto del anfitrión. **Cuándo gana el contenedor:** para empaquetar y distribuir aplicaciones.

---

## 4. Ventajas de Docker

### Frente a las máquinas virtuales

| Ventaja | En una frase |
|---|---|
| Ligereza | Una imagen de aplicación ocupa megas, no gigas |
| Rapidez | Un contenedor arranca en segundos: se crea, se prueba y se tira |
| Densidad | Caben muchos más contenedores que máquinas virtuales |
| Reutilización | Las imágenes se construyen por capas y comparten las comunes (apartado 5) |

### Frente a un `README` y un fichero de dependencias

| Ventaja | En una frase |
|---|---|
| Ejecutable, no descriptivo | El `Dockerfile` (apartado 7) es una receta que Docker sigue sin interpretarla: ningún paso se puede saltar |
| Incluye todo el entorno | El JRE, el sistema base y la configuración quedan dentro de la imagen, no solo las librerías |
| Reproducible | La imagen `contactos:1.0` es la misma en el equipo de quien la construyó y en el de quien la ejecuta |
| No ensucia el equipo | Para probar PostgreSQL no lo instalamos: ejecutamos un contenedor y, al borrarlo, no queda rastro |
| Versionable y revisable | El `Dockerfile` es texto y va a GitHub junto al código; cada cambio del entorno queda en el historial |
| Sin conflictos entre proyectos | Un proyecto con Java 17 y otro con Java 21, cada uno en su contenedor |

### Lo que Docker no resuelve

| Limitación | Detalle |
|---|---|
| No guarda datos por sí solo | Sin un volumen (S16-2), los datos se pierden al borrar el contenedor |
| No es tan estanco como una máquina virtual | Comparte el núcleo |
| Sigue necesitando configuración | Puertos y variables de entorno: Docker empaqueta el entorno, pero hay que decirle cómo conectarse al resto |
| No sustituye al `README` | Sigue haciendo falta para explicar qué hace el proyecto y cómo se usa; lo que desaparece son los pasos de instalación |

---

## 5. Capas

Una imagen no es un bloque único: está formada por **capas**. Cada capa es un conjunto de ficheros añadidos o cambiados respecto a la anterior, y se apilan como una **pila de transparencias**: vista desde arriba se ve un único sistema de ficheros, pero cada transparencia sigue siendo independiente.

```
 ┌────────────────────────────────────┐
 │ capa 3: nuestro app.jar            │ ← lo único que escribimos nosotros
 ├────────────────────────────────────┤
 │ capa 2: JRE de Java 21             │ ← viene en eclipse-temurin:21-jre
 ├────────────────────────────────────┤
 │ capa 1: sistema Linux base         │ ← viene en eclipse-temurin:21-jre
 └────────────────────────────────────┘
```

### Cinco propiedades

| Nº | Propiedad | Qué significa |
|---|---|---|
| 1 | **Solo lectura** | Al ejecutar un contenedor se añade encima su capa de escritura (apartado 2) |
| 2 | **Se identifican por un código** | Un *hash*: cadena de letras y números calculada a partir del contenido. Mismo contenido, mismo código |
| 3 | **Se comparten entre imágenes** | Dos imágenes con la misma base guardan esa base **una sola vez** en el disco. Es la pregunta 3 del test: ahorra **espacio** y **tiempo de descarga** |
| 4 | **Al descargar, solo bajan las que faltan** | En `docker pull` aparece `Already exists` (la teníamos) o `Pull complete` (se descarga ahora) |
| 5 | **Al construir, se reutilizan las que no cambian** | Es la **caché de construcción**: si solo cambia nuestro JAR, solo se rehace la última capa. Por eso reconstruir tarda segundos |

### Ejemplo con números aproximados

```
 eclipse-temurin:21-jre       ≈ 314 MB   (la base, una sola vez en disco)
 contactos:1.0  =  base + JAR ≈  +20 MB
 contactos:1.1  =  base + JAR ≈  +20 MB

 En disco:  314 + 20 + 20 = 354 MB      (y no 2 × 334 = 668 MB)
```

Para ver las capas de una imagen se usa `docker history`: una línea por capa, con la instrucción que la creó y su tamaño.

---

## 6. Nombre y etiqueta

Toda imagen se identifica con un **nombre** y una **etiqueta** (*tag*), separados por dos puntos:

```
 postgres : 17
 └───┬───┘   └┬┘
  nombre   etiqueta
```

| Parte | Qué dice | Ejemplos |
|---|---|---|
| **Nombre** | De qué imagen se trata | `nginx`, `postgres`, `eclipse-temurin`, `contactos` |
| **Etiqueta** | La versión o variante | `postgres:17`, `eclipse-temurin:21-jre`, `contactos:1.0` |

### Reglas que hay que recordar

- Si escribimos solo el nombre, Docker añade la etiqueta `latest`: `nginx` equivale a `nginx:latest`.
- **`latest` no significa "la más reciente".** Es una etiqueta más, que el autor asigna a lo que quiera y que puede cambiar con el tiempo.
- Por eso, para que todo el grupo use la misma versión, **se fija siempre la etiqueta**: `mongo:8`, no `mongo`.
- Una imagen puede tener **varias etiquetas**, igual que una persona tiene nombre y apodo (`eclipse-temurin:21-jre` puede ser también `eclipse-temurin:21`).

### El nombre completo

Normalmente no lo vemos porque Docker rellena las partes que faltan:

```
 mirror.gcr.io / library / nginx : latest
 └─────┬──────┘   └──┬──┘   └─┬─┘   └──┬─┘
   registro      espacio    nombre   etiqueta
```

| Parte | Qué es | Si se omite |
|---|---|---|
| **Registro** | El servidor donde está la imagen | Docker Hub (`docker.io`). En el aula está bloqueado: usaremos `mirror.gcr.io` o ficheros del Drive |
| **Espacio de nombres** | El propietario de la imagen | En las oficiales (`nginx`, `postgres`) es `library` y se omite. En las de una persona o empresa es su usuario: `usuario/contactos` |
| **Nombre** | La imagen | (obligatorio) |
| **Etiqueta** | La versión | `latest` |

### Identificadores que no hay que confundir

| Identificador | Qué es | Ejemplo |
|---|---|---|
| Nombre:etiqueta | Nombre legible; puede apuntar a cosas distintas con el tiempo | `contactos:1.0` |
| `ID` | Código corto único de la imagen **en este equipo** | `a3f1c2d4e5b6` |
| *Digest* | Código largo del contenido exacto | `sha256:9b1f...` |

---

## 7. El `Dockerfile`

Para empaquetar nuestra propia aplicación hay que describir cómo se construye la imagen. Eso es un **`Dockerfile`**.

> **Definición (pregunta 4 del test):** un `Dockerfile` es un **fichero de texto, sin extensión, que describe instrucción a instrucción cómo construir una imagen**.

| Es... | No es... |
|---|---|
| Una **receta**: lista, en orden, lo que hay que hacer | Compose (que arranca varios contenedores, S16-2) |
| Seguida por el comando `docker build` (el "cocinero") | La imagen ya construida (que es el *resultado*) |
| Un fichero que **se versiona con Git** junto al código | Un registro de peticiones (eso es `docker logs`) |

### Ejemplo: la API `saludos` de la Demo 2

```dockerfile
FROM eclipse-temurin:21-jre
COPY target/saludos-0.0.1-SNAPSHOT.jar app.jar
EXPOSE 8080
ENTRYPOINT ["java", "-jar", "app.jar"]
```

Cuatro líneas, cuatro instrucciones. Cada línea es `INSTRUCCIÓN argumentos`; la instrucción se escribe en mayúsculas por convención.

### Las cuatro instrucciones

| Instrucción | Qué hace | Crea capa |
|---|---|---|
| `FROM` | Elige la imagen de partida | Aporta las de la base |
| `COPY` | Copia un fichero del equipo a la imagen | Sí |
| `EXPOSE` | Anota el puerto de la aplicación | No (tamaño 0) |
| `ENTRYPOINT` | Fija el comando que se ejecuta al arrancar | No (tamaño 0) |

#### `FROM`: la imagen de partida

```dockerfile
FROM eclipse-temurin:21-jre
```

- Toda imagen parte de otra; `FROM` dice de cuál. Es la **primera** instrucción.
- `eclipse-temurin:21-jre` ya contiene un Linux ligero y el **JRE** de Java 21 (*Java Runtime Environment*: lo necesario para **ejecutar** programas Java, sin las herramientas para compilarlos).
- No usamos el **JDK** (que incluye el compilador): la imagen sería más grande y no hace falta, porque Maven ya compiló el JAR.

#### `COPY`: copiar ficheros a la imagen

```dockerfile
COPY target/saludos-0.0.1-SNAPSHOT.jar app.jar
```

```
 COPY   origen                              destino
        └──────────────┬─────────────────┘  └──┬──┘
          en nuestro equipo, relativo al     dentro de la imagen
          contexto de construcción
```

- **Origen:** ruta en nuestro equipo, relativa a la carpeta desde la que se ejecuta `docker build` (el **contexto de construcción**). Aquí, el JAR que Maven deja en `target/` con `mvn package`.
- **Destino:** ruta dentro de la imagen. `app.jar` es un nombre corto y fijo, para que `ENTRYPOINT` no dependa de la versión.
- Hay que construir el JAR **antes** que la imagen: dentro de la imagen no hay Maven, solo el JRE.

#### `EXPOSE`: documentar el puerto

```dockerfile
EXPOSE 8080
```

- Indica que la aplicación escucha en el puerto 8080 **dentro** del contenedor.
- **`EXPOSE` solo documenta, no publica nada.** Para llegar desde el equipo hay que usar `-p` en `docker run`.

#### `ENTRYPOINT`: qué ejecutar al arrancar

```dockerfile
ENTRYPOINT ["java", "-jar", "app.jar"]
```

- Es el comando que se ejecuta al arrancar un contenedor de esta imagen: equivale a escribir `java -jar app.jar` en una terminal.
- Los corchetes con comillas (**formato lista**) separan cada palabra. Es la forma recomendada: ejecuta Java directamente y permite que `docker stop` lo detenga bien.

### Otras instrucciones (no las usaremos hoy)

| Instrucción | Para qué sirve |
|---|---|
| `RUN` | Ejecuta un comando **durante la construcción** (por ejemplo, instalar un paquete) y guarda el resultado como capa |
| `CMD` | Comando por defecto al arrancar, que se puede sustituir al ejecutar el contenedor |
| `ENV` | Define una variable de entorno dentro de la imagen |
| `WORKDIR` | Fija la carpeta de trabajo para las instrucciones siguientes |

### Dockerfile, capas e imagen

- Cada instrucción que modifica ficheros (`COPY`, `RUN`) genera una capa. `EXPOSE` y `ENTRYPOINT` solo añaden información (aparecen en `docker history` con tamaño 0).
- Importa el **orden**: lo que cambia más a menudo (nuestro JAR) va **al final**, para que las capas anteriores se reutilicen de la caché.

### Flujo completo

```
 código fuente ─► mvn package ─► JAR ─► Dockerfile + docker build ─► imagen ─► docker run ─► contenedor
```

---

## 8. De dónde salen las imágenes

Las imágenes no se crean solas en el equipo. Se descargan de un **registro** (un servidor que guarda imágenes y las entrega por su nombre) o se cargan desde un fichero.

| Vía | Cómo funciona | Cuándo |
|---|---|---|
| **A: Docker Hub** | Registro público por defecto: `docker pull nginx` | Cuando la red lo permite |
| **B: espejo `mirror.gcr.io`** | Copia de las imágenes oficiales en un servidor de Google: `docker pull mirror.gcr.io/library/nginx` | Cuando Docker Hub está bloqueado pero el espejo responde |
| **C: fichero `.tar` del Drive** | Alguien guarda la imagen con `docker save` y los demás la cargan con `docker load` | Cuando no hay ningún registro accesible |

```
 Docker Hub ──pull──┐
 Espejo ───────pull─┼──►  docker images   (la imagen está en el equipo)
 Fichero .tar ─load─┘
```

En las tres vías el resultado es el mismo: la imagen aparece en `docker images`.

---

## 9. Los comandos de Docker

### Estructura general

```
 docker  run  -d -p 8081:80  nginx
   │      │        │           │
   │      │        │           └─ argumento: sobre qué se actúa
   │      │        └───────────── opciones: modifican la acción
   │      └────────────────────── comando: la acción
   └───────────────────────────── programa cliente (envía órdenes al motor)
```

| Elemento | Qué es |
|---|---|
| `docker` | El programa cliente, que envía las órdenes al motor |
| **Comando** | La acción (`run`, `pull`, `build`...) |
| **Opciones** | Modifican la acción. Empiezan por `-` (forma corta, una letra: `-d`) o `--` (forma larga: `--name`). Las cortas sin valor se pueden juntar: `-it` es `-i -t` |
| **Argumentos** | Sobre qué se actúa: una imagen, un contenedor |

> **Las opciones van antes del argumento principal.** `docker run -d -p 8081:80 nginx` es correcto; `docker run nginx -d -p 8081:80` no, porque lo que va tras el nombre de la imagen se interpreta como comando para ejecutar dentro del contenedor.

Los contenedores se señalan por **nombre** o por **identificador** (bastan los primeros caracteres, si no hay ambigüedad). Las imágenes, por `nombre:etiqueta` o por su `ID`.

### Mapa: qué comando actúa sobre qué

| Sobre **imágenes** | Sobre **contenedores** |
|---|---|
| `pull`, `images`, `history`, `tag`, `rmi`, `build`, `save`, `load`, `login`, `push` | `run`, `create`, `ps`, `logs`, `stop`, `start`, `restart`, `rm`, `exec` |

`inspect` sirve para ambos.

### Tabla de referencia rápida

| Grupo | Comando | Para qué sirve | ¿En S16-1? |
|---|---|---|---|
| Imágenes | `docker pull` | Descargar una imagen de un registro | Sí |
| | `docker images` | Listar las imágenes del equipo | Sí |
| | `docker history` | Ver las capas de una imagen | Sí |
| | `docker inspect` | Ver los detalles completos de una imagen o contenedor | Sí |
| | `docker tag` | Dar otro nombre o etiqueta a una imagen | Sí |
| | `docker rmi` | Borrar una imagen | Sí |
| | `docker build` | Construir una imagen desde un `Dockerfile` | Sí |
| | `docker save` | Guardar una imagen en un fichero `.tar` | Sí |
| | `docker load` | Cargar una imagen desde un fichero `.tar` | Sí |
| | `docker login` | Iniciar sesión en un registro | Solo con Docker Hub |
| | `docker push` | Subir una imagen a un registro | Solo con Docker Hub |
| Contenedores | `docker run` | Crear y arrancar un contenedor | Sí |
| | `docker ps` | Listar contenedores | Sí |
| | `docker logs` | Ver la salida de un contenedor | Sí |
| | `docker stop` | Detener un contenedor | Sí |
| | `docker start` | Arrancar un contenedor parado | Sí |
| | `docker rm` | Borrar un contenedor | Sí |
| | `docker restart` | Detener y arrancar | Ocasional |
| | `docker exec` | Ejecutar un comando dentro de un contenedor en marcha | Ocasional |
| | `docker create` | Crear un contenedor sin arrancarlo | Ocasional |

---

### Comandos de imágenes

#### `docker pull`: descargar una imagen

```
docker pull [opciones] NOMBRE[:ETIQUETA]
```

| Parte | Significado |
|---|---|
| `NOMBRE` | La imagen. Puede llevar registro y espacio de nombres (`mirror.gcr.io/library/nginx`) |
| `:ETIQUETA` | La versión. Si se omite, es `latest` |

Descarga solo las capas que faltan (apartado 5).

```bash
docker pull nginx
docker pull postgres:17
docker pull mirror.gcr.io/library/nginx
```

#### `docker images`: listar imágenes

```
docker images [opciones] [NOMBRE[:ETIQUETA]]
```

Sin argumentos lista todas las imágenes del equipo; con un nombre, filtra por él. Equivale a `docker image ls`. En Docker 29 (Docker Desktop 4.96.3) las columnas son:

| Columna | Qué muestra |
|---|---|
| `IMAGE` | Nombre y etiqueta juntos (`nginx:latest`) |
| `ID` | Código corto de la imagen |
| `DISK USAGE` | Espacio que ocupa descomprimida en el disco |
| `CONTENT SIZE` | Tamaño comprimido, el que se descarga |
| `EXTRA` | Una `U` indica que algún contenedor usa la imagen |

Las versiones anteriores mostraban `REPOSITORY`, `TAG`, `IMAGE ID`, `CREATED` y `SIZE`.

#### `docker history`: ver las capas

```
docker history [opciones] NOMBRE[:ETIQUETA]
```

Una línea por capa, de la más reciente a la más antigua.

| Columna | Qué muestra |
|---|---|
| `IMAGE` | Código de la capa; a veces `<missing>`, que es normal |
| `CREATED` | Cuándo se creó |
| `CREATED BY` | La instrucción que la creó (cortada por defecto) |
| `SIZE` | Su tamaño (`0B` si no añade ficheros) |
| `COMMENT` | Información adicional |

Con `--no-trunc` se ve la instrucción completa.

#### `docker inspect`: detalles completos

```
docker inspect [opciones] NOMBRE_O_ID
```

Devuelve en JSON toda la información de una imagen o un contenedor: etiquetas, variables de entorno, puerto expuesto, comando de arranque, capas, red... Con `--format` se extrae un solo dato:

```bash
docker inspect --format "{{.Config.ExposedPorts}}" nginx
```

#### `docker tag`: poner otro nombre

```
docker tag ORIGEN[:ETIQUETA] DESTINO[:ETIQUETA]
```

No copia la imagen: crea **otro nombre** que apunta a la misma (mismo `ID`). Sirve para renombrar o para preparar una imagen antes de subirla a un registro.

```bash
docker tag contactos:1.0 usuario/contactos:1.0
```

#### `docker rmi`: borrar una imagen

```
docker rmi [opciones] NOMBRE[:ETIQUETA] ...
```

| Detalle | Significado |
|---|---|
| `rmi` | *Remove image* |
| Qué borra | El nombre y, si no queda otro nombre apuntando a ella, las capas que no use otra imagen |
| Cuándo falla | Si un contenedor, **aunque esté parado**, usa la imagen: hay que borrar antes el contenedor |
| `-f` (`--force`) | Fuerza el borrado |

#### `docker build`: construir una imagen

```
docker build [opciones] CONTEXTO
```

| Parte | Significado |
|---|---|
| `CONTEXTO` | La carpeta cuyo contenido puede usar `COPY`. Casi siempre `.` (la carpeta actual). **El punto es obligatorio** |
| `-t NOMBRE:ETIQUETA` (`--tag`) | El nombre que tendrá la imagen. Sin él, queda sin nombre |
| `-f RUTA` (`--file`) | Ruta del `Dockerfile`, si no se llama así o no está en el contexto |
| `--no-cache` | Ignora la caché y reconstruye todas las capas |

```bash
docker build -t contactos:1.0 .
```

Se lee: "construye una imagen llamada `contactos` con etiqueta `1.0`, usando el `Dockerfile` y los ficheros de la carpeta actual".

#### `docker save` y `docker load`: imágenes en un fichero

```
docker save -o FICHERO.tar NOMBRE[:ETIQUETA]
docker load -i FICHERO.tar
```

| Opción | Significado |
|---|---|
| `save -o` | Guarda la imagen (con todas sus capas) en un fichero. `-o` es *output* |
| `load -i` | Lee la imagen de un fichero y la registra en el equipo. `-i` es *input* |

Es la vía para repartir imágenes por Drive, correo o USB cuando no hay registro. El fichero ocupa tanto como la imagen.

```bash
docker save -o nginx.tar nginx
docker load -i nginx.tar
```

#### `docker login` y `docker push`: publicar (solo con Docker Hub)

```
docker login [SERVIDOR]
docker push NOMBRE[:ETIQUETA]
```

| Comando | Qué hace |
|---|---|
| `login` | Pide usuario y contraseña (o token) y los recuerda para las operaciones siguientes |
| `push` | Sube la imagen. Su nombre debe empezar por el usuario del registro (`usuario/contactos:1.0`), por eso antes se usa `docker tag`. Solo sube las capas que el registro no tiene |

---

### Comandos de contenedores

#### `docker run`: crear y arrancar un contenedor

```
docker run [opciones] IMAGEN[:ETIQUETA] [COMANDO]
```

Es el comando más importante y el que más opciones tiene. Hace dos cosas seguidas: **crear** el contenedor a partir de la imagen y **arrancarlo**. Si la imagen no está en el equipo, la descarga antes.

| Opción | Forma larga | Qué hace |
|---|---|---|
| `-d` | `--detach` | Ejecuta en segundo plano; la terminal queda libre |
| `-p EQUIPO:CONTENEDOR` | `--publish` | Publica un puerto: lo que llegue al puerto `EQUIPO` del equipo se redirige al `CONTENEDOR` |
| `--name NOMBRE` | | Da un nombre único al contenedor |
| `-e VARIABLE=valor` | `--env` | Define una variable de entorno dentro del contenedor |
| `-it` | `--interactive --tty` | Terminal interactiva (`-i` mantiene la entrada abierta, `-t` asigna una terminal) |
| `--rm` | | Borra el contenedor automáticamente al detenerse |
| `-v NOMBRE:RUTA` | `--volume` | Monta un volumen (S16-2) |

Ejemplos:

```bash
docker run -d -p 8081:80 --name web nginx
docker run -d -p 8081:8080 --name api -e SALUDO=Hola contactos:1.0
```

Cómo se lee la segunda línea:

```
 docker run  -d  -p 8081:8080  --name api  -e SALUDO=Hola  contactos:1.0
             │   │             │           │               └─ la imagen
             │   │             │           └─ variable de entorno para la aplicación
             │   │             └─ nombre del contenedor
             │   └─ puerto 8081 del equipo → puerto 8080 del contenedor
             └─ en segundo plano
```

> **Puertos:** el **primer** número de `-p` es del equipo (el que escribimos en el navegador) y el **segundo** es del contenedor (el que usa la aplicación). Ocupados en el equipo: 8080 (Jenkins), 5432 (PostgreSQL), 27017 (MongoDB).

```
 navegador ──► localhost:8081 ──[ -p 8081:80 ]──► puerto 80 del contenedor
     (equipo)                                          (dentro de Docker)
```

#### `docker ps`: listar contenedores

```
docker ps [opciones]
```

Sin opciones, solo los **contenedores en marcha**. Con `-a` (`--all`), también los parados o que no llegaron a arrancar.

| Columna | Qué muestra |
|---|---|
| `CONTAINER ID` | Identificador corto |
| `IMAGE` | Imagen de la que sale |
| `COMMAND` | Comando que ejecuta |
| `CREATED` | Cuándo se creó |
| `STATUS` | `Up` (en marcha), `Exited (0)` (parado sin errores), `Created` |
| `PORTS` | Puertos publicados (`0.0.0.0:8081->80/tcp`) |
| `NAMES` | Nombre del contenedor |

#### `docker logs`: ver la salida

```
docker logs [opciones] CONTENEDOR
```

Muestra lo que el programa ha escrito en su salida estándar. Es la primera herramienta para entender por qué un contenedor falla.

| Opción | Qué hace |
|---|---|
| `-f` (`--follow`) | Sigue mostrando líneas nuevas hasta pulsar `Ctrl+C` |
| `--tail N` | Solo las últimas N líneas |

#### `docker stop`, `docker start` y `docker restart`

```
docker stop CONTENEDOR
docker start CONTENEDOR
docker restart CONTENEDOR
```

| Comando | Qué hace |
|---|---|
| `stop` | Pide al programa que termine y lo para (`Exited`). El contenedor **sigue existiendo** |
| `start` | Arranca uno ya creado y parado, conservando sus opciones originales (nombre, puertos) |
| `restart` | `stop` más `start` |

#### `docker rm`: borrar un contenedor

```
docker rm [opciones] CONTENEDOR ...
```

Borra contenedores **parados**; con `-f` (`--force`) también uno en marcha. Libera el nombre, pero no toca la imagen.

#### `docker exec`: ejecutar algo dentro de un contenedor

```
docker exec [opciones] CONTENEDOR COMANDO
```

Lanza un comando dentro de un contenedor **que ya está en marcha**. Con `-it` abre una sesión interactiva: `docker exec -it postgres-demo psql -U postgres`.

---

## 10. Qué hay que saber para el test

| Pregunta | Idea clave |
|---|---|
| 1. Imagen y contenedor | La imagen es la plantilla de solo lectura; el contenedor, esa imagen en ejecución. Como clase y objetos |
| 2. Contenedor y máquina virtual | El contenedor comparte el núcleo del equipo; la máquina virtual lleva un sistema operativo completo |
| 3. Capas | Imágenes con la misma base comparten capas: ahorran espacio y descarga. `docker history` las muestra. Se identifican con nombre y etiqueta |
| 4. `Dockerfile` | Fichero de texto que describe, instrucción a instrucción, cómo construir una imagen. `docker build` lo sigue. Se versiona con el código |

---

## Resumen

| Concepto | En una línea |
|---|---|
| Docker | Entrega el **entorno ya preparado** junto a la aplicación |
| Imagen / contenedor | Plantilla de solo lectura / imagen en ejecución |
| Contenedor / máquina virtual | El contenedor **comparte el núcleo**; la máquina virtual lleva sistema operativo completo |
| Capas | De solo lectura, se comparten entre imágenes y se reutilizan al construir |
| Nombre:etiqueta | Identifica la imagen. `latest` es solo un nombre de etiqueta, no "la última" |
| `Dockerfile` | La receta. `docker build` construye la imagen y `docker run` la ejecuta |
| `EXPOSE` / `-p` | `EXPOSE` documenta el puerto; `-p` lo publica |
| Sin Docker Hub | Las imágenes llegan por **espejo** (`mirror.gcr.io`) o por **fichero** (`docker save` y `docker load`) |
