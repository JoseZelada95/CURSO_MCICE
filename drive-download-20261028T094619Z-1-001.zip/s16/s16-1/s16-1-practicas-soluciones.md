# S16-1 Soluciones

Las salidas de este documento muestran el formato de Docker 29 (Docker Desktop 4.96.3). Los identificadores, los tamaños y las fechas son orientativos: en cada equipo salen otros. El código es el de la carpeta `contactos-docker` de `s16-1-practicas.zip`, que es la solución de las Prácticas 1 y 2.

---

## Práctica 1: Dockerfile de la API de contactos

La aplicación de partida (`contactos-docker-base`) ya funciona fuera de Docker. Empaquetarla en una imagen consiste en escribir un `Dockerfile` con las mismas cuatro instrucciones de la Demo 2. Lo único que cambia es el nombre del JAR, porque el `artifactId` del `pom.xml` es `contactos-docker` y no `contactos`.

Primero se construye el JAR y se prueba sin Docker, para saber que la aplicación funciona antes de meterla en una imagen:

```bash
mvn clean package
```

```bash
java -jar target\contactos-docker-0.0.1-SNAPSHOT.jar --server.port=8085
```

En `http://localhost:8085/api/contactos` sale la lista con los dos contactos de ejemplo:

<pre>
[{"id":1,"nombre":"Lucía Pérez","email":"lucia@example.com","telefono":"600123456"},{"id":2,"nombre":"Ana Ruiz","email":"ana@example.com","telefono":null}]
</pre>

El `Dockerfile` se crea en la raíz del proyecto, junto al `pom.xml`:

```dockerfile
# S16-1 Práctica 1: Dockerfile de la API de contactos
#
# Objetivo: empaquetar la API de contactos en una imagen de Docker.
#
# Aplica las técnicas de S16:
#   1. FROM con una imagen que ya trae Java.
#   2. COPY del JAR que construye Maven en nuestro equipo.
#   3. EXPOSE y ENTRYPOINT para documentar el puerto y arrancar la aplicación.
#
# Concepto clave: es el mismo Dockerfile de la Demo 2 con otro nombre de JAR. Cambia el
# JAR, pero el Dockerfile sigue teniendo cuatro instrucciones.
#
# Se construye con:  docker build -t contactos:1.0 .
# (el JAR tiene que existir antes: se genera con mvn package)

# Partimos de la imagen oficial con Java 21 y solo el JRE: basta para ejecutar un JAR ya compilado.
FROM eclipse-temurin:21-jre

# Copiamos el JAR de Spring Boot que dejó "mvn package" en target/. El nombre del origen
# es artifactId-version.jar; si no coincide exactamente con el fichero de target/,
# docker build falla con un error de "not found". Dentro de la imagen se llama app.jar.
COPY target/contactos-docker-0.0.1-SNAPSHOT.jar app.jar

# La aplicación escucha por defecto en el puerto 8080 del contenedor. EXPOSE solo lo anota:
# para llegar a él desde Windows hay que publicarlo con "-p" al ejecutar el contenedor.
# Si cambiamos el puerto con la variable PUERTO (Práctica 2), este número no se actualiza:
# EXPOSE es documentación y no influye en el funcionamiento.
EXPOSE 8080

# Comando que se ejecuta al arrancar un contenedor de esta imagen: java -jar app.jar.
# Las variables de entorno que definimos con "docker run -e" llegan al proceso de Java,
# y Spring las lee a través de application.properties.
ENTRYPOINT ["java", "-jar", "app.jar"]
```

Con la imagen base en el equipo (variante A, B o C, como en la Demo 2), se construye y se mira el resultado:

```bash
docker build -t contactos:1.0 .
```

```bash
docker images
```

```bash
docker history contactos:1.0
```

<pre>
C:\Users\Mananas\contactos-docker>docker images
IMAGE                    ID             DISK USAGE   CONTENT SIZE   EXTRA
contactos:1.0            3c5f0a9d21b8        334MB          141MB
eclipse-temurin:21-jre   1a66e3b47da9        314MB          121MB
</pre>

Se ejecuta el contenedor y se prueba:

```bash
docker run -d -p 8081:8080 --name contactos contactos:1.0
```

En `http://localhost:8081/api/contactos` sale la misma lista que sin Docker. El `POST` desde Postman (`POST http://localhost:8081/api/contactos`, `Body > raw > JSON`):

<pre>
{"nombre": "Luis Gomez", "email": "luis@example.com"}
</pre>

La respuesta es un `201` con el contacto creado, ya con su `id`:

<pre>
{"id":3,"nombre":"Luis Gomez","email":"luis@example.com","telefono":null}
</pre>

Al volver a listar aparecen tres contactos. Ahora se borra el contenedor y se crea otro igual:

```bash
docker rm -f contactos
```

```bash
docker run -d -p 8081:8080 --name contactos contactos:1.0
```

La lista vuelve a tener solo los dos contactos de ejemplo: el contacto `Luis Gomez` ha desaparecido. Los datos estaban en la memoria de la aplicación, dentro del contenedor, y al borrar el contenedor se perdieron. Un contenedor nuevo nace de la imagen, que no se ha modificado, y por eso arranca como el primero. Es el problema que resuelven los volúmenes y las bases de datos en contenedores de S16-2.

Por último, el error provocado: si el `COPY` nombra un JAR que no existe (por ejemplo `contactos-0.0.1-SNAPSHOT.jar`), `docker build` se detiene en esa línea:

<pre>
Dockerfile:22
--------------------
  20 |     # es artifactId-version.jar; si no coincide exactamente con el fichero de target/,
  21 |     # docker build falla con un error de "not found". Dentro de la imagen se llama app.jar.
  22 | >>> COPY target/contactos-0.0.1-SNAPSHOT.jar app.jar
--------------------
ERROR: failed to build: failed to solve: failed to compute cache key: failed to calculate checksum of ref ...: "/target/contactos-0.0.1-SNAPSHOT.jar": not found
</pre>

El mensaje señala la línea (`>>>`) y el fichero que no encuentra. La solución es escribir el nombre que aparece de verdad en `target`.

**Decisiones tomadas**
- El `Dockerfile` copia el JAR ya construido en lugar de compilar dentro de la imagen. La imagen no necesita Maven ni el código fuente, y es más pequeña. Es el mismo criterio de la Demo 2.
- Se usa `eclipse-temurin:21-jre` y no una imagen con JDK completo: para ejecutar un JAR ya compilado basta con el JRE, y el JDK ocupa más.
- `EXPOSE 8080` documenta el puerto, pero no lo publica. Por eso `docker run` lleva `-p 8081:8080`.
- El repositorio guarda los contactos en una lista en memoria, sin base de datos, para que la aplicación se pueda probar en un contenedor sin instalar nada más. Esa decisión es la que permite ver cómo se pierden los datos al borrar el contenedor.
- El `Dockerfile` usa la forma de lista en `ENTRYPOINT` para que Java sea el proceso principal del contenedor y reciba directamente la orden de `docker stop`.

---

## Práctica 2: Configuración con variables de entorno

La imagen de la Práctica 1 tiene el saludo escrito en el código. Para cambiarlo sin reconstruir, el valor se saca a `application.properties`, y allí se lee de una variable de entorno. Como Docker pasa las variables con `-e`, cada contenedor de la misma imagen se puede configurar de forma distinta.

`application.properties` define dos propiedades con el patrón `${VARIABLE:valor}`:

```properties
# Nombre de la aplicación: aparece entre corchetes en cada línea del log (S05-1).
spring.application.name=contactos-docker

# Puerto en el que escucha Tomcat dentro del contenedor.
# ${PUERTO:8080} se lee "el valor de la variable de entorno PUERTO; si no existe, 8080".
# Lo que va después de los dos puntos es el valor por defecto. Sin él, la aplicación
# no arrancaría cuando la variable no estuviera definida (como en S07 con POSTGRES_PASSWORD).
server.port=${PUERTO:8080}

# Texto del saludo. Mismo mecanismo: la variable SALUDO, o el texto por defecto.
# Los valores por defecto de este fichero van sin tildes para evitar problemas con
# los comandos de Windows, que no siempre escriben bien las tildes en la terminal.
app.saludo=${SALUDO:Hola desde la API de contactos}
```

`${PUERTO:8080}` se lee "el valor de la variable de entorno `PUERTO`, y si no existe, 8080". El valor por defecto es lo que permite arrancar la aplicación sin ninguna variable, que es lo que ocurría en la Práctica 1.

`SaludoController` recibe el saludo en el constructor:

```java
package com.curso.controller;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.LinkedHashMap;
import java.util.Map;

// Value procede de spring-beans, que trae el starter. Maven la ha descargado al cargar el pom.xml.
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * S16-1 Práctica 2: Saludo configurable por variable de entorno
 *
 * Objetivo: que el texto del saludo se pueda cambiar al ejecutar el contenedor,
 * sin tocar el código ni reconstruir la imagen.
 *
 * Aplica las técnicas de S16:
 *   1. Una propiedad de application.properties que lee una variable de entorno.
 *   2. Un valor por defecto para cuando la variable no está definida.
 *   3. La opción -e de docker run para definir la variable.
 *
 * Concepto clave: una imagen que se configura desde fuera es reutilizable. La misma
 * imagen sirve en cualquier equipo, y cada contenedor se configura al arrancar.
 */
@RestController
@RequestMapping("/api")
public class SaludoController {

    // El texto del saludo. Es final porque se asigna una sola vez, al crear el controlador.
    private final String saludo;

    // Spring entrega aquí el valor de la propiedad app.saludo (inyección por constructor, S06-1).
    // @Value("${app.saludo}") le dice a Spring que busque la propiedad "app.saludo" en
    // application.properties y pase su valor como parámetro. En ese fichero, app.saludo
    // se define a su vez a partir de la variable de entorno SALUDO.
    public SaludoController(@Value("${app.saludo}") String saludo) {
        this.saludo = saludo;
    }

    /**
     * Devuelve el saludo configurado y el nombre del equipo en el que se ejecuta la API.
     *
     * Ejemplo:
     *   sin variable SALUDO         →  {"mensaje":"Hola desde la API de contactos","equipo":"3f2a9c1b7d4e"}
     *   con SALUDO=Buenas tardes    →  {"mensaje":"Buenas tardes","equipo":"8b1d5e7a2c90"}
     */
    @GetMapping("/saludo")
    public Map<String, String> saludo() throws UnknownHostException {
        Map<String, String> respuesta = new LinkedHashMap<>();
        // Ya no hay un texto fijo: usamos el valor que Spring nos entregó en el constructor.
        respuesta.put("mensaje", saludo);
        respuesta.put("equipo", InetAddress.getLocalHost().getHostName());
        return respuesta;
    }
}
```

`@Value("${app.saludo}")` busca la propiedad `app.saludo` y pasa su valor como parámetro. El controlador no sabe de dónde viene el texto: puede ser el valor por defecto de `application.properties` o el de la variable `SALUDO`. El `Dockerfile` no cambia.

Se reconstruye el JAR y la imagen con una etiqueta nueva:

```bash
mvn clean package
```

```bash
docker build -t contactos:1.1 .
```

```bash
docker images
```

<pre>
C:\Users\Mananas\contactos-docker>docker images
IMAGE                    ID             DISK USAGE   CONTENT SIZE   EXTRA
contactos:1.0            3c5f0a9d21b8        334MB          141MB
contactos:1.1            9d2e7b61f4a0        334MB          141MB
eclipse-temurin:21-jre   1a66e3b47da9        314MB          121MB
</pre>

Se ejecutan dos contenedores de la misma imagen, uno sin variable y otro con ella:

```bash
docker run -d -p 8081:8080 --name contactos-a contactos:1.1
```

```bash
docker run -d -p 8082:8080 --name contactos-b -e "SALUDO=Buenas tardes" contactos:1.1
```

<pre>
http://localhost:8081/api/saludo
{"mensaje":"Hola desde la API de contactos","equipo":"5f7c1a3e9b20"}

http://localhost:8082/api/saludo
{"mensaje":"Buenas tardes","equipo":"c0d41b8e7a65"}
</pre>

La imagen es la misma y el resultado es distinto: el segundo contenedor recibió la variable `SALUDO` y la propiedad `app.saludo` tomó ese valor. El campo `equipo` también difiere, porque es el identificador de cada contenedor.

Con la variable `PUERTO`, hay que tener en cuenta que `-p` solo conecta puertos y no cambia el de la aplicación. Si la aplicación pasa a escuchar en el 9090 y se publica `-p 8083:8080`, el equipo reenvía al 8080 del contenedor, donde ya no hay nadie:

```bash
docker run -d -p 8083:8080 --name contactos-c -e PUERTO=9090 contactos:1.1
```

`http://localhost:8083/api/saludo` no responde (la conexión se cierra o se rechaza). El registro explica por qué:

```bash
docker logs contactos-c
```

<pre>
... o.s.boot.tomcat.TomcatWebServer      : Tomcat started on port 9090 (http) with context path '/'
</pre>

Tomcat escucha en el 9090 dentro del contenedor. La solución es que el segundo número de `-p` sea ese:

```bash
docker rm -f contactos-c
```

```bash
docker run -d -p 8083:9090 --name contactos-c -e PUERTO=9090 contactos:1.1
```

Ahora `http://localhost:8083/api/saludo` responde. Las variables de entorno de un contenedor se ven con `docker inspect`:

```bash
docker inspect --format "{{.Config.Env}}" contactos-b
```

<pre>
[SALUDO=Buenas tardes PATH=/opt/java/openjdk/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin JAVA_HOME=/opt/java/openjdk ...]
</pre>

La lista incluye la variable que se pasó y otras que ya traía la imagen base (`PATH`, `JAVA_HOME`...). Para terminar se borran los contenedores:

```bash
docker rm -f contactos-a contactos-b contactos-c
```

**Decisiones tomadas**
- Se usa una variable de entorno y no un argumento de línea de comandos porque es la forma habitual de configurar contenedores: `docker run -e` funciona igual con cualquier imagen, y herramientas posteriores (Docker Compose, S16-2) usan el mismo mecanismo.
- Los dos valores llevan un valor por defecto para que la aplicación arranque sin ninguna variable. Sin él, `${SALUDO}` no resuelto impediría arrancar.
- `EXPOSE 8080` no se cambia aunque el puerto sea configurable: `EXPOSE` es documentación del puerto por defecto, no influye en el funcionamiento.
- El saludo por defecto va sin tildes porque la consola de Windows no siempre las muestra bien al pasar texto por la línea de comandos.
- Se usa una etiqueta nueva (`1.1`) y no se reutiliza `1.0`: así la versión anterior sigue disponible y se pueden comparar.

---

## Práctica 3: Compartir una imagen con un compañero

El propósito es comprobar que una imagen viaja completa: quien la recibe ejecuta la aplicación sin Java, sin Maven y sin el proyecto. Cada alumno cambia el saludo por defecto de `application.properties` (por ejemplo, `app.saludo=${SALUDO:Hola de Ana}`), reconstruye el JAR y la imagen con la etiqueta `1.2`:

```bash
mvn clean package
```

```bash
docker build -t contactos:1.2 .
```

**Variante A: Docker Hub.** La imagen necesita en su nombre el usuario de Docker Hub:

```bash
docker tag contactos:1.2 usuario/contactos:1.2
```

```bash
docker push usuario/contactos:1.2
```

La pareja la descarga y la ejecuta (basta el nombre completo, `docker run` la descarga si no la tiene):

```bash
docker run -d -p 8081:8080 --name contactos-pareja usuario/contactos:1.2
```

**Variantes B y C: un fichero.** Cada alumno pone a su imagen un nombre con el suyo (para que al cargarla el compañero no pise su propia etiqueta `contactos:1.2`), la guarda en un fichero y la sube a la carpeta compartida:

```bash
docker tag contactos:1.2 contactos-ana:1.2
```

```bash
docker save -o contactos-ana-1.2.tar contactos-ana:1.2
```

La pareja descarga el fichero y lo carga:

```bash
docker load -i contactos-ana-1.2.tar
```

<pre>
C:\Users\Mananas>docker load -i contactos-ana-1.2.tar
Loaded image: contactos-ana:1.2
</pre>

```bash
docker run -d -p 8081:8080 --name contactos-pareja contactos-ana:1.2
```

En ambos casos `http://localhost:8081/api/saludo` muestra el saludo de la otra persona. Se ejecuta ahora un segundo contenedor de esa imagen con la variable, y se comprueba que se impone al valor que traía la imagen (aquí con la variante B o C; en la A se usa el nombre `usuario/contactos:1.2`):

```bash
docker run -d -p 8082:8080 --name contactos-pareja2 -e "SALUDO=Buenas desde mi equipo" contactos-ana:1.2
```

La respuesta de `http://localhost:8082/api/saludo` trae `"mensaje":"Buenas desde mi equipo"`. Para terminar se borran los contenedores y la imagen:

```bash
docker rm -f contactos-pareja contactos-pareja2
```

```bash
docker rmi contactos-ana:1.2
```

<pre>
C:\Users\Mananas>docker rmi contactos-ana:1.2
Untagged: contactos-ana:1.2
Deleted: sha256:5e2b9c7d41a8...
</pre>

**Decisiones tomadas**
- Se comparte la imagen y no el proyecto: quien la recibe no necesita Java, Maven ni el código, solo Docker. Es la ventaja de empaquetar la aplicación con su entorno.
- En las variantes B y C se pone el nombre de cada alumno a la imagen. Si dos alumnos guardan `contactos:1.2` y se cargan una tras otra, la segunda deja sin nombre a la primera, sin ningún aviso.
- El espejo `mirror.gcr.io` solo permite descargar, por eso en B y C el camino es `docker save` y `docker load`, igual que en la Demo 3.
- La carga con `docker load` no duplica `eclipse-temurin`: las capas que ya existen en el equipo se reutilizan, y lo único nuevo es la capa del JAR.
- Al borrar, el orden es siempre contenedores primero, imagen después: un contenedor, aunque esté parado, necesita su imagen.
