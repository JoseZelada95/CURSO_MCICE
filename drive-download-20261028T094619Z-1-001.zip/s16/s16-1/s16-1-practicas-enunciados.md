# S16-1 Prácticas

## Objetivos

En las demos hemos construido la imagen de una aplicación Spring Boot y la hemos ejecutado. En estas prácticas se hace lo mismo con otra aplicación, la API de contactos, y se avanza un paso: la aplicación se configura desde fuera con variables de entorno y la imagen se comparte con otra persona.

Las tres prácticas usan los mismos comandos de las demos. Cuando hay que conseguir o compartir una imagen, se sigue la variante (A, B o C) que se estableció en el apartado "Antes de empezar" de las demos, según lo que permita la red del aula:

| Variante | Conseguir `eclipse-temurin:21-jre` | Compartir una imagen propia |
|---|---|---|
| **A: Docker Hub** | `docker pull eclipse-temurin:21-jre` | `docker push` y `docker pull` |
| **B: espejo `mirror.gcr.io`** | `docker pull mirror.gcr.io/library/eclipse-temurin:21-jre`, `docker tag` al nombre corto y `docker rmi` del largo | `docker save` y `docker load` |
| **C: Drive** | `docker load -i eclipse-temurin.tar` | `docker save` y `docker load` |

Si la imagen `eclipse-temurin:21-jre` ya está en el equipo desde las demos, no hay que conseguirla otra vez.

Al terminar, el alumno es capaz de:
- Escribir el `Dockerfile` de una aplicación Spring Boot propia y construir su imagen.
- Comprobar que los datos de un contenedor desaparecen al borrarlo.
- Configurar una aplicación con variables de entorno que se pasan con `docker run -e`.
- Ejecutar varios contenedores de la misma imagen con configuraciones distintas.
- Compartir una imagen con un compañero y ejecutar la suya.

Todas las prácticas parten de `s16-1-practicas.zip`, que contiene la carpeta `contactos-docker-base`.

---

## Práctica 1: Dockerfile de la API de contactos

La carpeta `contactos-docker-base` es una API de contactos que guarda los datos en una lista en memoria (sin base de datos). Tiene tres rutas: `GET /api/contactos`, `GET /api/contactos/{id}` y `POST /api/contactos`, y una cuarta, `GET /api/saludo`, que responde con un texto fijo y el nombre del equipo. Todavía no tiene `Dockerfile`: hay que escribirlo.

**Pasos**
1. Descomprimimos el zip y abrimos en IntelliJ la carpeta `contactos-docker-base` (`File > Open`, la que contiene directamente el `pom.xml`). Pulsamos `Trust Project` y `Load` si aparece el aviso de Maven.
2. Abrimos la terminal de IntelliJ y construimos el JAR con `mvn clean package`. Anotamos el nombre exacto del JAR que aparece en `target`.
3. Probamos la aplicación sin Docker en el puerto 8085 (el 8080 lo ocupa Jenkins) y comprobamos en el navegador la lista de contactos y el saludo. Paramos la aplicación con `Ctrl+C`.
4. Nos aseguramos de tener la imagen `eclipse-temurin:21-jre` en el equipo, con la vía de nuestra variante.
5. Creamos en la raíz del proyecto el fichero `Dockerfile`, con una imagen base, la copia del JAR, el puerto de la aplicación y el comando de arranque.
6. Construimos la imagen con el nombre `contactos` y la etiqueta `1.0`, y miramos con `docker images` y `docker history` qué ha creado.
7. Ejecutamos un contenedor en segundo plano, llamado `contactos`, publicando el puerto de la aplicación en el 8081 del equipo, y comprobamos en el navegador `http://localhost:8081/api/contactos`.
8. Creamos un contacto nuevo con una petición `POST` (con Postman, S09; este proyecto no tiene Swagger) y comprobamos que aparece al volver a listar.
9. Borramos el contenedor, creamos otro igual desde la misma imagen y listamos los contactos. Anotamos qué ha pasado con el contacto que creamos.
10. Provocamos a propósito un error: cambiamos en el `Dockerfile` el nombre del JAR por uno que no existe, ejecutamos `docker build` y leemos el mensaje. Después lo dejamos como estaba.

**Pistas**
- El nombre del JAR es `artifactId-version.jar`. El `artifactId` de este proyecto no es `contactos`: se mira en el `pom.xml`.
- Las cuatro instrucciones que hacen falta son `FROM`, `COPY`, `EXPOSE` y `ENTRYPOINT` (la última, en forma de lista).
- El punto final de `docker build` es el contexto de construcción: sin él, el comando falla.
- La aplicación escucha en el puerto 8080 del contenedor. En `-p equipo:contenedor`, el primer número es el del equipo.
- Para el `POST` hace falta enviar el cuerpo en formato JSON, con las claves `nombre` y `email` (el teléfono es opcional), y la cabecera `Content-Type: application/json` (Postman la añade al elegir `Body > raw > JSON`).
- Un contenedor nuevo parte de la imagen, no del contenedor anterior. Hay que pensar dónde guarda los datos la aplicación.

---

## Práctica 2: Configuración con variables de entorno

Con la imagen de la Práctica 1, el saludo y el puerto de la aplicación son fijos: para cambiarlos habría que modificar el código y reconstruir. Se va a hacer que se puedan cambiar al arrancar el contenedor, sin tocar la imagen. Se trabaja sobre el mismo proyecto.

**Pasos**
1. En `application.properties`, hacemos que el puerto del servidor se lea de la variable de entorno `PUERTO`, con 8080 como valor por defecto, y añadimos una propiedad `app.saludo` que se lea de la variable `SALUDO`, con un texto por defecto sin tildes.
2. En `SaludoController`, sustituimos el texto fijo por el valor de `app.saludo`, que Spring entrega en el constructor.
3. Reconstruimos el JAR con `mvn clean package` y la imagen con la etiqueta `1.1` (`contactos:1.1`). Comprobamos con `docker images` que ahora hay dos versiones.
4. Ejecutamos un contenedor de `contactos:1.1` sin ninguna variable y comprobamos que el saludo es el de por defecto.
5. Ejecutamos otro con la variable `SALUDO` (un texto con espacios, entre comillas) y comprobamos que cambia el saludo, sin haber reconstruido nada.
6. Con los dos contenedores en marcha a la vez (puertos 8081 y 8082 del equipo), comparamos las dos respuestas de `/api/saludo` y los campos `equipo`.
7. Ejecutamos un contenedor con `PUERTO=9090`. Primero publicamos el puerto como siempre (`-p 8083:8080`) y comprobamos que no responde. Miramos el registro con `docker logs` para ver en qué puerto escucha Tomcat. Después lo repetimos publicando el puerto correcto.
8. Consultamos con `docker inspect --format` las variables de entorno de uno de los contenedores y comparamos con las que hemos pasado.
9. Borramos todos los contenedores.

**Pistas**
- La sintaxis de una propiedad con valor por defecto es `${VARIABLE:valor}`: lo que va después de los dos puntos se usa si la variable no existe.
- `@Value("${app.saludo}")` en el parámetro del constructor entrega el valor de la propiedad. `@Value` es de `org.springframework.beans.factory.annotation`.
- Con `docker run`, cada variable se pasa con una opción `-e NOMBRE=valor`, antes del nombre de la imagen. En `cmd`, si el valor lleva espacios, se escribe `-e "SALUDO=Buenas tardes"`.
- Un cambio de código exige repetir `mvn package`, `docker build` y `docker run`. Con una etiqueta nueva, la versión antigua sigue disponible.
- `-p` solo conecta puertos: si la aplicación escucha en otro puerto dentro del contenedor, el segundo número de `-p` tiene que ser ese.
- El campo que interesa de `docker inspect` es `.Config.Env`.
- Las tildes en el valor de una variable pueden salir deformadas en la consola de Windows; se usan textos sin tildes.

---

## Práctica 3: Compartir una imagen con un compañero

Una imagen sirve para que otra persona ejecute nuestra aplicación sin tener nada instalado salvo Docker. En parejas, cada alumno prepara su imagen `contactos` y ejecuta la de su compañero.

**Pasos**
1. Cada alumno cambia el saludo por defecto de su imagen por uno personal (por ejemplo, con su nombre) en `application.properties`, y reconstruye el JAR y la imagen con la etiqueta `1.2`.
2. Con la variante A: se le da a la imagen un nombre con el usuario de Docker Hub, se sube con `docker push` (hace falta tener sesión iniciada con `docker login`) y se pasa el nombre completo a la pareja. Con las variantes B y C: se le da a la imagen el nombre `contactos-nombre:1.2` (con el nombre de cada alumno), se guarda en un fichero `.tar` y se deja en la carpeta compartida del Drive.
3. Cada alumno consigue la imagen de su pareja (`docker pull` o `docker load`) y comprueba con `docker images` que aparece.
4. Ejecuta un contenedor de la imagen de su pareja en el puerto 8081 y comprueba que el saludo es el de la otra persona.
5. Ejecuta otro contenedor de esa misma imagen pasando la variable `SALUDO` con un texto propio y comprueba que se impone al que traía la imagen.
6. Borra los contenedores y la imagen de su pareja (`docker rm`, `docker rmi`).

**Pistas**
- Si dos alumnos guardan una imagen con el mismo nombre y etiqueta (`contactos:1.2`), al cargarla el segundo sobrescribe la etiqueta del primero. Por eso el nombre lleva el de cada alumno.
- `docker tag origen destino` no copia la imagen: solo añade un nombre.
- `docker save -o fichero.tar imagen` guarda la imagen con todas sus capas; el fichero pesa unos 140 MB. Si el Drive va lento, se puede pasar con una memoria USB.
- La imagen de la pareja incluye la base `eclipse-temurin`, que ya está en el equipo: `docker load` no la duplica.
- Para borrar una imagen hay que borrar antes los contenedores que la usan.
