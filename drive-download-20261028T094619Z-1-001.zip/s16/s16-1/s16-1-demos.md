# S16-1 Demos

## Objetivos

Hasta ahora solo hemos dejado Docker Desktop instalado (S15-2). Esta parte es la primera en la que se ejecuta algo con él. Empezamos por lo más sencillo: arrancar un primer contenedor de una imagen que ha construido otra persona (`nginx`, un servidor web) y ver qué ocurre al pararlo y borrarlo. Después abrimos esa imagen y miramos por dentro: sus capas, su nombre y su etiqueta. Después escribimos el `Dockerfile` de una aplicación Spring Boot, construimos su imagen y la ejecutamos. Por último la llevamos a otro equipo, que es el momento en que se ve para qué sirve todo esto: una aplicación Java que funciona en un equipo que no tiene Java ni el proyecto, con un solo comando.

La explicación de los conceptos (imagen y contenedor, contenedor y máquina virtual, capas, nombre y etiqueta, `Dockerfile`) y la lista de comandos con su sintaxis están en `s16-1-teoria.md`, que se cuenta antes de las demos. Aquí se aplican con comandos reales.

Hay un problema práctico que condiciona toda la parte: la red del aula bloquea Docker Hub, el servicio público del que Docker descarga las imágenes por defecto. Por eso cada vez que hay que conseguir una imagen o compartirla, este documento da tres caminos, que llamamos variantes A, B y C. Se explican en el apartado siguiente. Los pasos que no dependen de la variante son iguales para todos.

Al terminar esta parte los alumnos son capaces de:
- Conseguir una imagen por cualquiera de las tres vías y comprobar que está en el equipo con `docker images`.
- Leer las capas de una imagen con `docker history` y los detalles de una imagen con `docker inspect`.
- Explicar qué son el nombre y la etiqueta de una imagen, ponerle un nombre nuevo con `docker tag` y borrarla con `docker rmi`.
- Escribir un `Dockerfile` con `FROM`, `COPY`, `EXPOSE` y `ENTRYPOINT`, construir la imagen con `docker build` y ejecutarla publicando el puerto con `-p`.
- Reconocer en la salida de `docker build` qué capas se reutilizan al reconstruir una imagen.
- Llevar una imagen a otro equipo, con `docker push` o con `docker save` y `docker load`.

---

## Antes de empezar: tres formas de conseguir y de compartir imágenes

Una imagen se descarga de un **registro**: un servidor que guarda imágenes y las entrega por su nombre. Docker usa por defecto **Docker Hub** (`docker.io`), y en el aula está bloqueado. Hay dos alternativas, y cada una es una variante:

| Variante | Qué se necesita | Cómo se consigue una imagen | Cómo se comparte una imagen propia |
|---|---|---|---|
| **A: Docker Hub** | Red sin bloqueo y cuenta gratuita de Docker Hub | `docker pull nginx` | `docker push` |
| **B: Espejo `mirror.gcr.io`** | Que `mirror.gcr.io` responda desde el aula | `docker pull mirror.gcr.io/library/nginx` y después `docker tag` | `docker save` y `docker load` (el espejo solo permite descargar) |
| **C: Ficheros del Drive** | Los ficheros `.tar` descargados del Drive | `docker load -i nginx.tar` | `docker save` y `docker load` |

Un **espejo** (*mirror*) es un servidor que guarda copias de las imágenes de otro. `mirror.gcr.io` es el espejo de Google: contiene copias de las imágenes oficiales de Docker Hub, y solo sirve para descargar. Por eso las variantes B y C comparten el mismo método para llevar una imagen propia a otro equipo: guardarla en un fichero con `docker save` y cargarla con `docker load`.

### Cómo saber qué variante nos toca

Probamos con la imagen más pequeña que existe, `hello-world`, de la más cómoda a la menos cómoda. En un `cmd`:

```bash
docker pull hello-world
```

Si termina con `Status: Downloaded newer image for hello-world:latest` (o `Image is up to date`), usamos la variante A. Si no responde, esperamos unos segundos, pulsamos `Ctrl+C` y probamos el espejo:

```bash
docker pull mirror.gcr.io/library/hello-world
```

Si funciona, usamos la variante B. Si tampoco, usamos la variante C. Cuando Docker Hub está bloqueado, el fallo se parece a esto (puede tardar en aparecer, o dar un mensaje de tiempo de espera agotado):

<pre>
C:\Users\Mananas>docker pull hello-world
Using default tag: latest
Error response from daemon: Get "https://registry-1.docker.io/v2/": Forbidden
</pre>

### La variante C: las imágenes del Drive

El profesor ha guardado en el Drive, en la carpeta `imagenes-docker`, cinco imágenes en ficheros `.tar`:

| Fichero | Imagen que contiene | Se usa en |
|---|---|---|
| `hello-world.tar` | `hello-world` | Prueba de que Docker funciona (S16-1) |
| `nginx.tar` | `nginx` | Servidor web (S16-1, S16-2) |
| `eclipse-temurin.tar` | `eclipse-temurin:21-jre` | Base de las imágenes de Spring Boot (S16-1) |
| `postgres.tar` | `postgres:16` | Base de datos (S16-2) |
| `mongo.tar` | `mongo` | Base de datos (S16-2) |

Descargamos la carpeta entera del Drive en una carpeta del equipo, por ejemplo `C:\Users\Mananas\imagenes-docker`, y abrimos un `cmd` en ella. Para esta parte hacen falta los tres primeros:

```bash
cd C:\Users\Mananas\imagenes-docker
```

```bash
docker load -i hello-world.tar
```

```bash
docker load -i nginx.tar
```

```bash
docker load -i eclipse-temurin.tar
```

`docker load -i fichero.tar` lee un fichero creado con `docker save` y registra en el equipo la imagen que contiene: `-i` es *input* (entrada). El comando escribe una línea por imagen cargada:

<pre>
C:\Users\Mananas\imagenes-docker>docker load -i nginx.tar
Loaded image: nginx:latest
</pre>

Los ficheros pesan: `nginx.tar` unos 67 MB y `eclipse-temurin.tar` unos 121 MB. Conviene descargarlos antes de la sesión, y no todo el grupo a la vez.

### La regla del nombre corto

Sea cual sea la variante, las imágenes tienen que acabar llamándose `hello-world`, `nginx` y `eclipse-temurin:21-jre`. Con ese nombre corto todos los comandos y el `Dockerfile` de las demos son idénticos en las tres variantes. En la variante A y en la C ocurre solo. En la B, el espejo guarda las imágenes con un nombre más largo y hay que darles el corto con `docker tag`, que veremos en la Demo 1.

### Antes de empezar: comprobar que no quedan contenedores

En un `cmd`:

```bash
docker ps -a
```

La lista debería salir vacía (solo la cabecera de las columnas), porque en S15-2 solo se instaló Docker Desktop. Si hubiera algún contenedor de pruebas anteriores, lo borramos con `docker rm -f nombre`.

---

## Demo 1: Imágenes, capas y etiquetas

Trabajamos con `nginx`, un servidor web muy usado. Primero conseguimos la imagen, después arrancamos un contenedor a partir de ella, y por último miramos la imagen por dentro.

### Conseguir la imagen

**Variante A: Docker Hub.**

```bash
docker pull nginx
```

`docker pull` descarga una imagen de un registro. Si no indicamos etiqueta, Docker usa `latest`. Cada línea `Pull complete` es una capa que se descarga; una capa que ya estaba en el equipo aparece como `Already exists`.

<pre>
C:\Users\Mananas>docker pull nginx
Using default tag: latest
latest: Pulling from library/nginx
8334177aa35b: Pull complete
9a2c3eb3312e: Pull complete
...
Digest: sha256:4c41e2d0...
Status: Downloaded newer image for nginx:latest
docker.io/library/nginx:latest
</pre>

**Variante B: espejo `mirror.gcr.io`.**

```bash
docker pull mirror.gcr.io/library/nginx
```

El nombre completo de una imagen tiene la forma `registro/espacio/nombre`. Cuando escribimos solo `nginx`, Docker completa `docker.io/library/nginx`: el registro es Docker Hub (`docker.io`) y el espacio de nombres `library` es el de las imágenes oficiales. Con el espejo escribimos el nombre completo, cambiando solo el registro. La descarga es igual que la de la variante A, y la última línea muestra el nombre largo:

<pre>
C:\Users\Mananas>docker pull mirror.gcr.io/library/nginx
Using default tag: latest
latest: Pulling from library/nginx
...
Status: Downloaded newer image for mirror.gcr.io/library/nginx:latest
mirror.gcr.io/library/nginx:latest
</pre>

Ahora la imagen se llama `mirror.gcr.io/library/nginx`. Le damos el nombre corto con `docker tag`, que añade un nombre nuevo a la misma imagen sin copiarla:

```bash
docker tag mirror.gcr.io/library/nginx nginx
```

Y quitamos el nombre largo, que ya no necesitamos:

```bash
docker rmi mirror.gcr.io/library/nginx
```

`docker rmi` (*remove image*) borra un nombre de imagen; como la imagen sigue teniendo el nombre `nginx`, solo se quita el largo y las capas no se tocan. Lo vemos con detalle más abajo, en esta misma demo.

**Variante C: Drive.** Si no lo hemos hecho ya, cargamos la imagen desde la carpeta de los ficheros:

```bash
docker load -i nginx.tar
```

A partir de aquí, todos tenemos una imagen llamada `nginx`.

### Un primer contenedor

Descargar una imagen no ejecuta nada: la imagen es solo un paquete guardado en el disco. Para ejecutarla se crea un **contenedor** con `docker run`:

```bash
docker run -d -p 8081:80 --name web nginx
```

Cada parte del comando:

- `docker run` crea un contenedor a partir de una imagen y lo arranca. Si la imagen no estuviera en el equipo, la descargaría antes.
- `-d` (*detach*) lo deja en segundo plano. Sin `-d`, la terminal quedaría ocupada por `nginx` hasta pulsar `Ctrl+C`.
- `-p 8081:80` (*publish*) publica un puerto: lo que llegue al puerto 8081 del equipo se reenvía al puerto 80 del contenedor. El primer número es el del equipo y el segundo el del contenedor. `nginx` escucha en el 80 dentro del contenedor, y usamos el 8081 en el equipo porque el 8080 lo ocupa Jenkins.
- `--name web` le da un nombre al contenedor. Sin él, Docker inventa uno (como `quirky_turing`).
- `nginx` es la imagen de la que se crea.

Docker responde con el identificador completo del contenedor, una cadena larga de letras y números:

<pre>
C:\Users\Mananas>docker run -d -p 8081:80 --name web nginx
3f5a1c9e0b7d4a62c81e5f0d93b6a7c2e4d18f90a5b3c6d7e8f9012345678901
</pre>

Comprobamos que está en marcha con `docker ps`, que lista los contenedores:

```bash
docker ps
```

<pre>
C:\Users\Mananas>docker ps
CONTAINER ID   IMAGE     COMMAND                  CREATED          STATUS          PORTS                  NAMES
3f5a1c9e0b7d   nginx     "/docker-entrypoint.…"   10 seconds ago   Up 9 seconds    0.0.0.0:8081->80/tcp   web
</pre>

Las columnas importantes: `CONTAINER ID` (los doce primeros caracteres del identificador), `IMAGE` (de qué imagen sale), `STATUS` (`Up` es que está en marcha), `PORTS` (el puerto publicado, `0.0.0.0:8081->80/tcp`, que se lee "el 8081 del equipo va al 80 del contenedor") y `NAMES`.

Abrimos `http://localhost:8081` en el navegador: aparece la página «Welcome to nginx!». Hemos ejecutado un servidor web sin instalarlo en Windows. Lo que ha hecho el servidor se ve con `docker logs`:

```bash
docker logs web
```

<pre>
C:\Users\Mananas>docker logs web
/docker-entrypoint.sh: Configuration complete; ready for start up
...
2026/10/28 09:10:02 [notice] 1#1: start worker processes
172.17.0.1 - - [28/Oct/2026:09:10:11 +0000] "GET / HTTP/1.1" 200 615 "-" "Mozilla/5.0 ..." "-"
</pre>

La última línea es nuestra visita desde el navegador: `GET /` con respuesta `200` (S06-1). `docker logs` muestra lo que el programa del contenedor ha escrito en su salida, y es la primera herramienta cuando algo falla.

Un contenedor se puede **parar** y **volver a arrancar**, y seguirá existiendo mientras no se borre:

```bash
docker stop web
```

```bash
docker ps -a
```

<pre>
C:\Users\Mananas>docker ps -a
CONTAINER ID   IMAGE     COMMAND                  CREATED          STATUS                     PORTS     NAMES
3f5a1c9e0b7d   nginx     "/docker-entrypoint.…"   2 minutes ago    Exited (0) 5 seconds ago             web
</pre>

`docker ps` solo muestra los contenedores en marcha; con `-a` (*all*) también los parados. El estado `Exited (0)` significa que terminó sin errores. En el navegador, `http://localhost:8081` ya no responde. Lo arrancamos de nuevo, con las mismas opciones con las que se creó:

```bash
docker start web
```

Y ahora comprobamos la idea más importante de Docker: de **una imagen** pueden salir **muchos contenedores**, independientes entre sí. Creamos un segundo contenedor de la misma imagen `nginx`, en otro puerto:

```bash
docker run -d -p 8082:80 --name web2 nginx
```

```bash
docker ps
```

<pre>
C:\Users\Mananas>docker ps
CONTAINER ID   IMAGE     COMMAND                  CREATED          STATUS          PORTS                  NAMES
8c21d7e4a9b0   nginx     "/docker-entrypoint.…"   4 seconds ago    Up 3 seconds    0.0.0.0:8082->80/tcp   web2
3f5a1c9e0b7d   nginx     "/docker-entrypoint.…"   3 minutes ago    Up 20 seconds   0.0.0.0:8081->80/tcp   web
</pre>

Los dos responden, `http://localhost:8081` y `http://localhost:8082`, y la imagen `nginx` sigue siendo una sola. Es la misma relación que entre una clase y sus objetos (S02-1): la imagen es la clase y cada contenedor es un objeto.

Para terminar, borramos los dos contenedores. `docker rm` solo borra contenedores parados; con `-f` (*force*) también borra los que están en marcha:

```bash
docker rm -f web web2
```

Borrar un contenedor no borra la imagen: `docker images` sigue mostrando `nginx`.

### Listar las imágenes

```bash
docker images
```

<pre>
C:\Users\Mananas>docker images
IMAGE          ID             DISK USAGE   CONTENT SIZE   EXTRA
nginx:latest   a1b2c3d4e5f6        243MB         66.8MB
</pre>

Las columnas, con la versión de Docker del aula (Docker Desktop 4.96.3 con motor 29.9.2):

- `IMAGE`: el nombre y la etiqueta, separados por dos puntos. Aquí `nginx` es el nombre y `latest` la etiqueta.
- `ID`: un código corto que identifica la imagen en este equipo. Dos nombres distintos que apuntan a la misma imagen tienen el mismo `ID`.
- `DISK USAGE`: lo que ocupa la imagen una vez descomprimida en el disco.
- `CONTENT SIZE`: lo que ocupa la imagen comprimida, que es lo que se descarga. Coincide aproximadamente con el tamaño del fichero `.tar` del Drive.
- `EXTRA`: información adicional. Una `U` indica que algún contenedor está usando la imagen.

En versiones anteriores de Docker las columnas se llamaban `REPOSITORY`, `TAG`, `IMAGE ID`, `CREATED` y `SIZE`. Muestran lo mismo repartido de otra manera, y los comandos no cambian. Los identificadores y los tamaños de este documento son orientativos: en cada equipo salen otros.

### Ver las capas

```bash
docker history nginx
```

`docker history` muestra el historial de construcción de una imagen: una línea por capa, de la más reciente a la más antigua.

<pre>
C:\Users\Mananas>docker history nginx
IMAGE          CREATED        CREATED BY                                      SIZE      COMMENT
a1b2c3d4e5f6   2 weeks ago    CMD ["nginx" "-g" "daemon off;"]                0B        buildkit.dockerfile.v0
&amp;lt;missing&amp;gt;      2 weeks ago    STOPSIGNAL SIGQUIT                              0B        buildkit.dockerfile.v0
&amp;lt;missing&amp;gt;      2 weeks ago    EXPOSE map[80/tcp:{}]                           0B        buildkit.dockerfile.v0
&amp;lt;missing&amp;gt;      2 weeks ago    ENTRYPOINT ["/docker-entrypoint.sh"]            0B        buildkit.dockerfile.v0
&amp;lt;missing&amp;gt;      2 weeks ago    COPY 30-tune-worker-processes.sh /docker-ent…   4.62kB    buildkit.dockerfile.v0
...
&amp;lt;missing&amp;gt;      2 weeks ago    RUN /bin/sh -c set -x     &amp;&amp; groupadd --sys…   73.9MB    buildkit.dockerfile.v0
&amp;lt;missing&amp;gt;      2 weeks ago    ENV NGINX_VERSION=1.29.3                        0B        buildkit.dockerfile.v0
&amp;lt;missing&amp;gt;      3 weeks ago    # debian.sh --arch 'amd64' out/ 'trixie' '…   109MB     debuerreotype 0.17
</pre>

La salida está abreviada y las versiones, fechas y tamaños cambian. Se lee de abajo arriba, que es el orden en que se construyó:

- La línea de abajo es la base: un sistema Debian de unos 100 MB. Es la primera capa, de la que parten todas las demás.
- Encima, las instrucciones del `Dockerfile` de `nginx`: `ENV` define una variable, `RUN` ejecuta un comando de instalación (la capa de 70 MB y pico es el propio servidor `nginx`), `COPY` añade ficheros.
- Las instrucciones de arriba (`ENTRYPOINT`, `EXPOSE`, `CMD`) ocupan `0B`: no añaden ficheros, solo anotan información sobre cómo se ejecuta la imagen.
- Nos encontramos con las mismas instrucciones que veremos en nuestro `Dockerfile` en la Demo 2: `ENTRYPOINT`, `EXPOSE`, `COPY`. Un `Dockerfile` es exactamente lo que se ve aquí al revés.
- La columna `IMAGE` solo tiene identificador en la última línea. Las demás dicen `&lt;missing&gt;` ("falta"): es normal, no es un error. Con el motor actual Docker no guarda un identificador para cada capa intermedia, solo para la imagen final.

### Ver los detalles

```bash
docker inspect nginx
```

`docker inspect` devuelve en formato JSON (S09) todos los datos de una imagen o de un contenedor: son cientos de líneas, con las capas, las variables de entorno, el puerto y el comando de arranque. Para sacar un solo dato se usa `--format`, con una expresión entre llaves dobles que sigue la ruta del dato dentro del JSON:

```bash
docker inspect --format "{{.Config.ExposedPorts}}" nginx
```

```bash
docker inspect --format "{{.Config.Entrypoint}}" nginx
```

<pre>
C:\Users\Mananas>docker inspect --format "{{.Config.ExposedPorts}}" nginx
map[80/tcp:{}]

C:\Users\Mananas>docker inspect --format "{{.Config.Entrypoint}}" nginx
[/docker-entrypoint.sh]
</pre>

Son los mismos datos que vimos en `docker history`: el puerto 80 que anota `EXPOSE` y el comando de arranque de `ENTRYPOINT`. Es el puerto 80 que hemos publicado antes con `-p 8081:80`: no es un número que nos inventemos, está escrito en la propia imagen.

### Nombre y etiqueta: una imagen con dos nombres

Una imagen puede tener varios nombres. `docker tag` añade uno nuevo:

```bash
docker tag nginx nginx:mi-copia
```

El primer argumento es la imagen que ya existe y el segundo el nombre nuevo. Escribimos de nuevo la lista:

```bash
docker images
```

<pre>
C:\Users\Mananas>docker images
IMAGE             ID             DISK USAGE   CONTENT SIZE   EXTRA
nginx:latest      a1b2c3d4e5f6        243MB         66.8MB
nginx:mi-copia    a1b2c3d4e5f6        243MB         66.8MB
</pre>

Aparecen dos líneas con el **mismo `ID`**. No se ha copiado nada: es una sola imagen con dos nombres, igual que una persona con nombre y apodo. Los tamaños se repiten porque cada línea muestra el tamaño de la imagen a la que apunta, no un espacio adicional que se haya ocupado.

Borramos el nombre nuevo:

```bash
docker rmi nginx:mi-copia
```

<pre>
C:\Users\Mananas>docker rmi nginx:mi-copia
Untagged: nginx:mi-copia
</pre>

`Untagged` significa que se ha quitado un nombre, no que se haya borrado la imagen: sigue existiendo con el nombre `nginx:latest` y las capas siguen en el disco. Los ficheros solo se borran cuando se quita **el último nombre** de una imagen, y entonces aparece también una línea `Deleted`.

### Borrar una imagen del todo

Probamos con `hello-world`, la imagen más pequeña que existe: su único programa escribe un mensaje y termina. La conseguimos igual que `nginx`:

**Variante A:**

```bash
docker pull hello-world
```

**Variante B:**

```bash
docker pull mirror.gcr.io/library/hello-world
```

```bash
docker tag mirror.gcr.io/library/hello-world hello-world
```

```bash
docker rmi mirror.gcr.io/library/hello-world
```

**Variante C:**

```bash
docker load -i hello-world.tar
```

Ejecutamos un contenedor de esa imagen. Esta vez sin `-d`: el programa escribe su mensaje en la terminal y termina:

```bash
docker run hello-world
```

<pre>
C:\Users\Mananas>docker run hello-world

Hello from Docker!
This message shows that your installation appears to be working correctly.
...
</pre>

El mensaje (abreviado aquí) confirma que Docker funciona. El contenedor ya ha terminado, pero **sigue existiendo**, parado. Lo vemos con `docker ps -a`, donde `STATUS` es `Exited (0)` y el nombre es uno inventado por Docker. Ahora intentamos borrar la imagen:

```bash
docker rmi hello-world
```

Docker se niega, porque el contenedor parado sigue usando la imagen:

<pre>
C:\Users\Mananas>docker rmi hello-world
Error response from daemon: conflict: unable to remove repository reference "hello-world" (must force) - container 65a04289c181 is using its referenced image 046a267e50aa
</pre>

El mensaje dice que el contenedor `65a04289c181` usa la imagen. Un contenedor, aunque esté parado, necesita su imagen: se crea a partir de ella. Primero se borra el contenedor y después la imagen. El identificador que aparece en el mensaje es el del contenedor; lo borramos con él y repetimos:

```bash
docker rm 65a04289c181
```

```bash
docker rmi hello-world
```

(Sustituimos `65a04289c181` por el identificador que muestre cada equipo; sale también en `docker ps -a`.) Ahora sí se puede borrar:

<pre>
C:\Users\Mananas>docker rmi hello-world
Untagged: hello-world:latest
Deleted: sha256:046a267e50aa836ec2897c5373d52754ad73f76ecba641159c37a84359527b97
</pre>

`Untagged` quita el nombre y `Deleted` borra la imagen, porque era su único nombre. Si alguien necesita `hello-world` otra vez, solo tiene que volver a conseguirla con su variante.

### Resumen de comandos

| Comando | Qué hace |
|---|---|
| `docker run -d -p equipo:contenedor --name nombre imagen` | Crea y arranca un contenedor en segundo plano |
| `docker ps` / `docker ps -a` | Lista los contenedores en marcha / todos |
| `docker logs nombre` | Muestra lo que ha escrito el programa del contenedor |
| `docker stop nombre` / `docker start nombre` | Para / arranca de nuevo un contenedor |
| `docker rm -f nombre ...` | Borra contenedores (con `-f`, aunque estén en marcha) |
| `docker pull imagen` | Descarga una imagen de un registro |
| `docker load -i fichero.tar` | Carga una imagen desde un fichero |
| `docker images` | Lista las imágenes del equipo |
| `docker history imagen` | Muestra las capas de una imagen |
| `docker inspect imagen` | Muestra todos los datos de una imagen (con `--format`, solo uno) |
| `docker tag origen destino` | Añade un nombre nuevo a una imagen |
| `docker rmi imagen` | Quita un nombre de una imagen y, si era el último, la borra |

---

## Demo 2: Dockerfile con el JAR de Spring Boot

Llevamos a una imagen una aplicación Spring Boot muy pequeña, `saludos`. Tiene una sola ruta, `GET /api/saludo`, que responde con el nombre del equipo en el que se ejecuta, su sistema operativo y la versión de Java. Esos dos datos nos permitirán comprobar que dentro del contenedor el programa ve un entorno distinto del de Windows.

El plan tiene cinco pasos: construimos el JAR con Maven, lo probamos sin Docker, escribimos el `Dockerfile`, construimos la imagen y la ejecutamos. La imagen no lleva Maven ni el código fuente, solo Java y el JAR. Por eso el JAR se construye **antes**, en nuestro equipo.

### El proyecto

El proyecto está en `s16-1-demos.zip`, en la carpeta `saludos`. Lo descomprimimos y lo abrimos en IntelliJ con `File > Open`, eligiendo la carpeta `saludos` (la que contiene directamente el `pom.xml`). Pulsamos `Trust Project` y, si aparece el aviso `Maven build scripts found`, **Load** (S06-1).

El proyecto se creó con el generador de Spring Boot de IntelliJ (S05-1) con estos valores: Name `saludos`, Type `Maven`, Language `Java`, Group `com.curso`, Artifact `saludos`, Package name `com.curso`, JDK `21`, Java `21`, Packaging `Jar`, Configuration `Properties`, Spring Boot `4.1.1` y la dependencia `Spring Web`. Contiene tres clases. `Aplicacion` y `AplicacionTests` son las del generador (renombradas con `Shift+F6`, S06-1) y no cambian respecto a lo que ya conocemos. La clase nueva es el controlador:

```java
package com.curso.controller;

// InetAddress y UnknownHostException son clases de la librería estándar de Java (java.net).
// No hace falta ninguna dependencia de Maven para usarlas.
import java.net.InetAddress;
import java.net.UnknownHostException;
// LinkedHashMap y Map también son de la librería estándar de Java (java.util).
import java.util.LinkedHashMap;
import java.util.Map;

// Estas tres anotaciones proceden de spring-web, que trae spring-boot-starter-webmvc.
// Maven la ha descargado al cargar el pom.xml.
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * S16-1 Demo 2: Controlador que dice dónde se está ejecutando
 *
 * Objetivo: tener una API con una sola ruta cuya respuesta cambia según se
 * ejecute en Windows o dentro de un contenedor.
 *
 * Lo que hace este ejemplo:
 *   - Responde a GET /api/saludo con un JSON de cuatro campos.
 *   - Incluye el nombre del equipo, el sistema operativo y la versión de Java.
 *
 * Concepto clave: un contenedor es un entorno aislado. El mismo JAR, ejecutado
 * dentro de un contenedor, ve un equipo y un sistema operativo distintos de los
 * de Windows. Es la prueba de que la aplicación lleva su propio entorno.
 */
// @RestController es un @Controller cuyos métodos devuelven datos (JSON), no plantillas (S09).
@RestController
// @RequestMapping("/api") pone el prefijo /api a todas las rutas de la clase (S09).
@RequestMapping("/api")
public class SaludoController {

    /**
     * Devuelve un saludo con los datos del entorno en el que se ejecuta.
     *
     * Ejemplo:
     *   en Windows    →  {"mensaje":"Hola desde Spring Boot","equipo":"MANANAS-PC","sistema":"Windows 11","java":"21.0.8"}
     *   en contenedor →  {"mensaje":"Hola desde Spring Boot","equipo":"3f2a9c1b7d4e","sistema":"Linux","java":"21.0.8"}
     */
    // @GetMapping("/saludo") enlaza el verbo GET y la ruta /api/saludo con este método (S06-1).
    @GetMapping("/saludo")
    // getHostName() puede lanzar una excepción comprobada si el equipo no sabe su propio nombre;
    // "throws" la deja pasar y Spring la convertiría en un error 500.
    public Map<String, String> saludo() throws UnknownHostException {
        // LinkedHashMap guarda los pares clave-valor en el orden en que se añaden,
        // para que el JSON salga siempre con los campos en el mismo orden.
        Map<String, String> respuesta = new LinkedHashMap<>();

        // Texto fijo: es lo que cambiaremos entre la versión 1.0 y la 1.1 de la imagen.
        respuesta.put("mensaje", "Hola desde Spring Boot");

        // getLocalHost().getHostName() es el nombre del equipo en el que se ejecuta el programa.
        // En Windows es el nombre del PC; dentro de un contenedor, Docker lo pone igual
        // al identificador corto del contenedor: "3f2a9c1b7d4e".
        respuesta.put("equipo", InetAddress.getLocalHost().getHostName());

        // os.name es una propiedad del sistema de Java (S04-1): el sistema operativo
        // que ve el programa. Dentro de un contenedor de Linux siempre es "Linux".
        respuesta.put("sistema", System.getProperty("os.name"));

        // java.version es la versión de Java que ejecuta el programa.
        respuesta.put("java", System.getProperty("java.version"));

        // Spring convierte el Map a JSON con Jackson: {"mensaje": "...", "equipo": "...", ...}
        return respuesta;
    }
}
```

Conviene fijarse en los dos datos que cambian con el entorno. `getHostName()` devuelve el nombre del equipo: en Windows será el nombre del PC, pero dentro de un contenedor Docker lo pone igual al identificador corto del contenedor (el mismo que aparece en la columna `CONTAINER ID` de `docker ps`). `os.name` es una propiedad del sistema de Java (S04-1) que da el sistema operativo: en Windows, `Windows 11`; dentro de un contenedor, `Linux`, porque la imagen lleva un Linux.

El puerto no se configura: Spring Boot escucha en el 8080, como siempre. Dentro del contenedor eso no choca con Jenkins, que ocupa el 8080 de Windows, porque el contenedor tiene su propia red.

### Paso 1: construir el JAR

Abrimos la terminal de IntelliJ (`Alt+F12`), que se abre en la carpeta del proyecto, y ejecutamos:

```bash
mvn clean package
```

Es el comando de S03-2: `clean` borra `target` y `package` compila, ejecuta las pruebas y genera el JAR. El plugin de Spring Boot (`spring-boot-maven-plugin`, S05-1) lo reempaqueta para que contenga la aplicación y todas sus librerías.

Salida esperada (abreviada):

<pre>
[INFO] Scanning for projects...
[INFO] -------------------------< com.curso:saludos >--------------------------
[INFO] Building saludos 0.0.1-SNAPSHOT
[INFO]   from pom.xml
[INFO] --------------------------------[ jar ]---------------------------------
[INFO] --- clean:3.5.0:clean (default-clean) @ saludos ---
[INFO] --- resources:3.5.0:resources (default-resources) @ saludos ---
[INFO] --- compiler:3.15.0:compile (default-compile) @ saludos ---
[INFO] Compiling 2 source files with javac [debug parameters release 21] to target/classes
[INFO] --- surefire:3.5.6:test (default-test) @ saludos ---
[INFO] Running com.curso.AplicacionTests
[INFO] Tests run: 1, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 2.789 s -- in com.curso.AplicacionTests
[INFO] --- jar:3.5.1:jar (default-jar) @ saludos ---
[INFO] Building jar: /ruta/saludos/target/saludos-0.0.1-SNAPSHOT.jar
[INFO] --- spring-boot:4.1.1:repackage (repackage) @ saludos ---
[INFO] Replacing main artifact /ruta/saludos/target/saludos-0.0.1-SNAPSHOT.jar with repackaged archive, adding nested dependencies in BOOT-INF/.
[INFO] The original artifact has been renamed to /ruta/saludos/target/saludos-0.0.1-SNAPSHOT.jar.original
[INFO] BUILD SUCCESS
</pre>

Hay que mirar el nombre exacto del JAR, porque el `Dockerfile` lo necesita: es `artifactId-version.jar`, aquí `saludos-0.0.1-SNAPSHOT.jar`, y pesa unos 20 MB porque lleva dentro todas las librerías. Junto a él queda `saludos-0.0.1-SNAPSHOT.jar.original`, de unos pocos KB, que es el JAR de Maven antes de reempaquetar y no nos sirve.

### Paso 2: probarlo sin Docker

Antes de empaquetar, comprobamos que funciona. En la misma terminal:

```bash
java -jar target\saludos-0.0.1-SNAPSHOT.jar --server.port=8082
```

`java -jar` ejecuta un JAR (S05-1). El argumento `--server.port=8082` cambia el puerto de Tomcat para esta ejecución: en Spring Boot, cualquier propiedad de `application.properties` se puede sobrescribir en la línea de comandos con `--clave=valor`. Lo necesitamos porque el 8080 lo ocupa Jenkins; y usamos el 8082 y no el 8081 porque el 8081 será el del contenedor, y así podremos tener los dos a la vez.

Abrimos `http://localhost:8082/api/saludo` en el navegador:

<pre>
{"mensaje":"Hola desde Spring Boot","equipo":"MANANAS-PC","sistema":"Windows 11","java":"21.0.8"}
</pre>

El nombre del equipo y la versión de Java son los de cada PC. Dejamos esta ventana abierta (la aplicación sigue en marcha) y abrimos una segunda terminal para el resto de la demo; al final la paramos con `Ctrl+C`.

### Paso 3: conseguir la imagen base

La imagen que construimos parte de otra con Java: `eclipse-temurin:21-jre`. La conseguimos con la vía de nuestra variante, y siempre con el nombre corto.

**Variante A: Docker Hub.**

```bash
docker pull eclipse-temurin:21-jre
```

**Variante B: espejo.**

```bash
docker pull mirror.gcr.io/library/eclipse-temurin:21-jre
```

```bash
docker tag mirror.gcr.io/library/eclipse-temurin:21-jre eclipse-temurin:21-jre
```

```bash
docker rmi mirror.gcr.io/library/eclipse-temurin:21-jre
```

**Variante C: Drive** (desde la carpeta de los ficheros):

```bash
docker load -i eclipse-temurin.tar
```

Comprobamos con `docker images` que aparece `eclipse-temurin:21-jre`. Pesa unos 120 MB descargada (`CONTENT SIZE`) y unos 300 MB descomprimida (`DISK USAGE`).

### Paso 4: el Dockerfile

El `Dockerfile` está en la raíz del proyecto, junto al `pom.xml`. En IntelliJ se crea con clic derecho sobre la carpeta del proyecto, `New > File`, y el nombre `Dockerfile`, exactamente así, con la D mayúscula y sin extensión. Dentro:

```dockerfile
# S16-1 Demo 2: Dockerfile de la API de saludos
#
# Objetivo: describir, instrucción a instrucción, cómo construir la imagen que
# contiene nuestra aplicación Spring Boot.
#
# Lo que hace este fichero:
#   - Parte de una imagen que ya trae Linux y el JRE de Java 21.
#   - Copia dentro de la imagen el JAR que ha construido Maven.
#   - Anota el puerto en el que escucha la aplicación.
#   - Indica el comando que se ejecuta al arrancar un contenedor.
#
# Concepto clave: la imagen no contiene Maven ni el código fuente. Maven construye
# el JAR en nuestro equipo (mvn package) y el Dockerfile solo lo mete en la imagen.
# Cada instrucción que añade ficheros crea una capa nueva.
#
# Se construye con:  docker build -t saludos:1.0 .
# (el punto final es la carpeta de la que se copian los ficheros)

# FROM dice de qué imagen partimos. eclipse-temurin es una imagen oficial con Java;
# la etiqueta 21-jre significa "Java 21, solo el JRE". El JRE (Java Runtime Environment)
# basta para ejecutar un JAR que ya está compilado. No usamos el JDK, que incluye el
# compilador, porque la imagen pesaría más y aquí no compilamos nada.
# Las capas de esta imagen pasan a ser las primeras capas de la nuestra.
FROM eclipse-temurin:21-jre

# COPY origen destino copia un fichero de nuestro equipo a la imagen. El origen
# se busca desde la carpeta en la que ejecutamos "docker build" (el punto final).
# Copiamos el JAR de Spring Boot que dejó "mvn package" en target/ y lo guardamos
# dentro de la imagen con el nombre corto app.jar, para que el ENTRYPOINT no dependa
# de la versión del proyecto. Esta instrucción crea la capa que contiene el JAR.
# Ojo: el JAR tiene que existir antes de construir la imagen, o el build falla.
COPY target/saludos-0.0.1-SNAPSHOT.jar app.jar

# EXPOSE 8080 anota que la aplicación escucha en el puerto 8080 del contenedor.
# Solo documenta: no publica nada. Para llegar a ese puerto desde Windows hay que
# publicarlo al ejecutar el contenedor, con "-p 8081:8080".
EXPOSE 8080

# ENTRYPOINT es el comando que se ejecuta cuando arranca un contenedor de esta imagen.
# Equivale a escribir "java -jar app.jar" en una terminal. Cada palabra del comando
# va entre comillas y separada por comas (formato de lista), para que Java sea el proceso
# principal del contenedor y reciba directamente la orden de parada de "docker stop".
ENTRYPOINT ["java", "-jar", "app.jar"]
```

Repasamos cada instrucción, que ya conocemos de la teoría:

- **`FROM eclipse-temurin:21-jre`** elige la imagen de partida. Es lo que hemos descargado en el paso anterior. Si no estuviera en el equipo, `docker build` intentaría descargarla del registro, y en el aula eso falla: por eso el paso 3 viene antes. Con la imagen ya en el equipo, `docker build` no necesita red.
- **`COPY target/saludos-0.0.1-SNAPSHOT.jar app.jar`** copia el JAR a la imagen. El origen es una ruta de nuestro equipo, relativa a la carpeta desde la que ejecutamos `docker build`. Se separa con una barra normal (`/`) aunque estemos en Windows. Esta instrucción crea la capa con nuestro programa.
- **`EXPOSE 8080`** anota el puerto de la aplicación. No publica nada.
- **`ENTRYPOINT ["java", "-jar", "app.jar"]`** es el comando que se ejecuta cuando el contenedor arranca. La forma de lista, con las palabras entre comillas y separadas por comas, hace que Java sea el proceso principal del contenedor; así `docker stop` le llega directamente y lo para con orden.

### Paso 5: construir la imagen

En la segunda terminal, dentro de la carpeta del proyecto:

```bash
docker build -t saludos:1.0 .
```

Cada parte del comando:

- `docker build` construye una imagen siguiendo un `Dockerfile`.
- `-t saludos:1.0` (*tag*) le da nombre y etiqueta a la imagen resultante. Sin `-t`, la imagen quedaría sin nombre y sería incómoda de usar. El nombre es `saludos`; la etiqueta, `1.0`, indica la versión.
- El **punto final** es el **contexto de construcción**: la carpeta cuyo contenido puede usar `COPY`. El punto significa "la carpeta actual". Es obligatorio: sin él, el comando da un error de que requiere un argumento.

Salida esperada (abreviada; los tiempos cambian):

<pre>
C:\Users\Mananas\saludos>docker build -t saludos:1.0 .
[+] Building 1.4s (7/7) FINISHED                              docker:desktop-linux
 => [internal] load build definition from Dockerfile                          0.0s
 => => transferring dockerfile: 2.35kB                                        0.0s
 => [internal] load metadata for docker.io/library/eclipse-temurin:21-jre     0.0s
 => [internal] load .dockerignore                                             0.0s
 => => transferring context: 2B                                               0.0s
 => [internal] load build context                                             0.3s
 => => transferring context: 19.91MB                                          0.3s
 => [1/2] FROM docker.io/library/eclipse-temurin:21-jre                       0.0s
 => [2/2] COPY target/saludos-0.0.1-SNAPSHOT.jar app.jar                      0.5s
 => exporting to image                                                        0.4s
 => => exporting layers                                                       0.4s
 => => writing image sha256:7033f69c99c4...                                   0.0s
 => => naming to docker.io/library/saludos:1.0                                0.0s
</pre>

Las líneas `[internal]` son preparativos de Docker. Las importantes son las numeradas, una por cada instrucción que añade una capa: `[1/2] FROM` (la base, que ya teníamos) y `[2/2] COPY` (nuestro JAR). `EXPOSE` y `ENTRYPOINT` no aparecen porque no añaden ficheros. La línea `transferring context: 19.91MB` es Docker enviando al motor el contenido de la carpeta, y se parece mucho al tamaño de nuestro JAR porque casi todo lo que hay en la carpeta que le sirve es el JAR de `target`.

Comprobamos el resultado:

```bash
docker images
```

```bash
docker history saludos:1.0
```

<pre>
C:\Users\Mananas\saludos>docker images
IMAGE                    ID             DISK USAGE   CONTENT SIZE   EXTRA
eclipse-temurin:21-jre   1a66e3b47da9        314MB          121MB
saludos:1.0              7033f69c99c4        334MB          141MB

C:\Users\Mananas\saludos>docker history saludos:1.0
IMAGE          CREATED          CREATED BY                                      SIZE      COMMENT
7033f69c99c4   29 seconds ago   ENTRYPOINT ["java" "-jar" "app.jar"]            0B        buildkit.dockerfile.v0
&amp;lt;missing&amp;gt;      29 seconds ago   EXPOSE [8080/tcp]                               0B        buildkit.dockerfile.v0
&amp;lt;missing&amp;gt;      29 seconds ago   COPY target/saludos-0.0.1-SNAPSHOT.jar app.j…   19.9MB    buildkit.dockerfile.v0
&amp;lt;missing&amp;gt;      3 weeks ago      ... (las capas de eclipse-temurin:21-jre)       314MB
</pre>

La imagen `saludos:1.0` es la de `eclipse-temurin:21-jre` más tres líneas: la del JAR, de 19,9 MB, y las dos de `0B`. Esas tres son nuestro `Dockerfile` en forma de capas. Las capas de debajo (en un `eclipse-temurin` real son varias, con Linux, la configuración de zona horaria y el JRE) son exactamente las de la imagen base: no se han copiado ni modificado.

### Paso 6: ejecutar la imagen

```bash
docker run -d -p 8081:8080 --name saludos saludos:1.0
```

Es el mismo `docker run` que usamos con `nginx` al principio de la Demo 1. `-d` en segundo plano, `--name saludos` el nombre del contenedor y `saludos:1.0` la imagen, esta vez nuestra. `-p 8081:8080` publica el puerto 8080 del contenedor (el de Spring Boot) en el 8081 del equipo (primer número: el del equipo; segundo: el del contenedor). Recordamos el error más frecuente con los puertos: el 8080 del equipo lo ocupa Jenkins, y por eso el puerto del equipo es el 8081, mientras que el 8080 del contenedor no cambia.

```bash
docker ps
```

<pre>
C:\Users\Mananas\saludos>docker ps
CONTAINER ID   IMAGE         COMMAND               CREATED         STATUS         PORTS                    NAMES
4421bae37d00   saludos:1.0   "java -jar app.jar"   13 seconds ago  Up 12 seconds  0.0.0.0:8081->8080/tcp   saludos
</pre>

La columna `COMMAND` muestra el `ENTRYPOINT` de nuestro `Dockerfile`: `"java -jar app.jar"`. Esperamos unos segundos a que Spring Boot arranque (tarda lo mismo que fuera de Docker) y vemos los registros:

```bash
docker logs saludos
```

<pre>
  .   ____          _            __ _ _
 /\\ / ___'_ __ _ _(_)_ __  __ _ \ \ \ \
( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \
 \\/  ___)| |_)| | | | | || (_| |  ) ) ) )
  '  |____| .__|_| |_|_| |_\__, | / / / /
 =========|_|==============|___/=/_/_/_/

 :: Spring Boot ::                (v4.1.1)

2026-10-27T19:19:16.078Z  INFO 1 --- [saludos] [           main] com.curso.Aplicacion      : Starting Aplicacion v0.0.1-SNAPSHOT using Java 21 with PID 1
...
2026-10-27T19:19:17.235Z  INFO 1 --- [saludos] [           main] o.s.boot.tomcat.TomcatWebServer : Tomcat initialized with port 8080 (http)
...
2026-10-27T19:19:18.402Z  INFO 1 --- [saludos] [           main] com.curso.Aplicacion      : Started Aplicacion in 2.4 seconds
</pre>

Es el mismo arranque de las sesiones de Spring Boot, con una diferencia: `PID 1`. El PID es el número de proceso, y el 1 es el primero que arranca en el sistema donde se ejecuta. Dentro de un contenedor, el proceso del `ENTRYPOINT` es el único que arranca, y por eso es el 1.

Abrimos `http://localhost:8081/api/saludo`:

<pre>
{"mensaje":"Hola desde Spring Boot","equipo":"4421bae37d00","sistema":"Linux","java":"21.0.12.1"}
</pre>

Ponemos al lado las dos respuestas, la de Windows (puerto 8082) y la del contenedor (puerto 8081):

| | Fuera de Docker (8082) | Dentro del contenedor (8081) |
|---|---|---|
| `equipo` | `MANANAS-PC` (el nombre del PC) | `4421bae37d00` (el `CONTAINER ID` de `docker ps`) |
| `sistema` | `Windows 11` | `Linux` |
| `java` | La versión instalada en el PC | La del JRE de la imagen |

Es el mismo JAR, ejecutado en dos entornos. Dentro del contenedor ve un Linux y un equipo con otro nombre, y la versión de Java no depende de la que tenga instalada el PC: es la de la imagen. Lo mismo ocurriría en un equipo sin Java, que es el caso de la Demo 3. Ahora paramos la aplicación de Windows con `Ctrl+C` en la primera terminal.

### Paso 7: una versión nueva y las capas

Cambiamos el mensaje en `SaludoController`: sustituimos `"Hola desde Spring Boot"` por `"Hola desde Spring Boot, versión 1.1"`. Reconstruimos el JAR y la imagen con una etiqueta nueva:

```bash
mvn clean package
```

```bash
docker build -t saludos:1.1 .
```

<pre>
C:\Users\Mananas\saludos>docker build -t saludos:1.1 .
[+] Building 0.9s (7/7) FINISHED                              docker:desktop-linux
 => [internal] load build definition from Dockerfile                          0.0s
 => [internal] load metadata for docker.io/library/eclipse-temurin:21-jre     0.0s
 => [internal] load .dockerignore                                             0.0s
 => [internal] load build context                                             0.3s
 => => transferring context: 19.91MB                                          0.3s
 => CACHED [1/2] FROM docker.io/library/eclipse-temurin:21-jre                0.0s
 => [2/2] COPY target/saludos-0.0.1-SNAPSHOT.jar app.jar                      0.4s
 => exporting to image                                                        0.1s
 => => naming to docker.io/library/saludos:1.1                                0.0s
</pre>

La palabra importante es `CACHED` en la línea de `FROM`. Docker recuerda las capas que construyó antes y, cuando una instrucción y los ficheros de los que depende no han cambiado, reutiliza la capa en lugar de rehacerla. Aquí la base no ha cambiado y se reutiliza, y `COPY` sí se rehace, porque el JAR es otro. Por eso esta segunda construcción es mucho más rápida que la primera. Es la razón de la regla de ordenar el `Dockerfile` de lo que menos cambia a lo que más cambia: lo que cambia pronto invalida la caché de todo lo que hay debajo.

Listamos las imágenes y ejecutamos las dos versiones a la vez, cada una en su puerto:

```bash
docker images
```

```bash
docker run -d -p 8084:8080 --name saludos11 saludos:1.1
```

<pre>
C:\Users\Mananas\saludos>docker images
IMAGE                    ID             DISK USAGE   CONTENT SIZE   EXTRA
eclipse-temurin:21-jre   1a66e3b47da9        314MB          121MB
saludos:1.0              7033f69c99c4        334MB          141MB   U
saludos:1.1              b90c4126d3c1        334MB          141MB
</pre>

`http://localhost:8081/api/saludo` sigue respondiendo con la versión 1.0 y `http://localhost:8084/api/saludo` con la 1.1. Dos versiones de la misma aplicación conviviendo, cada una con su etiqueta. La `U` de `EXTRA` marca la imagen `saludos:1.0` como en uso (la usa el contenedor `saludos`) en el momento de listarla.

Una observación sobre los tamaños: `saludos:1.0` y `saludos:1.1` muestran 334 MB cada una, pero en el disco no ocupan 668 MB. Las dos comparten las capas de `eclipse-temurin:21-jre`, que existen una sola vez, y cada una añade sus 20 MB. La columna `DISK USAGE` cuenta las capas compartidas en cada imagen; el espacio real del disco es menor. Es la ventaja de las capas de la que hablábamos en la teoría.

Limpiamos los dos contenedores:

```bash
docker rm -f saludos saludos11
```

### Resumen de comandos

| Comando | Qué hace |
|---|---|
| `mvn clean package` | Construye el JAR de Spring Boot en `target/` |
| `docker build -t nombre:etiqueta .` | Construye una imagen con el `Dockerfile` de la carpeta actual |
| `docker run -d -p equipo:contenedor --name nombre imagen` | Ejecuta un contenedor de la imagen publicando un puerto |
| `docker logs nombre` | Muestra la salida del contenedor |
| `docker rm -f nombre ...` | Borra uno o varios contenedores aunque estén en marcha |

### Conviene saber

- **El JAR tiene que existir.** Si se construye la imagen sin haber ejecutado antes `mvn package` (o con otro nombre de JAR en el `COPY`), el error es este:

<pre>
C:\Users\Mananas\saludos>docker build -t saludos:1.0 .
...
Dockerfile:32
--------------------
  30 |     # de la versión del proyecto. Esta instrucción crea la capa que contiene el JAR.
  31 |     # Ojo: el JAR tiene que existir antes de construir la imagen, o el build falla.
  32 | >>> COPY target/saludos-0.0.1-SNAPSHOT.jar app.jar
--------------------
ERROR: failed to build: failed to solve: failed to compute cache key: failed to calculate checksum of ref ...: "/target/saludos-0.0.1-SNAPSHOT.jar": not found
</pre>

  Docker señala la línea del `Dockerfile` que falla (`>>>`) y el fichero que no encuentra (`"/target/saludos-0.0.1-SNAPSHOT.jar": not found`). La causa es siempre la misma: el fichero de la derecha de `COPY` no está en la carpeta, o se llama distinto. Se corrige ejecutando `mvn package` o escribiendo el nombre que de verdad aparece en `target/`.
- **Cada cambio de código exige reconstruir los dos.** Un contenedor se crea desde la imagen, y la imagen tiene copiado el JAR de cuando se construyó. Si cambiamos el código y solo ejecutamos `docker build`, la imagen lleva el JAR viejo, porque Docker copia lo que haya en `target/`. El orden es siempre: `mvn package`, `docker build`, `docker run`.
- **El contexto de construcción.** `docker build` envía al motor todo el contenido de la carpeta del punto. Aquí son 19 MB porque casi todo es el JAR, pero en un proyecto con carpetas pesadas (`.git`, `node_modules`) se puede excluir lo que no hace falta con un fichero `.dockerignore`, que funciona como el `.gitignore` de S11-1. No lo necesitamos en este curso.
- **Docker Hub no hace falta para construir.** Mientras la imagen base esté en el equipo, `docker build` funciona sin red. Si la imagen base ya está en el equipo, Docker no intenta descargarla.
- **Espejo configurado en el motor (opcional).** Docker Desktop permite declarar un espejo en `Settings > Docker Engine` añadiendo `"registry-mirrors": ["https://mirror.gcr.io"]` al JSON de configuración. Con eso, `docker pull nginx` consultaría el espejo sin escribir el nombre largo. No se ha comprobado en el aula y no lo usamos: con el nombre largo y `docker tag` se ve qué ocurre.

---

## Demo 3: Publicar la imagen y ejecutarla en otro equipo

Una imagen sirve de poco si solo la tiene el equipo que la construyó. La idea de Docker es la contraria: la imagen es lo que se reparte, y quien la recibe la ejecuta con un comando, sin tener Java ni el proyecto. En esta demo llevamos `saludos` a otro equipo. Como no tenemos un segundo equipo en cada mesa, lo simulamos: borramos la imagen del nuestro y la recuperamos como lo haría otra persona.

### Antes: la etiqueta `latest`

Hay una etiqueta que no hemos escrito nunca, `latest`, y se interpreta mal con facilidad. Hacemos una prueba con las dos versiones de `saludos`:

```bash
docker tag saludos:1.0 saludos:latest
```

```bash
docker images
```

<pre>
C:\Users\Mananas\saludos>docker images
IMAGE                    ID             DISK USAGE   CONTENT SIZE   EXTRA
eclipse-temurin:21-jre   1a66e3b47da9        314MB          121MB
saludos:1.0              7033f69c99c4        334MB          141MB
saludos:1.1              b90c4126d3c1        334MB          141MB
saludos:latest           7033f69c99c4        334MB          141MB
</pre>

Hemos asignado `latest` a la versión **1.0**, aunque la 1.1 es más reciente. Docker no lo impide ni lo corrige: `latest` es una etiqueta como cualquier otra, que quien publica asigna a lo que quiera. Significa solo "la imagen sin etiqueta explícita". Por eso, para que todos trabajen con la misma versión, usamos siempre etiquetas con número (`mongo:8`, `postgres:17`, `saludos:1.1`).

Quitamos esa etiqueta, que no queremos:

```bash
docker rmi saludos:latest
```

### Variante A: Docker Hub

Necesitamos una cuenta gratuita en Docker Hub (se crea en `hub.docker.com`, con un nombre de usuario en minúsculas) y haber iniciado sesión desde la terminal con `docker login`, que pide el usuario y la contraseña (o un token de acceso) y los recuerda. Una imagen publicada en Docker Hub tiene en su nombre el usuario del propietario: `usuario/saludos:1.0`. Sustituimos `usuario` por el nuestro (en minúsculas).

```bash
docker tag saludos:1.0 usuario/saludos:1.0
```

```bash
docker push usuario/saludos:1.0
```

`docker push` sube una imagen a un registro. Solo sube las capas que el registro no tiene todavía: la base `eclipse-temurin` ya está en Docker Hub, y se sube únicamente la capa de nuestro JAR.

<pre>
C:\Users\Mananas\saludos>docker push usuario/saludos:1.0
The push refers to repository [docker.io/usuario/saludos]
7c1f2a3b4d5e: Pushed
9f8e7d6c5b4a: Mounted from library/eclipse-temurin
...
1.0: digest: sha256:3b1f... size: 856
</pre>

`Pushed` indica una capa subida y `Mounted from library/eclipse-temurin` una capa que ya estaba en Docker Hub y se reutiliza sin subirla. Simulamos el otro equipo borrando las imágenes locales (primero el nombre largo y después el corto) y ejecutando la imagen publicada:

```bash
docker rmi usuario/saludos:1.0 saludos:1.0 saludos:1.1
```

```bash
docker run -d -p 8081:8080 --name saludos usuario/saludos:1.0
```

<pre>
C:\Users\Mananas\saludos>docker run -d -p 8081:8080 --name saludos usuario/saludos:1.0
Unable to find image 'usuario/saludos:1.0' locally
1.0: Pulling from usuario/saludos
9f8e7d6c5b4a: Already exists
7c1f2a3b4d5e: Pull complete
Digest: sha256:3b1f...
Status: Downloaded newer image for usuario/saludos:1.0
a8e1c0d4f2b7...
</pre>

La imagen no estaba en el equipo y `docker run` la descarga antes de crear el contenedor. Como `eclipse-temurin` ya está en este equipo (línea `Already exists`), solo baja la capa del JAR. Una persona de otro equipo escribiría exactamente el mismo comando, con nuestro usuario, y obtendría nuestra aplicación. Esa persona no necesita Java, ni Maven, ni el proyecto.

### Variantes B y C: un fichero

El espejo solo sirve para descargar, así que sin Docker Hub la imagen se lleva en un fichero. `docker save` guarda una imagen, con todas sus capas, en un fichero `.tar`:

```bash
docker save -o saludos-1.0.tar saludos:1.0
```

`-o` es *output* (salida): el nombre del fichero que se crea. El resultado ocupa unos 140 MB, porque contiene la imagen completa, la base incluida. El fichero se comparte por el Drive (o se pasa en una memoria USB), y la otra persona, o nosotros mismos en el otro equipo, la carga con `docker load`. Simulamos el otro equipo borrando las imágenes:

```bash
docker rmi saludos:1.0 saludos:1.1
```

```bash
docker load -i saludos-1.0.tar
```

<pre>
C:\Users\Mananas\saludos>docker load -i saludos-1.0.tar
Loaded image: saludos:1.0
</pre>

Y la ejecutamos con el mismo `docker run`:

```bash
docker run -d -p 8081:8080 --name saludos saludos:1.0
```

En el navegador, `http://localhost:8081/api/saludo`. Lo importante es lo que no hemos necesitado: ni el código fuente, ni `mvn`, ni la versión de Java del PC. Solo Docker y un fichero (o un nombre de imagen).

Para repartir el fichero, quien lo guarda lo sube a una carpeta compartida del Drive. Hay otro registro, `ghcr.io` (el de GitHub, que pide un token con el permiso `write:packages`), que permitiría la variante A con la cuenta de GitHub en lugar de la de Docker Hub. No se ha comprobado que responda desde el aula, y lo dejamos como opción si llegara a funcionar.

### Limpiar

```bash
docker rm -f saludos
```

Dejamos las imágenes `saludos` y `eclipse-temurin` en el equipo: se vuelven a usar en las prácticas. Los ficheros `.tar` se pueden borrar de la carpeta cuando ya no hagan falta, porque ocupan lo mismo que la imagen.

### Resumen de comandos

| Comando | Qué hace |
|---|---|
| `docker tag saludos:1.0 usuario/saludos:1.0` | Da a la imagen el nombre que necesita un registro: usuario, nombre y etiqueta |
| `docker push usuario/saludos:1.0` | Sube la imagen al registro (variante A) |
| `docker save -o fichero.tar imagen` | Guarda la imagen en un fichero (variantes B y C) |
| `docker load -i fichero.tar` | Carga una imagen desde un fichero (variantes B y C) |
