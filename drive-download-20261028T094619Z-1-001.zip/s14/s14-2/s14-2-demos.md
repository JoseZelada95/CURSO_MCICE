# S14-2 Demos

## Objetivos

Hasta ahora Jenkins construía y mostraba el resultado en su página, pero alguien tenía que abrir la página para enterarse. En esta parte hacemos que la construcción hable. Una construcción fallida solo sirve si alguien se entera, y una construcción que vuelve a funcionar también merece un aviso. El bloque `post` de un pipeline declarativo define qué hacer según el resultado: cuando falla, cuando termina bien y cuando se recupera tras un fallo. Los avisos se escriben en la consola de la construcción, que es lo que Jenkins deja a la vista de todos, y el bloque es el mismo que se usaría después para enviar un correo o un mensaje a un canal de equipo.

Un resultado verde o rojo informa de una construcción, pero un proyecto necesita ver la evolución. Jenkins guarda el resultado de cada ejecución y, con el plugin de JUnit que ya utilizamos, dibuja la tendencia de las pruebas: cuántas pasan, cuántas fallan y desde qué construcción. Con ese historial se localiza la construcción que rompió algo, que es la información que más tiempo ahorra cuando varias personas modifican el mismo proyecto.

Al terminar esta parte los alumnos son capaces de:
- Añadir a un `Jenkinsfile` un bloque `post` a nivel de pipeline con las condiciones `failure`, `success` y `fixed`.
- Escribir un aviso que incluya el nombre del job y el número de construcción con `env.JOB_NAME` y `env.BUILD_NUMBER`.
- Explicar qué distingue `fixed` de `success` y por qué una construcción recuperada muestra los dos avisos.
- Leer la tendencia de las pruebas y el historial de construcciones de un job.
- Localizar la primera construcción en rojo y los cambios que contenía.

---

## El material de esta parte

Esta parte no crea ningún proyecto nuevo. Trabajamos con `contactos`, el proyecto de S11-1 que Jenkins construye desde S13-2: la clase `Contacto` con Lombok, `ContactoTests` con cinco pruebas y `AplicacionTests` con `contextLoads`, seis pruebas en total y sin base de datos. El zip `s14-2-demos.zip` lo incluye tal cual, sin ningún cambio en el código Java ni en el `pom.xml`. Lo único distinto es el `Jenkinsfile`, que parte del de la Demo 2 de S14-1 (etapas `Compilar`, `Probar` con `post` y `always`, y `Empaquetar` con `archiveArtifacts`) y le añade un bloque `post` al final.

<pre>
s14-2-demos/
├── cambios/
│   ├── cambio-inocuo.txt
│   ├── cambio-rompe-email.txt
│   └── cambio-rompe-resumen.txt
└── contactos/
    ├── src/
    ├── .gitattributes
    ├── .gitignore
    ├── Jenkinsfile
    └── pom.xml
</pre>

La carpeta `cambios` no es código del proyecto: son tres fichas de texto que indican, línea por línea, qué se cambia en `contactos` para provocar cada situación. Los dos cambios que rompen una prueba son los mismos que ya usamos en S13-2 y S14-1. Los ficheros llevan extensión `.txt` para que no se confundan con código ni se suban al repositorio.

El repositorio es el de siempre, `https://github.com/JD-CFTIC/contactos.git` (privado, con el token de S11-1), en la rama `main`. Cada alumno usa el suyo.

### Antes de empezar

Comprobamos cuatro cosas, porque la Demo 1 se ve tal como se cuenta aquí solo si se cumplen:

1. Jenkins responde en `http://localhost:8080`. Si no responde, desde un `cmd` de administrador: `sc query Jenkins` y, si está parado, `net start Jenkins`.
2. El job `contactos` es el de la Demo 2 de S14-1: tipo `Pipeline`, `Pipeline script from SCM` con Git, `Branch Specifier` `*/main` y `Script Path` `Jenkinsfile`. El sondeo (`Poll SCM`, `H/2 * * * *`) puede estar activado o no: más abajo usamos `Build Now` para no esperar.
3. La última construcción del job está en verde. Si estuviera en rojo, la primera construcción con avisos saldría como recuperada y la Demo 1 no se vería como se cuenta.
4. La copia local de `contactos` en IntelliJ está al día (`git pull`) y `git status` dice `nothing to commit, working tree clean`.

Una aclaración sobre los números. En los ejemplos las construcciones tienen números concretos (la 8, la 9...) para que se pueda seguir la historia. Los números de cada alumno serán otros, porque dependen de cuántas construcciones lleve su job. El nombre del job también sale en los avisos: si el job se llama `contactos`, saldrá `contactos`; si se llama de otra forma, saldrá ese nombre.

---

## Demo 1: Avisos de fallo y de recuperación con post

### Qué es un aviso y por qué lo necesitamos

Pensemos en un corte de luz en casa. Lo normal es que nos enteremos de dos cosas: de que se ha ido la luz y de que ha vuelto. Lo que no esperamos es que alguien nos avise cada minuto de que sigue habiendo luz. Un buen aviso informa de los cambios que importan y se calla el resto.

Con Jenkins pasa lo mismo. Queremos enterarnos de que una construcción ha fallado y de que el proyecto ha vuelto a funcionar, sin tener que mirar la página del job cada pocos minutos. En esta demo el aviso es una línea que la construcción escribe en su consola. Es lo más sencillo que Jenkins deja a la vista de todos y no necesita configurar nada más. Más adelante veremos qué cambia en un equipo real.

### El bloque post, otra vez

En S14-1 usamos `post` dentro de la etapa `Probar` para publicar las pruebas. Un `post` define qué hacer cuando algo termina, según cómo haya terminado. Se puede escribir en dos sitios:

| Dónde se escribe | Cuándo se evalúa | Ejemplo en nuestro `Jenkinsfile` |
|---|---|---|
| Dentro de una `stage` | Al terminar esa etapa | `always` con `junit`, en `Probar` |
| Al nivel de `pipeline`, después de `stages` | Al terminar todo el pipeline, o cuando una etapa falla y el pipeline se detiene | Los avisos de esta demo |

Es como el cierre de caja de una tienda. Cada turno puede hacer su propio recuento al terminar, y además el encargado hace un cierre del día cuando ya ha acabado todo. Los avisos que queremos hablan de la construcción entera ("ha fallado", "ha ido bien"), así que van en el cierre del día: el `post` del nivel de `pipeline`. El `post` de la etapa `Probar` se queda donde está.

### Las condiciones: failure, success y fixed

Dentro de un `post`, cada bloque lleva delante una **condición**: una palabra que indica en qué situación se ejecuta ese bloque. Jenkins mira cómo ha terminado la construcción y ejecuta solo los bloques cuya condición se cumple. Ya conocemos `always`, que se ejecuta siempre. Hoy añadimos tres:

- **`failure`**: la construcción ha terminado en rojo (*Failed*). Es la alarma de la casa: suena cuando algo ha ido mal.
- **`success`**: la construcción ha terminado en verde (*Stable*). Es la luz verde que confirma que todo ha ido bien.
- **`fixed`**: esta construcción ha terminado bien y la anterior no. Avisa de una recuperación. Es el "ya hay luz otra vez": se dice una vez, cuando vuelve, y no en cada minuto siguiente en que sigue habiendo luz.

`success` y `fixed` no se excluyen. Una construcción que se recupera cumple las dos a la vez: ha terminado bien (`success`) y la anterior no (`fixed`). Por eso, en la recuperación, saldrán los dos avisos. Lo veremos en la consola.

Existen más condiciones (`unstable`, `changed`, `aborted`, `unsuccessful`, `regression`, `cleanup`) que aquí no usamos. Con estas cuatro se cubre lo que un equipo necesita saber al principio.

### Los datos del aviso: env.JOB_NAME y env.BUILD_NUMBER

Un aviso que dijera solo "ha fallado" no serviría: ¿qué proyecto?, ¿cuál de todas las construcciones? Necesitamos que el mensaje lleve el nombre del proyecto y el número de la construcción.

Jenkins prepara, para cada construcción, un conjunto de **variables de entorno**: valores con nombre que le entrega al pipeline, igual que el sistema operativo entregaba `POSTGRES_PASSWORD` a Spring Boot en S07. En un `Jenkinsfile` se leen con `env.` delante del nombre. Usamos dos:

- `env.JOB_NAME`: el nombre del job. En nuestro caso, `contactos`.
- `env.BUILD_NUMBER`: el número de la construcción, el `#12` que aparece en la lista de construcciones, pero sin el `#`.

Existen más (por ejemplo `env.BUILD_URL`, la dirección de la construcción), pero con estas dos el aviso ya dice qué proyecto y cuál construcción.

### Comillas dobles para que ${...} se sustituya

Para meter el valor de una variable dentro de un texto, el `Jenkinsfile` (que está escrito en Groovy) usa la forma `${variable}`. Hay una condición: el texto tiene que ir entre **comillas dobles**. Con comillas simples, Groovy no sustituye nada y escribe el texto tal cual, con las llaves incluidas. Lo comprobamos con el intérprete de Groovy usando los mismos valores que veremos después:

| Cómo se escribe | Qué sale |
|---|---|
| `"FALLO: la construccion ${env.BUILD_NUMBER} de ${env.JOB_NAME}"` | el texto con los valores sustituidos |
| `'FALLO: la construccion ${env.BUILD_NUMBER} de ${env.JOB_NAME}'` | el texto escrito literalmente |

<pre>
FALLO: la construccion 7 de contactos
FALLO: la construccion ${env.BUILD_NUMBER} de ${env.JOB_NAME}
</pre>

Hasta ahora habíamos escrito `bat 'mvn -B test'` con comillas simples, porque ahí no hay nada que sustituir. En los avisos usamos dobles.

Una última regla, la de S14-1: los textos de `echo` van sin tildes, porque la consola de Windows puede deformarlas. Los comentarios del `Jenkinsfile`, que Jenkins no escribe en ninguna consola, sí llevan tildes.

### El código, pieza a pieza

Partimos del `Jenkinsfile` de la Demo 2 de S14-1, que no cambia: `tools`, las tres etapas y el `post` con `always` dentro de `Probar` se quedan como están. Lo nuevo va **después de `stages`** y **antes de la llave que cierra `pipeline`**. Empieza con el `post`:

```groovy
    // Este post está fuera de stages, al nivel de pipeline: se evalúa una sola vez, cuando han
    // terminado todas las etapas (o cuando una ha fallado y el pipeline se ha detenido).
    // El post de la etapa Probar, en cambio, se evalúa al terminar esa etapa.
    post {
```

Primero el aviso de fallo:

```groovy
        // failure: se ejecuta solo si la construcción ha terminado en rojo (Failed).
        failure {
            // env.JOB_NAME es el nombre del job ("contactos") y env.BUILD_NUMBER es el número de
            // esta construcción (7, 8, 9...). Jenkins las crea solo para cada construcción.
            // Las comillas dobles hacen que ${...} se sustituya por su valor; con comillas simples
            // saldría escrito el texto ${env.JOB_NAME}. Sin tildes, por la consola de Windows.
            echo "FALLO: la construccion ${env.BUILD_NUMBER} de ${env.JOB_NAME} ha fallado. Revisar la etapa en rojo."
        }
```

Después, el aviso de que todo ha ido bien:

```groovy
        // success: se ejecuta solo si la construcción ha terminado en verde (Stable).
        success {
            echo "OK: la construccion ${env.BUILD_NUMBER} de ${env.JOB_NAME} ha terminado bien."
        }
```

Y por último, el aviso de recuperación:

```groovy
        // fixed: se ejecuta cuando esta construcción termina bien y la anterior no había terminado bien.
        // Es decir, avisa del paso de rojo a verde y no de cada verde. En una construcción que se
        // recupera se cumplen a la vez fixed y success, así que salen los dos avisos.
        fixed {
            echo "RECUPERADA: ${env.JOB_NAME} vuelve a funcionar desde la construccion ${env.BUILD_NUMBER}."
        }
```

Cada `echo` se ejecuta solo si su condición se cumple. Así queda el `Jenkinsfile` completo, que es el que contiene el zip en `contactos/Jenkinsfile`. Es el que pegamos en IntelliJ en el paso siguiente:

```groovy
/*
 * S14-2 Demo 1: Avisos de fallo y de recuperación con post
 *
 * Objetivo: que cada construcción escriba un aviso cuando falla, cuando termina bien
 * y cuando vuelve a funcionar después de un fallo.
 *
 * Lo que hace este ejemplo:
 *   - Parte del Jenkinsfile de S14-1 Demo 2 (compilar, probar y empaquetar) sin cambiar sus etapas
 *   - Añade al final un bloque post a nivel de pipeline con las condiciones failure, success y fixed
 *   - Cada aviso incluye el nombre del job y el número de construcción
 *
 * Concepto clave: el aviso es un paso más que Jenkins ejecuta según el resultado de la construcción.
 * Aquí es un echo en la consola; en un equipo real, el mismo bloque enviaría un correo o un mensaje de chat.
 */
pipeline {

    // Cualquier agente disponible: en el aula, el propio Jenkins.
    agent any

    // tools le dice a Jenkins qué JDK y qué Maven debe poner en el PATH durante la construcción.
    // El servicio de Jenkins no ve el PATH del usuario que lo instaló, así que sin este bloque
    // el comando mvn no se encontraría.
    // Los nombres entre comillas son los de Manage Jenkins > Tools (S13-2) y deben
    // coincidir letra por letra con ellos; si no coinciden, Jenkins no podrá encontrar la herramienta.
    tools {
        jdk 'jdk-21'
        maven 'maven-3.9'
    }

    stages {

        stage('Compilar') {
            steps {
                // -B (batch mode) hace que Maven escriba una salida limpia, sin colores
                // ni barras de progreso, pensada para leerse en un registro y no en una terminal.
                // clean borra target/ antes de empezar: así no quedan informes de
                // pruebas de una construcción anterior que confundan a Jenkins.
                bat 'mvn -B clean compile'
            }
        }

        stage('Probar') {
            steps {
                // mvn test compila las pruebas y las ejecuta con Surefire.
                // Si una prueba falla, Maven termina con error y esta etapa se pone en rojo.
                bat 'mvn -B test'
            }
            // post define qué hacer cuando termina la etapa, según su resultado.
            post {
                // always se ejecuta siempre, también cuando las pruebas han fallado.
                // Sin él, el informe solo se publicaría con las construcciones en verde,
                // que es justo cuando menos falta hace.
                always {
                    // junit lee los informes XML de Surefire y los muestra en Jenkins.
                    // allowEmptyResults evita un segundo error si no llegó a generarse ningún informe
                    // (por ejemplo, si las pruebas ni siquiera compilan).
                    junit testResults: 'target/surefire-reports/*.xml', allowEmptyResults: true
                }
            }
        }

        stage('Empaquetar') {
            steps {
                // Las pruebas ya se ejecutaron en la etapa anterior, así que aquí las saltamos
                // con -DskipTests para no hacerlas dos veces.
                // Maven genera target/contactos-0.0.1-SNAPSHOT.jar.
                bat 'mvn -B package -DskipTests'
                // archiveArtifacts guarda el JAR dentro de Jenkins, asociado a esta construcción,
                // para poder descargarlo después. El patrón target/*.jar no incluye el
                // fichero .jar.original, porque este termina en .original.
                archiveArtifacts artifacts: 'target/*.jar'
            }
        }
    }

    // Este post está fuera de stages, al nivel de pipeline: se evalúa una sola vez, cuando han
    // terminado todas las etapas (o cuando una ha fallado y el pipeline se ha detenido).
    // El post de la etapa Probar, en cambio, se evalúa al terminar esa etapa.
    post {

        // failure: se ejecuta solo si la construcción ha terminado en rojo (Failed).
        failure {
            // env.JOB_NAME es el nombre del job ("contactos") y env.BUILD_NUMBER es el número de
            // esta construcción (7, 8, 9...). Jenkins las crea solo para cada construcción.
            // Las comillas dobles hacen que ${...} se sustituya por su valor; con comillas simples
            // saldría escrito el texto ${env.JOB_NAME}. Sin tildes, por la consola de Windows.
            echo "FALLO: la construccion ${env.BUILD_NUMBER} de ${env.JOB_NAME} ha fallado. Revisar la etapa en rojo."
        }

        // success: se ejecuta solo si la construcción ha terminado en verde (Stable).
        success {
            echo "OK: la construccion ${env.BUILD_NUMBER} de ${env.JOB_NAME} ha terminado bien."
        }

        // fixed: se ejecuta cuando esta construcción termina bien y la anterior no había terminado bien.
        // Es decir, avisa del paso de rojo a verde y no de cada verde. En una construcción que se
        // recupera se cumplen a la vez fixed y success, así que salen los dos avisos.
        fixed {
            echo "RECUPERADA: ${env.JOB_NAME} vuelve a funcionar desde la construccion ${env.BUILD_NUMBER}."
        }
    }
}
```

### Paso 1: subir el Jenkinsfile y ver el primer aviso

1. En IntelliJ abrimos `contactos` y, en el panel `Project` (`Alt+1`), hacemos doble clic en `Jenkinsfile`, que está en la raíz, junto a `pom.xml`.
2. Seleccionamos todo el contenido (`Ctrl+A`) y pegamos el `Jenkinsfile` completo de arriba.
3. Abrimos la terminal de IntelliJ (`Alt+F12`), que se abre en la carpeta del proyecto, y ejecutamos:

```bash
git add Jenkinsfile
git commit -m "Anade avisos con post al Jenkinsfile"
git push
```

   El mensaje del commit va sin tildes por la misma razón que el texto de `echo`: la consola de Windows puede deformarlas.

4. En Jenkins abrimos el job `contactos`. Si el sondeo está activado, esperamos a que lo detecte (hasta dos minutos). Si no, pulsamos `Build Now` (*Construir ahora*).
5. Cuando la construcción nueva termina (la 8 en nuestro ejemplo), la abrimos y entramos en `Console Output` (*Salida de consola*). Buscamos las últimas líneas.

Salida esperada, en la consola de la construcción:

<pre>
OK: la construccion 8 de contactos ha terminado bien.
</pre>

Fijémonos en lo que no aparece. No hay aviso de recuperación, porque la construcción anterior estaba en verde y por tanto esta no "se ha recuperado" de nada. Tampoco hay aviso de fallo.

Jenkins escribe alrededor de nuestro mensaje otras líneas suyas (una antes que indica el paso, otra al final con el resultado). Su texto exacto no lo hemos comprobado en el aula, así que aquí mostramos solo la línea que escribe nuestro `echo`.

### Paso 2: provocar un fallo y leer el aviso

Rompemos una prueba con el cambio de S13-2 y S14-1. Lo tenemos descrito en `cambios/cambio-rompe-email.txt`.

1. En el panel `Project` abrimos `src/main/java/com/curso/model/Contacto.java` y buscamos `emailValido` (`Ctrl+F`).
2. En la línea del `return` quitamos la última condición, `&& !email.contains(" ")`, y dejamos:

```java
        return email.contains("@") && email.contains(".");
```

3. Antes de enviar el cambio, lo probamos en local, porque Jenkins es la red de seguridad y no el primer sitio donde se prueba (S13-2). En la terminal de IntelliJ:

```bash
mvn -B test
```

Líneas relevantes de la salida de Maven. Falla la prueba `emailSinPuntoOConEspaciosNoEsValido`, porque un correo con un espacio ya se considera válido:

<pre>
[INFO] Tests run: 1, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 1.851 s -- in com.curso.AplicacionTests
[ERROR] Tests run: 5, Failures: 1, Errors: 0, Skipped: 0, Time elapsed: 0.039 s &lt;&lt;&lt; FAILURE! -- in com.curso.model.ContactoTests
[ERROR] com.curso.model.ContactoTests.emailSinPuntoOConEspaciosNoEsValido -- Time elapsed: 0.012 s &lt;&lt;&lt; FAILURE!
[ERROR] Failures: 
[ERROR]   ContactoTests.emailSinPuntoOConEspaciosNoEsValido:57 expected: &lt;false&gt; but was: &lt;true&gt;
[ERROR] Tests run: 6, Failures: 1, Errors: 0, Skipped: 0
[INFO] BUILD FAILURE
</pre>

4. Enviamos el cambio roto a propósito:

```bash
git add .
git commit -m "Rompe emailValido"
git push
```

5. En Jenkins lanzamos la construcción (la 9 en el ejemplo). En la vista de etapas, `Compilar` sale en verde, `Probar` en rojo y `Empaquetar` sin ejecutar, igual que en la Demo 3 de S14-1. En `Console Output`, al final, está nuestro aviso:

<pre>
FALLO: la construccion 9 de contactos ha fallado. Revisar la etapa en rojo.
</pre>

El aviso de fallo ha salido porque la construcción terminó en rojo. No ha salido el de `OK`, porque `success` no se cumple. Y el informe de pruebas sigue publicado gracias al `always` de la etapa `Probar`, que no hemos tocado.

### Paso 3: corregir y ver la recuperación

1. Volvemos a `Contacto.java` y restauramos la línea original:

```java
        return email.contains("@") && email.contains(".") && !email.contains(" ");
```

2. Probamos en local con `mvn -B test` (seis pruebas, `BUILD SUCCESS`) y enviamos el arreglo:

```bash
git add .
git commit -m "Arregla emailValido"
git push
```

3. Lanzamos la construcción (la 10) y miramos el final de la consola. Ahora salen dos avisos:

<pre>
RECUPERADA: contactos vuelve a funcionar desde la construccion 10.
OK: la construccion 10 de contactos ha terminado bien.
</pre>

Los dos son correctos. La construcción 10 ha terminado bien (`success`) y la 9, la anterior, había fallado (`fixed`). El orden en que salen lo decide Jenkins, no el orden en que los escribimos en el fichero: según su documentación, `fixed` se evalúa antes que `success`. Esa parte del orden no la hemos comprobado en el aula.

### Paso 4: otro verde, y el aviso de recuperación no se repite

Para ver el valor de `fixed`, lanzamos una construcción más sin romper nada. Hacemos un cambio inocuo, que no altera lo que hace el programa (`cambios/cambio-inocuo.txt`): añadimos una línea de comentario al final de `Aplicacion.java`, con el texto `Demo 1: comentario inocuo`, y la enviamos.

```bash
git add .
git commit -m "Comentario inocuo"
git push
```

La construcción 11 escribe solo:

<pre>
OK: la construccion 11 de contactos ha terminado bien.
</pre>

La recuperación se avisa una vez, cuando ocurre. Si `fixed` se escribiera en todas las construcciones verdes, el aviso perdería su sentido y dejaríamos de leerlo, que es justo lo que queremos evitar.

### Resumen de la demo

Con los tres cambios, lo que esperamos que escriba cada construcción es esto. Los resultados de Maven, de las pruebas y de los avisos se han comprobado con una simulación que ejecuta Maven y Git de verdad y evalúa las condiciones de `post` según la documentación de Jenkins (más detalle en la última sección):

| Construcción | Qué contiene | Resultado | Pruebas | Avisos que salen |
|---|---|---|---|---|
| 8 | `Jenkinsfile` con `post` | Verde | 6, ninguna falla | `OK` |
| 9 | Se quita `&& !email.contains(" ")` | Rojo | 6, falla 1 | `FALLO` |
| 10 | Se restaura la línea | Verde | 6, ninguna falla | `RECUPERADA` y `OK` |
| 11 | Cambio inocuo | Verde | 6, ninguna falla | `OK` |

### Y en un equipo real

En el aula el aviso es una línea de consola porque no necesitamos ningún servidor más. En un equipo real el bloque `post` es el mismo, con las mismas condiciones, y lo único que cambia es lo que hace cada una: en lugar de escribir con `echo`, envía un mensaje a quien corresponda, normalmente un correo o un mensaje a un canal de chat del equipo. Un correo de aviso de fallo, con el paso `mail`, tendría esta forma. La mostramos como referencia y no la ejecutamos: necesita que Jenkins tenga configurado un servidor de correo, y esa parte no se hace en el curso.

<pre>
        failure {
            mail to: 'equipo@example.com',
                 subject: "FALLO: ${env.JOB_NAME} #${env.BUILD_NUMBER}",
                 body: "La construccion ha fallado. Detalle: ${env.BUILD_URL}"
        }
</pre>

Lo que sí es transferible a cualquier equipo es la idea: un aviso de fallo y otro de recuperación, ambos con el nombre del proyecto y el número de construcción, para que quien lo reciba sepa qué abrir.

---

## Demo 2: Tendencia de pruebas y construcción culpable

### Para qué sirve el historial

Imaginemos que en casa empieza a gotear el grifo. Para saber cuándo empezó, buscamos la última vez que estaba seco y la primera vez que lo vimos mojado. Lo que cambió entre una y otra es lo que tenemos que revisar: no hace falta mirar todo lo que ha pasado en casa desde que se compró.

Con las construcciones de Jenkins hacemos exactamente eso. Una construcción roja nos dice que algo falla, pero no cuándo empezó. Para saberlo necesitamos el historial.

### Los conceptos, antes de empezar

- **Historial de construcciones** (*Build History*): la lista de todas las construcciones del job, con su número, su color y su fecha.
- **Resultado de las pruebas** de una construcción: cuántas pruebas se ejecutaron, cuántas pasaron y cuáles fallaron. Lo publica el paso `junit` que ya tenemos desde S13-2 y S14-1.
- **Tendencia de las pruebas** (*Test Result Trend*): una gráfica con un punto por construcción que dibuja Jenkins uniendo esos resultados. Se ve de un vistazo si los fallos aparecen, crecen o desaparecen.
- **Cambios de una construcción** (*Changes*): la lista de commits que han entrado en esa construcción desde la anterior, con su mensaje y su autor.
- **Última construcción buena y primera construcción mala**: la última verde antes de un fallo y la primera roja que viene después.
- **Construcción culpable**: la primera construcción en rojo de una racha. Es la que contiene el cambio que rompió algo. "Culpable" no señala a una persona, sino a una construcción: lo que buscamos es el cambio, no a quien lo hizo. El fallo se arregla con el cambio, no con la discusión.

### No hay nada nuevo que configurar

La gráfica sale de los informes que el pipeline ya publica en cada construcción. Es la consecuencia de haber puesto `junit` dentro de `post` con `always` en S14-1: el informe se publica tanto si las pruebas pasan como si fallan, y por eso cada construcción, también las rojas, aporta un punto a la gráfica. Si hubiéramos puesto `junit` como un paso más de `Probar`, las construcciones rojas se quedarían sin informe, y justo esas son las que queremos ver.

Por tanto, esta demo usa el mismo `Jenkinsfile` de la Demo 1, sin tocarlo. Lo único que hacemos es alimentar el historial con varias construcciones que alternan verde y rojo.

### El plan: cinco construcciones

Partimos de la última construcción de la Demo 1, la 11, que está en verde. Preparamos cinco construcciones más. La tercera lleva dos commits dentro a propósito, porque eso es lo que ocurre en un equipo real: la construcción que falla casi nunca contiene un único cambio.

| Construcción | Qué se hace | Cambios que contiene |
|---|---|---|
| 12 | Un cambio inocuo | Un commit: `Cambio inocuo 1` |
| 13 | Un cambio inocuo y se rompe `emailValido()`, con un solo `push` | Dos commits: `Cambio inocuo 2` y `Rompe emailValido` |
| 14 | Se arregla `emailValido()` | Un commit: `Arregla emailValido` |
| 15 | Se rompe `resumen()` | Un commit: `Rompe resumen` |
| 16 | Se arregla `resumen()` | Un commit: `Arregla resumen` |

En cada paso hacemos el cambio, lo enviamos y lanzamos la construcción antes de pasar al siguiente. Para no esperar al sondeo pulsamos `Build Now` justo después del `push`.

**Construcción 12.** Añadimos una línea de comentario al final de `Aplicacion.java` (`cambios/cambio-inocuo.txt`, con el texto `Demo 2: cambio inocuo 1`) y ejecutamos:

```bash
git add .
git commit -m "Cambio inocuo 1"
git push
```

**Construcción 13.** Primero otro comentario en `Aplicacion.java`, con el texto `Demo 2: cambio inocuo 2`, y un commit sin enviar:

```bash
git add .
git commit -m "Cambio inocuo 2"
```

Después rompemos `emailValido()` como en la Demo 1 (`cambios/cambio-rompe-email.txt`), hacemos un segundo commit y enviamos los dos de golpe:

```bash
git add .
git commit -m "Rompe emailValido"
git push
```

Ahora hay dos commits nuevos en el remoto, y la construcción 13 los trae los dos.

**Construcción 14.** Restauramos la línea de `emailValido()`:

```bash
git add .
git commit -m "Arregla emailValido"
git push
```

**Construcción 15.** Rompemos otra prueba distinta: quitamos el espacio que hay después de la coma en `resumen()` (`cambios/cambio-rompe-resumen.txt`):

```bash
git add .
git commit -m "Rompe resumen"
git push
```

**Construcción 16.** Restauramos la línea de `resumen()`:

```bash
git add .
git commit -m "Arregla resumen"
git push
```

### Qué debe recoger Jenkins

Estos son los datos que cada construcción debería dejar, comprobados con la simulación (Maven y Git reales). En todas se ejecutan seis pruebas:

| Construcción | Resultado | Pruebas que fallan | Avisos |
|---|---|---|---|
| 12 | Verde | Ninguna | `OK` |
| 13 | Rojo | 1: `emailSinPuntoOConEspaciosNoEsValido` | `FALLO` |
| 14 | Verde | Ninguna | `RECUPERADA` y `OK` |
| 15 | Rojo | 1: `resumenIncluyeEmailYTelefono` | `FALLO` |
| 16 | Verde | Ninguna | `RECUPERADA` y `OK` |

El mensaje de Maven de la construcción 15 es este (línea relevante):

<pre>
[ERROR]   ContactoTests.resumenIncluyeEmailYTelefono:42 expected: &lt;Lucía Pérez (lucia@example.com, 600123456)&gt; but was: &lt;Lucía Pérez (lucia@example.com,600123456)&gt;
</pre>

En una consola de Windows sin UTF-8, las tildes de `Lucía Pérez` pueden salir como `?`. Es solo la codificación de la consola, como en S13-2.

### Leer la tendencia

Abrimos la página del job `contactos`. En ella debería verse, junto a la lista de construcciones, la gráfica de tendencia de las pruebas (*Test Result Trend*), con un punto por construcción. Lo que esperamos ver, según los datos de la tabla anterior:

- Las pruebas totales no cambian: seis en todas las construcciones.
- Los fallos son 0, 1, 0, 1, 0 en las construcciones 12 a 16. Es decir, aparecen dos veces y desaparecen dos veces.

Esa forma de "dientes de sierra" es la que indica que alguien rompe y arregla cosas. Una gráfica sin fallos significa que las pruebas pasan siempre, y una gráfica con fallos que no bajan significa que nadie ha arreglado lo que se rompió.

La posición exacta de la gráfica, cuántas construcciones necesita para dibujarse y los nombres de los menús dependen de la versión de Jenkins y de sus plugins, y no los hemos comprobado en el aula. Si la gráfica no aparece en la página del job, sigue sirviendo el resultado de cada construcción: en la página de cada una, la opción `Test Result` (*Resultado de las pruebas*) muestra cuántas pasan y cuáles fallan.

### Localizar la construcción culpable

Con el historial delante, localizar el origen de un fallo es una consulta de segundos. El procedimiento tiene cinco pasos. Lo aplicamos al primer fallo de la secuencia:

1. **Buscar la primera construcción en rojo tras una racha en verde.** En el historial, la 12 está en verde y la 13 en rojo. La 12 es la última buena y la 13 es la construcción culpable.
2. **Abrir esa construcción y mirar `Changes` (*Cambios*).** La lista de la construcción 13 tiene los commits que entraron desde la 12: `Cambio inocuo 2` y `Rompe emailValido`. Lo que rompió algo está en uno de esos dos, y en ningún otro: lo anterior ya estaba probado en la 12.
3. **Abrir `Test Result` y ver qué prueba falla.** Falla `emailSinPuntoOConEspaciosNoEsValido`, con el mensaje `expected: <false> but was: <true>`.
4. **Cruzar la prueba con los cambios.** La prueba habla de si un correo con espacio es válido, es decir, de `emailValido()`. De los dos commits, solo uno toca ese método. Lo comprobamos en el repositorio.
5. **Confirmar con Git.** En la terminal de IntelliJ:

```bash
git log --oneline
```

<pre>
bc7ec9a Arregla resumen
61a5a1c Rompe resumen
4fa49fb Arregla emailValido
597c760 Rompe emailValido
8b56721 Cambio inocuo 2
f4a6e21 Cambio inocuo 1
afd7f7b Primer commit de contactos
</pre>

   Los identificadores de la izquierda (`597c760`...) serán otros en cada repositorio. Con el del commit sospechoso, `git show` enseña lo que cambió:

```bash
git show 597c760
```

<pre>
diff --git a/src/main/java/com/curso/model/Contacto.java b/src/main/java/com/curso/model/Contacto.java
index 06b15b2..4e68d5f 100644
--- a/src/main/java/com/curso/model/Contacto.java
+++ b/src/main/java/com/curso/model/Contacto.java
@@ -62,7 +62,7 @@ public class Contacto {
     public boolean emailValido() {
         // contains() devuelve true si el texto contiene la cadena indicada.
         // El operador && exige que se cumplan las tres condiciones a la vez.
-        return email.contains("@") && email.contains(".") && !email.contains(" ");
+        return email.contains("@") && email.contains(".");
     }
 
 }
</pre>

   La salida de `git show` empieza con el autor, la fecha y el mensaje del commit; después viene la diferencia, que es lo que mostramos. Se lee así: la línea que empieza por `-` es la que había y la que empieza por `+` es la que hay ahora. Aquí ha desaparecido la condición `!email.contains(" ")`. Con el otro commit de la construcción 13, `git show 8b56721`, solo se ve una línea de comentario nueva en `Aplicacion.java`: ese no puede haber roto nada.

Conclusión: la construcción culpable es la 13, el cambio que la rompió es el commit `Rompe emailValido`, y la corrección es devolver a la línea su condición, que es lo que hace la construcción 14. Sin el historial habríamos tenido que repasar todo el proyecto. Con él, hemos revisado dos commits.

El mismo procedimiento sirve para el segundo fallo: la 14 es la última buena, la 15 es la culpable, `Changes` muestra un solo commit (`Rompe resumen`) y la prueba que falla es `resumenIncluyeEmailYTelefono`.

### Tres matices

- **Una construcción puede contener varios commits.** Ocurre cuando se envían varios commits juntos, como en la 13, y también cuando el sondeo del repositorio solo mira cada dos minutos y entre una mirada y otra se envía más de un cambio. Jenkins señala la construcción, no el commit. Para llegar al commit hay que cruzar la lista de cambios con la prueba que falla.
- **La culpable es la primera de la racha, no la última.** Si tras la 13 se hubiera enviado otro cambio sin arreglar nada, la 14 también estaría en rojo. La 14 no habría roto nada: ya encontró el fallo. La culpable seguiría siendo la 13. Este es el caso que trabajamos en la Práctica 2.
- **Jenkins dice cuándo, no por qué.** El historial acota el cambio, pero entender por qué falla la prueba sigue siendo trabajo de quien lee el mensaje de Maven, como en las demos anteriores.

---

## Problemas frecuentes

- **El aviso sale con `${env.JOB_NAME}` escrito tal cual.** El texto está entre comillas simples. Hay que usar comillas dobles para que `${...}` se sustituya.
- **El aviso de fallo no sale nunca.** Comprobamos que el bloque `post` está **fuera** de `stages`, al nivel de `pipeline`. Si está dentro de una etapa, su condición se evalúa respecto a esa etapa y no respecto a toda la construcción. También comprobamos que el nombre de la condición está bien escrito: `failure`, no `fail` ni `failed`.
- **Jenkins protesta del `Jenkinsfile` antes de empezar a construir.** Suele ser una llave sin cerrar o una condición mal escrita (`fixd`, `sucess`). La sangría no importa en Groovy, las llaves sí. El texto exacto del mensaje de error de Jenkins no lo hemos comprobado.
- **Las comillas son curvas.** Se han pegado desde un documento. Groovy no las reconoce como comillas (con Groovy 4 da `Unexpected character`). Se sustituyen por comillas rectas.
- **Las letras con tilde salen deformadas en la consola de Jenkins.** El texto de `echo` lleva tildes. Hay que escribirlo sin ellas: la consola de Windows no siempre usa la misma codificación que el fichero.
- **No sale el aviso de `RECUPERADA`.** Para que `fixed` se cumpla, la construcción anterior tiene que haber terminado mal. Si la anterior estaba en verde, no hay nada que recuperar.
- **En la recuperación salen dos avisos y parece un error.** No lo es: la construcción cumple `success` y `fixed` a la vez. Si molesta, se quita el `success`; es una decisión de equipo.
- **El mensaje de commit sale con caracteres raros.** El commit se hizo en `cmd` con una tilde o una eñe. Los mensajes de esta parte van sin tildes.
- **La gráfica de tendencia no aparece.** Puede que haya pocas construcciones con informe de pruebas, o que `junit` no se esté ejecutando. Se comprueba en la consola de la construcción si se publicó el informe, y en la página de la construcción que existe `Test Result`. La causa exacta no está comprobada en el aula.
- **La lista de cambios de la construcción sale vacía.** La primera construcción de un job no tiene "anterior" con la que comparar, y una construcción lanzada sin commits nuevos tampoco trae cambios. Si en una construcción con commits nuevos sale vacía, se anota y se comprueba con `git log` en el repositorio.
- **El sondeo ha juntado dos commits en una construcción.** Es lo normal si se envían con menos de dos minutos de diferencia. Para tener una construcción por commit, se lanza `Build Now` tras cada `push`.

---

## Qué está verificado y qué no

**Verificado** (Maven 3.9.11, JDK 21.0.12, Surefire 3.5.6, Git 2.43; `contactos` real de S11-1, cuyo código es idéntico al del zip de S14-1):

- Los `Jenkinsfile` de esta parte (el de las demos y el de la Práctica 1) pasan el analizador de Groovy 4.0.24 y el de Groovy 2.4.21 (una línea más antigua, por si el intérprete de Jenkins es de esa familia). Jenkins ejecuta los pipelines con su propio intérprete, así que esta comprobación no sustituye a la suya. Se ha pasado además una comprobación estructural propia, más simple que la de Jenkins: todas las directivas y condiciones de `post` son conocidas. Se ha probado con ficheros erróneos a propósito, y detecta `fixd` en lugar de `fixed`, `stagess` en lugar de `stages`, una llave sin cerrar y unas comillas curvas.
- Las secuencias de la Demo 1 y de la Demo 2 se han ejecutado de principio a fin con Git (un repositorio remoto local y un espacio de trabajo que se actualiza con `git pull`, como el de Jenkins) y con Maven reales. Los resultados de cada construcción, el número de pruebas, la prueba que falla y los mensajes de Maven de este documento salen de esas ejecuciones.
- El texto de los avisos, con `${...}` ya sustituido, y la diferencia entre comillas dobles y simples en Groovy.
- Los comandos de Git de la demo y la salida de `git log --oneline` y `git show`.
- Los ficheros `cambios/*.txt` coinciden, línea por línea, con los cambios que se ejecutaron en la simulación.

**Simulado, no es Jenkins**: la lógica de `failure`, `success` y `fixed` (qué avisos salen en cada construcción) se ha evaluado con un simulador propio que ejecuta el texto real del `Jenkinsfile` y aplica las definiciones de la documentación oficial. Sirve para comprobar que el fichero y los mensajes son correctos y que la secuencia da lo esperado, pero no sustituye a Jenkins.

**No verificado (requiere Jenkins real)**:

- Que `fixed` se dispare exactamente en la construcción esperada, que en ella salgan los dos avisos y su orden.
- Las líneas que Jenkins escribe alrededor del `echo` en la consola.
- La vista de etapas, el historial de construcciones, la gráfica de tendencia de las pruebas (si existe en la página del job, dónde y con cuántas construcciones se dibuja), `Test Result` y `Changes`, sus nombres exactos y si aparecen en español.
- Que `Changes` se rellene en un job de tipo `Pipeline` con `Pipeline script from SCM`.
- El color exacto de una construcción en verde (verde o azul) y el comportamiento de `Build Now` frente al sondeo.
- El mensaje de error de Jenkins ante un `Jenkinsfile` con una condición de `post` mal escrita.
- Las tildes de la salida de Maven en la consola de Jenkins sobre Windows.
- Que los nombres `jdk-21` y `maven-3.9` coincidan con los de cada equipo (son los supuestos de S13-2).
- El paso `mail`: el fragmento es solo de referencia.

---

## Conceptos que se añaden a conceptos-introducidos.md

Las filas siguientes se añaden al final de `conceptos-introducidos.md` sin tocar las existentes. Incluyen las de las prácticas de esta parte.

| Bloque `post` a nivel de pipeline frente a nivel de etapa | S14-1 → S14-2 | Completo: `post` define qué hacer cuando termina algo, según cómo haya terminado. Dentro de una `stage` se evalúa al terminar esa etapa (S14-1: `always` con `junit` en `Probar`); al nivel de `pipeline`, después de `stages`, se evalúa una sola vez cuando termina toda la construcción, o cuando una etapa falla y el pipeline se detiene. Los avisos de S14-2 hablan de la construcción entera y por eso van al nivel de `pipeline`; el `post` de `Probar` no se toca. Ejemplo del cierre de caja de cada turno frente al cierre del día |
| Condiciones de `post`: `failure`, `success` y `fixed` | S14-2 | Completo: `failure` = la construcción ha terminado en rojo (*Failed*); `success` = ha terminado en verde (*Stable*); `fixed` = esta construcción termina bien y la anterior no. `success` y `fixed` no se excluyen: una construcción que se recupera cumple las dos y escribe los dos avisos. `fixed` no se repite en los verdes siguientes (ejemplo del corte de luz: se avisa de que se va y de que vuelve, no cada minuto de que sigue). Según la documentación de Jenkins las condiciones se evalúan en un orden fijo en el que `fixed` va antes que `success`; no verificado en el aula. Existen además `unstable`, `changed`, `aborted`, `unsuccessful`, `regression` y `cleanup`, mencionadas sin uso |
| Variables de entorno de Jenkins: `env.JOB_NAME` y `env.BUILD_NUMBER` | S14-2 | Completo: Jenkins prepara para cada construcción variables de entorno (el mismo concepto que `POSTGRES_PASSWORD` en S07) que el pipeline lee con `env.` delante. `env.JOB_NAME` = nombre del job (`contactos`; sale el que tenga el job de cada alumno) y `env.BUILD_NUMBER` = número de la construcción, sin el `#`. Mencionada `env.BUILD_URL` (dirección de la construcción) sin usarla en el código del curso |
| Comillas dobles y `${...}` en un `Jenkinsfile` (Groovy) | S14-2 | Completo: dentro de un texto entre comillas dobles, Groovy sustituye `${expresión}` por su valor; entre comillas simples escribe el texto tal cual, con las llaves. Comprobado con el intérprete de Groovy (`"... ${env.JOB_NAME}"` frente a `'... ${env.JOB_NAME}'`). Los comandos de `bat` siguen con comillas simples porque no hay nada que sustituir. Los textos de `echo` y de los mensajes de commit, sin tildes (consola de Windows) |
| Aviso por consola y aviso en un equipo real | S14-2 | Completo: en el curso el aviso es un `echo` en la consola de la construcción, sin servidor de correo ni Mailpit. En un equipo real el bloque `post` es el mismo y lo que cambia es el paso: un correo (paso `mail`, mostrado como referencia; necesita un servidor de correo configurado en Jenkins; no verificado) o un mensaje a un canal de chat |
| Historial de construcciones, resultado de pruebas por construcción y tendencia de pruebas (*Test Result Trend*) | S14-2 | Completo: el historial es la lista de construcciones del job con número, color y fecha; el resultado de pruebas, lo que publica `junit` en cada una; la tendencia, la gráfica con un punto por construcción que dibuja Jenkins con esos resultados. No requiere configurar nada nuevo porque `junit` está en `post` con `always` (S14-1) y publica también en las construcciones rojas. Datos esperados en la secuencia de la Demo 2: seis pruebas siempre y fallos 0, 1, 0, 1, 0. La existencia, la posición y los nombres de la gráfica no están verificados en el aula |
| `Changes`, última construcción buena y construcción culpable | S14-2 | Completo: `Changes` lista los commits que entraron en una construcción desde la anterior. La construcción culpable es la primera en rojo de una racha tras una verde; la anterior es la última buena. "Culpable" señala una construcción y un cambio, no a una persona. Procedimiento de cinco pasos: primera roja, `Changes`, `Test Result`, cruzar la prueba con los cambios y confirmar con `git log --oneline` y `git show <id>`. Ejemplo del grifo que gotea (última vez seco, primera vez mojado) |
| Construcción con varios commits; culpable = primera de la racha | S14-2 | Completo: una construcción puede contener varios commits (se envían juntos con un solo `git push`, o el sondeo `H/2 * * * *` junta los que llegan entre dos consultas); Jenkins señala la construcción y el commit se localiza cruzando `Changes` con la prueba que falla. Si tras la culpable se envía otro cambio sin arreglar, la siguiente también sale en rojo pero no es culpable. Jenkins dice cuándo y qué cambió, no por qué falla la prueba |
| Cambios inocuos y fichas de cambios (`cambios/*.txt`) | S14-2 | Introducido: un cambio inocuo es uno que no altera lo que hace el programa (una línea de comentario al final de `Aplicacion.java`) y sirve para tener un commit que no rompe nada. Los cambios que rompen una prueba son los de S13-2 y S14-1 (quitar `&& !email.contains(" ")` de `emailValido()` y el espacio tras la coma de `resumen()`). Las fichas `.txt` del zip los describen línea por línea y no forman parte del proyecto |
| Proyecto `contactos` y repositorio en S14-2 | S14-2 | Reutilizado de S11-1 y S14-1 sin cambios en el código ni en el `pom.xml` (comprobado: idéntico al de `s11-1-practicas.zip`); `s14-2-demos.zip` lo incluye con el `Jenkinsfile` de las demos, que parte del de la Demo 2 de S14-1 y añade el `post` de nivel de pipeline. Mismo repositorio (https://github.com/JD-CFTIC/contactos.git, cada alumno el suyo), rama `main`. Secuencias de ejemplo con números de construcción de ejemplo (8 a 11 en la Demo 1; 12 a 16 en la Demo 2) |
| Práctica 1: aviso de fallo y de recuperación | S14-2 | Completo (solución): `post` a nivel de pipeline con solo `failure` y `fixed`, sin `success` (dos verdes seguidos no necesitan aviso). Mensajes con `env.JOB_NAME` y `env.BUILD_NUMBER` y una indicación de dónde mirar. Comprobado por simulación en cinco construcciones: verde sin aviso, rojo, rojo con dos pruebas rotas, recuperada y verde sin aviso |
| Práctica 2: encontrar la construcción que rompió la prueba | S14-2 | Completo (solución): cinco cambios seguidos (comentario, rompe `resumen()`, rompe `emailValido()`, arregla `resumen()`, arregla `emailValido()`). Datos esperados: fallos 0, 1, 2, 1, 0; la culpable es la segunda; la tercera añade un segundo fallo; la cuarta sigue en rojo por el correo; la quinta recupera. Muestra que una racha roja tiene un solo origen y que arreglar un fallo no basta si queda otro |
| Práctica 3: integración continua del proyecto en grupo | S14-2 | Completo (solución orientativa, sin zip): `Jenkinsfile` del grupo con `Compilar`, `Probar` con `"-Dtest=!NombreTests"` y `junit` en `always`, `Empaquetar` con `archiveArtifacts` y `post` con `failure`, `success` y `fixed`. Si el `pom.xml` no está en la raíz del repositorio: `mvn -B -f subcarpeta/pom.xml ...` (comprobado con Maven) y la ruta de los informes de `junit` con la subcarpeta. Cada grupo anota qué pruebas excluye |
| `cmd` elevado y `net session` | S14-2 | Completo; **sin verificar en Windows**: para instalar Docker Desktop (S15-2) hace falta administrador. Un `cmd` elevado se abre con clic derecho sobre `Símbolo del sistema` y `Ejecutar como administrador`; la barra de título dice `Administrador`. `net session` lo comprueba: con permisos de administrador responde que no hay entradas en la lista; sin ellos, acceso denegado (error de sistema 5). Se usa solo para esa comprobación |
| Virtualización: `systeminfo` | S14-2 | Completo; **sin verificar en Windows**: Docker Desktop crea una máquina Linux ligera y necesita la virtualización activada en el equipo. `systeminfo` muestra al final los requisitos de Hyper-V, con la línea de virtualización habilitada en el firmware; si Windows ya usa un hipervisor, dice que se ha detectado uno en lugar de mostrar esos requisitos, y eso también vale. `systeminfo \| findstr /i "hipervisor hypervisor virtualiz"` se queda con esas líneas. Si está desactivada, se activa en la BIOS o UEFI del equipo |
| WSL: `wsl --status` | S14-2 | Completo; **sin verificar en Windows**: WSL (*Windows Subsystem for Linux*) es la capa de Windows que ejecuta Linux; Docker Desktop usa WSL 2. `wsl --status` informa de la versión por defecto y de la distribución; si WSL no está instalado, indica cómo instalarlo. Si falta, no se instala en S14-2: se instala en S15-2 con `wsl --install --no-distribution` (Demo 1) |
| Pantallas y datos de Jenkins de S14-2: verificado y no verificado | S14-2 | Nota para chats posteriores. **Verificado** (Maven 3.9.11, JDK 21, Git 2.43, `contactos` real de S11-1): las secuencias de las Demos 1 y 2 y de las Prácticas 1 y 2 con Git y Maven reales; sintaxis Groovy (4.0.24 y 2.4.21) y estructura de los `Jenkinsfile`; textos de los avisos tras sustituir `${...}`; `-Dtest=!` y `-f subcarpeta/pom.xml`. **Simulado, no es Jenkins**: qué avisos salen en cada construcción. **No verificado (requiere Jenkins real)**: `fixed` en la construcción esperada, el orden de `fixed` y `success`, las líneas que Jenkins escribe alrededor del `echo`, el historial, `Changes` en un job Pipeline con SCM, la gráfica de tendencia (existencia, posición, mínimo de construcciones), `Test Result`, nombres de menús, el mensaje de error ante una condición de `post` mal escrita y el paso `mail`. **No verificado (sin Windows)**: las salidas de `net session`, `systeminfo` y `wsl --status` |
