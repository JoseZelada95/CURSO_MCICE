# S14-2 Prácticas

## Objetivos

Se aplican los avisos con `post`, el historial y la tendencia de pruebas de las demos. Las dos primeras prácticas usan el proyecto `contactos` y su job de Jenkins. La tercera lleva la integración continua al proyecto del grupo. La cuarta comprueba el equipo para instalar Docker en S15-2.

El material está en `s14-2-practicas.zip` (Prácticas 1 y 2). Las Prácticas 3 y 4 no llevan zip.

---

## Práctica 1: Aviso de fallo y de recuperación en contactos

Se parte del job `contactos` con el `Jenkinsfile` de la Demo 1 de esta parte. Se deja un aviso solo cuando algo falla y cuando se recupera, sin avisar de cada construcción correcta.

**Pasos**

1. Abrimos `practica1-aviso-contactos/Jenkinsfile` del zip y lo comparamos con el `Jenkinsfile` del repositorio: la única diferencia está en el bloque `post` del final.
2. Copiamos ese `Jenkinsfile` sobre el del repositorio. Hacemos commit con el mensaje `Anade aviso de fallo y de recuperacion`, `git push` y lanzamos la construcción con `Build Now`. Debe salir en verde y sin ningún aviso en la consola.
3. Rompemos `emailValido()` quitando `&& !email.contains(" ")`. Commit, `git push` y `Build Now`. Buscamos el aviso en la consola.
4. Rompemos también `resumen()` quitando el espacio tras la coma. Commit, `git push` y `Build Now`. Anotamos cuántas pruebas fallan y qué avisos salen.
5. Arreglamos los dos métodos en un solo commit. Commit, `git push` y `Build Now`. Anotamos el aviso que sale.
6. Hacemos un último cambio inocuo (un comentario) y lanzamos otra construcción. Comprobamos que ya no sale ningún aviso.

**Pistas**

- El bloque `post` va fuera de `stages`, al final del `pipeline`.
- Las condiciones que se piden son `failure` y `fixed`. No se necesita `success`.
- Los mensajes llevan comillas dobles para que `${env.JOB_NAME}` y `${env.BUILD_NUMBER}` se sustituyan por su valor.
- Los textos de `echo` y de los commits van sin tildes por la consola de Windows.
- Si no sale ningún aviso en un rojo, la construcción no ha llegado a ejecutar el `post`: se revisa que el `Jenkinsfile` subido sea el nuevo.

---

## Práctica 2: Encontrar la construcción que rompió la prueba

Se aplican cinco cambios seguidos al proyecto `contactos`, uno por commit, y después se localiza desde Jenkins qué construcción introdujo el fallo, sin mirar qué hace cada cambio.

**Pasos**

1. Abrimos `practica2-encontrar-culpable/cambios.txt` del zip. Contiene los cinco cambios, el commit de cada uno y el orden.
2. Aplicamos el cambio 1, hacemos commit con el mensaje indicado, `git push` y `Build Now`. Esperamos a que termine antes de pasar al siguiente.
3. Repetimos con los cambios 2, 3, 4 y 5, una construcción por cada cambio.
4. En el historial del job, anotamos el color de cada construcción y cuántas pruebas fallan en cada una (`Test Result`).
5. Localizamos la construcción culpable: la primera en rojo tras una verde. Abrimos sus `Changes` y anotamos qué commit entró.
6. Con `git log --oneline` y `git show <id>` confirmamos qué línea cambió ese commit.
7. Contestamos: ¿qué construcción es la culpable? ¿Qué construcciones siguen en rojo sin ser culpables? ¿Cuál recupera el job?

**Pistas**

- Los mensajes de commit no dicen qué cambio rompe algo. Hay que usar `Changes` y `Test Result`.
- Una construcción roja no es culpable si la anterior también estaba en rojo.
- Si una racha roja empeora o mejora, el número de pruebas fallidas cambia: ese dato ayuda a ver qué cambio entró en cada construcción.
- Variante en parejas: una persona aplica los cambios sin decir cuáles rompen algo y la otra localiza la culpable.

---

## Práctica 3: Integración continua del proyecto en grupo

Se crea el job del proyecto del grupo y se completa su `Jenkinsfile`. El resultado es el pipeline del grupo funcionando, con avisos.

**Pasos**

1. Creamos un job Pipeline para el repositorio del grupo, con las mismas opciones que el de `contactos` (Pipeline script from SCM, rama `main` y sondeo `H/2 * * * *`).
2. Escribimos el `Jenkinsfile` en la raíz del repositorio con las etapas `Compilar`, `Probar` y `Empaquetar`, y con el bloque `post` de la Práctica 1 (`failure`, `success` y `fixed`).
3. Ejecutamos las pruebas del proyecto en la consola de Windows (`mvn test`) y anotamos cuáles necesitan una base de datos.
4. Excluimos esas pruebas en la etapa `Probar` con `"-Dtest=!NombreTests"`.
5. Subimos el `Jenkinsfile`, lanzamos la construcción y corregimos hasta que salga en verde.
6. Ejecutamos al menos tres construcciones más (una de ellas con un fallo provocado y su arreglo) y revisamos el historial y la tendencia de pruebas.
7. Anotamos qué pruebas hemos excluido y por qué.

**Pistas**

- Si el `pom.xml` no está en la raíz del repositorio, los comandos llevan `-f subcarpeta/pom.xml` y la ruta de `junit` incluye la subcarpeta.
- Para excluir varias clases se separan con comas dentro de las mismas comillas.
- Las comillas dobles en `"-Dtest=!NombreTests"` evitan que `cmd` interprete el signo `!`.
- Los nombres de las herramientas del bloque `tools` deben coincidir letra por letra con los de `Manage Jenkins > Tools`.

---

## Práctica 4: Comprobación del entorno para Docker

En S15-2 se instala Docker Desktop. Antes se comprueba que el equipo cumple lo necesario. No se instala nada en esta práctica.

**Pasos**

1. Abrimos `cmd` como administrador: clic derecho sobre `Símbolo del sistema` y `Ejecutar como administrador`. La barra de título debe empezar por `Administrador`.
2. Ejecutamos `net session` y anotamos qué responde.
3. Ejecutamos `systeminfo | findstr /i "hipervisor hypervisor virtualiz"` y anotamos las líneas que salen.
4. Ejecutamos `wsl --status` y anotamos qué responde.
5. Con los resultados, escribimos una lista con lo que está listo y lo que falta en nuestro equipo.

**Pistas**

- Si `net session` responde con acceso denegado, el `cmd` no está elevado: se cierra y se abre de nuevo como administrador.
- Si `systeminfo` indica que se ha detectado un hipervisor, Windows ya usa virtualización: no hace falta nada más.
- Si la virtualización aparece desactivada, se activa en la BIOS o UEFI del equipo; hay que anotarlo, no cambiarlo en clase.
- Si `wsl --status` indica que WSL no está instalado, solo se anota: se instala en S15-2.
