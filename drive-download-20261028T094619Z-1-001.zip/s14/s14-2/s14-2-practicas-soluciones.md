# S14-2 Soluciones de las prácticas

## Práctica 1: Aviso de fallo y de recuperación en contactos

`Jenkinsfile` (idéntico al de `practica1-aviso-contactos/` del zip):

```groovy
/*
 * S14-2 Práctica 1: Aviso de fallo y de recuperación en contactos
 *
 * Objetivo: que el pipeline de contactos escriba un aviso cuando una construcción falla
 * y otro cuando vuelve a funcionar después de un fallo.
 *
 * Aplica las técnicas de S14-2:
 *   1. Bloque post a nivel de pipeline, fuera de stages
 *   2. Condiciones failure y fixed
 *   3. Variables env.JOB_NAME y env.BUILD_NUMBER dentro de un texto con comillas dobles
 *
 * Concepto clave: cada condición de post es independiente y se puede usar o no. Aquí solo
 * avisamos de lo que importa a quien lo recibe: el fallo y la recuperación, no cada verde.
 */
pipeline {
    agent any

    // Los nombres deben coincidir letra por letra con los de Manage Jenkins > Tools (S13-2).
    tools {
        jdk 'jdk-21'
        maven 'maven-3.9'
    }

    stages {

        stage('Compilar') {
            steps {
                bat 'mvn -B clean compile'
            }
        }

        stage('Probar') {
            steps {
                bat 'mvn -B test'
            }
            post {
                // El informe de pruebas se publica siempre, también cuando fallan (S14-1).
                always {
                    junit testResults: 'target/surefire-reports/*.xml', allowEmptyResults: true
                }
            }
        }

        stage('Empaquetar') {
            steps {
                bat 'mvn -B package -DskipTests'
                archiveArtifacts artifacts: 'target/*.jar'
            }
        }
    }

    // post fuera de stages: se evalúa cuando termina el pipeline entero.
    // No escribimos success: dos verdes seguidos no necesitan aviso.
    post {

        // failure: la construcción ha terminado en rojo.
        // Incluimos el nombre del job y el número para saber cuál abrir, y dónde mirar primero.
        // Comillas dobles: con comillas simples ${...} no se sustituiría. Sin tildes, por la consola de Windows.
        failure {
            echo "FALLO: ${env.JOB_NAME}, construccion ${env.BUILD_NUMBER}. Abrir su consola y buscar la etapa en rojo."
        }

        // fixed: esta construcción es verde y la anterior no lo era.
        // Avisa de que el problema anterior ya está resuelto y desde qué construcción.
        fixed {
            echo "RECUPERADA: ${env.JOB_NAME}, construccion ${env.BUILD_NUMBER}. El fallo anterior ya esta resuelto."
        }
    }
}
```

**Decisiones**

- El `post` va al nivel de `pipeline`, porque el aviso habla de la construcción entera.
- Solo `failure` y `fixed`: dos verdes seguidos no necesitan aviso. `success` se deja fuera a propósito.
- Con `fixed` el aviso sale una sola vez, en la construcción que pasa de rojo a verde.

**Resultado esperado** (comprobado por simulación con Git y Maven reales; no es Jenkins):

| Construcción | Cambio | Resultado | Pruebas fallidas | Aviso |
|---|---|---|---|---|
| 1 | `Jenkinsfile` con `post` | verde | 0 | ninguno |
| 2 | rompe `emailValido()` | rojo | 1 | `FALLO` |
| 3 | rompe también `resumen()` | rojo | 2 | `FALLO` |
| 4 | arregla los dos | verde | 0 | `RECUPERADA` |
| 5 | comentario inocuo | verde | 0 | ninguno |

Qué sale exactamente en la consola de Jenkins alrededor del `echo` no está verificado.

---

## Práctica 2: Encontrar la construcción que rompió la prueba

**Resultado esperado** (comprobado por simulación con Git y Maven reales; no es Jenkins):

| Construcción | Cambio | Resultado | Pruebas fallidas | Prueba que falla |
|---|---|---|---|---|
| 1 | cambio 1, comentario | verde | 0 | ninguna |
| 2 | cambio 2, rompe `resumen()` | rojo | 1 | `resumenIncluyeEmailYTelefono` |
| 3 | cambio 3, rompe `emailValido()` | rojo | 2 | las dos anteriores |
| 4 | cambio 4, arregla `resumen()` | rojo | 1 | `emailSinPuntoOConEspaciosNoEsValido` |
| 5 | cambio 5, arregla `emailValido()` | verde | 0 | ninguna |

**Respuestas**

- La construcción culpable es la 2: es la primera en rojo tras una verde, y en sus `Changes` está el commit `Cambio 2 modifica resumen`.
- Las construcciones 3 y 4 siguen en rojo sin ser culpables: la anterior ya estaba en rojo. La 3 añade un segundo fallo y la 4 arregla uno pero deja el otro.
- La construcción 5 recupera el job. Con el `Jenkinsfile` de las demos salen `RECUPERADA` y `OK`.
- Con `git log --oneline` se ve el commit y con `git show <id>` la línea cambiada (la coma sin espacio).

**Idea que se refuerza:** una racha roja tiene un solo origen, y arreglar un fallo no basta si queda otro. La tendencia y `Changes` dicen cuándo y qué cambió; el motivo de la prueba fallida se lee en `Test Result`.

---

## Práctica 3: Integración continua del proyecto en grupo

Solución orientativa: cada grupo ajusta los nombres de sus pruebas excluidas.

```groovy
/*
 * S14-2 Práctica 3: Integración continua del proyecto en grupo (solución orientativa)
 *
 * Objetivo: completar el pipeline del proyecto del grupo con compilar, probar y empaquetar,
 * y con avisos de fallo y de recuperación.
 *
 * Aplica las técnicas de S14-1 y S14-2:
 *   1. Etapas Compilar, Probar y Empaquetar con bat
 *   2. Exclusión de las pruebas que dependen de la base de datos con -Dtest
 *   3. Bloque post a nivel de pipeline con failure, success y fixed
 *
 * Concepto clave: el Jenkinsfile del grupo es el de contactos con los ajustes que pide su proyecto.
 * Lo único propio de cada grupo son los nombres de las pruebas excluidas.
 */
pipeline {
    agent any

    // Los nombres deben coincidir letra por letra con los de Manage Jenkins > Tools (S13-2).
    tools {
        jdk 'jdk-21'
        maven 'maven-3.9'
    }

    stages {

        stage('Compilar') {
            steps {
                bat 'mvn -B clean compile'
            }
        }

        stage('Probar') {
            steps {
                // -Dtest elige qué pruebas ejecuta Surefire. El signo ! delante de un nombre lo excluye.
                // AplicacionTests es la prueba de arranque de contactos; cada grupo pone aquí el nombre
                // de sus propias pruebas que arrancan la aplicación con JPA y necesitan base de datos.
                // Las comillas dobles evitan que cmd interprete el signo !.
                bat 'mvn -B test "-Dtest=!AplicacionTests"'
            }
            post {
                // El informe se publica siempre, también cuando las pruebas fallan.
                always {
                    junit testResults: 'target/surefire-reports/*.xml', allowEmptyResults: true
                }
            }
        }

        stage('Empaquetar') {
            steps {
                // Las pruebas ya se ejecutaron en la etapa anterior, así que aquí no se repiten.
                bat 'mvn -B package -DskipTests'
                // Guardamos el JAR de cada construcción para poder descargarlo después.
                archiveArtifacts artifacts: 'target/*.jar'
            }
        }
    }

    // post fuera de stages: se evalúa al terminar el pipeline entero.
    post {

        // Fallo: se avisa en rojo con el nombre del proyecto y el número de construcción.
        // Comillas dobles para que ${...} se sustituya; sin tildes, por la consola de Windows.
        failure {
            echo "FALLO: ${env.JOB_NAME}, construccion ${env.BUILD_NUMBER}. Abrir su consola y buscar la etapa en rojo."
        }

        // Verde: se confirma cada construcción correcta.
        success {
            echo "OK: ${env.JOB_NAME}, construccion ${env.BUILD_NUMBER}."
        }

        // Recuperación: avisa del paso de rojo a verde, una sola vez.
        fixed {
            echo "RECUPERADA: ${env.JOB_NAME} vuelve a funcionar desde la construccion ${env.BUILD_NUMBER}."
        }
    }
}
```

**Cómo descubrir qué pruebas necesitan base de datos**

1. En la consola de Windows, `mvn test` en la raíz del proyecto.
2. Las pruebas que fallan con errores de conexión, de `DataSource` o de contexto de Spring al arrancar son las que dependen de la base de datos.
3. Se excluyen por nombre de clase: `"-Dtest=!NombreTests"`. Para varias, `"-Dtest=!UnoTests,!OtroTests"` (sin verificar con varias clases).
4. Se vuelve a ejecutar `mvn test` con la exclusión hasta que pasen todas.

`"-Dtest=!AplicacionTests"` en `contactos` deja 5 pruebas (verificado).

**Si el `pom.xml` está en una subcarpeta**

```bat
mvn -B -f subcarpeta/pom.xml clean compile
```

y la ruta de `junit` pasa a `subcarpeta/target/surefire-reports/*.xml`. El uso de `-f` está verificado con Maven; la ruta de `junit` en Jenkins no.

---

## Práctica 4: Comprobación del entorno para Docker

No se ha podido probar en Windows. Lo siguiente se basa en el comportamiento documentado de cada comando.

| Comando | Qué indica | Qué hacer |
|---|---|---|
| `net session` | Con administrador responde que no hay entradas en la lista. Sin él, acceso denegado (error de sistema 5). | Si hay acceso denegado, abrir `cmd` de nuevo como administrador. |
| `systeminfo \| findstr /i "hipervisor hypervisor virtualiz"` | Muestra la línea de virtualización habilitada en el firmware o indica que se ha detectado un hipervisor. Los dos casos valen. | Si está desactivada, activarla en la BIOS o UEFI y anotarlo. |
| `wsl --status` | Informa de la versión por defecto y de la distribución. Si WSL no está instalado, lo indica. | Si falta, no se instala hoy: se instala en S15-2 con `wsl --install --no-distribution`. |

**Lista de ejemplo del resultado**

- Administrador: sí.
- Virtualización: activada.
- WSL: falta, se instala en S15-2.

Cualquier "falta" se resuelve antes de S15-2. No se cambia ninguna configuración del equipo en esta práctica.
