# S14-1 Demos

## Objetivos

En S13-2 configuramos a mano, con el ratón, un job freestyle que descarga `contactos`, lo construye con Maven y publica sus pruebas. Funciona, pero tiene un problema: esa configuración vive dentro de Jenkins y no con el código. Si el proyecto cambia, hay que acordarse de cambiar el job, y nadie sabe con qué versión de la configuración se construyó cada versión del código.

En esta parte pasamos esa configuración a un fichero de texto, el `Jenkinsfile`, que se guarda en el repositorio junto al proyecto. Lo hacemos en tres pasos. Primero escribimos un pipeline mínimo para ver su forma. Después lo movemos al repositorio de `contactos`, le damos las etapas de compilar, probar y empaquetar, y hacemos que Jenkins lo ejecute solo cada vez que alguien envía un cambio. Por último rompemos cosas a propósito para aprender a leer los fallos y a corregir un pipeline sin ensuciar el historial.

Al terminar esta parte los alumnos son capaces de:
- Escribir un `Jenkinsfile` declarativo con `pipeline`, `agent`, `stages`, `stage` y `steps`.
- Configurar un job de tipo Pipeline que lee su `Jenkinsfile` del repositorio.
- Declarar con `tools` el JDK y el Maven de las herramientas globales y lanzar Maven con `bat`.
- Publicar el informe de pruebas con `junit` dentro de `post` con `always`, y archivar el JAR con `archiveArtifacts`.
- Activar el sondeo periódico del repositorio (Poll SCM) y comprobar que un `push` lanza una construcción.
- Localizar en qué etapa falla una construcción y probar una corrección con Replay.

Todo el trabajo se hace sobre el proyecto `contactos` de S11-1, que ya está en el repositorio de cada persona. En el aula usamos https://github.com/JD-CFTIC/contactos.git; cada alumno usa el suyo, con el mismo token de acceso de S11-1. No creamos ningún proyecto nuevo ni ninguna rama: todo ocurre en `main`.

## Antes de empezar

Comprobamos tres cosas, porque las tres se usan en las demos.

**1. Los nombres de las herramientas globales.** En Jenkins, `Manage Jenkins > Tools` (en la interfaz en español, `Administrar Jenkins`; Jenkins mezcla los dos idiomas en pantalla, como vimos en S13-2, y las instrucciones de este documento dan el nombre en inglés). Anotamos el nombre exacto del JDK y el de Maven que configuramos en S13-2. En este documento se escriben `jdk-21` y `maven-3.9`. Si en el aula se pusieron otros nombres, hay que usar los reales en todos los `Jenkinsfile`: Jenkins busca la herramienta por su nombre y la comparación es letra por letra (mayúsculas, guiones y puntos incluidos).

**2. La credencial de GitHub.** `Manage Jenkins > Credentials`. Debe existir la credencial de tipo usuario y contraseña (el usuario de GitHub y el token como contraseña) que creamos en S13-2. En la Demo 2 la elegiremos de una lista desplegable.

**3. El remoto de `contactos`.** En una ventana de `cmd`, dentro de la carpeta del proyecto:

```bash
git remote -v
git status
```

El primer comando debe mostrar la dirección del repositorio en `origin`, y el segundo debe decir `On branch main` y que no hay nada pendiente de confirmar (`nothing to commit, working tree clean`). Si hay algo pendiente, se confirma o se descarta antes de empezar.

---

## Demo 1: Primer Jenkinsfile declarativo

Un **pipeline** (en castellano, "tubería" o "cadena de montaje") es una secuencia de etapas por las que pasa el código: primero se compila, luego se prueba, luego se empaqueta. Es la misma idea que una cadena de montaje de coches: el chasis entra por un extremo, pasa por el taller de soldadura, después por el de pintura, después por el de inspección, y si una pieza falla en pintura, la inspección ni siquiera la ve. Cada taller es una **etapa**, y lo que hace el operario en ese taller son los **pasos**.

El **`Jenkinsfile`** es el fichero de texto donde se escribe esa cadena de montaje. Se llama exactamente así, con la J mayúscula y sin extensión, y por costumbre va en la raíz del proyecto, junto al `pom.xml`. En esta demo todavía no lo guardamos en ningún repositorio: lo pegamos directamente en Jenkins para ver su forma con pasos muy simples.

### La forma de un pipeline declarativo

Jenkins admite dos estilos de escribir pipelines. El **declarativo**, que usamos en el curso, tiene una estructura fija y fácil de leer: se declara qué etapas hay y qué pasos tiene cada una. El otro estilo (el "con script") permite programar con más libertad, pero es más difícil de leer y no lo necesitamos. Un pipeline declarativo se construye por capas, y lo vamos a presentar poco a poco.

La primera capa es el bloque `pipeline`, que envuelve todo. Jenkins no lee nada que esté fuera de él:

```groovy
pipeline {
}
```

Las llaves `{ }` delimitan los bloques, como en Java. El lenguaje se llama **Groovy**, un lenguaje de la familia de Java, pero para escribir un `Jenkinsfile` solo necesitamos la estructura que vemos aquí; no hace falta saber Groovy.

La segunda capa es `agent`. Un **agente** es la máquina donde Jenkins ejecuta el trabajo. Con `agent any` decimos "en cualquier máquina disponible". En el aula solo hay una, la del propio Jenkins, así que da igual, pero la línea es obligatoria:

```groovy
pipeline {
    agent any
}
```

La tercera capa es `stages`, que agrupa todas las etapas, y dentro de ella cada `stage` con su nombre. El nombre entre comillas es el que aparecerá en pantalla, así que conviene que diga qué hace la etapa. Dentro de cada etapa, `steps` contiene los pasos concretos:

```groovy
pipeline {
    agent any
    stages {
        stage('Saludo') {
            steps {
                echo 'Hola desde Jenkins'
            }
        }
    }
}
```

Con esto ya hay un pipeline completo con una etapa y un paso. El paso `echo` escribe un mensaje en la consola de la construcción, como `System.out.println` en Java. Es la forma más sencilla de comprobar que algo se ejecuta.

La última capa es una segunda etapa con el paso `bat`. **`bat`** ejecuta un comando de la consola de Windows (`cmd`), igual que el paso "Ejecutar comando de Windows por lotes" del job freestyle de S13-2. El nombre viene de los ficheros `.bat`, los guiones de la consola de Windows. En Linux habría que usar `sh`, pero en el aula todos los equipos son Windows, así que usamos siempre `bat`. Con `java -version` preguntamos qué Java ve Jenkins al ejecutarse como servicio:

### Código

```groovy
/*
 * S14-1 Demo 1: Primer Jenkinsfile declarativo
 *
 * Objetivo: escribir el pipeline más pequeño posible para ver la forma de un Jenkinsfile.
 *
 * Lo que hace este ejemplo:
 *   - Declara un pipeline que puede ejecutarse en cualquier agente de Jenkins
 *   - Define dos etapas: una muestra un mensaje y otra pregunta qué Java ve Jenkins
 *
 * Concepto clave: un pipeline declarativo siempre tiene la misma forma:
 * pipeline > stages > stage > steps. Lo que cambia de un proyecto a otro son los pasos.
 */

// pipeline es el bloque que envuelve todo. Jenkins no lee nada que esté fuera de él.
pipeline {

    // agent indica dónde se ejecuta el trabajo. any significa "en cualquier máquina
    // disponible": en el aula solo hay una, la del propio Jenkins.
    agent any

    // stages agrupa las etapas. Jenkins las ejecuta una tras otra, de arriba abajo,
    // y se detiene en la primera que falle.
    stages {

        // stage define una etapa con nombre. Ese nombre es el que aparece en la vista de etapas.
        stage('Saludo') {
            // steps contiene los pasos concretos de la etapa.
            steps {
                // echo escribe un mensaje en la consola de la construcción.
                // Evitamos las tildes en el texto para que se vea igual en cualquier consola.
                echo 'Hola desde Jenkins'   // → Hola desde Jenkins
            }
        }

        stage('Java') {
            steps {
                // bat ejecuta un comando de la consola de Windows (cmd), igual que
                // el paso "Ejecutar comando de Windows por lotes" del job freestyle de S13-2.
                // Con java -version comprobamos qué Java ve Jenkins al ejecutarse como servicio.
                bat 'java -version'   // → openjdk version "21..." (la versión que vea el servicio)
            }
        }
    }
}
```

Dos detalles del código. El primero: los comentarios `//` y `/* */` funcionan igual que en Java. El segundo: en el texto de `echo` no hemos puesto tildes. La consola de Windows usa una codificación de caracteres distinta de la que usa Jenkins, y las tildes de los mensajes que pasan por `bat` pueden salir deformadas. En los comentarios sí podemos ponerlas, porque Jenkins no los ejecuta.

### Crear el job de tipo Pipeline

En la página principal de Jenkins hacemos clic en `New Item`.

- **Enter an item name**: `demo1-pipeline`.
- Seleccionamos el tipo `Pipeline` (no `Freestyle project`, que es el que usamos en S13-2).
- Hacemos clic en `OK`.

En la página de configuración bajamos hasta la sección `Pipeline`. El campo **Definition** tiene dos opciones principales: `Pipeline script` (el script se escribe en la propia página) y `Pipeline script from SCM` (el script se lee del repositorio; es la que usaremos en la Demo 2). Dejamos `Pipeline script`, pegamos el contenido del `Jenkinsfile` en el cuadro `Script` y hacemos clic en `Save`.

### Ejecutar y observar

Hacemos clic en `Build Now`. Al terminar, en la página del job aparece la **vista de etapas** (*Stage View*): una tabla con una columna por etapa (`Saludo` y `Java`) y, debajo de cada una, cuánto ha tardado y si ha terminado bien (verde) o mal (rojo). Esta vista es lo que diferencia un pipeline de un job freestyle: cuando algo falla, la columna roja dice en qué etapa. Además, el tiempo de cada columna es la primera información útil para mejorar una construcción lenta.

Abrimos la construcción (`#1`) y hacemos clic en `Console Output`. La salida debería tener este aspecto. Es orientativa y no está verificada con un Jenkins real: la forma exacta de las líneas `[Pipeline]` puede variar con la versión, y la versión de Java será la que vea el servicio.

<pre>
[Pipeline] Start of Pipeline
[Pipeline] node
[Pipeline] stage
[Pipeline] { (Saludo)
[Pipeline] echo
Hola desde Jenkins
[Pipeline] }
[Pipeline] // stage
[Pipeline] stage
[Pipeline] { (Java)
[Pipeline] bat
openjdk version "21..." 
[Pipeline] }
[Pipeline] // stage
[Pipeline] End of Pipeline
Finished: SUCCESS
</pre>

Cada línea `[Pipeline] ...` es Jenkins anunciando lo que va a hacer: abre la etapa `Saludo`, ejecuta `echo`, la cierra, abre la etapa `Java` y ejecuta `bat`. Debajo de `[Pipeline] bat` aparece la salida del comando.

Fijamos una idea para la siguiente demo: la versión de Java que aparece aquí es la que ve el servicio de Jenkins, y puede no ser la que usamos nosotros en IntelliJ. Por eso el pipeline real declarará qué JDK quiere.

---

## Demo 2: Pipeline desde el repositorio y disparo automático

En la Demo 1 el script vive dentro de Jenkins: si el job se borra, el pipeline desaparece, y si alguien lo cambia, no queda rastro. Ahora hacemos lo que justifica un `Jenkinsfile`: guardarlo en el repositorio de `contactos`. Así se versiona como cualquier otra clase, cambia a la vez que el proyecto y cada construcción de Jenkins queda asociada a una versión concreta del pipeline.

En esta demo hacemos cuatro cosas: escribimos el `Jenkinsfile` con las etapas de compilar, probar y empaquetar; lo subimos al repositorio; configuramos un job que lo lee de allí; y activamos el sondeo para que un `push` lance la construcción sin que nadie pulse nada.

### Declarar las herramientas con tools

Un job freestyle usaba el JDK y el Maven de `Manage Jenkins > Tools`. Un pipeline también debe usarlos, y para decirlo existe el bloque `tools`, que va dentro de `pipeline`, debajo de `agent`:

```groovy
tools {
    jdk 'jdk-21'
    maven 'maven-3.9'
}
```

Es imprescindible por una razón que ya vimos en S13-2: Jenkins se ejecuta como servicio de Windows, y un servicio no ve el `PATH` (la lista de carpetas donde Windows busca los programas) del usuario que lo instaló. Sin `tools`, el comando `mvn` daría "no se reconoce como un comando" aunque Maven esté instalado y funcione en nuestra consola. Con `tools`, Jenkins localiza el JDK y el Maven por el nombre que les dimos en las herramientas globales y los añade al `PATH` solo durante esa construcción. Los nombres entre comillas tienen que coincidir letra por letra con los de `Manage Jenkins > Tools`.

### Las tres etapas

La primera etapa compila. Maven necesita las siguientes opciones, que explicamos aquí porque son nuevas:

- **`mvn -B`**: `-B` significa *batch mode* (modo por lotes). Maven deja de usar colores y barras de progreso, pensados para una terminal con persona delante, y escribe una salida limpia que se lee bien en el registro de Jenkins.
- **`clean`**: borra la carpeta `target/` antes de empezar. Así no pueden quedar informes de pruebas de una construcción anterior que Jenkins confunda con los nuevos.

```groovy
stage('Compilar') {
    steps {
        bat 'mvn -B clean compile'
    }
}
```

La segunda etapa ejecuta las pruebas con `mvn -B test`. Si una prueba falla, Maven termina con error y la etapa se pone en roja. Aquí aparece el problema que resolvemos justo después con `post`.

La tercera etapa empaqueta con `mvn -B package -DskipTests`. Las pruebas ya se ejecutaron en la etapa anterior, y `-DskipTests` evita repetirlas. Maven genera en `target/` el fichero `contactos-0.0.1-SNAPSHOT.jar`.

### Publicar las pruebas aunque fallen: post y always

Jenkins puede mostrar el informe de las pruebas (qué pasó, qué falló, cuánto tardó cada una) con el paso `junit`, que lee los ficheros XML que Maven deja en `target/surefire-reports/`. Aquí hay un problema de orden. Si ponemos `junit` como un paso más de la etapa `Probar`, justo después de `mvn test`, ocurre esto cuando una prueba falla:

1. `mvn test` termina con error.
2. Jenkins abandona la etapa en ese mismo momento.
3. El paso `junit`, que estaba detrás, no llega a ejecutarse.

Resultado: la construcción está en rojo, que es cuando más necesitamos el informe, y no hay informe. Es como un inspector que se marcha de la fábrica en cuanto ve un coche defectuoso, sin rellenar el parte de incidencias.

Hay dos formas de resolverlo:

| Opción | Cómo funciona | Inconveniente |
|---|---|---|
| `post { always { junit ... } }` | Se declara un bloque aparte que Jenkins ejecuta siempre al terminar la etapa, con éxito o con fallo | Ninguno relevante: es la forma estándar |
| `mvn test -Dmaven.test.failure.ignore=true` | Maven no termina con error aunque falle una prueba | La etapa sale verde con pruebas rotas, y la siguiente etapa genera el JAR igualmente. Jenkins tiene que corregir el color después |

Hemos comprobado con Maven real que la segunda opción funciona (Maven termina con `BUILD SUCCESS` aunque haya dos pruebas rotas y deja los XML), pero es la menos clara para quien empieza: una etapa verde que contiene fallos engaña. Elegimos la primera. El bloque **`post`** define qué hacer cuando termina una etapa o el pipeline entero, según cómo haya terminado. Las condiciones más habituales son `always` (siempre), `success` (solo si fue bien) y `failure` (solo si falló). Con `always`, el informe se publica en todos los casos:

```groovy
post {
    always {
        junit testResults: 'target/surefire-reports/*.xml', allowEmptyResults: true
    }
}
```

El patrón `target/surefire-reports/*.xml` significa "todos los ficheros `.xml` de esa carpeta". `allowEmptyResults: true` evita un segundo error cuando no ha llegado a generarse ningún informe; por ejemplo, si las propias pruebas no compilan.

### Archivar el JAR: archiveArtifacts

Un **artefacto** es el resultado de una construcción: en nuestro caso, el JAR. Por defecto Jenkins trabaja en una carpeta temporal y la siguiente construcción la reutiliza, así que el JAR de hoy se pierde mañana. El paso `archiveArtifacts` copia los ficheros indicados dentro de Jenkins y los asocia al número de construcción, de modo que después se pueden descargar desde la página de esa ejecución:

```groovy
archiveArtifacts artifacts: 'target/*.jar'
```

El patrón `target/*.jar` coge solo el JAR ejecutable. Spring Boot deja en `target/` dos ficheros: `contactos-0.0.1-SNAPSHOT.jar` (el ejecutable, con las librerías dentro) y `contactos-0.0.1-SNAPSHOT.jar.original` (el JAR sin empaquetar, que no nos interesa); el patrón no incluye el segundo porque termina en `.original`.

### Código: Jenkinsfile de contactos

```groovy
/*
 * S14-1 Demo 2: Pipeline desde el repositorio y disparo automático
 *
 * Objetivo: describir en un fichero versionado cómo se compila, prueba y empaqueta contactos.
 *
 * Lo que hace este ejemplo:
 *   - Declara con tools el JDK y el Maven que ya configuramos en S13-2
 *   - Compila, ejecuta las pruebas y empaqueta el JAR en tres etapas separadas
 *   - Publica el informe de pruebas aunque alguna falle y archiva el JAR en cada construcción
 *
 * Concepto clave: el Jenkinsfile vive junto al código. Si el proyecto cambia, el pipeline
 * cambia en el mismo commit, y cada construcción sabe con qué versión del pipeline se hizo.
 */
pipeline {

    // Cualquier agente disponible: en el aula, el propio Jenkins.
    agent any

    // tools le dice a Jenkins qué JDK y qué Maven debe poner en el PATH durante la construcción.
    // El servicio de Jenkins no ve el PATH del usuario que lo instaló, así que sin este bloque
    // el comando mvn no se encontraría.
    // Los nombres entre comillas son los de Manage Jenkins > Tools (S13-2) y deben
    // coincidir letra por letra con ellos; si no coinciden, Jenkins no podrá encontrar la herramienta.
    tools {
        jdk 'jdk-21'
        maven 'maven-3.9'
    }

    stages {

        stage('Compilar') {
            steps {
                // -B (batch mode) hace que Maven escriba una salida limpia, sin colores
                // ni barras de progreso, pensada para leerse en un registro y no en una terminal.
                // clean borra target/ antes de empezar: así no quedan informes de
                // pruebas de una construcción anterior que confundan a Jenkins.
                bat 'mvn -B clean compile'
            }
        }

        stage('Probar') {
            steps {
                // mvn test compila las pruebas y las ejecuta con Surefire.
                // Si una prueba falla, Maven termina con error y esta etapa se pone en rojo.
                bat 'mvn -B test'
            }
            // post define qué hacer cuando termina la etapa, según su resultado.
            post {
                // always se ejecuta siempre, también cuando las pruebas han fallado.
                // Sin él, el informe solo se publicaría con las construcciones en verde,
                // que es justo cuando menos falta hace.
                always {
                    // junit lee los informes XML de Surefire y los muestra en Jenkins.
                    // allowEmptyResults evita un segundo error si no llegó a generarse ningún informe
                    // (por ejemplo, si las pruebas ni siquiera compilan).
                    junit testResults: 'target/surefire-reports/*.xml', allowEmptyResults: true
                }
            }
        }

        stage('Empaquetar') {
            steps {
                // Las pruebas ya se ejecutaron en la etapa anterior, así que aquí las saltamos
                // con -DskipTests para no hacerlas dos veces.
                // Maven genera target/contactos-0.0.1-SNAPSHOT.jar.
                bat 'mvn -B package -DskipTests'
                // archiveArtifacts guarda el JAR dentro de Jenkins, asociado a esta construcción,
                // para poder descargarlo después. El patrón target/*.jar no incluye el
                // fichero .jar.original, porque este termina en .original.
                archiveArtifacts artifacts: 'target/*.jar'
            }
        }
    }
}
```

### Subir el Jenkinsfile al repositorio

Copiamos el fichero `Jenkinsfile` a la raíz de la carpeta `contactos`, al lado del `pom.xml`. Debe llamarse exactamente `Jenkinsfile`, sin extensión (en IntelliJ: clic derecho sobre el proyecto, `New > File`). En `cmd`, dentro de la carpeta del proyecto:

```bash
git add Jenkinsfile
git commit -m "Añade el Jenkinsfile con las etapas compilar, probar y empaquetar"
git push
```

`git add` prepara el fichero, `git commit` lo guarda en el historial local con un mensaje, y `git push` lo envía al remoto. Comprobamos en GitHub que el fichero aparece en la raíz del repositorio.

### Crear el job desde el repositorio

En Jenkins, `New Item`:

- **Enter an item name**: `contactos-pipeline`.
- Tipo `Pipeline`. Clic en `OK`.

En la sección `Pipeline`:

- **Definition**: `Pipeline script from SCM`. **SCM** son las siglas de *Source Code Management*, la gestión del código fuente, es decir, Git. Con esta opción, Jenkins descarga el repositorio y busca el `Jenkinsfile` dentro.
- **SCM**: `Git`.
- **Repository URL**: `https://github.com/JD-CFTIC/contactos.git` (cada alumno, la de su repositorio).
- **Credentials**: elegimos en la lista la credencial de S13-2. Como el repositorio es privado, sin ella Jenkins no podría descargarlo.
- **Branch Specifier**: aquí está la primera trampa. Jenkins propone `*/master`, y nuestra rama se llama `main`. Lo cambiamos a **`*/main`**. El `*/` inicial es un comodín para el nombre del remoto (`origin`).
- **Script Path**: `Jenkinsfile`. Es la ruta del fichero dentro del repositorio, y ya viene así por defecto. Si el fichero estuviera en una subcarpeta, aquí iría `carpeta/Jenkinsfile`.

Todavía no guardamos: falta el disparo automático.

### Activar el sondeo: Poll SCM

Sin disparo automático, la construcción solo ocurre cuando alguien pulsa `Build Now`, y en eso no hay integración continua. Lo ideal sería que GitHub avisara a Jenkins en cuanto llega un `push` (un *webhook*), pero eso exige que el servidor de Jenkins sea accesible desde Internet y el del aula no lo es. La alternativa es el **sondeo** (*polling*): Jenkins pregunta él mismo al repositorio cada cierto tiempo si hay commits nuevos, y construye solo si los hay. Es como mirar el buzón cada dos minutos en lugar de esperar a que llame el cartero.

Se activa en la sección `Build Triggers`, marcando **`Poll SCM`**. Aparece el campo **Schedule**, donde se escribe cada cuánto sondear con la sintaxis de cron, que consta de cinco campos separados por espacios:

<pre>
minuto  hora  día-del-mes  mes  día-de-la-semana
</pre>

Escribimos:

```bash
H/2 * * * *
```

Se lee así: en el campo del minuto, `H/2` significa "cada 2 minutos"; los cuatro asteriscos significan "cualquier hora, día, mes y día de la semana". La **`H`** (de *hash*) hace que Jenkins elija él el minuto exacto dentro de cada intervalo; así, si hay muchos jobs, no consultan todos el repositorio en el mismo segundo. En el aula, con pocos jobs, la diferencia es invisible.

Hacemos clic en `Save`.

### Primera construcción

El sondeo solo construye cuando detecta un cambio **posterior** a su última consulta, así que no lanza nada al guardar el job. Para la primera construcción hacemos clic en `Build Now`. Debe verse la vista de etapas con tres columnas, `Compilar`, `Probar` y `Empaquetar`, en verde. En el registro de la consola, al principio, Jenkins descarga el repositorio, lee el `Jenkinsfile` y muestra la versión de Maven y de Java que ha puesto `tools`. La salida de Maven en la etapa `Probar` debe ser la que obtenemos nosotros ejecutando `mvn -B test` en la consola:

<pre>
[INFO] Tests run: 1, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 2.4 s -- in com.curso.AplicacionTests
[INFO] Tests run: 5, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 0.05 s -- in com.curso.model.ContactoTests
[INFO] 
[INFO] Results:
[INFO] 
[INFO] Tests run: 6, Failures: 0, Errors: 0, Skipped: 0
[INFO] 
[INFO] BUILD SUCCESS
</pre>

Seis pruebas: una de arranque de Spring (`contextLoads`) y cinco de `Contacto`. Los tiempos varían. Y en la etapa `Empaquetar`, Maven escribe:

<pre>
[INFO] --- jar:3.5.1:jar (default-jar) @ contactos ---
[INFO] Building jar: /ruta/contactos/target/contactos-0.0.1-SNAPSHOT.jar
[INFO] --- spring-boot:4.1.1:repackage (repackage) @ contactos ---
[INFO] Replacing main artifact /ruta/contactos/target/contactos-0.0.1-SNAPSHOT.jar with repackaged archive, adding nested dependencies in BOOT-INF/.
[INFO] The original artifact has been renamed to /ruta/contactos/target/contactos-0.0.1-SNAPSHOT.jar.original
[INFO] BUILD SUCCESS
</pre>

*Repackage* es el paso en que Spring Boot mete dentro del JAR todas las librerías que necesita, y por eso el JAR es ejecutable. Al final de la construcción, en la página de la ejecución (`#1`), aparecen el resultado de las pruebas (`Test Result`, con las seis pruebas) y el artefacto archivado, `contactos-0.0.1-SNAPSHOT.jar`, que podemos descargar.

Para comprobar que el JAR archivado funciona, lo descargamos y lo ejecutamos en `cmd`:

```bash
java -jar contactos-0.0.1-SNAPSHOT.jar
```

El proyecto es una aplicación de Spring sin servidor web, así que arranca, escribe su banner de Spring Boot y unas líneas de registro (`Started Aplicacion in ... seconds`) y termina enseguida. Que arranque y termine sin errores es la prueba de que el JAR es válido.

### El momento de la integración continua: un push que lanza la construcción

Ahora hacemos el cambio inofensivo de la demo. En IntelliJ, en `Contacto.java`, dentro del método `resumen()`, añadimos al final del comentario `// Concatenamos los tres datos con los separadores que queremos entre ellos.` el texto ` Pipeline probado.` (con el espacio inicial). No cambia el comportamiento. Después, en `cmd`:

```bash
git add .
git commit -m "Comentario de prueba para el sondeo de Jenkins"
git push
```

No pulsamos nada en Jenkins. Esperamos un máximo de dos minutos y observamos la página de `contactos-pipeline`: aparece sola la construcción `#2`. En su página, Jenkins indica la causa de la ejecución (`Started by an SCM change` o un texto equivalente). Si pasados tres minutos no ha aparecido, abrimos en el menú del job el enlace `Git Polling Log`, que explica qué ha comprobado Jenkins y qué ha encontrado.

Esto es lo que diferencia al pipeline de ejecutar `mvn package` a mano: el cambio de una persona produce una construcción y un informe sin que nadie lo pida.

---

## Demo 3: Fallos, Replay y depuración

Un pipeline sirve sobre todo cuando algo sale mal. Un pipeline que falla en la etapa tres de cinco indica dónde buscar, y esa es la habilidad que practicamos aquí: provocar tres fallos de naturaleza distinta y localizar cada uno con la vista de etapas. En el tercero descubrimos **Replay**, la herramienta que más tiempo ahorra al escribir un `Jenkinsfile` por primera vez.

### Fallo 1: error de compilación

En `Contacto.java`, método `resumen()`, cambiamos `return` por `retun` (le quitamos una letra). Confirmamos y enviamos:

```bash
git add .
git commit -m "Rompe la compilacion a proposito"
git push
```

Esperamos al sondeo. La construcción nueva sale en rojo. En la vista de etapas, `Compilar` está en rojo y `Probar` y `Empaquetar` aparecen vacías o atenuadas: Jenkins se detiene en la primera etapa que falla y no ejecuta las siguientes. Es la cadena de montaje: la pieza defectuosa no pasa al taller siguiente.

Para ver el motivo, hacemos clic en la etapa roja y abrimos su registro (o en `Console Output`). Maven escribe exactamente esto:

<pre>
[ERROR] COMPILATION ERROR : 
[ERROR] /ruta/contactos/src/main/java/com/curso/model/Contacto.java:[49,21] ';' expected
[ERROR] /ruta/contactos/src/main/java/com/curso/model/Contacto.java:[49,55] not a statement
[INFO] BUILD FAILURE
</pre>

Se lee así: fichero `Contacto.java`, línea 49, columna 21, "se esperaba un punto y coma". Para Java, `retun nombre` parece una declaración de variable a medias. El consejo vale siempre: en el registro de una etapa roja, buscamos la primera línea que empieza por `[ERROR]`.

Corregimos (`return`), confirmamos y enviamos. La construcción siguiente vuelve al verde.

### Fallo 2: pruebas rotas y el informe que sí se publica

Ahora rompemos el código sin que deje de compilar, con los dos cambios que ya usamos en S13-2, en `Contacto.java`:

1. En `emailValido()`, quitamos `&& !email.contains(" ")`, de modo que la línea queda `return email.contains("@") && email.contains(".");`.
2. En `resumen()`, quitamos el espacio después de la coma: `", "` pasa a `","`.

```bash
git add .
git commit -m "Rompe dos pruebas a proposito"
git push
```

Esperamos al sondeo. Esta vez `Compilar` sale en verde y `Probar` en rojo; `Empaquetar` no se ejecuta, así que **esta construcción no genera ningún JAR**. Es lo que queremos: un código con pruebas rotas no debe empaquetarse.

En el registro, Maven resume (con la salida real de nuestra comprobación; la consola de Windows puede mostrar deformadas las tildes de `Lucía Pérez`):

<pre>
[ERROR] Failures: 
[ERROR]   ContactoTests.emailSinPuntoOConEspaciosNoEsValido:57 expected: &lt;false&gt; but was: &lt;true&gt;
[ERROR]   ContactoTests.resumenIncluyeEmailYTelefono:42 expected: &lt;Lucía Pérez (lucia@example.com, 600123456)&gt; but was: &lt;Lucía Pérez (lucia@example.com,600123456)&gt;
[ERROR] Tests run: 6, Failures: 2, Errors: 0, Skipped: 0
[INFO] BUILD FAILURE
</pre>

Aquí se ve el valor del bloque `post { always { junit ... } }`. Aunque `mvn test` terminó con error, Jenkins publicó el informe: en la página de la construcción hay un enlace `Test Result` que muestra las dos pruebas fallidas con su mensaje. Sin `always`, tendríamos una construcción roja sin ningún informe.

Corregimos los dos cambios, confirmamos y enviamos para volver al verde.

### Fallo 3: un error en el propio Jenkinsfile, y Replay

Los dos fallos anteriores estaban en el código Java y se corrigen con un commit. Pero los errores también pueden estar en el `Jenkinsfile`, y en ese caso probar una corrección con un commit por cada intento llena el historial de mensajes del tipo "arreglo 1", "arreglo 2", "ahora sí". **Replay** (reproducir) lo evita: permite editar el `Jenkinsfile` de una construcción ya hecha y volver a ejecutarla sin tocar el repositorio. La edición solo vive en esa ejecución.

Abrimos la última construcción en verde, y en el menú de la izquierda hacemos clic en `Replay`. Aparece un cuadro de texto con el contenido del `Jenkinsfile` de esa construcción. Provocamos el error a propósito: en la etapa `Empaquetar` cambiamos `package` por `packge`. (Si no queremos editarlo a mano, el zip trae el fichero `Jenkinsfile-con-error.txt`, que es el mismo `Jenkinsfile` con esa errata; pegamos su contenido en el cuadro.) Hacemos clic en `Run`.

La construcción nueva falla en `Empaquetar`, y Maven dice (salida real):

<pre>
[ERROR] Unknown lifecycle phase "packge". You must specify a valid lifecycle phase or a goal in the format &lt;plugin-prefix&gt;:&lt;goal&gt; or &lt;plugin-group-id&gt;:&lt;plugin-artifact-id&gt;[:&lt;plugin-version&gt;]:&lt;goal&gt;. Available lifecycle phases are: pre-clean, clean, post-clean, validate, initialize, generate-sources, process-sources, generate-resources, process-resources, compile, process-classes, generate-test-sources, process-test-sources, generate-test-resources, process-test-resources, test-compile, process-test-classes, test, prepare-package, package, pre-integration-test, integration-test, post-integration-test, verify, install, deploy, pre-site, site, post-site, site-deploy. -&gt; [Help 1]
</pre>

Maven no conoce la fase `packge` y lista las que existen; ahí se ve que debía ser `package`. Nos fijamos en la vista de etapas: `Compilar` y `Probar` están en verde, y solo `Empaquetar` en rojo. El error está localizado antes de abrir ningún registro.

Ahora lo corregimos sin commits: abrimos esa construcción roja, `Replay`, cambiamos `packge` por `package` y `Run`. La nueva construcción sale en verde. Todo esto ha ocurrido sin ningún commit nuevo: el `Jenkinsfile` del repositorio sigue siendo el original y correcto. Si el cambio que probamos con Replay fuera una mejora real, entonces sí lo copiamos al `Jenkinsfile` del repositorio y lo confirmamos, porque Replay no guarda nada.

Replay solo está disponible para construcciones de jobs de tipo Pipeline.

---

## Problemas frecuentes

Los fallos más habituales al empezar con un `Jenkinsfile`, con el síntoma y la causa. Los mensajes literales de Jenkins los hemos marcado como *no verificados* cuando no hemos podido comprobarlos en una instalación real; el tema es siempre reconocible aunque la frase exacta cambie.

**Sangría y llaves.** En Groovy la sangría (los espacios al inicio de la línea) no cambia el significado del código, a diferencia de YAML (S16-2). Lo que sí importa es que cada `{` tenga su `}`: una llave de más o de menos produce un error de sintaxis antes de que empiece la construcción. Se detecta cuando Jenkins indica `WorkflowScript` y un número de línea (formato habitual, no verificado). Para evitarlo, sangramos igual que en el zip: cada bloque se abre y se cierra a la misma altura.

**Comillas.** Las comillas deben ser rectas, simples (`'`) o dobles (`"`). Si el texto se copia desde Word, un PDF o una página web, pueden llegar comillas curvas (`‘ ’ “ ”`) y el script no compila. Hemos comprobado con el analizador de Groovy que una comilla sin cerrar produce `Unexpected character: '\''`. Para el curso, usamos siempre comillas simples: en Groovy las dobles interpretan el símbolo `$`, que los comandos de Windows no usan pero que puede aparecer en rutas.

**`bat` frente a `sh`.** En Windows hay que usar `bat`. Si se escribe `sh 'mvn -B test'`, Jenkins intenta lanzar una consola de Linux que no existe y falla en esa etapa (el error habitual menciona `nohup`, no verificado). Al revés, `bat` no funciona en Linux. Los proyectos de los grupos se construyen en el mismo Jenkins de Windows, por lo que también llevan `bat`.

**Branch Specifier.** Si se deja el valor por defecto `*/master` y la rama del repositorio es `main`, Jenkins no encuentra nada que construir. El mensaje habitual contiene "Couldn't find any revision to build" (no verificado). Se corrige en la configuración del job, `Pipeline > Branches to build > Branch Specifier`, escribiendo `*/main`.

**Ruta del Jenkinsfile.** Si `Script Path` no coincide con la ubicación real del fichero, o el fichero no se subió (o se llama `Jenkinsfile.txt` porque Windows ocultó la extensión), Jenkins falla nada más descargar el repositorio sin ejecutar ninguna etapa (mensaje habitual con "Unable to find Jenkinsfile", no verificado). Comprobamos en GitHub que el fichero está en la raíz y que su nombre es exacto.

**Nombre de la herramienta.** Si el nombre de `tools` no coincide con `Manage Jenkins > Tools` (`jdk-21` frente a `jdk21`, por ejemplo), la construcción falla antes de empezar la primera etapa. Jenkins suele sugerir el nombre correcto (mensaje del estilo "did you mean", no verificado). Se corrige copiando el nombre exacto desde la página de herramientas.

**Tildes deformadas en `bat`.** Las tildes escritas en un `echo` o pasadas a un comando `bat` pueden salir como símbolos raros por la codificación de la consola de Windows. No es un fallo: se evitan escribiendo esos textos sin tildes.

**El sondeo no construye.** Tres causas habituales: el job no tiene marcado `Poll SCM`; el `push` fue a otra rama distinta de `main`; o aún no han pasado los minutos del `Schedule`. Se comprueba con `Git Polling Log`.

**Informe de pruebas viejo.** Si se quita el `clean` de la primera etapa, `target/` conserva informes de construcciones anteriores y Jenkins puede mostrar como nuevas pruebas que ya no existen.

---

## Qué está verificado y qué no

Esta sección es una nota para quien prepara la clase; no se proyecta.

**Verificado con Maven 3.9.11, JDK 21 y el proyecto `contactos` de S11-1 (zip real):**
- `mvn -B clean package`: seis pruebas en verde, `contactos-0.0.1-SNAPSHOT.jar` y `.jar.original`.
- `java -jar` del JAR: arranca (`Started Aplicacion`) y termina sin error.
- Los dos cambios de S13-2: dos pruebas fallan, `BUILD FAILURE`, y se generan los XML de `surefire-reports`.
- El error de compilación con `retun` (línea 49 de `Contacto.java`) y el de `packge` (`Unknown lifecycle phase`).
- `-Dmaven.test.failure.ignore=true`: `BUILD SUCCESS` con dos pruebas rotas.
- `git add`, `git commit` y `git push` contra un repositorio remoto local.
- Que los seis `Jenkinsfile` son sintácticamente válidos como Groovy (analizador de Groovy 4; Jenkins usa su propio intérprete, así que es una comprobación de sintaxis, no de ejecución).

**No verificado (requiere un Jenkins real):**
- Todo el comportamiento de Jenkins: vista de etapas, `Replay`, sondeo, `archiveArtifacts`, `junit` y `tools`.
- Los nombres exactos de menús y botones (`New Item`, `Build Now`, `Replay`, `Poll SCM`, `Git Polling Log`...) y los mensajes de error de Jenkins citados. Son los habituales de Jenkins en inglés, pero hay que mirarlos en la instalación del aula.
- Los nombres `jdk-21` y `maven-3.9`, tomados de lo configurado en S13-2.
- Cómo se ven las tildes de la salida de Maven en la consola de Jenkins sobre Windows.
