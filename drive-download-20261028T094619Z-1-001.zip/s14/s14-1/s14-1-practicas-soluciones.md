# S14-1 Soluciones

## Práctica 1: Jenkinsfile de contactos

El `Jenkinsfile` va en la raíz del proyecto, tiene las tres etapas pedidas y publica el informe de pruebas con `post { always { junit ... } }`. La práctica no archiva el JAR (eso es la Práctica 3). Se crea un job `Pipeline` con `Pipeline script from SCM`, Git, la dirección del repositorio, la credencial de S13-2, `Branch Specifier` con `*/main` y `Script Path` con `Jenkinsfile`.

```groovy
/*
 * S14-1 Práctica 1: Jenkinsfile de contactos
 *
 * Objetivo: escribir el pipeline de contactos con tres etapas: compilar, probar y empaquetar.
 *
 * Aplica las técnicas de S14-1:
 *   1. Estructura pipeline, agent, stages, stage y steps
 *   2. Bloque tools con el JDK y el Maven de las herramientas globales
 *   3. Paso bat para lanzar Maven en Windows
 *   4. Publicación de las pruebas con junit dentro de post y always
 *
 * Concepto clave: el Jenkinsfile es la traducción a texto de lo que en S13-2 hicimos
 * con el ratón en un job freestyle.
 */
pipeline {

    // Cualquier agente disponible.
    agent any

    // Declaramos el JDK y el Maven de Manage Jenkins > Tools (S13-2).
    // Sin este bloque, el servicio de Jenkins no encontraría ni java ni mvn.
    tools {
        jdk 'jdk-21'
        maven 'maven-3.9'
    }

    stages {

        stage('Compilar') {
            steps {
                // clean borra target/ y compile genera las clases. -B simplifica la salida.
                bat 'mvn -B clean compile'
            }
        }

        stage('Probar') {
            steps {
                // Ejecutamos las seis pruebas de contactos.
                bat 'mvn -B test'
            }
            post {
                // always: publicamos el informe tanto si las pruebas pasan como si fallan.
                always {
                    junit testResults: 'target/surefire-reports/*.xml', allowEmptyResults: true
                }
            }
        }

        stage('Empaquetar') {
            steps {
                // Generamos el JAR sin repetir las pruebas, que ya se ejecutaron arriba.
                bat 'mvn -B package -DskipTests'
            }
        }
    }
}
```

Comandos para subirlo:

```bash
git add Jenkinsfile
git commit -m "Añade el Jenkinsfile de contactos"
git push
```

Resultado esperado en la etapa `Probar`, con el mismo `mvn -B test` que ejecutamos en `cmd`:

<pre>
[INFO] Tests run: 1, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 2.4 s -- in com.curso.AplicacionTests
[INFO] Tests run: 5, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 0.05 s -- in com.curso.model.ContactoTests
[INFO] Tests run: 6, Failures: 0, Errors: 0, Skipped: 0
[INFO] BUILD SUCCESS
</pre>

**Decisiones tomadas**
- **Tres etapas y no una.** Con una sola etapa que ejecutara `mvn clean package`, el resultado sería el mismo, pero la vista de etapas no diría en qué punto falla. Separar compilar, probar y empaquetar convierte cada fallo en una columna roja.
- **`clean` solo en la primera etapa.** Borra `target/` una vez, al empezar. Si se repitiera en cada etapa, cada una borraría lo que hizo la anterior.
- **`-DskipTests` al empaquetar.** Las pruebas ya se ejecutaron en la etapa anterior; repetirlas alargaría la construcción sin aportar nada.
- **`junit` en `post` con `always`, y no como último paso de `Probar`.** Si una prueba falla, Maven termina con error y el paso que va detrás no llegaría a ejecutarse. En `post` el informe se publica en las dos situaciones.
- **`allowEmptyResults: true`.** Si las pruebas no compilan, no hay informes y `junit` daría un segundo error que despista del primero.

---

## Práctica 2: Etapa nueva y fallo provocado

La etapa `Entorno` va la primera para que su información aparezca antes que cualquier otra en el registro. Muestra el Java y el Maven que ha puesto `tools`, la ruta de `mvn` y un mensaje propio. El resto del pipeline es el de la Práctica 1.

```groovy
/*
 * S14-1 Práctica 2: Etapa nueva y fallo provocado
 *
 * Objetivo: añadir una etapa que muestra información del entorno y diagnosticar
 * un fallo provocado en la etapa de pruebas.
 *
 * Aplica las técnicas de S14-1:
 *   1. Añadir una etapa al principio de un pipeline existente
 *   2. Usar varios pasos dentro de una misma etapa
 *   3. Leer la vista de etapas y el registro de la etapa que falla
 *
 * Concepto clave: cada etapa es una unidad independiente. Si la de pruebas falla,
 * la vista de etapas señala cuál ha sido y su registro explica por qué.
 */
pipeline {
    agent any

    tools {
        jdk 'jdk-21'
        maven 'maven-3.9'
    }

    stages {

        // Etapa nueva: va primero para que su información aparezca antes que nada en el registro.
        stage('Entorno') {
            steps {
                // Cada línea de steps es un paso distinto y Jenkins los ejecuta en orden.
                // java -version muestra el JDK que ha puesto tools en el PATH.
                bat 'java -version'
                // mvn -version muestra el Maven que ha puesto tools y el Java que usa.
                bat 'mvn -version'
                // where busca en el PATH dónde está el ejecutable: confirma que es el de tools
                // y no uno instalado en otra carpeta del equipo.
                bat 'where mvn'
                // echo escribe un mensaje propio. Sin tildes, para evitar problemas de consola.
                echo 'Entorno comprobado'   // → Entorno comprobado
            }
        }

        stage('Compilar') {
            steps {
                bat 'mvn -B clean compile'
            }
        }

        stage('Probar') {
            steps {
                // Para provocar el fallo se quita "&& !email.contains(" ")" de emailValido()
                // en Contacto.java: la prueba emailSinPuntoOConEspaciosNoEsValido fallará aquí.
                bat 'mvn -B test'
            }
            post {
                always {
                    junit testResults: 'target/surefire-reports/*.xml', allowEmptyResults: true
                }
            }
        }

        stage('Empaquetar') {
            steps {
                bat 'mvn -B package -DskipTests'
            }
        }
    }
}
```

Para el fallo, en `Contacto.java` el método `emailValido()` pasa a esta línea:

```java
return email.contains("@") && email.contains(".");
```

Con ese cambio, la prueba `emailSinPuntoOConEspaciosNoEsValido` falla porque el correo con un espacio ya se considera válido. Salida de Maven en la etapa `Probar`:

<pre>
[ERROR] Failures: 
[ERROR]   ContactoTests.emailSinPuntoOConEspaciosNoEsValido:57 expected: &lt;false&gt; but was: &lt;true&gt;
[ERROR] Tests run: 6, Failures: 1, Errors: 0, Skipped: 0
[INFO] BUILD FAILURE
</pre>

En la vista de etapas: `Entorno` y `Compilar` en verde, `Probar` en rojo y `Empaquetar` sin ejecutar. En el resultado de pruebas aparece la prueba fallida y su mensaje.

**Decisiones tomadas**
- **La etapa nueva al principio.** Si estuviera al final, una construcción que falla en pruebas no llegaría nunca a mostrar el entorno, que es justo cuando más ayuda saber qué Java y qué Maven se han usado.
- **Cuatro pasos en una sola etapa.** Los cuatro pertenecen a la misma idea (describir el entorno), y una etapa por paso llenaría la vista de columnas casi vacías.
- **`where mvn`.** Confirma que el `mvn` que se ejecuta es el que ha puesto `tools` y no otro instalado en el equipo.
- **Provocar el fallo con el código, no con el `Jenkinsfile`.** Es el caso más habitual en un equipo, y el que localiza la vista de etapas sin abrir ningún registro.

---

## Práctica 3: Archivar y descargar el artefacto

Se añade a la etapa `Empaquetar` el paso `archiveArtifacts` con el patrón `target/*.jar`. Ese patrón recoge `contactos-0.0.1-SNAPSHOT.jar` y no `contactos-0.0.1-SNAPSHOT.jar.original`.

```groovy
/*
 * S14-1 Práctica 3: Archivar y descargar el artefacto
 *
 * Objetivo: conservar en Jenkins el JAR de cada construcción para poder descargar
 * el de una ejecución antigua y ejecutarlo.
 *
 * Aplica las técnicas de S14-1:
 *   1. Paso archiveArtifacts con un patrón de ficheros
 *   2. Un artefacto distinto por cada construcción
 *   3. Descarga del JAR desde Jenkins y ejecución con java -jar
 *
 * Concepto clave: el artefacto es el resultado de la construcción. Jenkins lo guarda
 * asociado al número de ejecución, y con ese número se recupera la versión que se necesite.
 */
pipeline {
    agent any

    tools {
        jdk 'jdk-21'
        maven 'maven-3.9'
    }

    stages {

        stage('Compilar') {
            steps {
                bat 'mvn -B clean compile'
            }
        }

        stage('Probar') {
            steps {
                bat 'mvn -B test'
            }
            post {
                always {
                    junit testResults: 'target/surefire-reports/*.xml', allowEmptyResults: true
                }
            }
        }

        stage('Empaquetar') {
            steps {
                bat 'mvn -B package -DskipTests'
                // Archivamos solo el JAR ejecutable. El patrón target/*.jar no recoge
                // contactos-0.0.1-SNAPSHOT.jar.original, que termina en .original.
                // fingerprint: true añade una huella (un resumen del contenido) a cada JAR,
                // y Jenkins la usa para saber qué construcción produjo cada fichero.
                archiveArtifacts artifacts: 'target/*.jar', fingerprint: true
            }
        }
    }
}
```

El parámetro `fingerprint: true` añade una huella a cada fichero archivado. Una **huella** (*fingerprint*) es un resumen del contenido del fichero que Jenkins calcula y guarda; sirve para saber qué construcción produjo un fichero concreto, y que dos ficheros iguales tienen la misma huella. No hace falta para descargar el JAR, pero es un buen hábito con artefactos.

Para comprobar el JAR descargado, en `cmd`, desde la carpeta de la descarga:

```bash
java -jar contactos-0.0.1-SNAPSHOT.jar
```

Se ve el banner de Spring Boot y unas líneas de registro, entre ellas `Started Aplicacion in ... seconds`, y el programa termina.

**Decisiones tomadas**
- **`target/*.jar` y no `target/*`.** Archivar toda la carpeta `target` ocuparía mucho espacio con ficheros que se reconstruyen al compilar. Archivamos solo lo que se entrega.
- **Archivar en `Empaquetar`.** El JAR existe solo después de empaquetar; archivar antes no encontraría nada.
- **Cambios entre construcciones.** Con el mismo código, todas las construcciones producen el mismo JAR. Los cambios inofensivos entre ejecuciones hacen que cada artefacto corresponda a un estado distinto del código, que es lo que permite volver a una versión anterior.

---

## Práctica 4: Pipeline del proyecto en grupo

Esta práctica no tiene zip: el código es el proyecto de cada grupo. La solución es un `Jenkinsfile` orientativo y un procedimiento para decidir qué pruebas se excluyen.

### Averiguar qué pruebas dependen de la base de datos

En `cmd`, desde la carpeta del proyecto, sin las variables de entorno de IntelliJ:

```bash
mvn -B test
```

Las pruebas que arrancan la aplicación con JPA (la `contextLoads` que genera Spring Boot, y cualquier prueba con `@SpringBootTest` o `@DataJpaTest`) fallan al no poder conectar con la base de datos. Las pruebas de clases sueltas, como las de `Contacto` en `contactos`, no se ven afectadas. Con esa lista, el grupo decide qué excluir.

### Jenkinsfile orientativo

El nombre `AplicacionTests` es el de la clase de arranque de `contactos`; cada grupo pone los nombres de sus propias clases de prueba.

```groovy
/*
 * S14-1 Práctica 4: Pipeline del proyecto en grupo (solución orientativa)
 *
 * Objetivo: construir y probar el proyecto del grupo en Jenkins sin que
 * las pruebas que necesitan base de datos rompan la construcción.
 *
 * Aplica las técnicas de S14-1:
 *   1. Bloque tools con el JDK y el Maven de las herramientas globales
 *   2. Etapas de compilar y probar con bat
 *   3. Exclusión de pruebas con la propiedad -Dtest de Surefire
 *
 * Concepto clave: el entorno de Jenkins no es el de IntelliJ. Lo que se define
 * como variable de entorno en el IDE no existe para el servicio de Jenkins.
 */
pipeline {
    agent any

    // Los nombres deben coincidir con los de Manage Jenkins > Tools.
    tools {
        jdk 'jdk-21'
        maven 'maven-3.9'
    }

    stages {

        stage('Compilar') {
            steps {
                bat 'mvn -B clean compile'
            }
        }

        stage('Probar') {
            steps {
                // -Dtest elige qué pruebas ejecuta Surefire. El signo ! delante de un nombre
                // lo excluye, y las comas separan varios nombres: aquí se excluye
                // la prueba de arranque, que intentaría conectar con la base de datos.
                // Las comillas dobles evitan que cmd interprete el signo !.
                bat 'mvn -B test "-Dtest=!AplicacionTests"'
            }
            post {
                always {
                    junit testResults: 'target/surefire-reports/*.xml', allowEmptyResults: true
                }
            }
        }
    }
}
```

Con `contactos` esa orden ejecuta solo las cinco pruebas de `Contacto`:

<pre>
[INFO] Tests run: 5, Failures: 0, Errors: 0, Skipped: 0, Time elapsed: 0.1 s -- in com.curso.model.ContactoTests
[INFO] Tests run: 5, Failures: 0, Errors: 0, Skipped: 0
[INFO] BUILD SUCCESS
</pre>

Para excluir varias clases se separan por comas: `"-Dtest=!AplicacionTests,!*RepositoryTests"`. El asterisco sustituye cualquier texto.

**Decisiones tomadas**
- **Solo compilar y probar.** El enunciado no pide empaquetar; empaquetar y archivar se añaden después, como en `contactos`.
- **Excluir por nombre, no borrar la prueba.** La prueba sigue en el proyecto y funciona en el equipo de cada persona; solo se omite en Jenkins. Borrarla perdería una comprobación útil.
- **Es una solución provisional.** El grupo anota qué pruebas ha excluido. Lo habitual en un equipo real es darle a Jenkins una base de datos de pruebas o variables de entorno propias; aquí basta con tener claro qué no se comprueba.
- **Comillas dobles alrededor de `-Dtest=...`.** Se han comprobado con Maven en Linux; en el `cmd` de Windows el signo `!` es normal, y las comillas son una protección, no una exigencia. Hay que probarlo en el aula antes de darlo por bueno.
