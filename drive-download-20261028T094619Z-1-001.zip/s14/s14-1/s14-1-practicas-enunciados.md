# S14-1 Prácticas

## Objetivos

En las demos hemos visto cómo se describe una construcción en un `Jenkinsfile`, cómo Jenkins lo lee del repositorio y cómo se localizan los fallos. En estas prácticas escribimos nosotros los pipelines. Las tres primeras se hacen sobre `contactos`, el proyecto de S11-1, con el repositorio propio de cada persona. La cuarta se hace sobre el proyecto del grupo.

Escribir el fichero a partir de lo visto, y no copiarlo de las demos, es lo que fija la sintaxis. Los errores de formato son muy frecuentes al principio y tienen mensajes reconocibles: la sección de problemas frecuentes de `s14-1-demos` es el primer sitio donde mirar.

Antes de empezar, cada persona comprueba tres datos y los anota, porque los necesita en todas las prácticas:

- El nombre del JDK y el de Maven en `Manage Jenkins > Tools`.
- Que la credencial de GitHub de S13-2 sigue existiendo en `Manage Jenkins > Credentials`.
- Que la rama de su repositorio se llama `main` (`git status` dice `On branch main`).

---

## Práctica 1: Jenkinsfile de contactos

Se escribe el `Jenkinsfile` del proyecto `contactos` con las etapas de compilar, probar y empaquetar, se sube al repositorio y se ejecuta desde un job de Jenkins de tipo Pipeline que lo lee de allí.

**Pasos**
1. En la raíz del proyecto `contactos`, junto al `pom.xml`, creamos un fichero llamado exactamente `Jenkinsfile`, sin extensión.
2. Escribimos la estructura de un pipeline declarativo: `pipeline`, `agent`, `tools` y `stages`.
3. Declaramos con `tools` el JDK y el Maven de las herramientas globales, con los nombres que hemos anotado.
4. Añadimos tres etapas, `Compilar`, `Probar` y `Empaquetar`, cada una con su comando de Maven lanzado con `bat`.
5. En la etapa `Probar`, añadimos el bloque que publica los informes de pruebas en Jenkins aunque alguna prueba falle.
6. Confirmamos el fichero y lo enviamos al repositorio con `git add`, `git commit` y `git push`. Comprobamos en GitHub que aparece en la raíz.
7. En Jenkins creamos un job nuevo, `practica1-contactos`, de tipo `Pipeline`, que lea el `Jenkinsfile` del repositorio. Configuramos la dirección del repositorio, la credencial, la rama y la ruta del fichero.
8. Lo ejecutamos con `Build Now`. Comprobamos que las tres etapas salen en verde y que el resultado de pruebas muestra seis pruebas.

**Pistas**
- La definición del job es `Pipeline script from SCM`, no `Pipeline script`.
- La rama por defecto que propone Jenkins no es la de nuestro repositorio.
- El comando para compilar y el de probar con Maven llevan la opción de salida por lotes que usamos en las demos; para empaquetar sin repetir las pruebas hay una opción que las salta.
- Los nombres de `tools` se escriben entre comillas simples y deben coincidir letra por letra con los de `Manage Jenkins > Tools`.
- El informe de pruebas se publica con el paso `junit` y la ruta de los ficheros XML que deja Maven en `target/surefire-reports`.
- Si el job falla antes de la primera etapa, el error está en la configuración del job o en el nombre del fichero; si falla dentro de una etapa, el error está en el registro de esa etapa.

---

## Práctica 2: Etapa nueva y fallo provocado

Se añade al pipeline de `contactos` una etapa que muestra información del entorno, se provoca un fallo en las pruebas y se diagnostica con la vista de etapas.

**Pasos**
1. Partimos del `Jenkinsfile` de la Práctica 1, con el árbol de trabajo limpio (`git status`).
2. Añadimos al principio de `stages` una etapa nueva llamada `Entorno`. Debe mostrar en el registro la versión de Java que usa la construcción, la versión de Maven, la ruta del ejecutable `mvn` y un mensaje propio con `echo`.
3. Confirmamos, enviamos y creamos o reutilizamos un job que lea el repositorio (puede ser el de la Práctica 1). Lo ejecutamos y comprobamos que la etapa `Entorno` aparece primero en la vista de etapas.
4. Provocamos un fallo de prueba: en `Contacto.java`, método `emailValido()`, quitamos la condición `&& !email.contains(" ")`.
5. Confirmamos y enviamos el cambio. Lanzamos la construcción.
6. Con la vista de etapas, localizamos qué etapa ha fallado y cuáles no se han ejecutado. Abrimos el resultado de pruebas y anotamos el nombre de la prueba que falla y el mensaje.
7. Corregimos el código, confirmamos, enviamos y comprobamos que la construcción vuelve al verde.

**Pistas**
- Cada línea de `steps` es un paso distinto. Una misma etapa puede tener varios.
- Para saber dónde está un ejecutable en el `PATH` de Windows hay un comando de `cmd` cuyo nombre empieza por `where`.
- En el texto del `echo` conviene no usar tildes, para que se vea bien en la consola de Windows.
- Si la construcción en rojo no muestra resultado de pruebas, falta el bloque que lo publica con la condición que se ejecuta siempre.
- La etapa de empaquetar no debería ejecutarse con una prueba rota: comprobamos que así ocurre.

---

## Práctica 3: Archivar y descargar el artefacto

Se archiva el JAR de `contactos` en cada construcción, se descarga desde Jenkins el de una ejecución antigua y se comprueba que se puede ejecutar con `java -jar`.

**Pasos**
1. Partimos del `Jenkinsfile` de la Práctica 1 (sin la etapa de entorno, o con ella si se prefiere), con las pruebas en verde.
2. Añadimos a la etapa `Empaquetar` el paso que archiva el JAR, con un patrón de ficheros que recoja el JAR ejecutable y no el fichero que termina en `.original`.
3. Confirmamos y enviamos. Lanzamos la construcción y comprobamos que en su página aparece el artefacto archivado.
4. Hacemos un cambio inofensivo en el código (por ejemplo, ampliamos un comentario), lo confirmamos y lo enviamos. Lanzamos una segunda construcción y una tercera con otro cambio.
5. Comprobamos que cada construcción tiene su propio artefacto en su propia página.
6. Descargamos el JAR de la primera construcción. En `cmd`, desde la carpeta donde lo hemos descargado, lo ejecutamos con `java -jar` y comprobamos que arranca sin errores.

**Pistas**
- El paso se llama `archiveArtifacts`, y recibe el patrón con el parámetro `artifacts`.
- Un patrón con asterisco (`*`) sustituye cualquier texto: `target/*.jar` recoge todos los ficheros de `target` que terminan en `.jar`.
- El JAR es una aplicación de Spring sin servidor web: arranca, escribe unas líneas y termina enseguida. Eso es lo esperado.
- El número de cada construcción está en la lista de ejecuciones del job y en el título de su página.

---

## Práctica 4: Pipeline del proyecto en grupo

Cada grupo escribe el `Jenkinsfile` de su proyecto con las etapas de compilar y probar, lo sube a su repositorio y comprueba que Jenkins lo ejecuta. Esta práctica no lleva zip: el código es el proyecto de cada grupo.

El proyecto del grupo no es `contactos`, y tiene una diferencia importante: la contraseña de la base de datos se definió como una variable de entorno en IntelliJ. Esa variable no existe para el servicio de Jenkins, que tiene su propio entorno. Cualquier prueba que arranque la aplicación con JPA, como la que genera Spring Boot para comprobar que el contexto carga, intentará conectar con la base de datos y fallará en Jenkins aunque funcione en el equipo de cada persona. Descubrirlo y decidir qué pruebas se ejecutan es parte de la práctica.

**Pasos**
1. En el equipo de una persona del grupo, ejecutamos `mvn -B test` en `cmd`, desde la carpeta del proyecto, sin las variables de entorno de IntelliJ. Anotamos qué pruebas fallan y por qué.
2. Con esa lista, decidimos qué pruebas se ejecutan en Jenkins y cuáles se excluyen por depender de la base de datos.
3. Escribimos el `Jenkinsfile` en la raíz del proyecto: `tools` con el JDK y el Maven de las herramientas globales, una etapa `Compilar` y una etapa `Probar` con la publicación de las pruebas. Las pruebas que dependen de la base de datos no se ejecutan en esa etapa.
4. Lo subimos al repositorio del grupo. Comprobamos que está en la raíz.
5. Creamos en Jenkins un job de tipo Pipeline que lea el `Jenkinsfile` del repositorio del grupo, con la credencial y con el nombre de rama que use el grupo.
6. Lo ejecutamos y lo dejamos en verde. Anotamos qué pruebas se ejecutan y cuáles se han excluido.

**Pistas**
- Surefire, el plugin de Maven que ejecuta las pruebas, admite una propiedad `-Dtest` para elegir qué pruebas se ejecutan, y acepta un signo de exclamación delante de un nombre para excluirlo.
- Se pueden excluir varias pruebas separando sus nombres con comas, y se pueden usar asteriscos en los nombres.
- Al escribir la propiedad dentro de `bat`, se pone entre comillas dobles para que `cmd` no interprete el signo de exclamación.
- Si el repositorio del grupo tiene otra rama principal o el proyecto no está en la raíz del repositorio, hay que ajustar `Branch Specifier` y `Script Path`.
- Excluir las pruebas de base de datos es una solución provisional. Anotamos cuáles son, porque hacen falta para otra solución más adelante.
