# S07 Demos

## Objetivos

En S06 construimos una aplicación web con una base de datos H2 en memoria: Hibernate creaba las tablas al arrancar y todo desaparecía al parar. Una aplicación real no funciona así. Sus datos viven en una base de datos que existe antes de arrancar el programa, que tiene un esquema diseñado y que conserva la información entre ejecuciones. En esta parte sustituimos H2 por **PostgreSQL instalado en el propio ordenador**, en tres pasos.

Primero creamos el esquema del gimnasio (monitores, clases, socios e inscripciones) escribiendo las sentencias SQL a mano con la herramienta Query Tool de pgAdmin, con sus claves primarias, sus claves foráneas y algunas restricciones. Después conectamos un proyecto Spring Boot a esa base de datos con tres propiedades y una variable de entorno para la contraseña, y comprobamos la conexión con una clase mínima. Por último mapeamos la primera entidad, `Monitor`, a una tabla que ya existe y listamos sus filas.

Los tres pasos comparten un hilo: el esquema se diseña en SQL y Java solo lo refleja. Las relaciones entre entidades (`@ManyToOne`, `@OneToMany`) de la siguiente parte son la traducción a Java de las claves foráneas que creamos aquí.

Al terminar esta parte los alumnos son capaces de:
- Explicar qué es una clave primaria, una clave foránea y una restricción, y qué comprueba la base de datos por su cuenta.
- Crear tablas con sentencias `create table` y cargar filas de ejemplo con `insert` desde pgAdmin.
- Conectar un proyecto Spring Boot a PostgreSQL con `application.properties` sin escribir la contraseña en ningún fichero.
- Definir la variable de entorno `POSTGRES_PASSWORD` en IntelliJ y reconocer el síntoma de que falta.
- Mapear una entidad a una tabla existente con la creación automática de tablas desactivada.

Una nota sobre las salidas de este documento. Las de la consola de IntelliJ se han obtenido ejecutando este mismo código contra PostgreSQL 16. Pueden variar detalles como la versión de PostgreSQL, los tiempos de arranque o los números de proceso. Las de pgAdmin se marcan como **Salida esperada**: son lo que debe verse, pero pgAdmin cambia de aspecto entre versiones y los nombres exactos de menús y botones pueden variar un poco.

---

## Demo 1: Tablas del gimnasio con scripts SQL

### De H2 a una base de datos real

Con H2, en S06, no escribimos ninguna tabla: Hibernate las creaba a partir de las clases (`create-drop`) y las borraba al parar. H2 en memoria funciona como la pizarra del aula: sirve mientras la usamos y se borra al terminar la clase. Una base de datos real se parece más al archivador de una oficina: sigue ahí, con todo su contenido, aunque nadie la esté usando.

PostgreSQL es ese archivador: una base de datos que corre como un programa aparte, el **servidor** de PostgreSQL, que se instala una vez en el ordenador y queda funcionando. Cualquier aplicación se conecta a él por un puerto (aquí el `5432`) con un usuario y una contraseña. Aquí ocurre lo contrario que con H2: el **esquema** existe primero y la aplicación se adapta a él. El esquema es el conjunto de tablas de una base de datos, con sus columnas, sus tipos de dato y sus reglas.

El esquema se escribe en **SQL** (*Structured Query Language*), el lenguaje con el que se habla con una base de datos relacional. En S06 aparecieron las siglas DDL (*Data Definition Language*): son las sentencias que definen la estructura, como `create table`. Hoy escribimos esas sentencias nosotros, en lugar de dejar que las genere Hibernate. También usamos dos sentencias más: `insert`, que añade una fila, y `select`, que consulta filas.

Una base de datos **relacional** organiza la información en tablas, igual que una hoja de cálculo: cada **tabla** guarda un tipo de cosa (monitores, clases...), cada **columna** es un dato de esa cosa (nombre, correo...) y cada **fila** es un caso concreto (un monitor).

### El esquema del gimnasio

El dominio del gimnasio tiene cuatro tablas:

| Tabla | Qué guarda |
|---|---|
| `monitor` | Las personas que imparten las clases |
| `clase` | Cada sesión semanal (día, hora, duración), su aforo, las plazas libres y su monitor |
| `socio` | Las personas apuntadas al gimnasio |
| `inscripcion` | Qué socio se ha apuntado a qué clase y cuándo |

Las tablas se enlazan entre sí con **claves foráneas**. Antes de verlas, hace falta la **clave primaria**: la columna cuyo valor identifica cada fila de forma única, como el número de socio. No se puede repetir ni dejar vacía. En nuestras tablas es siempre la columna `id`.

Una **clave foránea** es una columna que guarda la clave primaria de otra tabla. Funciona como anotar el número de socio en el carnet de una clase: solo vale un número que exista de verdad. Si anotamos un socio que no está registrado, la base de datos rechaza la fila. Nuestras claves foráneas son estas:

| Columna | Apunta a | Qué significa |
|---|---|---|
| `clase.monitor_id` | `monitor.id` | Cada clase la imparte un monitor. Un monitor puede impartir varias clases |
| `inscripcion.socio_id` | `socio.id` | El socio que se inscribe |
| `inscripcion.clase_id` | `clase.id` | La clase en la que se inscribe |

La tabla `inscripcion` merece una explicación aparte. Un socio puede apuntarse a muchas clases y una clase tiene muchos socios: es una relación de **muchos a muchos**. Una tabla no puede guardar eso en una sola columna, así que se resuelve con una tabla intermedia que tiene dos claves foráneas, una hacia cada lado. `inscripcion` además guarda un dato propio de la relación: la fecha en que el socio se inscribió. En la siguiente parte veremos cómo se expresa esto en Java.

### Preparar PostgreSQL y pgAdmin

Si PostgreSQL ya está instalado en el ordenador, pasamos a «Crear la base de datos». Si no, lo instalamos una vez, y servirá para todo el curso.

**Instalar PostgreSQL en Windows**

1. Entramos en `https://www.postgresql.org/download/windows/` y descargamos el instalador de la versión estable más reciente (el enlace lleva al instalador de EDB, la empresa que lo empaqueta). Cualquier versión desde la 14 en adelante sirve para el curso.
2. Ejecutamos el instalador y aceptamos la carpeta de instalación y los componentes que propone. Entre ellos están `PostgreSQL Server` y `pgAdmin 4`, que son los que necesitamos. `Stack Builder` no se usa.
3. Cuando pide una **contraseña para el superusuario (`postgres`)**, escribimos una y la apuntamos: sin ella no podemos conectar. Es la contraseña que luego irá en la variable de entorno. Conviene una sin caracteres especiales (letras y números), para evitar problemas al escribirla en IntelliJ.
4. Dejamos el puerto en `5432` (el valor por defecto) y la configuración regional por defecto.
5. Terminamos la instalación. No hace falta ejecutar `Stack Builder` al final.

El instalador deja un servicio de Windows que arranca con el ordenador, de modo que el servidor está siempre en marcha. Si más adelante la conexión falla con `Connection refused`, lo primero es comprobar en `Servicios` de Windows que el servicio `postgresql-x64-<versión>` está iniciado.

**Abrir pgAdmin**

pgAdmin es la herramienta con ventanas para trabajar con PostgreSQL. Lo abrimos desde el menú Inicio (`pgAdmin 4`). La primera vez pide una **contraseña maestra**: es una contraseña propia de pgAdmin para proteger las que guarda, distinta de la de `postgres`. Elegimos una y la apuntamos. En el panel izquierdo, desplegamos `Servers` y hacemos clic en el servidor `PostgreSQL <versión>`; pide la contraseña de `postgres`, la que pusimos al instalar.

### Crear la base de datos

Un servidor PostgreSQL puede contener varias **bases de datos** separadas. Cada proyecto del curso usa la suya. Para las demos creamos una llamada `gimnasio`:

1. En el panel izquierdo, clic derecho sobre `Databases`, `Create` y `Database...`.
2. En `Database` escribimos `gimnasio` y pulsamos `Save`.
3. Aparece `gimnasio` bajo `Databases`. Hacemos clic derecho sobre ella y elegimos `Query Tool`.

La **Query Tool** es el editor donde escribimos y ejecutamos SQL sobre esa base de datos. El texto se ejecuta con el botón ▶ (`Execute script`) o con `F5`. Si seleccionamos una parte del texto antes de ejecutar, pgAdmin ejecuta solo lo seleccionado. Esto último lo usaremos para probar las consultas de una en una. Los mensajes y los errores aparecen en la pestaña `Messages`, abajo.

### El script, tabla a tabla

El script completo está en el zip, en `sql/01-crear-gimnasio.sql`. Lo recorremos por partes. El texto de cada parte, comentarios incluidos, es el que hay que pegar en el editor. La primera parte es la cabecera, solo comentarios: en SQL, todo lo que va detrás de `--` hasta el final de la línea es un comentario.

```sql
-- S07 Demo 1: Tablas del gimnasio
--
-- Crea las cuatro tablas del dominio del gimnasio, con sus claves primarias,
-- sus claves foráneas y sus restricciones, y carga filas de ejemplo.
--
-- Se ejecuta una sola vez, en una base de datos vacía (gimnasio), desde la herramienta Query Tool de pgAdmin.
-- Los datos se insertan sin escribir los id: la base de datos los genera (1, 2, 3...)
-- y las claves foráneas de los INSERT se apoyan en esos valores.
```

#### La tabla monitor

```sql
-- ============================================================
-- MONITOR: quien imparte las clases
-- ============================================================
create table monitor (
    -- Clave primaria: identifica cada fila de forma única.
    -- "generated by default as identity" hace que la base de datos genere el valor sola
    -- (1, 2, 3...), igual que GenerationType.IDENTITY en Hibernate.
    id            bigint generated by default as identity primary key,
    nombre        varchar(100) not null,
    -- unique: no puede haber dos monitores con el mismo email.
    email         varchar(150) not null unique,
    -- Sin "not null": un monitor puede no tener especialidad todavía.
    especialidad  varchar(60),
    fecha_alta    date not null
);
```

Cada línea entre paréntesis es una columna con su nombre, su tipo y sus reglas:

- `bigint` es un número entero grande. Es el tipo habitual de las claves primarias. En Java se corresponde con `Long`.
- `generated by default as identity primary key` hace dos cosas. `primary key` declara la clave primaria. `generated by default as identity` hace que la base de datos genere el valor sola (1, 2, 3...) cuando no se lo damos. Es lo mismo que pedíamos en S06 con `GenerationType.IDENTITY`.
- `varchar(100)` es un texto de hasta 100 caracteres. En Java es un `String`.
- `not null` obliga a que la columna tenga siempre un valor. `especialidad` no lo lleva, así que puede quedar vacía.
- `unique` impide que dos filas tengan el mismo valor en esa columna: no puede haber dos monitores con el mismo correo.
- `date` es una fecha sin hora (`2022-09-01`). En Java es `LocalDate`.

#### La tabla clase

```sql
-- ============================================================
-- CLASE: una sesión semanal del gimnasio, con aforo y monitor
-- ============================================================
create table clase (
    id             bigint generated by default as identity primary key,
    nombre         varchar(100) not null,
    dia_semana     varchar(10) not null,
    hora           time not null,
    duracion_min   integer not null,
    -- aforo: máximo de socios que caben en la clase.
    aforo          integer not null,
    -- plazas_libres: plazas que quedan ahora mismo (aforo menos inscripciones).
    plazas_libres  integer not null,
    monitor_id     bigint not null,

    -- Clave foránea: monitor_id solo admite valores que existan en monitor.id.
    -- Con un nombre propio, el mensaje de error dice exactamente cuál se ha violado.
    constraint fk_clase_monitor foreign key (monitor_id) references monitor (id),

    -- check: condición que toda fila tiene que cumplir para poder guardarse.
    constraint ck_clase_dia check (dia_semana in
        ('LUNES', 'MARTES', 'MIERCOLES', 'JUEVES', 'VIERNES', 'SABADO', 'DOMINGO')),
    constraint ck_clase_duracion check (duracion_min > 0),
    constraint ck_clase_aforo check (aforo > 0),
    constraint ck_clase_plazas check (plazas_libres >= 0 and plazas_libres <= aforo)
);
```

Aparecen cuatro elementos nuevos:

- `time` es una hora del día sin fecha (`09:00`). En Java es `LocalTime`. `integer` es un entero normal, `int` en Java.
- `aforo` es el máximo de socios que caben en la clase y `plazas_libres` son las que quedan ahora mismo (el aforo menos las inscripciones). Las dos son necesarias: más adelante, al inscribir a un socio, se guardará la inscripción y se descontará una plaza.
- `constraint fk_clase_monitor foreign key (monitor_id) references monitor (id)` declara la clave foránea: `monitor_id` solo admite valores que existan en `monitor.id`. La palabra `constraint` seguida de un nombre pone nombre a la regla. Con nombre, el mensaje de error dice exactamente cuál se ha violado, y lo veremos al final de la demo.
- Los `check` son condiciones que toda fila tiene que cumplir para guardarse: el día tiene que ser uno de los siete de la lista, la duración y el aforo tienen que ser mayores que cero y las plazas libres no pueden ser negativas ni superar el aforo. Escribimos los días sin tilde (`MIERCOLES`) para que la lista no dependa de cómo se teclee.

#### La tabla socio

```sql
-- ============================================================
-- SOCIO: persona apuntada al gimnasio
-- ============================================================
create table socio (
    id          bigint generated by default as identity primary key,
    nombre      varchar(100) not null,
    email       varchar(150) not null unique,
    fecha_alta  date not null
);
```

No trae nada nuevo: es una tabla como `monitor`, con su clave primaria, un correo único y la fecha de alta.

#### La tabla inscripcion

```sql
-- ============================================================
-- INSCRIPCION: une a un socio con una clase
-- ============================================================
-- Un socio puede apuntarse a muchas clases y una clase tiene muchos socios.
-- Esa relación de muchos a muchos se guarda en una tabla intermedia con dos claves foráneas.
-- Además lleva un dato propio: la fecha en que el socio se inscribió.
create table inscripcion (
    id                 bigint generated by default as identity primary key,
    socio_id           bigint not null,
    clase_id           bigint not null,
    -- default current_date: si el INSERT no indica la fecha, se guarda la de hoy.
    fecha_inscripcion  date not null default current_date,

    constraint fk_inscripcion_socio foreign key (socio_id) references socio (id),
    constraint fk_inscripcion_clase foreign key (clase_id) references clase (id),

    -- unique sobre dos columnas: la pareja (socio, clase) no se puede repetir.
    -- Así un socio no se inscribe dos veces en la misma clase.
    constraint uq_inscripcion_socio_clase unique (socio_id, clase_id)
);
```

Es la tabla intermedia de la relación de muchos a muchos. Tiene dos claves foráneas y dos elementos nuevos:

- `default current_date` da un valor por defecto: si un `insert` no indica la fecha de inscripción, la base de datos guarda la fecha de hoy.
- `unique (socio_id, clase_id)` aplica `unique` a una pareja de columnas, no a cada una por separado. Un mismo socio puede aparecer muchas veces y una misma clase también, pero la pareja no se puede repetir. Es la restricción que impide que un socio se inscriba dos veces en la misma clase.

#### Los datos de ejemplo

Los `insert` van en orden: primero las tablas a las que otras apuntan (`monitor` y `socio`), después las que las referencian (`clase`) y por último `inscripcion`. Si insertáramos una clase antes que su monitor, la clave foránea rechazaría la fila. No escribimos los `id`: los genera la base de datos, y por eso las claves foráneas de los `insert` posteriores usan los valores 1, 2, 3... que se asignan en orden.

```sql
-- ============================================================
-- DATOS DE EJEMPLO
-- ============================================================
-- Primero las tablas a las que otras apuntan (monitor y socio),
-- después las que las referencian (clase) y por último inscripcion.

insert into monitor (nombre, email, especialidad, fecha_alta) values
    ('Laura Gómez', 'laura.gomez@gimnasio.test', 'Yoga',                    '2022-09-01'),  -- id 1
    ('Carlos Ruiz', 'carlos.ruiz@gimnasio.test', 'Spinning',                '2021-03-15'),  -- id 2
    ('Marta Sanz',  'marta.sanz@gimnasio.test',  'Entrenamiento funcional', '2023-01-09');  -- id 3

insert into socio (nombre, email, fecha_alta) values
    ('Ana Pérez',      'ana.perez@correo.test',      '2024-01-10'),  -- id 1
    ('Luis Martín',    'luis.martin@correo.test',    '2024-02-05'),  -- id 2
    ('Elena Torres',   'elena.torres@correo.test',   '2024-03-18'),  -- id 3
    ('Pablo Díaz',     'pablo.diaz@correo.test',     '2024-05-02'),  -- id 4
    ('Sofía Navarro',  'sofia.navarro@correo.test',  '2025-01-20'),  -- id 5
    ('Diego Castro',   'diego.castro@correo.test',   '2025-09-08');  -- id 6
```

```sql
-- Las columnas son: nombre, dia_semana, hora, duracion_min, aforo, plazas_libres, monitor_id.
-- plazas_libres ya descuenta las inscripciones que se cargan más abajo.
insert into clase (nombre, dia_semana, hora, duracion_min, aforo, plazas_libres, monitor_id) values
    ('Yoga matinal',      'LUNES',     '09:00', 60, 12, 10, 1),  -- id 1: 2 inscritos
    ('Spinning',          'MARTES',    '18:30', 45,  3,  0, 2),  -- id 2: 3 inscritos, clase llena
    ('Funcional',         'MIERCOLES', '19:00', 50, 15, 13, 3),  -- id 3: 2 inscritos
    ('Yoga vespertino',   'JUEVES',    '19:30', 60, 12, 12, 1),  -- id 4: sin inscritos
    ('Spinning avanzado', 'VIERNES',   '08:00', 45, 10,  9, 2);  -- id 5: 1 inscrito

-- Las columnas son: socio_id, clase_id, fecha_inscripcion.
insert into inscripcion (socio_id, clase_id, fecha_inscripcion) values
    (1, 1, '2025-09-15'),
    (2, 1, '2025-09-16'),
    (1, 2, '2025-09-15'),
    (3, 2, '2025-09-20'),
    (4, 2, '2025-09-22'),
    (2, 3, '2025-10-01'),
    (5, 3, '2025-10-02'),
    (6, 5, '2025-10-06');
```

Los datos están pensados para que las siguientes partes tengan algo con lo que trabajar: la clase de Spinning del martes está llena (aforo 3, tres inscritos, cero plazas libres) y la de Yoga vespertino no tiene ningún inscrito. Los `plazas_libres` ya descuentan las inscripciones cargadas.

### Ejecutar el script

Abrimos `sql/01-crear-gimnasio.sql` del zip con IntelliJ (o con el Bloc de notas), copiamos todo su contenido, lo pegamos en la Query Tool y pulsamos ▶ (o `F5`). Sin nada seleccionado, ejecuta el script entero.

Salida esperada:

<pre>
Query returned successfully in 90 msec.
</pre>

Aparece en la pestaña `Messages`, y el tiempo será distinto. Las sentencias `create table` e `insert` no devuelven filas, así que no hay tabla de resultados: ese mensaje es la confirmación de que todo se ha ejecutado. Si alguna sentencia fallara, pgAdmin mostraría el error en esa misma pestaña: habría que corregir el script y, si ya se hubiera creado alguna tabla, empezar de cero con el script de borrado que se explica al final de la demo.

Para ver las tablas, en el panel izquierdo desplegamos `gimnasio`, `Schemas`, `public` y `Tables` (si no aparecen, clic derecho sobre `Tables` y `Refresh`). Salen `clase`, `inscripcion`, `monitor` y `socio`. Para ver las filas de una, clic derecho sobre ella y `View/Edit Data` > `All Rows`.

### Comprobar con consultas

Vamos a comprobar el resultado con `select`. El script `sql/02-comprobar-gimnasio.sql` tiene cuatro consultas. Se ejecutan de una en una: seleccionamos el texto de la consulta y pulsamos ▶ (o `F5`). Una consulta `select` pide filas a una tabla. La primera pide todas las columnas (`*`) de `monitor`, ordenadas por `id`.

```sql
-- 1. Monitores cargados
select * from monitor order by id;
```

Salida esperada:

<pre>
 id |   nombre    |           email           |      especialidad       | fecha_alta
----+-------------+---------------------------+-------------------------+------------
  1 | Laura Gómez | laura.gomez@gimnasio.test | Yoga                    | 2022-09-01
  2 | Carlos Ruiz | carlos.ruiz@gimnasio.test | Spinning                | 2021-03-15
  3 | Marta Sanz  | marta.sanz@gimnasio.test  | Entrenamiento funcional | 2023-01-09
</pre>

La segunda consulta une dos tablas con `join`. Cada clase tiene en `monitor_id` el número de su monitor, y `join monitor m on m.id = c.monitor_id` busca esa fila de `monitor` y trae sus columnas. Es seguir la clave foránea hasta la otra tabla. Las letras `c` y `m` son apodos (alias) de las tablas para escribir menos.

```sql
-- 2. Cada clase con el nombre de su monitor.
-- El JOIN sigue la clave foránea clase.monitor_id hasta monitor.id.
select c.id, c.nombre as clase, c.dia_semana, c.hora, m.nombre as monitor
from clase c
join monitor m on m.id = c.monitor_id
order by c.id;
```

Salida esperada:

<pre>
 id |       clase       | dia_semana |   hora   |   monitor
----+-------------------+------------+----------+-------------
  1 | Yoga matinal      | LUNES      | 09:00:00 | Laura Gómez
  2 | Spinning          | MARTES     | 18:30:00 | Carlos Ruiz
  3 | Funcional         | MIERCOLES  | 19:00:00 | Marta Sanz
  4 | Yoga vespertino   | JUEVES     | 19:30:00 | Laura Gómez
  5 | Spinning avanzado | VIERNES    | 08:00:00 | Carlos Ruiz
</pre>

Esta consulta, escrita en SQL con un `join`, es la que Hibernate generará cuando en la siguiente parte pidamos a una clase el nombre de su monitor sin escribir ningún `join`.

La tercera cuenta cuántos inscritos tiene cada clase y los compara con las plazas libres. `count(i.id)` cuenta las inscripciones de cada grupo y `group by` define los grupos (uno por clase). Con `left join` aparecen también las clases sin ninguna inscripción, como Yoga vespertino. Con un `join` normal esa clase no saldría. El aforo menos los inscritos tiene que coincidir con `plazas_libres`.

```sql
-- 3. Inscritos de cada clase frente a sus plazas libres.
-- left join: aparecen también las clases sin ninguna inscripción.
-- aforo - plazas_libres tiene que coincidir con inscritos.
select c.id, c.nombre, c.aforo, c.plazas_libres, count(i.id) as inscritos
from clase c
left join inscripcion i on i.clase_id = c.id
group by c.id
order by c.id;
```

Salida esperada:

<pre>
 id |      nombre       | aforo | plazas_libres | inscritos
----+-------------------+-------+---------------+-----------
  1 | Yoga matinal      |    12 |            10 |         2
  2 | Spinning          |     3 |             0 |         3
  3 | Funcional         |    15 |            13 |         2
  4 | Yoga vespertino   |    12 |            12 |         0
  5 | Spinning avanzado |    10 |             9 |         1
</pre>

La cuarta consulta recorre dos claves foráneas a la vez: de `inscripcion` a `socio` y de `inscripcion` a `clase`, para listar los socios de la clase de Spinning.

```sql
-- 4. Socios inscritos en la clase de Spinning
select s.nombre as socio, i.fecha_inscripcion
from inscripcion i
join socio s on s.id = i.socio_id
join clase c on c.id = i.clase_id
where c.nombre = 'Spinning'
order by i.fecha_inscripcion;
```

Salida esperada:

<pre>
    socio     | fecha_inscripcion
--------------+-------------------
 Ana Pérez    | 2025-09-15
 Elena Torres | 2025-09-20
 Pablo Díaz   | 2025-09-22
</pre>

### Lo que la base de datos comprueba por su cuenta

Las claves foráneas y las restricciones no son documentación: la base de datos las hace cumplir. El script `sql/03-restricciones-que-fallan.sql` tiene cuatro sentencias que **deben fallar**. Se ejecutan también de una en una. Ninguna deja datos guardados.

La primera intenta crear una clase con el monitor 99, que no existe:

```sql
-- 1. Clave foránea: el monitor 99 no existe.
-- Error esperado: insert or update on table "clase" violates foreign key constraint "fk_clase_monitor"
insert into clase (nombre, dia_semana, hora, duracion_min, aforo, plazas_libres, monitor_id)
values ('Pilates', 'LUNES', '10:00', 50, 10, 10, 99);
```

Salida esperada (pgAdmin la muestra en la pestaña `Messages`, con alguna línea añadida como `SQL state: 23503`):

<pre>
ERROR:  insert or update on table "clase" violates foreign key constraint "fk_clase_monitor"
DETAIL:  Key (monitor_id)=(99) is not present in table "monitor".
</pre>

El mensaje nombra la restricción violada (`fk_clase_monitor`) y el valor que no existe. Por eso les pusimos nombre. La segunda intenta inscribir otra vez al socio 1 en la clase 1:

```sql
-- 2. Unique: el socio 1 ya está inscrito en la clase 1.
-- Error esperado: duplicate key value violates unique constraint "uq_inscripcion_socio_clase"
insert into inscripcion (socio_id, clase_id) values (1, 1);
```

Salida esperada:

<pre>
ERROR:  duplicate key value violates unique constraint "uq_inscripcion_socio_clase"
DETAIL:  Key (socio_id, clase_id)=(1, 1) already exists.
</pre>

La tercera intenta crear una clase con aforo cero y la cuarta una con un día que no está en la lista:

```sql
-- 3. Check: el aforo tiene que ser mayor que cero.
-- Error esperado: new row for relation "clase" violates check constraint "ck_clase_aforo"
insert into clase (nombre, dia_semana, hora, duracion_min, aforo, plazas_libres, monitor_id)
values ('Pilates', 'LUNES', '10:00', 50, 0, 0, 1);
```

Salida esperada:

<pre>
ERROR:  new row for relation "clase" violates check constraint "ck_clase_aforo"
DETAIL:  Failing row contains (7, Pilates, LUNES, 10:00:00, 50, 0, 0, 1).
</pre>

```sql
-- 4. Check: un día de la semana que no está en la lista.
-- Error esperado: new row for relation "clase" violates check constraint "ck_clase_dia"
insert into clase (nombre, dia_semana, hora, duracion_min, aforo, plazas_libres, monitor_id)
values ('Pilates', 'FESTIVO', '10:00', 50, 10, 10, 1);
```

Salida esperada:

<pre>
ERROR:  new row for relation "clase" violates check constraint "ck_clase_dia"
DETAIL:  Failing row contains (8, Pilates, FESTIVO, 10:00:00, 50, 10, 10, 1).
</pre>

Los números que aparecen en `Failing row contains (7, ...)` pueden ser otros en tu proyecto. Fijémonos en un detalle: la fila fallida llevaba el `id` 7 y 8, cuando solo hay cinco clases. La base de datos reservó un número del contador antes de comprobar las restricciones y **no lo devuelve** aunque la fila se rechace. Es un comportamiento normal de las columnas `identity`: los `id` pueden tener huecos. Si queremos que el siguiente `id` vuelva a ser el 6, repetimos la demo desde cero como se explica a continuación.

### Repetir la demo desde cero

El script `sql/00-borrar-gimnasio.sql` elimina las cuatro tablas con `drop table`, en el orden inverso al de creación (primero `inscripcion` y `clase`, que apuntan a otras; al final `socio` y `monitor`). Con `if exists` no falla si alguna no existe todavía.

```sql
-- S07 Demo 1: borrar las tablas del gimnasio para empezar de cero.
--
-- Úsalo solo si necesitas repetir la demo: elimina las cuatro tablas y todos sus datos.
-- El orden importa: primero las tablas que apuntan a otras (inscripcion y clase) y
-- al final las que reciben las claves foráneas (socio y monitor).
-- "if exists" evita el error si alguna tabla todavía no existe.

drop table if exists inscripcion;
drop table if exists clase;
drop table if exists socio;
drop table if exists monitor;
```

Es una operación destructiva: borra las tablas y todos sus datos. Por eso pgAdmin puede pedir confirmación antes de ejecutarla. Después de ejecutarlo, volvemos a ejecutar `sql/01-crear-gimnasio.sql`: las tablas nacen otra vez y los `id` empiezan de nuevo en 1.

Con las cuatro tablas creadas y con datos, la base de datos está lista. Las demos siguientes la conectan a una aplicación.

---

## Demo 2: Conexión a PostgreSQL desde Spring Boot

### Qué hace falta para conectar

Para que un programa hable con la base de datos hacen falta tres datos: **dónde está** (la dirección), **quién es** (el usuario) y **qué contraseña tiene**. Spring Boot los lee de `application.properties` y construye por sí mismo el objeto que abre las conexiones. Es el mismo mecanismo que ya vimos con H2 en S06: cambia solo el valor de la dirección.

La dirección es una **URL JDBC**. JDBC (*Java Database Connectivity*) es el estándar de Java para hablar con bases de datos, y la URL se lee separada por dos puntos, igual que la de H2 (`jdbc:h2:mem:libreria`):

| Parte | En H2 (S06) | En PostgreSQL |
|---|---|---|
| Protocolo | `jdbc` | `jdbc` |
| Base de datos | `h2` | `postgresql` |
| Dónde está | `mem:libreria` (en memoria) | `//localhost:5432/gimnasio` (el servidor, su puerto y el nombre de la base de datos) |

`localhost` significa «este mismo ordenador»: el servidor de PostgreSQL está instalado en la misma máquina que la aplicación. `5432` es el puerto por el que escucha el servidor, el que dejamos por defecto al instalar. `gimnasio` es la base de datos que creamos en la Demo 1 con pgAdmin.

Para que Java sepa hablar con PostgreSQL hace falta el **controlador** (*driver*) de PostgreSQL: una librería que conoce el protocolo del servidor. Sin él, Java no sabría qué decirle. Se añade como dependencia (`org.postgresql:postgresql`) con scope `runtime`, el mismo que tenía H2 en S06: solo hace falta al ejecutar, no al compilar.

El usuario es `postgres`, el superusuario que creó el instalador, y la contraseña es la que escribimos al instalar.

Con el starter de JDBC, Spring Boot crea un **`DataSource`**: el objeto estándar de Java que sabe abrir conexiones con una base de datos, con las tres propiedades que le damos. Cuando pedimos una conexión (`Connection`), el `DataSource` la abre y nos la entrega. Una `Connection` es la línea abierta con la base de datos y hay que cerrarla al terminar. Por debajo, Spring Boot usa HikariCP, el conjunto de conexiones abiertas que ya mencionamos en S06.

En esta demo usamos solo el starter de JDBC, sin JPA todavía. Es una decisión deliberada: con JPA, Hibernate abre la conexión al arrancar, así que un fallo de conexión pararía toda la aplicación antes de que nuestra clase pueda explicarlo. Con JDBC solo, la aplicación arranca y nuestra clase intenta conectar y cuenta qué ha pasado. En la Demo 3 añadimos JPA y vemos la diferencia.

### La contraseña no se escribe en ningún fichero

`application.properties` se guarda con el proyecto: se versiona, se comparte, viaja en un zip. Una contraseña escrita ahí acaba en manos de quien no debe. Por eso la contraseña nunca se escribe en el código, ni en `application.properties`, ni en los documentos.

Se entrega al programa de otra forma: con una **variable de entorno**. Una variable de entorno es un valor con nombre que el sistema operativo pone a disposición de un programa cuando arranca. Es como entregar la contraseña en un sobre cerrado al abrir el programa, en lugar de escribirla en la carta que cualquiera puede leer. En `application.properties` solo escribimos la referencia: `${POSTGRES_PASSWORD}`, que significa «el valor de la variable `POSTGRES_PASSWORD`». Spring Boot hace la sustitución al arrancar.

### Crear el proyecto

Creamos un proyecto nuevo con el generador de Spring Boot de IntelliJ.

1. Vamos a `File > New > Project`. En el panel izquierdo, dentro de `Generators`, seleccionamos `Spring Boot`.
2. Rellenamos los campos:
   - **Name**: `s07-demos`.
   - **Location**: la carpeta donde guardamos los proyectos del curso.
   - **Type**: `Maven`. Puede venir seleccionado `Gradle - Groovy`: lo cambiamos.
   - **Language**: `Java`.
   - **Group**: `com.curso`.
   - **Artifact**: `s07-demos`.
   - **Package name**: `com.curso`. IntelliJ recalcula este campo cada vez que cambiamos Group o Artifact, así que lo rellenamos el último.
   - **JDK** y **Java**: `21`. Java puede venir en `17`: lo cambiamos.
   - **Packaging**: `Jar`. **Configuration**: `Properties`.
3. Hacemos clic en `Next`. IntelliJ se conecta a start.spring.io, por lo que necesita Internet.
4. En la segunda pantalla elegimos la versión de Spring Boot `4.1.1` y marcamos dos dependencias, que buscamos por su nombre: `JDBC API` y `PostgreSQL Driver`.
5. Hacemos clic en `Create`.
6. Si aparece el aviso `Maven build scripts found`, pulsamos `Load` para que IntelliJ lea el `pom.xml` y descargue las librerías.

Abrimos el `pom.xml` y miramos las tres dependencias que ha generado:

<pre>
    &amp;lt;dependencies&amp;gt;
        &amp;lt;dependency&amp;gt;
            &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
            &amp;lt;artifactId&amp;gt;spring-boot-starter-jdbc&amp;lt;/artifactId&amp;gt;
        &amp;lt;/dependency&amp;gt;

        &amp;lt;dependency&amp;gt;
            &amp;lt;groupId&amp;gt;org.postgresql&amp;lt;/groupId&amp;gt;
            &amp;lt;artifactId&amp;gt;postgresql&amp;lt;/artifactId&amp;gt;
            &amp;lt;scope&amp;gt;runtime&amp;lt;/scope&amp;gt;
        &amp;lt;/dependency&amp;gt;
        &amp;lt;dependency&amp;gt;
            &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
            &amp;lt;artifactId&amp;gt;spring-boot-starter-jdbc-test&amp;lt;/artifactId&amp;gt;
            &amp;lt;scope&amp;gt;test&amp;lt;/scope&amp;gt;
        &amp;lt;/dependency&amp;gt;
    &amp;lt;/dependencies&amp;gt;
</pre>

- `spring-boot-starter-jdbc` es el starter de JDBC: trae el `DataSource`, HikariCP y lo necesario para que Spring Boot configure la conexión.
- `postgresql` es el controlador de PostgreSQL, con scope `runtime`.
- La última dependencia, con scope `test`, es la librería de pruebas que el generador añade junto al starter. La usa el test que genera el proyecto.

Ninguna lleva `<version>`: la versión la fija `spring-boot-starter-parent`, igual que en S05-1 y S06-1.

### La clase de arranque

El generador crea la clase de arranque con un nombre derivado del artefacto, `S07DemosApplication`. La renombramos como hicimos en S06: clic derecho sobre el nombre de la clase, `Refactor > Rename` (o `Shift+F6`), escribimos `Aplicacion` y pulsamos Enter. Después sustituimos su contenido por esta versión, que solo añade comentarios al código generado:

```java
package com.curso;

// Importamos SpringApplication y @SpringBootApplication de Spring Boot.
// Maven los ha descargado con spring-boot-starter-data-jpa, que a su vez trae el starter base de Spring Boot.
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * S07 Demo 2: Aplicación Spring Boot conectada a PostgreSQL
 *
 * Objetivo: arrancar una aplicación Spring Boot cuyo origen de datos es una base de datos
 * PostgreSQL en la nube, en lugar de la base de datos H2 en memoria de S06.
 *
 * Lo que hace este ejemplo:
 *   - Es la clase de arranque que genera el generador de Spring Boot de IntelliJ (renombrada a Aplicacion)
 *   - Spring Boot lee application.properties, crea el origen de datos y ejecuta los CommandLineRunner
 *
 * Concepto clave: la clase de arranque es la misma que en S06. Lo único que cambia al pasar de H2
 * a PostgreSQL local es la configuración de application.properties: la dirección, el usuario y la contraseña.
 */
// @SpringBootApplication marca la clase de arranque y activa el escaneo del paquete com.curso
// y de sus subpaquetes (model, repository, config), igual que en S05 y S06.
@SpringBootApplication
public class Aplicacion {

    // main() es el punto de entrada del programa.
    // SpringApplication.run() crea el contenedor de Spring, lo arranca y crea los beans.
    // Antes de crear ninguno, Spring Boot lee application.properties y sustituye ${POSTGRES_PASSWORD}
    // por el valor de la variable de entorno. Si la variable no existe, Spring Boot no avisa:
    // usa el texto "${POSTGRES_PASSWORD}" como contraseña y es PostgreSQL quien rechaza la conexión.
    public static void main(String[] args) {
        SpringApplication.run(Aplicacion.class, args);
    }
}
```

### application.properties

Abrimos `src/main/resources/application.properties`. El generador ha dejado una sola línea, `spring.application.name`. Escribimos el contenido siguiente:

```properties
# Nombre de la aplicación: aparece entre corchetes en cada línea del log.
spring.application.name=s07-demos

# Conexión a PostgreSQL, instalado en este mismo ordenador.

# Dirección de la base de datos: protocolo jdbc, base de datos postgresql,
# servidor localhost (este ordenador), puerto 5432 y nombre de la base de datos (gimnasio).
spring.datasource.url=jdbc:postgresql://localhost:5432/gimnasio

# Usuario: postgres es el administrador que crea el instalador de PostgreSQL.
spring.datasource.username=postgres

# La contraseña NO se escribe aquí: este fichero se versiona con el proyecto.
# ${POSTGRES_PASSWORD} le dice a Spring que la lea de la variable de entorno POSTGRES_PASSWORD.
spring.datasource.password=${POSTGRES_PASSWORD}
```

Cada propiedad hace una cosa:

- `spring.application.name` es el nombre de la aplicación, el que aparece entre corchetes en cada línea del log.
- `spring.datasource.url` es la dirección JDBC: servidor `localhost`, puerto `5432` y la base de datos `gimnasio`. Si al instalar PostgreSQL cambiamos el puerto, aquí va el que elegimos.
- `spring.datasource.username` es el usuario, `postgres`.
- `spring.datasource.password` solo contiene `${POSTGRES_PASSWORD}`, la referencia a la variable de entorno. La contraseña no aparece.

Al final de la Demo 3 el fichero tendrá dos propiedades más; el zip lleva ese estado final.

### La clase ComprobarConexion

Creamos el paquete `com.curso.config`: clic derecho sobre `com.curso` en `src/main/java`, `New > Package`, escribimos `com.curso.config` y pulsamos Enter. Sobre ese paquete, clic derecho y `New > Java Class`: escribimos `ComprobarConexion` y pulsamos Enter.

```java
package com.curso.config;

// Importamos DataSource de Java (paquete javax.sql). Es la interfaz estándar de un origen de datos:
// sabe abrir conexiones con una base de datos. Viene con el propio JDK, no hace falta ninguna librería.
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.DatabaseMetaData;

// Importamos CommandLineRunner de Spring Boot: su método run() se ejecuta al terminar el arranque.
// Maven ha descargado Spring Boot con el starter; sin él habría que arrancar y conectar todo a mano.
import org.springframework.boot.CommandLineRunner;

// Importamos @Order de Spring: fija en qué orden se ejecutan varios CommandLineRunner.
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * S07 Demo 2: Comprobación de la conexión con PostgreSQL
 *
 * Objetivo: pedir una conexión a la base de datos y escribir por consola si ha tenido éxito
 * o cuál ha sido el motivo del fallo.
 *
 * Lo que hace este ejemplo:
 *   - Recibe por constructor el DataSource que Spring Boot crea a partir de application.properties
 *   - Abre una conexión y escribe datos de la base de datos a la que se ha conectado
 *   - Si no puede conectar, captura el error y escribe su motivo
 *
 * Concepto clave: Spring Boot construye el origen de datos a partir de tres propiedades
 * (dirección, usuario y contraseña). Comprobar la conexión con una clase mínima, antes de
 * añadir entidades, permite descartar los problemas de conexión del resto.
 */
// @Component: Spring crea un bean de esta clase al escanear el paquete.
// @Order(1): si hay varios CommandLineRunner, los ejecuta de menor a mayor número.
// Ahora solo hay uno; en la Demo 3 habrá dos y este debe ir primero.
@Component
@Order(1)
public class ComprobarConexion implements CommandLineRunner {

    // DataSource es el origen de datos: el objeto que sabe abrir conexiones con la base de datos.
    // Spring Boot lo ha creado por nosotros con la dirección, el usuario y la contraseña
    // de application.properties (autoconfiguración).
    private final DataSource dataSource;

    // Inyección por constructor (S06): Spring busca en el contenedor un bean de tipo DataSource
    // y se lo entrega a esta clase al crearla.
    public ComprobarConexion(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    // run() se ejecuta una vez, cuando el contenedor ya está arrancado y todos los beans están listos.
    @Override
    public void run(String... args) {
        System.out.println("Comprobando la conexión con PostgreSQL...");

        // try-with-resources (S04-1): la Connection se cierra sola al salir del bloque,
        // tanto si todo va bien como si hay una excepción.
        // getConnection() es el momento en que se intenta de verdad llegar al servidor.
        try (Connection conexion = dataSource.getConnection()) {

            // DatabaseMetaData describe la base de datos a la que estamos conectados:
            // producto, versión, usuario... Es una forma de comprobar que la conexión funciona de verdad.
            DatabaseMetaData info = conexion.getMetaData();

            System.out.println("CONEXIÓN CORRECTA");
            System.out.println("  Base de datos: " + info.getDatabaseProductName()
                    + " " + info.getDatabaseProductVersion());   // → PostgreSQL 17.x (la versión que hayas instalado)
            System.out.println("  Usuario:       " + info.getUserName());  // → postgres

        } catch (Exception e) {
            // Si algo falla (dirección mal escrita, contraseña incorrecta, red que no llega al servidor),
            // getConnection() lanza una excepción. La capturamos para escribir el motivo
            // en lugar de dejar que el programa termine con un error largo.
            System.out.println("NO SE HA PODIDO CONECTAR");
            System.out.println("  Motivo: " + e.getMessage());
        }
    }
}
```

Recorremos lo que hace la clase:

- Es un `CommandLineRunner`, como `CargaDatos` en S06: su método `run()` se ejecuta una vez, cuando el contenedor ya está arrancado. Lleva `@Component` para que Spring la encuentre al escanear el paquete.
- `@Order(1)` fija el orden cuando hay varios `CommandLineRunner`: Spring los ejecuta de menor a mayor número. Ahora solo hay uno, pero en la Demo 3 habrá dos y este tiene que ir primero. Sin `@Order`, el orden no está garantizado.
- Recibe el `DataSource` por constructor (inyección por constructor, S06): Spring busca en el contenedor un bean de ese tipo y lo entrega. Lo ha creado Spring Boot a partir de `application.properties`.
- `try (Connection conexion = ...)` es un try-with-resources (S04-1): la conexión se cierra sola al salir del bloque. `getConnection()` es el momento en que se intenta llegar al servidor de verdad. Hasta esa línea no se ha conectado nada.
- `DatabaseMetaData` es la descripción de la base de datos a la que estamos conectados (producto, versión, usuario). Escribirla demuestra que la conexión funciona de verdad.
- El `catch (Exception e)` captura cualquier fallo de conexión y escribe su motivo con `e.getMessage()`, en lugar de dejar que el programa termine con un error largo.

### Primera ejecución, sin la variable

Hacemos clic en ▶ junto al `main()` de `Aplicacion`. Todavía no hemos definido la variable `POSTGRES_PASSWORD`, así que esta primera ejecución va a fallar, y nos sirve para aprender a leer el fallo.

IntelliJ crea de forma automática una **configuración de ejecución** llamada `Aplicacion` y la deja seleccionada arriba a la derecha. Una configuración de ejecución es la ficha que le dice a IntelliJ cómo ejecutar algo: qué clase, con qué JDK, con qué variables de entorno. Es ahí donde definiremos la variable.

Salida (solo las líneas relevantes del log):

<pre>
2026-10-12T20:34:06.803+02:00  INFO 26340 --- [s07-demos] [           main] com.curso.Aplicacion                     : Started Aplicacion in 0.673 seconds (process running for 0.915)
Comprobando la conexión con PostgreSQL...
2026-10-12T20:34:06.805+02:00  INFO 26340 --- [s07-demos] [           main] com.zaxxer.hikari.HikariDataSource       : HikariPool-1 - Starting...
NO SE HA PODIDO CONECTAR
  Motivo: FATAL: password authentication failed for user "postgres"
</pre>

El texto exacto del mensaje puede variar un poco, porque lo escribe el servidor de PostgreSQL. Leemos el resultado línea a línea:

1. `Started Aplicacion` aparece: Spring Boot ha arrancado bien. El fallo no es de la aplicación.
2. `HikariPool-1 - Starting...`: el conjunto de conexiones arranca cuando pedimos la primera conexión, no antes. Por eso aparece justo después de nuestro mensaje.
3. Las dos líneas siguientes son las nuestras. `FATAL` es un mensaje del servidor de la base de datos, no de Java: significa que **el servidor ha recibido nuestro intento y lo ha rechazado**. Con `password authentication failed`, la dirección y el puerto son correctos; lo que falla son las credenciales.

Spring Boot no ha avisado de que falta la variable de entorno. Cuando no encuentra `POSTGRES_PASSWORD`, usa el texto literal `${POSTGRES_PASSWORD}` como contraseña, y es el servidor quien lo rechaza. El síntoma de que falta la variable no es un error de configuración: es un error de autenticación.

### Definir la variable en IntelliJ

Definimos la variable una vez en la configuración de ejecución. Todos los ▶ posteriores la usarán.

1. Arriba a la derecha, abrimos el desplegable que muestra `Aplicacion` y elegimos `Edit Configurations…`.
2. En la lista de la izquierda seleccionamos `Aplicacion`.
3. En el panel de la derecha buscamos el campo `Environment variables`. Si no se ve, hacemos clic en `Modify options` (enlace azul) y marcamos `Environment variables`: aparece una fila nueva con ese nombre.
4. En el campo escribimos `POSTGRES_PASSWORD=` seguido de la contraseña de `postgres` que elegimos al instalar PostgreSQL, sin espacios ni comillas. Si la contraseña contiene un punto y coma, usamos el icono que hay a la derecha del campo, que abre un cuadro con una fila por variable.
5. Pulsamos `Apply` y `OK`.
6. Volvemos a hacer clic en ▶.

Salida:

<pre>
Comprobando la conexión con PostgreSQL...
2026-10-12T20:36:21.187+02:00  INFO 29304 --- [s07-demos] [           main] com.zaxxer.hikari.HikariDataSource       : HikariPool-1 - Starting...
2026-10-12T20:36:21.778+02:00  INFO 29304 --- [s07-demos] [           main] com.zaxxer.hikari.pool.HikariPool        : HikariPool-1 - Added connection org.postgresql.jdbc.PgConnection@64fe9da7
2026-10-12T20:36:21.779+02:00  INFO 29304 --- [s07-demos] [           main] com.zaxxer.hikari.HikariDataSource       : HikariPool-1 - Start completed.
CONEXIÓN CORRECTA
  Base de datos: PostgreSQL 17.x
  Usuario:       postgres
</pre>

Las líneas de Hikari indican que el conjunto de conexiones ha abierto una conexión real con PostgreSQL. Después, nuestra clase escribe el producto, la versión del servidor y el usuario con el que nos hemos conectado. La versión exacta es la que hayamos instalado.

### Provocar tres fallos más

Conviene ver cómo se leen los otros fallos de conexión más frecuentes. En todos los casos volvemos a dejar todo correcto al terminar.

**Contraseña incorrecta.** Cambiamos el valor de la variable en `Edit Configurations…` (por ejemplo, a `POSTGRES_PASSWORD=incorrecta`) y pulsamos ▶. El resultado es el mismo mensaje que cuando faltaba la variable:

<pre>
NO SE HA PODIDO CONECTAR
  Motivo: FATAL: password authentication failed for user "postgres"
</pre>

Falta de variable y contraseña incorrecta producen exactamente el mismo mensaje. Ante un `password authentication failed`, revisamos tres cosas en este orden: que el nombre de la variable esté escrito exactamente `POSTGRES_PASSWORD`, que la configuración de ejecución sea la que estamos usando, y que el valor sea la contraseña correcta. Restauramos la contraseña correcta.

**Base de datos que no existe.** En `application.properties` cambiamos `gimnasio` por `gimnasi` y pulsamos ▶:

<pre>
Comprobando la conexión con PostgreSQL...
NO SE HA PODIDO CONECTAR
  Motivo: FATAL: database "gimnasi" does not exist
</pre>

También es un `FATAL`, así que el servidor ha respondido: sabemos que la contraseña y el puerto son correctos. Lo que falla es el nombre. Se comprueba en pgAdmin, en `Databases`. Restauramos `gimnasio`.

**Servidor parado o puerto equivocado.** Cambiamos el puerto de la URL, `5432`, por `5999` y pulsamos ▶:

<pre>
Comprobando la conexión con PostgreSQL...
NO SE HA PODIDO CONECTAR
  Motivo: Connection to localhost:5999 refused. Check that the hostname and port are correct and that the postmaster is accepting TCP/IP connections.
</pre>

Este mensaje no empieza por `FATAL`: la petición no ha llegado a ningún servidor, porque en ese puerto no hay nadie escuchando. El mismo mensaje sale si el servidor de PostgreSQL está parado. En ese caso se comprueba en `Servicios` de Windows (el servicio `postgresql-x64-<versión>`) y se inicia. Restauramos el puerto `5432`.

### Cuatro salvedades de la variable de entorno

La variable que acabamos de definir tiene cuatro limitaciones que sorprenden la primera vez. Cada una tiene su síntoma y su solución.

**1. Desde la terminal, la variable de IntelliJ no existe.**

La variable vive en la configuración de ejecución de IntelliJ. Si arrancamos la aplicación desde una terminal con `mvn spring-boot:run` o con `java -jar`, no pasa por esa configuración.

- Síntoma: el mismo `NO SE HA PODIDO CONECTAR` con `password authentication failed`, aunque en IntelliJ funcione.
- Solución: definir la variable en la propia terminal antes de arrancar. En PowerShell:

```powershell
$env:POSTGRES_PASSWORD="la-contraseña-de-postgres"
mvn spring-boot:run
```

o, con el JAR ya construido con `mvn package`:

```powershell
$env:POSTGRES_PASSWORD="la-contraseña-de-postgres"
java -jar target/s07-demos-0.0.1-SNAPSHOT.jar
```

La variable definida con `$env:` solo vale para esa ventana de PowerShell y desaparece al cerrarla. Hay que repetirla en cada ventana nueva. Aquí la contraseña sí aparece en un comando, pero es lo que se teclea en nuestra terminal: no se guarda en ningún fichero del proyecto.

**2. El ▶ de `@Test` usa otra configuración.**

El ▶ que aparece junto a un método `@Test` no usa la configuración `Aplicacion` que editamos, sino una configuración de tipo `JUnit` que IntelliJ crea la primera vez que lo pulsamos.

- Síntoma: la aplicación arranca bien con ▶ en `main()`, pero el test falla. Con JPA (Demo 3), el fallo es `Failed to load ApplicationContext`, y en su causa aparece `password authentication failed`. Con solo JDBC, como ahora, el test pasa aunque la conexión falle, porque `ComprobarConexion` captura el error: la señal está en la consola, no en el resultado del test.
- Solución: abrir `Edit Configurations…`, seleccionar la configuración del test (se llama como la clase o el método, por ejemplo `S07DemosApplicationTests.contextLoads`) y añadir `POSTGRES_PASSWORD` en `Environment variables`, igual que antes. Para que todos los tests futuros la lleven ya incluida, se puede añadir una sola vez en `Edit Configurations… > Edit configuration templates… > JUnit`.

**3. La variable es propia de cada proyecto.**

Se guarda dentro de la configuración de ejecución de un proyecto concreto, no del ordenador ni de IntelliJ.

- Síntoma: abrimos otro proyecto que también se conecta a PostgreSQL (la Práctica 2, por ejemplo) y falla con `password authentication failed`, pese a que ya habíamos definido la variable en otro proyecto.
- Solución: repetir el paso «Definir la variable en IntelliJ» en cada proyecto que se conecte a PostgreSQL, y también en su configuración de test.

**4. La variable no viaja con el código ni con el zip.**

Como la contraseña no está en ningún fichero del proyecto, tampoco está en el zip. La configuración de ejecución se guarda en la carpeta `.idea/`, que no incluimos en los zips del curso.

- Síntoma: quien recibe el proyecto lo abre, ejecuta y obtiene `password authentication failed`.
- Solución: quien recibe el proyecto define `POSTGRES_PASSWORD` en su IntelliJ con la contraseña del `postgres` de su propio ordenador (que puede ser distinta de la tuya). Es el comportamiento buscado: la contraseña nunca sale del ordenador de su dueño.

---

## Demo 3: Entidad Monitor sobre una tabla existente

Hasta ahora hemos hablado con la base de datos mediante JDBC puro. En esta demo volvemos a lo que conocemos de S06: una entidad, un repositorio y un `CommandLineRunner`. La diferencia con S06 es que Hibernate no crea la tabla, porque ya existe en PostgreSQL desde la Demo 1.

### Pasar de JDBC a JPA

Abrimos el `pom.xml` y cambiamos dos dependencias:

- `spring-boot-starter-jdbc` pasa a `spring-boot-starter-data-jpa`.
- `spring-boot-starter-jdbc-test` pasa a `spring-boot-starter-data-jpa-test`.

Es decir, quitamos el starter de JDBC y ponemos el de Spring Data JPA, que ya incluye JDBC, HikariCP y además Hibernate y los repositorios. La sección de dependencias queda así:

<pre>
    &amp;lt;dependencies&amp;gt;
        &amp;lt;dependency&amp;gt;
            &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
            &amp;lt;artifactId&amp;gt;spring-boot-starter-data-jpa&amp;lt;/artifactId&amp;gt;
        &amp;lt;/dependency&amp;gt;

        &amp;lt;dependency&amp;gt;
            &amp;lt;groupId&amp;gt;org.postgresql&amp;lt;/groupId&amp;gt;
            &amp;lt;artifactId&amp;gt;postgresql&amp;lt;/artifactId&amp;gt;
            &amp;lt;scope&amp;gt;runtime&amp;lt;/scope&amp;gt;
        &amp;lt;/dependency&amp;gt;
        &amp;lt;dependency&amp;gt;
            &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
            &amp;lt;artifactId&amp;gt;spring-boot-starter-data-jpa-test&amp;lt;/artifactId&amp;gt;
            &amp;lt;scope&amp;gt;test&amp;lt;/scope&amp;gt;
        &amp;lt;/dependency&amp;gt;
    &amp;lt;/dependencies&amp;gt;
</pre>

IntelliJ detecta el cambio y muestra en la esquina superior derecha del editor un icono con una `m` (Maven). Lo pulsamos (`Load Maven Changes`) o usamos `Ctrl+Shift+O`: IntelliJ descarga Hibernate y las demás librerías nuevas.

### La entidad Monitor

Creamos el paquete `com.curso.model` (clic derecho sobre `com.curso`, `New > Package`) y dentro la clase `Monitor`:

```java
package com.curso.model;

// Importamos LocalDate de Java: representa una fecha sin hora (2022-09-01).
// Viene con el propio JDK. Hibernate la guarda en una columna de tipo date.
import java.time.LocalDate;

// Importamos las anotaciones de JPA que ya conocemos de S06.
// Proceden de jakarta.persistence-api, que Maven ha descargado de forma transitiva
// con spring-boot-starter-data-jpa.
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

/**
 * S07 Demo 3: Entidad Monitor sobre una tabla existente
 *
 * Objetivo: mapear una clase Java a la tabla monitor que creamos con SQL en la Demo 1.
 *
 * Lo que hace este ejemplo:
 *   - Declara Monitor como entidad, con las mismas anotaciones que Libro en S06
 *   - Tiene un campo por cada columna de la tabla monitor
 *   - fechaAlta se corresponde con la columna fecha_alta sin ninguna configuración adicional
 *
 * Concepto clave: el esquema lo diseña el SQL y la entidad solo lo refleja. Hibernate no crea
 * la tabla: busca una tabla que ya existe y une cada campo con la columna que le corresponde.
 */
// @Entity: Hibernate gestiona esta clase. Sin más anotaciones, la tabla se llama como la clase
// ("monitor") y cada columna como su campo. La tabla monitor ya existe en PostgreSQL.
@Entity
public class Monitor {

    // Clave primaria generada por la base de datos (columna id con "generated by default as identity").
    // Con IDENTITY, Hibernate no escribe el id al insertar: lo genera Postgres.
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Cada campo se une con la columna que tiene su mismo nombre: nombre, email y especialidad.
    private String nombre;
    private String email;
    private String especialidad;

    // En Java los campos se escriben en camelCase (fechaAlta) y en SQL los nombres usan guiones bajos
    // (fecha_alta). Spring Boot configura Hibernate para traducir uno al otro de forma automática:
    // cada letra mayúscula pasa a minúscula con un guion bajo delante. No hace falta @Column.
    private LocalDate fechaAlta;

    // Constructor sin argumentos: Hibernate lo necesita para crear un objeto vacío
    // y rellenarlo con los datos de cada fila que lee.
    public Monitor() {
    }

    // Un getter por campo, como en Libro (S06).
    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEmail() {
        return email;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public LocalDate getFechaAlta() {
        return fechaAlta;
    }

    // toString() devuelve el texto con el que se imprime el objeto.
    @Override
    public String toString() {
        return "Monitor{id=" + id + ", nombre='" + nombre + "', email='" + email
                + "', especialidad='" + especialidad + "', fechaAlta=" + fechaAlta + "}";
    }
}
```

Es la misma estructura que `Libro` en S06, con tres diferencias que conviene fijar:

- **La tabla ya existe.** `@Entity` no crea nada: Hibernate busca una tabla llamada `monitor` y une cada campo con una columna del mismo nombre. Si la tabla o una columna no existen, el error aparece al consultar (lo provocamos más adelante).
- **`fechaAlta` y `fecha_alta`.** Java escribe los nombres en camelCase y SQL con guiones bajos. Spring Boot configura Hibernate para traducir uno al otro: `fechaAlta` se une con `fecha_alta` sin ninguna anotación adicional.
- **Tipo `LocalDate`.** Representa una fecha sin hora y se une con una columna `date`. Es el tipo equivalente al que usamos en el SQL.

Una entidad no está obligada a mapear todas las columnas de su tabla. Más adelante, en las prácticas, `Pelicula` dejará fuera la columna `director_id`; la incorporaremos en S08-1.

### El repositorio

Creamos el paquete `com.curso.repository` y dentro, con `New > Java Class`, elegimos `Interface` y escribimos `MonitorRepository`:

```java
package com.curso.repository;

import com.curso.model.Monitor;

// Importamos JpaRepository de Spring Data JPA, igual que en S06.
// Maven la ha descargado de forma transitiva con spring-boot-starter-data-jpa.
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * S07 Demo 3: Repositorio de monitores con Spring Data JPA
 *
 * Objetivo: obtener las operaciones de acceso a la tabla monitor sin escribir su implementación.
 *
 * Lo que hace este ejemplo:
 *   - Declara una interfaz vacía que extiende JpaRepository
 *   - Indica con qué entidad trabaja (Monitor) y de qué tipo es su clave primaria (Long)
 *
 * Concepto clave: el repositorio funciona igual con H2 que con PostgreSQL. Spring Data JPA genera
 * el SQL para el dialecto de la base de datos que detecta; el código Java no cambia.
 */
// JpaRepository<Monitor, Long>: la entidad que gestiona y el tipo de su clave primaria.
// Heredamos save(), findAll(), findById(), count() y deleteById() sin escribir nada.
public interface MonitorRepository extends JpaRepository<Monitor, Long> {
}
```

Igual que en S06, con extender `JpaRepository` obtenemos `count()`, `findAll()`, `save()` y las demás operaciones sin escribir ninguna implementación.

### Propiedades de JPA

Añadimos al final de `application.properties` las dos propiedades nuevas:

```properties
# las cree, las modifique ni las borre.
spring.jpa.hibernate.ddl-auto=none

# Escribe en la consola cada sentencia SQL que genera Hibernate.
spring.jpa.show-sql=true
```

- `spring.jpa.hibernate.ddl-auto=none` le dice a Hibernate que no toque el esquema. En S06 usábamos `create-drop` para que construyera las tablas al arrancar y las borrara al terminar, pero con una base de datos real y compartida eso sería peligroso: el SQL es quien manda sobre el esquema.
- `spring.jpa.show-sql=true` escribe en la consola cada sentencia SQL que genera Hibernate, para ver qué hay detrás de cada llamada.

### El listado de monitores

En `com.curso.config` creamos la clase `ListarMonitores`:

```java
package com.curso.config;

import com.curso.model.Monitor;
import com.curso.repository.MonitorRepository;

// Importamos CommandLineRunner, @Order y @Component, ya vistos en ComprobarConexion y en S06.
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * S07 Demo 3: Listado de los monitores guardados en PostgreSQL
 *
 * Objetivo: leer con la entidad Monitor las filas que insertó el script SQL de la Demo 1.
 *
 * Lo que hace este ejemplo:
 *   - Cuenta los monitores de la tabla con count()
 *   - Los recorre con findAll() y escribe cada uno por consola
 *
 * Concepto clave: la entidad no ha creado ninguna fila ni ninguna tabla. Lee datos que existían
 * antes de arrancar la aplicación: ese es el ciclo completo entre el esquema SQL y el mapeo Java.
 */
// @Order(2): se ejecuta después de ComprobarConexion, que tiene @Order(1).
@Component
@Order(2)
public class ListarMonitores implements CommandLineRunner {

    // Inyección por constructor del repositorio, como en CargaDatos de S06.
    private final MonitorRepository monitorRepository;

    public ListarMonitores(MonitorRepository monitorRepository) {
        this.monitorRepository = monitorRepository;
    }

    @Override
    public void run(String... args) {
        // count() ejecuta "select count(*) from monitor" y devuelve cuántas filas hay.
        System.out.println("Monitores en la base de datos: " + monitorRepository.count());  // → 3

        // findAll() ejecuta "select ... from monitor" y devuelve una lista de objetos Monitor,
        // uno por fila. Hibernate crea cada objeto con el constructor vacío y rellena sus campos.
        // Con el for-each de S06 escribimos cada monitor; println() llama a su toString().
        for (Monitor monitor : monitorRepository.findAll()) {
            System.out.println(monitor);
        }
    }
}
```

Tiene `@Order(2)`, así que se ejecuta después de `ComprobarConexion`. Primero vemos la comprobación de la conexión y luego el listado.

### Ejecución

Pulsamos ▶ en `main()`. Salida esperada (omitimos las líneas de log de Hibernate y de Hikari):

<pre>
Comprobando la conexión con PostgreSQL...
CONEXIÓN CORRECTA
  Base de datos: PostgreSQL 17.x
  Usuario:       postgres
Hibernate: select count(*) from monitor m1_0
Monitores en la base de datos: 3
Hibernate: select m1_0.id,m1_0.email,m1_0.especialidad,m1_0.fecha_alta,m1_0.nombre from monitor m1_0
Monitor{id=1, nombre='Laura Gómez', email='laura.gomez@gimnasio.test', especialidad='Yoga', fechaAlta=2022-09-01}
Monitor{id=2, nombre='Carlos Ruiz', ... }
Monitor{id=3, nombre='Marta Sanz', ... }
</pre>

Cada línea que empieza por `Hibernate:` es el SQL que Hibernate genera por nosotros. `count()` se convierte en `select count(*)` y `findAll()` en un `select` con una columna por campo. Los alias como `m1_0` los inventa Hibernate. Los tres monitores son los que insertó `01-crear-gimnasio.sql` en la Demo 1: la entidad lee datos que existían antes de que la aplicación arrancara. Los valores de las filas 2 y 3 son los de ese script.

### Sin la variable, con JPA

Con JPA, la conexión ya no es opcional. Si quitamos la variable `POSTGRES_PASSWORD` de `Edit Configurations…` y volvemos a ejecutar, la aplicación no llega a arrancar, porque Hibernate necesita la conexión para averiguar con qué base de datos está hablando. En la consola aparece, entre otras líneas:

<pre>
HHH000247 ... ErrorCode: 0, SQLState: 28P01
Unable to obtain isolated JDBC connection [FATAL: password authentication failed for user "postgres"]
Unable to determine Dialect without JDBC metadata ...
Application run failed
</pre>

Dos diferencias con la Demo 2: la aplicación termina con `Application run failed` (en la Demo 2 arrancaba y nuestro mensaje explicaba el fallo) y la pista útil está más arriba, en `password authentication failed`. Es el mismo síntoma, solo que ahora la aplicación entera falla. Volvemos a definir la variable.

### Provocar un error de columna

Para ver qué pasa cuando la entidad no coincide con la tabla, cambiamos solo el nombre del campo `private String especialidad;` por `especialidades` en `Monitor`, escribiéndolo a mano. Como el getter y el `toString()` usan ese campo, usamos `Refactor > Rename` (`Shift+F6`) sobre el campo y aceptamos que renombre también el getter si IntelliJ lo propone. Ahora la entidad pide una columna `especialidades` que no existe en la tabla. Ejecutamos con ▶.

Con `ddl-auto=none`, Hibernate no comprueba nada al arrancar y el error aparece al hacer la consulta, ya con la aplicación en marcha:

<pre>
Hibernate: select count(*) from monitor m1_0
Monitores en la base de datos: 3
Hibernate: select m1_0.id,m1_0.email,m1_0.especialidades,m1_0.fecha_alta,m1_0.nombre from monitor m1_0
...
Caused by: org.postgresql.util.PSQLException: ERROR: column m1_0.especialidades does not exist
  Hint: Perhaps you meant to reference the column "m1_0.especialidad".
</pre>

PostgreSQL nos lo dice con claridad: la columna no existe, y sugiere la más parecida. Fijarse en que `count()` funciona (no nombra ninguna columna) y falla `findAll()`: el error aparece solo cuando se usa la columna.

Hay una forma de detectar este tipo de error antes, al arrancar: cambiar `ddl-auto` a `validate`. Con ese valor Hibernate no modifica nada, pero compara cada entidad con su tabla y se detiene si no coinciden. Cambiamos la propiedad:

```properties
spring.jpa.hibernate.ddl-auto=validate
```

y ejecutamos de nuevo:

<pre>
Schema validation: missing column [especialidades] in table [monitor]
</pre>

La aplicación se detiene al arrancar, antes de ejecutar ninguna consulta. `validate` es una buena red de seguridad cuando el esquema lo mantiene otra persona o un script. Dejamos `none` en el código del curso para que los mensajes de las demos no cambien; en las prácticas puedes probar `validate`.

Terminamos devolviendo el campo a `especialidad` y la propiedad a `none`, y comprobamos que vuelve a salir el listado de tres monitores.

### Un detalle de las claves identity

Si en la Demo 1 provocamos inserciones rechazadas por una restricción, habremos observado que los `id` no son consecutivos. Es normal: la secuencia que genera los `id` avanza aunque la fila se rechace, y no vuelve atrás. Así que si el siguiente monitor que se guarde tiene `id` 5 en lugar de 4, no hay ningún problema. El `id` identifica filas; no las numera.

### Resumen de la parte

| Cosa | Dónde | Qué hace |
|---|---|---|
| Esquema y datos | `sql/01-crear-gimnasio.sql` | Crea las tablas del gimnasio y los datos |
| Datos de conexión | `application.properties` | URL, usuario y `${POSTGRES_PASSWORD}` |
| Contraseña | Variable de entorno | Se define en IntelliJ, fuera de los ficheros |
| Comprobar conexión | `ComprobarConexion` | Abre una conexión y cuenta lo que pasa |
| Entidad | `Monitor` | Refleja la tabla `monitor` |
| Repositorio | `MonitorRepository` | `count()` y `findAll()` |
| Esquema | `ddl-auto=none` | Hibernate no toca las tablas |

En S08-1 completaremos el resto de las entidades del gimnasio (`Clase`, `Socio` e `Inscripcion`) y las relaciones entre ellas.
