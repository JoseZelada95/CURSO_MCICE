# S16-2 Soluciones

Las salidas de este documento muestran el formato de Docker 29 (Docker Desktop 4.96.3) y de Docker Compose v5. Los identificadores, los tamaños y las fechas son orientativos: en cada equipo salen otros. El código es el de la carpeta `soluciones` de `s16-2-practicas.zip`: `practica1` es la solución de la Práctica 1 y `practica2`, la de la Práctica 2. La Práctica 3 se hace sobre el proyecto de cada grupo y no tiene solución única.

---

## Práctica 1: Compose de la API de contactos

La aplicación de partida (`contactos-compose-base`) ya lee los datos de la conexión de variables de entorno y trae su `Dockerfile`. Falta describir en un fichero cómo se ejecuta junto a PostgreSQL.

Primero se construye el JAR. El `artifactId` del `pom.xml` es `contactos-compose`, y por eso el JAR es `contactos-compose-0.0.1-SNAPSHOT.jar` (el mismo nombre que ya lleva el `COPY` del `Dockerfile`):

```bash
mvn clean package -DskipTests
```

Con las imágenes `eclipse-temurin:21-jre` y `postgres:16` en el equipo (variante A, B o C, como en las demos), se construye la imagen de la API:

```bash
docker build -t contactos-compose:1.0 .
```

El `docker-compose.yml` se crea en la raíz del proyecto, junto al `pom.xml`:

```yaml
# S16-2 Práctica 1: Compose de contactos
#
# Objetivo: levantar la API y PostgreSQL con un solo comando: docker compose up -d
#
# Aplica las técnicas de S16:
#   1. Dos servicios (db y api) que Compose conecta en una red propia, por nombre.
#   2. Un volumen para que los datos de PostgreSQL sobrevivan al borrado de los contenedores.
#   3. Una comprobación de salud para que la API espere a que la base de datos esté lista.
#
# Concepto clave: cada línea es una opción de "docker run" escrita en otro formato.
# La sangría (dos espacios, nunca tabuladores) forma parte de la sintaxis de YAML.

services:

  # Servicio de la base de datos. Su nombre, "db", es también su nombre en la red:
  # la API lo encuentra con jdbc:postgresql://db:5432/contactos.
  db:
    # Imagen con etiqueta fija (S16-1). Si ya está en el equipo, Compose no la descarga.
    image: postgres:16
    environment:
      # Contraseña del superusuario "postgres". Obligatoria en la imagen de PostgreSQL.
      POSTGRES_PASSWORD: secreto
      # Base de datos que se crea la primera vez que arranca con el volumen vacío.
      POSTGRES_DB: contactos
    ports:
      # Publicamos PostgreSQL en el 5433 del equipo solo para conectarnos con pgAdmin.
      # El 5432 lo ocupa el PostgreSQL instalado en Windows. La API NO usa este puerto.
      - "5433:5432"
    volumes:
      # Volumen con nombre "pgdata" montado en la carpeta donde PostgreSQL guarda sus datos.
      - pgdata:/var/lib/postgresql/data
    healthcheck:
      # pg_isready responde con éxito cuando PostgreSQL ya acepta conexiones.
      test: ["CMD-SHELL", "pg_isready -U postgres -d contactos"]
      interval: 5s
      timeout: 3s
      retries: 10

  # Servicio de la API. Usa la imagen que construimos con docker build.
  api:
    image: contactos-compose:1.0
    ports:
      # Puerto 8081 del equipo (el 8080 lo ocupa Jenkins) hacia el 8080 del contenedor.
      - "8081:8080"
    environment:
      # Dentro de la red de Compose se usa el nombre del servicio y el puerto INTERNO (5432),
      # nunca localhost ni el 5433.
      DB_URL: jdbc:postgresql://db:5432/contactos
      DB_USER: postgres
      DB_PASSWORD: secreto
    depends_on:
      db:
        # No basta con que el contenedor de la base de datos haya arrancado:
        # la API espera a que pase la comprobación de salud.
        condition: service_healthy

# Volúmenes con nombre que usan los servicios. Compose los crea la primera vez.
volumes:
  pgdata:
```

Se comprueba y se arranca:

```bash
docker compose config
```

```bash
docker compose up -d
```

```bash
docker compose ps
```

<pre>
C:\Users\Mananas\contactos-compose-base>docker compose ps
NAME                            IMAGE                   COMMAND                  SERVICE   CREATED         STATUS                   PORTS
contactos-compose-base-api-1    contactos-compose:1.0   "java -jar app.jar"      api       9 seconds ago   Up 1 second              0.0.0.0:8081->8080/tcp
contactos-compose-base-db-1     postgres:16             "docker-entrypoint.s…"   db        9 seconds ago   Up 9 seconds (healthy)   0.0.0.0:5433->5432/tcp
</pre>

Los nombres llevan el de la carpeta (`contactos-compose-base`) porque el proyecto de Compose se llama como ella. En `http://localhost:8081/api/contactos` sale la lista vacía, y tras el `POST` desde Postman (`POST http://localhost:8081/api/contactos`, `Body > raw > JSON`):

<pre>
{"nombre":"Lucía Pérez","email":"lucia@example.com","telefono":null,"id":1}
</pre>

El contacto aparece en la lista, y en pgAdmin (host `localhost`, puerto `5433`, base de datos `contactos`, usuario `postgres`, contraseña `secreto`) en la tabla `contacto`.

Se comprueba la persistencia:

```bash
docker compose down
```

```bash
docker compose up -d
```

El contacto sigue en la lista. Y la comprobación contraria:

```bash
docker compose down -v
```

```bash
docker compose up -d
```

La lista sale vacía: el volumen se borró y PostgreSQL empezó de cero.

El error provocado se consigue cambiando `DB_URL` a `jdbc:postgresql://localhost:5432/contactos`. Tras `docker compose up -d`, los registros de la API (`docker compose logs api`) contienen:

<pre>
api-1  | ... WARN 1 --- [contactos-compose] [  main] org.hibernate.orm.jdbc.error : Connection to localhost:5432 refused. Check that the hostname and port are correct and that the postmaster is accepting TCP/IP connections.
api-1  | ... Caused by: java.net.ConnectException: Connection refused
</pre>

El contenedor `api` se para solo (`docker compose ps -a` lo muestra como `Exited (1)`). La causa: dentro del contenedor, `localhost` es la propia API, y allí no hay ningún PostgreSQL. Se corrige volviendo a `db:5432`.

Para terminar:

```bash
docker compose down -v
```

**Decisiones tomadas**
- La imagen de la API se construye con `docker build` y el fichero la usa con `image:`, igual que en la Demo 2. Se podría usar `build: .`, pero así se ven por separado la construcción de la imagen y la puesta en marcha, y es lo que se hará con una imagen publicada en un registro.
- `DB_URL` usa el nombre del servicio (`db`) y el puerto interno (5432). El puerto 5433 solo existe en Windows, para pgAdmin, y la API no lo usa.
- Se publica `db` en el 5433 y no en el 5432 porque el 5432 lo ocupa el PostgreSQL instalado en Windows.
- Se usa un volumen con nombre (`pgdata`) y no una carpeta del equipo: lo gestiona Docker, no depende de rutas de Windows y es lo que se recomienda para bases de datos.
- El `healthcheck` usa `pg_isready` con el usuario y la base de datos: comprueba que PostgreSQL acepta conexiones, que es lo que necesita la API. Un contenedor arrancado no basta.
- `depends_on` con `condition: service_healthy` y no la forma corta: la forma corta solo espera a que el contenedor haya arrancado, y la API fallaría al conectar mientras PostgreSQL se inicializa.
- Las pruebas se omiten al empaquetar (`-DskipTests`) porque `contextLoads` arranca la aplicación entera y necesita una base de datos disponible desde Maven.
- La contraseña `secreto` está escrita en el fichero porque es una práctica local con datos de prueba. La Práctica 2 la saca del fichero.

---

## Práctica 2: Credenciales fuera del fichero

Los tres valores secretos o variables (`DB_USER`, `DB_PASSWORD`, `DB_NAME`) pasan a un fichero `.env`, y el `docker-compose.yml` solo conserva los nombres. El fichero resultante, junto al `.env`, el `.env.example` y el `.gitignore`, está en la carpeta `soluciones/practica2` del zip.

El `docker-compose.yml`:

```yaml
# S16-2 Práctica 2: Compose de contactos con las credenciales fuera del fichero
#
# Objetivo: que el docker-compose.yml se pueda versionar sin contraseñas escritas dentro.
#
# Aplica las técnicas de S16:
#   1. Un fichero .env junto al docker-compose.yml con los valores secretos.
#   2. ${VARIABLE} en el docker-compose.yml: Compose la sustituye por el valor del .env.
#   3. .gitignore para que el .env no llegue nunca al repositorio.
#
# Concepto clave: el docker-compose.yml describe la estructura y se comparte; el .env guarda
# los secretos y se queda en cada equipo. Se comparte un .env.example con las claves vacías.

services:

  db:
    image: postgres:16
    environment:
      POSTGRES_USER: ${DB_USER}
      POSTGRES_PASSWORD: ${DB_PASSWORD}
      POSTGRES_DB: ${DB_NAME}
    ports:
      - "5433:5432"
    volumes:
      - pgdata:/var/lib/postgresql/data
    healthcheck:
      # Dentro del contenedor, Compose ya ha sustituido las variables al crearlo.
      test: ["CMD-SHELL", "pg_isready -U ${DB_USER} -d ${DB_NAME}"]
      interval: 5s
      timeout: 3s
      retries: 10

  api:
    image: contactos-compose:1.0
    ports:
      - "8081:8080"
    environment:
      DB_URL: jdbc:postgresql://db:5432/${DB_NAME}
      DB_USER: ${DB_USER}
      DB_PASSWORD: ${DB_PASSWORD}
    depends_on:
      db:
        condition: service_healthy

volumes:
  pgdata:
```

El fichero `.env`, con los valores de este equipo:

```bash
# Valores reales de este equipo. Este fichero NO se sube a Git (está en .gitignore).
DB_USER=postgres
DB_PASSWORD=secreto
DB_NAME=contactos
```

La comprobación con `docker compose config` muestra los valores ya sustituidos (abreviada):

<pre>
C:\Users\Mananas\contactos-compose-base>docker compose config
name: contactos-compose-base
services:
  api:
    environment:
      DB_PASSWORD: secreto
      DB_URL: jdbc:postgresql://db:5432/contactos
      DB_USER: postgres
    image: contactos-compose:1.0
    ...
  db:
    environment:
      POSTGRES_DB: contactos
      POSTGRES_PASSWORD: secreto
      POSTGRES_USER: postgres
    image: postgres:16
    ...
</pre>

Si se cambia un valor del `.env` y se repite el comando, cambia la salida. Sin el `.env`, Compose no falla: avisa y sustituye por una cadena vacía, lo que da un fichero que parece válido pero no funciona:

<pre>
C:\Users\Mananas\contactos-compose-base>docker compose config
time="2026-10-28T09:01:49+01:00" level=warning msg="The \"DB_USER\" variable is not set. Defaulting to a blank string."
time="2026-10-28T09:01:49+01:00" level=warning msg="The \"DB_PASSWORD\" variable is not set. Defaulting to a blank string."
time="2026-10-28T09:01:49+01:00" level=warning msg="The \"DB_NAME\" variable is not set. Defaulting to a blank string."
...
</pre>

Aparece una advertencia por cada vez que se usa la variable en el fichero, de ahí que se repitan. Con `docker compose up -d` y el `.env` en su sitio, la API funciona igual que en la Práctica 1.

Para el repositorio se crean dos ficheros más. El `.gitignore` impide que el `.env` y la carpeta `target` lleguen a Git:

```bash
# Credenciales de este equipo: nunca al repositorio
.env

# Resultado de Maven
target/
```

Y el `.env.example` es la plantilla que sí se sube:

```bash
# Plantilla del .env. Se copia como .env y se rellenan los valores.
# Este fichero SÍ se sube a Git, siempre sin valores secretos.
DB_USER=
DB_PASSWORD=
DB_NAME=contactos
```

Se comprueba con Git en una carpeta nueva (`git init` y `git status`). Antes del `.gitignore`, `git status --short` muestra el `.env`:

<pre>
C:\Users\Mananas\contactos-compose-base>git status --short
?? .env
?? docker-compose.yml
</pre>

Con el `.gitignore` el `.env` ya no aparece, y con el `.env.example` creado aparece este último:

<pre>
C:\Users\Mananas\contactos-compose-base>git status --short
?? .env.example
?? .gitignore
?? docker-compose.yml
</pre>

Quien clone el repositorio copia `.env.example` como `.env`, escribe su contraseña y ejecuta `docker compose up -d`. Para terminar:

```bash
docker compose down -v
```

**Decisiones tomadas**
- `DB_USER` y `DB_NAME` también salen al `.env`, aunque no son secretos: así los valores que tienen que coincidir entre `db` y `api` se escriben **una sola vez**. Si el usuario o la base de datos cambian, se cambia en un solo sitio.
- El `healthcheck` también usa las variables. Si se dejaran escritos `postgres` y `contactos`, la comprobación fallaría con otro usuario o base de datos, y el servicio nunca pasaría a `healthy`.
- El `.env` no se sube a Git. Se sube el `.env.example` con los nombres de variable y sin la contraseña, para que quien clone el proyecto sepa qué crear.
- Se ignora también `target/` porque es el resultado de Maven y se regenera; no tiene sentido versionarlo.
- Compose lee el `.env` solo si está en la carpeta desde la que se ejecuta el comando. Por eso el fichero va junto al `docker-compose.yml`.
- El cambio de `DB_PASSWORD` solo se prueba con `docker compose config`. Las variables `POSTGRES_*` solo valen la primera vez que arranca con el volumen vacío: con datos ya creados, cambiar la contraseña en el `.env` y arrancar daría un error de autenticación en la API, porque la contraseña del volumen sigue siendo la anterior. La solución sería `docker compose down -v` (perdiendo los datos) o cambiarla desde PostgreSQL.

---

## Práctica 3: Docker Compose en el proyecto del grupo

Cada grupo escribe su propio fichero, y no hay una solución única. Se comprueba que el resultado cumple esta lista:

| Comprobación | Cómo se verifica |
|---|---|
| La aplicación lee la conexión de variables de entorno con `${NOMBRE:valor}` | Se abre `application.properties` |
| El `Dockerfile` copia el JAR con el nombre correcto | `docker build` termina sin errores |
| La base de datos tiene volumen | Aparece en `volumes` y en el servicio |
| La aplicación espera a la base de datos | `depends_on` con `condition: service_healthy` y `healthcheck` |
| La aplicación se conecta por el nombre del servicio | La URL no contiene `localhost` |
| Las credenciales no están en el fichero | `docker compose config` las muestra, el `docker-compose.yml` solo `${...}` |
| El `.env` no está en Git | `git status` no lo muestra; el repositorio tiene `.env.example` |
| Otro miembro lo levanta con un comando | Clona, crea su `.env` y ejecuta `docker compose up -d` |

Un ejemplo de estructura, para un proyecto con MongoDB en lugar de PostgreSQL (la imagen es `mongo:8`, que se monta en `/data/db`; el `healthcheck` usa `mongosh`):

```yaml
services:
  db:
    image: mongo:8
    environment:
      MONGO_INITDB_ROOT_USERNAME: ${DB_USER}
      MONGO_INITDB_ROOT_PASSWORD: ${DB_PASSWORD}
    volumes:
      - mongodata:/data/db
    healthcheck:
      test: ["CMD-SHELL", "mongosh --quiet --eval 'db.runCommand({ping:1})'"]
      interval: 5s
      timeout: 3s
      retries: 10

  api:
    build: .
    ports:
      - "8081:8080"
    environment:
      MONGO_URI: mongodb://${DB_USER}:${DB_PASSWORD}@db:27017
    depends_on:
      db:
        condition: service_healthy

volumes:
  mongodata:
```

Este ejemplo es solo orientativo y no se ha ejecutado con el proyecto de ningún grupo. El `healthcheck` de MongoDB cambia según la versión de la imagen, y la variable de la aplicación depende de cómo la lea cada proyecto.

**Decisiones tomadas**
- No hay solución única: cada proyecto tiene sus servicios, sus variables y su base de datos. Lo que se comprueba es la lista, no un fichero concreto.
- El ejemplo con MongoDB usa `build: .` para que quien clone el proyecto no necesite construir la imagen a mano (solo el JAR con `mvn clean package -DskipTests`).
- El grupo reparte el trabajo en tres piezas (`Dockerfile`, `docker-compose.yml`, `.env`) que encajan en los nombres de las variables. Es el mismo reparto que en un equipo real.
