# S16-2 Teoría: volúmenes, redes y Docker Compose

## Objetivos

Esta primera parte de S16-2 no usa el ordenador. Sirve para entender los conceptos que luego se manejan en las demos y que aparecen en el cuestionario de Docker y Kubernetes (preguntas 5 y 6).

En S16-1 empaquetamos una API en una imagen. Ahora la conectamos con una base de datos y la ponemos en marcha entera con un solo comando. Hay dos obstáculos y cada uno se resuelve con una pieza nueva:

| Obstáculo | Qué lo resuelve | Apartado |
|---|---|---|
| Los datos desaparecen al borrar el contenedor | **Volúmenes** | 1 |
| Un contenedor tiene que encontrar a otro (la API a su base de datos) | **Redes** y nombres de servicio | 2 |
| Configurar la base de datos de la imagen | **Variables de entorno** de la imagen | 3 |
| Todo lo anterior, a mano, son muchos comandos largos | **Docker Compose** | 4 a 6 |

| Al terminar sabremos explicar... | Apartado |
|---|---|
| Para qué sirve un volumen y cómo se usa | 1 |
| Cómo se encuentran los contenedores entre sí | 2 |
| Cómo se configura PostgreSQL en un contenedor | 3 |
| Qué es Docker Compose y qué problema resuelve | 4 |
| Cómo se escribe un `docker-compose.yml` | 5 |
| Qué hace cada comando de Compose | 6 |

---

## 1. Volúmenes: los datos que sobreviven

### El problema

Un contenedor escribe en su **capa de escritura** (S16-1, apartado 2), que desaparece al borrarlo. Para una aplicación sin estado no importa. Para una base de datos es inaceptable: al borrar el contenedor se pierden todos los datos.

```
 contenedor postgres
 ┌─────────────────────────────┐
 │ capa de escritura           │ ← aquí se guardan las tablas
 ├─────────────────────────────┤      y se pierden al borrar el contenedor
 │ capas de la imagen postgres │
 └─────────────────────────────┘
```

### La solución

Un **volumen** es una carpeta que Docker guarda **fuera del contenedor** y que se **monta** (se conecta) en una ruta de su sistema de ficheros. El contenedor cree que escribe en su carpeta, pero los datos van al volumen.

```
 contenedor postgres                         volumen pgdata
 ┌─────────────────────────────┐            ┌──────────────┐
 │ /var/lib/postgresql/data  ──┼───────────►│ (los datos)  │
 └─────────────────────────────┘            └──────────────┘
      se borra con el contenedor              sobrevive
```

> **Idea clave:** el contenedor es desechable, los datos no. El volumen vive aparte del contenedor y se puede conectar a otro contenedor nuevo, que encuentra los datos tal como estaban.

### Tipos de montaje

| Tipo | Se escribe | Quién lo gestiona | Para qué se usa |
|---|---|---|---|
| **Volumen con nombre** | `-v pgdata:/var/lib/postgresql/data` | Docker (no hace falta saber dónde está en disco) | Datos que deben conservarse: bases de datos. Es el que usaremos |
| **Montaje de carpeta** (*bind mount*) | `-v C:\proyecto\datos:/datos` | Nosotros: una carpeta concreta del equipo | Compartir ficheros entre el equipo y el contenedor, por ejemplo código en desarrollo |
| **Temporal** (`tmpfs`) | `--tmpfs /tmp` | La memoria del equipo | Datos que no deben quedar en disco. Solo se menciona |

La diferencia se reconoce en el primer trozo de `-v`: si es un **nombre** (`pgdata`), es un volumen de Docker. Si es una **ruta** (`C:\proyecto\datos`), es una carpeta del equipo.

### Cómo se lee la opción `-v`

```
 -v   pgdata : /var/lib/postgresql/data
      └──┬──┘   └──────────┬───────────┘
    volumen        ruta DENTRO del contenedor
```

La ruta de destino la decide la imagen, no nosotros: cada imagen guarda sus datos en un sitio y hay que montar el volumen justo ahí. En PostgreSQL es `/var/lib/postgresql/data`; en MongoDB, `/data/db`.

### Qué pasa con cada operación

| Operación | Contenedor | Volumen | Datos |
|---|---|---|---|
| `docker stop` y `docker start` | Se conserva | Se conserva | Se conservan |
| `docker rm` del contenedor | Se borra | **Se conserva** | **Se conservan** |
| Crear otro contenedor y montar el mismo volumen | Nuevo | El mismo | Los encuentra |
| `docker volume rm` | (ya borrado) | Se borra | **Se pierden** |
| `docker compose down -v` | Se borra | Se borra | **Se pierden** |

### Comandos de volúmenes

| Comando | Para qué sirve |
|---|---|
| `docker volume create NOMBRE` | Crear un volumen. Si se monta uno que no existe, Docker lo crea solo |
| `docker volume ls` | Listar los volúmenes |
| `docker volume inspect NOMBRE` | Ver sus detalles (dónde está, cuándo se creó) |
| `docker volume rm NOMBRE` | Borrar un volumen. Falla si algún contenedor lo usa |
| `docker volume prune` | Borrar todos los volúmenes que ningún contenedor usa. **Cuidado: pierde datos** |

---

## 2. Redes: cómo se encuentran los contenedores

### Cada contenedor tiene su propia red

En S16-1 vimos que el contenedor tiene su propia red y que `-p` conecta un puerto del equipo con uno del contenedor. Eso sirve para que **nosotros** (el navegador) lleguemos al contenedor. Pero la API necesita llegar a la base de datos **desde otro contenedor**.

### El error más frecuente: `localhost`

Dentro de un contenedor, `localhost` es **el propio contenedor**, no el equipo ni otro contenedor.

| Quien escribe | Escribe | A dónde llega |
|---|---|---|
| Un programa en Windows | `localhost:5432` | Al PostgreSQL instalado en Windows |
| La API dentro de su contenedor | `localhost:5432` | **A sí misma.** No hay PostgreSQL ahí: falla con `Connection refused` |
| La API dentro de su contenedor | `db:5432` | Al contenedor cuyo nombre es `db` |

### Nombres en lugar de direcciones

En una **red definida por el usuario** (la que crea Compose, o `docker network create`), cada contenedor puede encontrar a los demás **por su nombre**. Docker tiene un servicio de nombres integrado: no se necesitan direcciones IP, que cambian cada vez que se crea un contenedor.

| Quién | Cómo llega | A dónde llega |
|---|---|---|
| El navegador (equipo) | `localhost:8081` (con `-p 8081:8080`) | Contenedor `api` |
| El contenedor `api` | `jdbc:postgresql://db:5432/contactos` | Contenedor `db`, dentro de la red `contactos_default` |

### Dos puertos distintos

| Puerto | Quién lo usa | Dónde se escribe |
|---|---|---|
| **Publicado** (`5433` en el equipo) | Programas **fuera** de Docker: pgAdmin, el navegador | En `-p` o en `ports:` |
| **Interno** (`5432` en el contenedor) | Otros contenedores de la misma red | En la URL de conexión de la API |

> **Regla:** entre contenedores siempre se usa el puerto **interno** y el **nombre del servicio**. El puerto publicado solo sirve para llegar desde el equipo, y ni siquiera hace falta publicarlo si nadie desde fuera necesita llegar a esa base de datos.

### Comandos de redes

| Comando | Para qué sirve |
|---|---|
| `docker network create NOMBRE` | Crear una red |
| `docker network ls` | Listar las redes |
| `docker network inspect NOMBRE` | Ver sus detalles y qué contenedores tiene |
| `docker network rm NOMBRE` | Borrar una red |

Con Compose casi nunca se escriben: crea una red por proyecto sola.

---

## 3. PostgreSQL en un contenedor

La imagen oficial de PostgreSQL se configura con **variables de entorno** (S16-1, `-e`):

| Variable | Qué hace | ¿Obligatoria? |
|---|---|---|
| `POSTGRES_PASSWORD` | Contraseña del superusuario | **Sí.** Sin ella el contenedor se para al arrancar |
| `POSTGRES_USER` | Nombre del superusuario | No. Por defecto, `postgres` |
| `POSTGRES_DB` | Base de datos que se crea al arrancar | No. Por defecto, la del nombre del usuario |

Ejemplo con `docker run`:

```bash
docker run -d --name db -e POSTGRES_PASSWORD=secreto -e POSTGRES_DB=contactos -p 5433:5432 -v pgdata:/var/lib/postgresql/data postgres:16
```

Cómo se lee:

| Parte | Qué hace |
|---|---|
| `-e POSTGRES_PASSWORD=secreto` | Contraseña del superusuario |
| `-e POSTGRES_DB=contactos` | Crea la base de datos `contactos` |
| `-p 5433:5432` | El 5433 del equipo va al 5432 del contenedor. El 5432 del equipo ya lo ocupa el PostgreSQL instalado |
| `-v pgdata:/var/lib/postgresql/data` | Guarda los datos en el volumen `pgdata` |
| `postgres:16` | La imagen, con etiqueta fija (S16-1, apartado 6) |

> **Trampa habitual:** las variables `POSTGRES_*` solo se usan **la primera vez**, cuando el volumen está vacío y PostgreSQL inicializa su carpeta de datos. Si el volumen ya tiene datos, se ignoran. Cambiar la contraseña en el fichero y volver a arrancar **no** la cambia. Hay que borrar el volumen (y perder los datos) o cambiarla desde dentro de PostgreSQL.

Cuando la imagen se ejecuta por primera vez, PostgreSQL tarda unos segundos en estar listo. Una API que arranque antes intenta conectar y falla. Esto se resuelve en el apartado 5 con la comprobación de salud.

---

## 4. Docker Compose

### El problema

Para levantar la API con su base de datos a mano hay que escribir, en orden:

```bash
docker network create contactos
docker volume create pgdata
docker run -d --name db --network contactos -e POSTGRES_PASSWORD=secreto -e POSTGRES_DB=contactos -v pgdata:/var/lib/postgresql/data postgres:16
docker run -d --name api --network contactos -p 8081:8080 -e DB_URL=jdbc:postgresql://db:5432/contactos contactos:2.0
```

Funciona, pero es largo y frágil: un error de escritura, un orden equivocado o una opción olvidada y no arranca. Y quien reciba el proyecto tiene que adivinar estos comandos.

### La solución

**Docker Compose** es una herramienta que lee un fichero de texto con la descripción de **todos los contenedores de la aplicación** y los pone en marcha juntos. Viene incluida en Docker Desktop.

| Sin Compose | Con Compose |
|---|---|
| Varios comandos `docker run` largos, en el orden correcto | Un fichero `docker-compose.yml` |
| Hay que crear la red y los volúmenes a mano | Compose los crea |
| Para pararlo todo, comando a comando | `docker compose down` |
| Los comandos viven en la cabeza de alguien o en un `README` | El fichero se versiona con Git junto al código |

> **Idea clave:** Compose no añade conceptos nuevos. Todo lo que contiene el fichero (imagen, puertos, variables, volúmenes) son las opciones de `docker run` que ya conocemos, escritas en otro formato. Y es documentación ejecutable: quien clona el proyecto lo pone en marcha con `docker compose up`.

### Equivalencias entre `docker run` y Compose

| `docker run` | En el fichero Compose |
|---|---|
| Imagen (`postgres:16`) | `image: postgres:16` |
| `--name db` | El nombre del servicio (`db:`) |
| `-p 8081:8080` | `ports:` con `"8081:8080"` |
| `-e VARIABLE=valor` | `environment:` |
| `-v pgdata:/var/...` | `volumes:` |
| `--network` | No hace falta: Compose crea una red |
| `--restart` | `restart:` |
| (a mano, comando a comando) | `depends_on:` para el orden |

---

## 5. El fichero `docker-compose.yml`

### Qué es YAML

El fichero está escrito en **YAML**, un formato de texto para datos que se parece a JSON (S09) pero se escribe con **sangría** en lugar de llaves.

| Elemento | Se escribe | Ejemplo |
|---|---|---|
| Pareja clave y valor | `clave: valor` (hay un espacio tras los dos puntos) | `image: nginx` |
| Anidar | Sangría de **dos espacios** | `services:` y debajo `  web:` |
| Lista | Un guion y un espacio por elemento | `- "8081:80"` |
| Comentario | `#` | `# puerto del equipo` |

> **La sangría es la sintaxis.** En YAML se escribe siempre con **espacios, nunca con tabuladores**, y un espacio de más o de menos cambia el significado o rompe el fichero. A diferencia de Groovy en el `Jenkinsfile` (S14-1), aquí la sangría sí importa. Los errores de sangría son el fallo más frecuente: Compose los señala con un mensaje que indica la línea.

### Estructura

Un fichero Compose tiene tres bloques principales al nivel más externo:

| Bloque | Qué contiene |
|---|---|
| `services:` | Los contenedores de la aplicación. **Es el único obligatorio** |
| `volumes:` | Los volúmenes con nombre que usan los servicios |
| `networks:` | Redes propias (opcional: sin él, Compose crea una) |

> **Servicio** es la descripción de un contenedor. El nombre del servicio (`db`, `api`) es también **el nombre de red** con el que los demás lo encuentran (apartado 2).

### Ejemplo mínimo

```yaml
services:
  web:
    image: nginx
    ports:
      - "8081:80"
```

Equivale a `docker run -d --name web -p 8081:80 nginx`. Los puertos van **entre comillas** para que YAML no confunda `8081:80` con otro tipo de dato.

### Ejemplo completo: la API con su base de datos

```yaml
services:
  db:
    image: postgres:16
    environment:
      POSTGRES_PASSWORD: secreto
      POSTGRES_DB: contactos
    volumes:
      - pgdata:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U postgres"]
      interval: 5s
      timeout: 3s
      retries: 10

  api:
    image: contactos:2.0
    ports:
      - "8081:8080"
    environment:
      DB_URL: jdbc:postgresql://db:5432/contactos
      DB_PASSWORD: secreto
    depends_on:
      db:
        condition: service_healthy

volumes:
  pgdata:
```

### Las claves de un servicio

| Clave | Qué hace |
|---|---|
| `image` | Imagen de la que se crea el contenedor. Con etiqueta fija |
| `build` | En lugar de `image`: construye la imagen desde un `Dockerfile` (por ejemplo `build: .`) |
| `ports` | Lista de puertos publicados, `"equipo:contenedor"` |
| `environment` | Variables de entorno, `NOMBRE: valor` |
| `env_file` | Lee las variables de un fichero |
| `volumes` | Volúmenes y carpetas montados, `nombre:ruta` |
| `depends_on` | De qué otros servicios depende, para el orden de arranque |
| `healthcheck` | Cómo comprobar que el servicio ya está listo |
| `restart` | Cuándo reiniciarlo (`no`, `always`, `unless-stopped`) |

> **`image` o `build`.** Con `image: contactos:2.0`, Compose usa una imagen que ya existe (construida con `docker build` como en S16-1). Con `build: .`, Compose la construye al hacer `docker compose up --build`. En el aula, `image` y `build` solo necesitan Docker Hub si la imagen base no está ya en el equipo: si `postgres:16` y `eclipse-temurin:21-jre` están cargadas, no se descarga nada.

### El orden de arranque: `depends_on` y `healthcheck`

El problema clásico: la API arranca antes de que PostgreSQL esté listo, intenta conectar y falla.

| Opción | Qué espera Compose | ¿Basta? |
|---|---|---|
| `depends_on: - db` | A que el contenedor `db` **haya arrancado** | **No.** Arrancado no es lo mismo que listo para aceptar conexiones |
| `depends_on` con `condition: service_healthy` | A que `db` **pase su comprobación de salud** | **Sí** |

La **comprobación de salud** (*healthcheck*) es un comando que Compose ejecuta cada cierto tiempo dentro del contenedor. Si termina bien, el servicio está sano.

| Parte | Significado |
|---|---|
| `test` | El comando. `pg_isready` es una utilidad de PostgreSQL que responde si acepta conexiones |
| `interval` | Cada cuánto se ejecuta |
| `timeout` | Cuánto se espera la respuesta |
| `retries` | Cuántos fallos seguidos se admiten antes de declararlo no sano |

El estado del servicio pasa por `starting`, `healthy` o `unhealthy`; se ve en `docker compose ps`.

### Variables y el fichero `.env`

Escribir la contraseña en el `docker-compose.yml` la deja en el repositorio. Compose puede leer los valores de un fichero llamado **`.env`**, en la misma carpeta, y sustituirlos donde aparezca `${NOMBRE}`:

| Fichero | Contenido | ¿Va a Git? |
|---|---|---|
| `.env` | `DB_PASSWORD=secreto` | **No.** Se añade a `.gitignore` (S11-1) |
| `docker-compose.yml` | `POSTGRES_PASSWORD: ${DB_PASSWORD}` | Sí |

Es el mismo principio que la variable `POSTGRES_PASSWORD` de S07: **las credenciales no se versionan**. Cada persona crea su propio `.env`. Es habitual subir un `.env.example` con los nombres de las variables y valores de ejemplo.

### Nombres que genera Compose

Compose agrupa todo lo de un fichero en un **proyecto**, que por defecto se llama como la **carpeta**. Con una carpeta `contactos` y servicios `db` y `api`:

| Recurso | Nombre |
|---|---|
| Contenedores | `contactos-db-1`, `contactos-api-1` |
| Red | `contactos_default` |
| Volumen `pgdata` | `contactos_pgdata` |

Dentro de la red, los servicios se encuentran por el **nombre del servicio** (`db`), no por el del contenedor.

---

## 6. Los comandos de Compose

Se escriben `docker compose` (**dos palabras**; el antiguo `docker-compose` con guion ya no se usa) y se ejecutan **en la carpeta del fichero**.

| Comando | Para qué sirve |
|---|---|
| `docker compose up` | Crea la red, los volúmenes y los contenedores, y los arranca |
| `docker compose up -d` | Igual, pero en segundo plano |
| `docker compose up --build` | Reconstruye antes las imágenes de los servicios con `build:` |
| `docker compose down` | Para y **borra los contenedores y la red**. Los volúmenes se conservan |
| `docker compose down -v` | Lo mismo y **borra también los volúmenes** (se pierden los datos) |
| `docker compose ps` | Lista los contenedores del proyecto y su estado |
| `docker compose logs` | Muestra la salida de todos los servicios |
| `docker compose logs -f api` | Sigue la salida del servicio `api` hasta pulsar `Ctrl+C` |
| `docker compose build` | Construye las imágenes de los servicios con `build:` |
| `docker compose stop` / `start` | Para / arranca sin borrar nada |
| `docker compose exec db psql -U postgres` | Ejecuta un comando dentro de un servicio en marcha |
| `docker compose config` | Muestra el fichero ya con las variables sustituidas. Sirve para comprobar el YAML |

### Qué conserva cada orden

| | Contenedores | Red | Volumen | Datos |
|---|---|---|---|---|
| `docker compose stop` | Parados | Se conserva | Se conserva | Se conservan |
| `docker compose down` | **Se borran** | **Se borra** | Se conserva | Se conservan |
| `docker compose down -v` | Se borran | Se borra | **Se borra** | **Se pierden** |

> **Regla:** `down` es seguro, `down -v` borra los datos. Antes de escribir `-v`, preguntarse si hay algo en esa base de datos que se quiera conservar.

### Errores frecuentes

| Síntoma | Causa habitual |
|---|---|
| `yaml: line N: ... mapping values are not allowed` | Sangría mal o falta el espacio tras los dos puntos |
| `found character that cannot start any token` | Un tabulador en lugar de espacios |
| La API falla con `Connection refused` a la base | Se usa `localhost` en lugar del nombre del servicio |
| La API arranca antes que la base de datos | Falta `healthcheck` o `condition: service_healthy` |
| `port is already allocated` o `address already in use` | El puerto del equipo está ocupado (8080 Jenkins, 5432 PostgreSQL local): elegir otro |
| La contraseña nueva no se aplica | El volumen ya tenía datos: las variables `POSTGRES_*` solo se usan la primera vez |

---

## 7. Qué hay que saber para el test

| Pregunta | Idea clave |
|---|---|
| 5. Volúmenes | Un volumen guarda los datos **fuera del contenedor**, así que sobreviven a su borrado. Se monta en la ruta donde la imagen guarda sus datos (`-v nombre:ruta`). Sin volumen, los datos se pierden al borrar el contenedor |
| 6. Docker Compose | Herramienta que describe en un fichero YAML todos los servicios de la aplicación y los levanta juntos con `docker compose up`, creando la red y conectándolos por nombre. Se detiene con `docker compose down` |

---

## Resumen

| Concepto | En una línea |
|---|---|
| Volumen | Carpeta fuera del contenedor que conserva los datos al borrarlo |
| Volumen con nombre | `-v pgdata:/ruta`: lo gestiona Docker. Una **ruta** en lugar de un nombre es un montaje de carpeta |
| Red y nombre de servicio | En una red de usuario los contenedores se encuentran por su nombre, con el puerto **interno** |
| `localhost` en un contenedor | Es el propio contenedor, nunca otro |
| `POSTGRES_PASSWORD` | Obligatoria. Las variables `POSTGRES_*` solo valen la primera vez |
| Docker Compose | Un fichero YAML que levanta todos los contenedores juntos |
| YAML | Se escribe con sangría de espacios, nunca con tabuladores |
| `depends_on` y `healthcheck` | Esperan a que la base de datos esté **lista**, no solo arrancada |
| `down` frente a `down -v` | `down` conserva los datos, `down -v` los borra |
| `.env` | Contiene las credenciales, no va a Git |
