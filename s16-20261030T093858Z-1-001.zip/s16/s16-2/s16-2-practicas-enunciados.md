# S16-2 Prácticas

## Objetivos

En las demos hemos levantado la API de contactos y PostgreSQL con un `docker-compose.yml` ya escrito. En estas prácticas se escribe el fichero desde cero, se sacan las contraseñas del fichero y se aplica lo aprendido al proyecto del grupo.

Las prácticas usan los mismos comandos de las demos. Las imágenes que hacen falta son `eclipse-temurin:21-jre` y `postgres:16`; se consiguen con la variante (A, B o C) que se estableció en el apartado "Antes de empezar" de `s16-2-demos.md`, y si ya están en el equipo desde las demos no hay que conseguirlas otra vez.

Al terminar, el alumno es capaz de:
- Escribir un `docker-compose.yml` con dos servicios, un volumen, un `healthcheck` y `depends_on`.
- Conectar una aplicación con su base de datos por el nombre del servicio.
- Sacar las credenciales del `docker-compose.yml` a un fichero `.env` que no se sube a Git.
- Aplicar Docker Compose al proyecto del grupo.

Las Prácticas 1 y 2 parten de `s16-2-practicas.zip`, que contiene la carpeta `contactos-compose-base`. La Práctica 3 se hace sobre el proyecto del grupo y no lleva zip.

---

## Práctica 1: Compose de la API de contactos

La carpeta `contactos-compose-base` es la API de contactos de la Demo 2: guarda los contactos en PostgreSQL y lee los datos de la conexión de las variables `DB_URL`, `DB_USER` y `DB_PASSWORD`. Ya tiene `Dockerfile`, pero no tiene `docker-compose.yml`: hay que escribirlo. El resultado final tiene que ser el mismo que en la Demo 2.

**Pasos**
1. Descomprimimos el zip y abrimos en IntelliJ la carpeta `contactos-compose-base` (`File > Open`, la que contiene directamente el `pom.xml`). Pulsamos `Trust Project` y `Load` si aparece el aviso de Maven.
2. Construimos el JAR sin ejecutar las pruebas y anotamos el nombre exacto del JAR que aparece en `target`.
3. Nos aseguramos de tener las imágenes `eclipse-temurin:21-jre` y `postgres:16` en el equipo, con la vía de nuestra variante.
4. Construimos la imagen de la API con el nombre `contactos-compose` y la etiqueta `1.0`.
5. Creamos en la raíz del proyecto el fichero `docker-compose.yml` con dos servicios: `db` (PostgreSQL) y `api` (la imagen del paso anterior). Los datos de la base de datos tienen que conservarse al borrar los contenedores, y la API no debe arrancar hasta que PostgreSQL esté listo.
6. Comprobamos el fichero con `docker compose config` y lo arrancamos en segundo plano.
7. Miramos `docker compose ps`, hasta ver el servicio `db` como `healthy`, y los registros de la API: tiene que aparecer que ha arrancado sin errores.
8. Comprobamos en el navegador `http://localhost:8081/api/contactos` y creamos un contacto con una petición `POST` (con Postman, S09).
9. Nos conectamos a la base de datos con pgAdmin y comprobamos que la tabla `contacto` tiene el contacto.
10. Hacemos `docker compose down` y `up -d` otra vez: el contacto tiene que seguir en la lista. Después `docker compose down -v` y `up -d`: la lista tiene que estar vacía.
11. Provocamos a propósito un error: cambiamos en `DB_URL` el nombre `db` por `localhost`, recreamos con `docker compose up -d` y leemos los registros de la API. Lo dejamos como estaba.
12. Terminamos con `docker compose down -v`.

**Pistas**
- La estructura es la del ejemplo de la teoría (apartado 5) y la de la Demo 2. Hay tres bloques: `services`, dentro `db` y `api`, y al final `volumes`.
- El nombre del JAR es `artifactId-version.jar`. El `artifactId` de este proyecto es `contactos-compose`.
- El `pom.xml` y el `application.properties` dicen qué variables lee la aplicación. La base de datos y el usuario de `db` tienen que coincidir con los de `DB_URL` y `DB_USER`.
- La API escucha en el 8080 del contenedor. El 8080 del equipo lo ocupa Jenkins: se publica en el 8081.
- La URL de conexión usa el **nombre del servicio** y el puerto **interno** de PostgreSQL (5432). Si además se publica `db` para pgAdmin, el puerto del equipo no puede ser el 5432, que ocupa el PostgreSQL de Windows.
- PostgreSQL guarda sus datos en `/var/lib/postgresql/data`. El volumen se declara dos veces: en el servicio (donde se monta) y en el bloque `volumes` del final.
- Para el `healthcheck` sirve el comando `pg_isready -U postgres -d contactos`, con `CMD-SHELL`.
- Para esperar a que `db` esté sano, `depends_on` lleva `condition: service_healthy`.
- El YAML se sangra con **dos espacios**, nunca con tabuladores. Si algo falla, `docker compose config` indica la línea.
- Los nombres de los recursos llevan el nombre de la carpeta del proyecto (`contactos-compose-base_pgdata`, por ejemplo).

---

## Práctica 2: Credenciales fuera del fichero

En la Práctica 1 la contraseña `secreto` está escrita en el `docker-compose.yml`, y el fichero se sube a Git junto con el código. Se va a sacar a un fichero `.env` que no se versiona. Se trabaja sobre el mismo proyecto.

**Pasos**
1. Creamos junto al `docker-compose.yml` un fichero `.env` con las variables `DB_USER`, `DB_PASSWORD` y `DB_NAME`, con los valores que usábamos.
2. En el `docker-compose.yml` sustituimos los valores escritos por `${DB_USER}`, `${DB_PASSWORD}` y `${DB_NAME}` en **todos** los sitios donde aparecían: variables de `db`, variables de `api` y `healthcheck`.
3. Comprobamos con `docker compose config` que Compose sustituye las variables: la salida tiene que mostrar los valores del `.env`.
4. Arrancamos con `docker compose up -d` y comprobamos que la API funciona como antes.
5. Cambiamos en el `.env` el valor de `DB_PASSWORD` y ejecutamos `docker compose config`: la salida cambia. Restauramos el valor.
6. Borramos el `.env` (o lo renombramos) y ejecutamos `docker compose config`. Leemos el aviso que da Compose. Lo restauramos.
7. Inicializamos un repositorio Git en la carpeta (`git init`) y comprobamos con `git status` que `.env` aparece como fichero sin seguimiento.
8. Creamos el fichero `.gitignore` con `.env` y `target/`, y comprobamos con `git status` que `.env` ya no aparece.
9. Creamos un fichero `.env.example` con los mismos nombres de variable, sin la contraseña, y comprobamos que este sí aparece en `git status`.
10. Terminamos con `docker compose down -v`.

**Pistas**
- Dentro del `.env` se escribe una variable por línea, `NOMBRE=valor`, sin espacios alrededor del signo igual ni comillas.
- En el `docker-compose.yml`, `${NOMBRE}` se sustituye por el valor del `.env`, que tiene que estar en la misma carpeta que el fichero.
- Si una variable no está definida, Compose la sustituye por una cadena vacía y avisa con `The "NOMBRE" variable is not set. Defaulting to a blank string.`
- Un `healthcheck` con `pg_isready -U ${DB_USER}` también lleva variable: si se olvida, el servicio nunca pasa a `healthy`.
- `.gitignore` se escribe como una lista de nombres de fichero o carpeta, uno por línea (S11-1). El fichero que se ignora no aparece en `git status`.
- Las variables `POSTGRES_*` solo se aplican cuando el volumen está vacío. Si cambiamos `DB_PASSWORD` con datos ya creados y arrancamos, la API fallará con un error de autenticación. En este ejercicio el cambio de valor solo se prueba con `docker compose config`, que no arranca nada.
- Un `.env.example` es la plantilla que se sube a Git: dice qué variables hacen falta sin decir sus valores secretos.

---

## Práctica 3: Docker Compose en el proyecto del grupo

Cada grupo tiene su proyecto (S05 en adelante). Se escribe un `docker-compose.yml` que lo ponga en marcha junto con su base de datos. Esta práctica se hace sobre el proyecto del grupo, no hay zip. Si el proyecto del grupo no usa PostgreSQL, se adapta al servicio que use (la teoría y las demos son válidas para cualquier base de datos con imagen oficial; para MongoDB, la imagen es `mongo` y el volumen se monta en `/data/db`).

**Pasos**
1. En grupo, decidimos qué piezas tiene el proyecto: la aplicación Spring Boot y qué base de datos usa. Hacemos una lista de las variables de entorno que necesita la aplicación para conectarse.
2. Comprobamos que `application.properties` lee de variables de entorno los datos de la conexión, con la sintaxis `${NOMBRE:valor}`. Si no es así, lo cambiamos.
3. Escribimos el `Dockerfile` de la aplicación (como en S16-1), construimos el JAR y la imagen.
4. Escribimos el `docker-compose.yml` del proyecto con la aplicación y la base de datos, con volumen, `healthcheck` y `depends_on`. Las credenciales van en un `.env` y se añaden al `.gitignore`.
5. Arrancamos el proyecto con `docker compose up -d` y probamos que funciona desde el navegador o Postman.
6. Comprobamos que los datos sobreviven a `docker compose down` y `up -d`.
7. Subimos a Git el `Dockerfile`, el `docker-compose.yml`, el `.gitignore` y el `.env.example`. El `.env` no se sube.
8. Otro miembro del grupo clona el repositorio en su equipo, crea su `.env` a partir del `.env.example` y levanta el proyecto con un solo comando.

**Pistas**
- Lo habitual es repartir el trabajo: una persona escribe el `Dockerfile`, otra el `docker-compose.yml` y una tercera el `.env`. Lo importante es que las tres piezas encajen en nombres de variable.
- Los puertos del equipo no pueden repetirse entre miembros del grupo que trabajan en el mismo PC: 8081 y 5433 son los de las demos.
- Quien clona el repositorio no tiene la imagen de la aplicación: necesita construirla (con el JAR) o descargarla de un registro. Para evitar el segundo paso, se puede usar `build: .` en el servicio de la aplicación y `docker compose up --build`, después de ejecutar `mvn clean package -DskipTests`.
- Si la aplicación del grupo usa pruebas que necesitan la base de datos, `-DskipTests` evita que Maven falle al empaquetar.
- Si algo no arranca, el orden de comprobación es: `docker compose ps` (¿está `healthy`?), `docker compose logs servicio` (¿qué dice?) y `docker compose config` (¿qué valores ha sustituido?).
