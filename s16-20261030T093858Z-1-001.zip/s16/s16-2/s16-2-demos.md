# S16-2 Demos

## Objetivos

En S16-1 empaquetamos una aplicación Spring Boot en una imagen y la ejecutamos con `docker run`. Esa aplicación no tenía base de datos: guardaba los contactos en una lista, y desaparecían al borrar el contenedor. En esta parte la API de contactos guarda los datos en **PostgreSQL**, que también se ejecuta en un contenedor, y las dos piezas se ponen en marcha con **un solo comando** gracias a Docker Compose.

La explicación de los conceptos (volúmenes, redes, PostgreSQL en un contenedor, formato YAML, claves de un servicio, comandos de Compose) está en `s16-2-teoria.md`, que se cuenta antes de las demos. Aquí se aplican con ficheros y comandos reales.

| Demo | Qué se hace | Qué se aprende |
|---|---|---|
| 1 | Un `docker-compose.yml` mínimo con `nginx` | Estructura del fichero y los comandos `up`, `ps`, `logs` y `down` |
| 2 | La API de contactos y PostgreSQL en un solo fichero | Imagen, variables, puertos, volumen, red por nombre, `healthcheck` y `depends_on` |
| 3 | Los datos frente a `down` y `down -v` | Qué conserva y qué borra cada orden |

Al terminar esta parte los alumnos son capaces de:
- Escribir un `docker-compose.yml` con `services`, `image`, `ports`, `environment` y `volumes`, y levantarlo con `docker compose up -d`.
- Explicar por qué la API se conecta a la base de datos con `db:5432` y no con `localhost:5433`.
- Hacer que la API espere a que PostgreSQL esté listo con `healthcheck` y `depends_on`.
- Comprobar que los datos sobreviven a `docker compose down` y desaparecen con `docker compose down -v`.
- Conectarse con pgAdmin a la base de datos que corre en el contenedor.

---

## Antes de empezar

### Las imágenes que hacen falta

Esta parte usa tres imágenes. Como en S16-1, la red del aula bloquea Docker Hub y cada imagen se consigue con la variante A, B o C que ya se estableció (apartado "Antes de empezar" de `s16-1-demos.md`):

| Imagen | Se usa en | Variante A: Docker Hub | Variante B: espejo | Variante C: Drive |
|---|---|---|---|---|
| `nginx` | Demo 1 | `docker pull nginx` | `docker pull mirror.gcr.io/library/nginx`, `docker tag` y `docker rmi` | `docker load -i nginx.tar` |
| `eclipse-temurin:21-jre` | Demo 2 (base de la imagen de la API) | `docker pull eclipse-temurin:21-jre` | Igual que `nginx`, con `eclipse-temurin:21-jre` | `docker load -i eclipse-temurin.tar` |
| `postgres:16` | Demos 2 y 3 | `docker pull postgres:16` | Igual que `nginx`, con `postgres:16` | `docker load -i postgres.tar` |

Si `nginx` y `eclipse-temurin:21-jre` ya están en el equipo desde S16-1, no hay que conseguirlas otra vez. Se comprueba con:

```bash
docker images
```

La regla es la de S16-1: las imágenes tienen que acabar con **el nombre corto** (`nginx`, `eclipse-temurin:21-jre`, `postgres:16`). Compose usa ese nombre, y si la imagen ya está en el equipo, no intenta descargarla. Con la variante B, por ejemplo para PostgreSQL:

```bash
docker pull mirror.gcr.io/library/postgres:16
```

```bash
docker tag mirror.gcr.io/library/postgres:16 postgres:16
```

```bash
docker rmi mirror.gcr.io/library/postgres:16
```

Con la variante C, desde la carpeta `imagenes-docker` del Drive (`postgres.tar` pesa unos 160 MB, conviene descargarlo antes de la sesión):

```bash
docker load -i postgres.tar
```

### Comprobar Docker Compose y los contenedores

```bash
docker compose version
```

<pre>
C:\Users\Mananas>docker compose version
Docker Compose version v5.6.1
</pre>

Compose viene incluido en Docker Desktop: no se instala nada. Se escribe `docker compose` (dos palabras). El número de versión puede ser otro. Y comprobamos que no quedan contenedores de la parte anterior:

```bash
docker ps -a
```

La lista debería salir vacía. Si queda alguno, lo borramos con `docker rm -f nombre`.

---

## Demo 1: Un primer docker-compose.yml con nginx

El fichero más pequeño que tiene sentido: un solo servicio. Sirve para ver la estructura de un fichero Compose y los cuatro comandos que se usan cada día. El proyecto está en `s16-2-demos.zip`, carpeta `compose-nginx`. No es un proyecto de Maven: solo contiene el fichero, así que no se abre en IntelliJ. Abrimos un `cmd` dentro de la carpeta:

```bash
cd C:\Users\Mananas\compose-nginx
```

### El fichero

```yaml
# S16-2 Demo 1: Primer docker-compose.yml
#
# Objetivo: levantar un servidor web nginx con un solo comando: docker compose up -d
#
# Aplica las técnicas de S16:
#   1. Un servicio con su imagen y su puerto publicado.
#   2. La equivalencia con docker run: este fichero hace lo mismo que
#      docker run -d --name web -p 8081:80 nginx
#
# Concepto clave: Compose no añade conceptos nuevos. Las opciones de docker run que
# ya conocemos (imagen, nombre, puerto) pasan a ser líneas de un fichero que se versiona.

services:
  # El nombre del servicio (web) es el nombre con el que los demás servicios lo encuentran.
  web:
    # Imagen con etiqueta fija (S16-1).
    image: nginx:latest
    ports:
      # Puerto 8081 del equipo hacia el 80 del contenedor. Va entre comillas para que
      # YAML lo lea como texto y no como otro tipo de dato.
      - "8081:80"
```

Se lee de arriba abajo:

- **`services:`** es el bloque de los contenedores de la aplicación. Es el único obligatorio.
- **`web:`** (con dos espacios de sangría) es el nombre del servicio. Es una descripción de un contenedor, y su nombre es también el nombre con el que los demás contenedores lo encontrarían en la red.
- **`image: nginx:latest`** es la imagen de la que se crea el contenedor. En S16-1 vimos que `latest` no garantiza una versión concreta; para esta demo da igual.
- **`ports:`** es una lista (cada elemento empieza por un guion). `"8081:80"` es la opción `-p 8081:80` de `docker run`: el 8081 del equipo va al 80 del contenedor. Va entre comillas para que YAML no lo confunda con otro tipo de dato.

Es equivalente a este comando de S16-1, que ahora no hace falta escribir:

```bash
docker run -d --name web -p 8081:80 nginx
```

La sangría es de **dos espacios**, siempre. En YAML un espacio de más o de menos cambia el significado, y un tabulador es un error.

### Comprobar el fichero

Antes de arrancar nada, Compose puede comprobar que el fichero está bien escrito:

```bash
docker compose config
```

`docker compose config` lee el fichero, comprueba la sintaxis y lo muestra ya completo, con todos los valores por defecto escritos. Si hay un error de sangría, lo dice aquí y no al arrancar:

<pre>
C:\Users\Mananas\compose-nginx>docker compose config
name: compose-nginx
services:
  web:
    image: nginx:latest
    networks:
      default: null
    ports:
      - mode: ingress
        target: 80
        published: "8081"
        protocol: tcp
networks:
  default:
    name: compose-nginx_default
</pre>

Compose ha añadido cosas que no escribimos: `name: compose-nginx` es el nombre del **proyecto**, que por defecto es el de la carpeta, y una red llamada `compose-nginx_default`. Los dos nombres van a aparecer enseguida en todos los recursos que cree.

### Arrancar

```bash
docker compose up -d
```

`up` crea la red, los volúmenes y los contenedores que describe el fichero, y los arranca. `-d` (*detach*) lo deja en segundo plano, como en `docker run -d`. Sin `-d`, la terminal se queda ocupada mostrando los registros hasta pulsar `Ctrl+C`.

<pre>
C:\Users\Mananas\compose-nginx>docker compose up -d
 Network compose-nginx_default Creating
 Network compose-nginx_default Created
 Container compose-nginx-web-1 Creating
 Container compose-nginx-web-1 Created
 Container compose-nginx-web-1 Starting
 Container compose-nginx-web-1 Started
</pre>

Compose crea la red y después el contenedor. El nombre del contenedor se forma con el del proyecto, el del servicio y un número: `compose-nginx-web-1`. Abrimos `http://localhost:8081` en el navegador: aparece "Welcome to nginx!".

### Ver el estado y los registros

```bash
docker compose ps
```

<pre>
C:\Users\Mananas\compose-nginx>docker compose ps
NAME                  IMAGE          COMMAND                  SERVICE   CREATED          STATUS          PORTS
compose-nginx-web-1   nginx:latest   "/docker-entrypoint.…"   web       12 seconds ago   Up 11 seconds   0.0.0.0:8081->80/tcp
</pre>

Es como `docker ps`, pero solo muestra los contenedores de este proyecto, y trae la columna `SERVICE`, con el nombre que escribimos en el fichero. Los registros:

```bash
docker compose logs
```

<pre>
C:\Users\Mananas\compose-nginx>docker compose logs
web-1  | /docker-entrypoint.sh: Configuration complete; ready for start up
web-1  | 172.18.0.1 - - [28/Oct/2026:09:41:12 +0000] "GET / HTTP/1.1" 200 615 "-" "Mozilla/5.0 ..." "-"
</pre>

Cada línea empieza por el nombre del servicio (`web-1`), que sirve para distinguirlos cuando hay varios. La segunda línea es nuestra visita desde el navegador. Con `docker compose logs -f web` se siguen los registros de un servicio hasta pulsar `Ctrl+C`.

### Una herramienta más: entrar en el servicio

```bash
docker compose exec web ls /usr/share/nginx/html
```

`docker compose exec servicio comando` ejecuta un comando **dentro de un contenedor en marcha**. Aquí lista la carpeta de la que nginx sirve la página que hemos visto:

<pre>
C:\Users\Mananas\compose-nginx>docker compose exec web ls /usr/share/nginx/html
50x.html  index.html
</pre>

Se usa el nombre del servicio (`web`), no el del contenedor. Lo usaremos en la Demo 3 para entrar en PostgreSQL.

### Parar y borrar

```bash
docker compose down
```

<pre>
C:\Users\Mananas\compose-nginx>docker compose down
 Container compose-nginx-web-1 Stopping
 Container compose-nginx-web-1 Stopped
 Container compose-nginx-web-1 Removing
 Container compose-nginx-web-1 Removed
 Network compose-nginx_default Removing
 Network compose-nginx_default Removed
</pre>

`down` hace lo contrario que `up`: para y **borra** los contenedores y la red. Comprobamos que no queda nada:

```bash
docker ps -a
```

Con un solo servicio no se nota la ventaja. Con dos o tres, `up` y `down` siguen siendo un solo comando cada uno. Es lo que vemos en la Demo 2.

### Un error de sangría

Comprobamos qué ocurre con un fichero mal escrito. En `docker-compose.yml`, quitamos la sangría de la línea `image` (que quede pegada al margen izquierdo) y ejecutamos:

```bash
docker compose config
```

<pre>
C:\Users\Mananas\compose-nginx>docker compose config
go-yaml load error in scanner at L18.C10: mapping values are not allowed in this context
</pre>

El mensaje indica la línea y la columna (`L18.C10`), pero apunta a **donde el lector de YAML se pierde**, que suele ser la línea siguiente a la equivocada. Aquí señala la línea de `ports:`, cuando el fallo está en `image`. El texto exacto depende de la versión de Compose (en otras sale `yaml: line 18: mapping values are not allowed in this context`). Se corrige restaurando los dos espacios.

El otro error clásico es escribir un **tabulador** en lugar de espacios. El mensaje es `found character that cannot start any token`. IntelliJ avisa, pero el Bloc de notas no. Volvemos a dejar el fichero como estaba.

### Resumen de comandos

| Comando | Qué hace |
|---|---|
| `docker compose config` | Comprueba el fichero y lo muestra completo |
| `docker compose up -d` | Crea y arranca todo lo del fichero, en segundo plano |
| `docker compose ps` | Lista los contenedores del proyecto |
| `docker compose logs` | Muestra la salida de todos los servicios |
| `docker compose exec servicio comando` | Ejecuta un comando dentro de un servicio en marcha |
| `docker compose down` | Para y borra los contenedores y la red |

---

## Demo 2: La API de contactos y su base de datos PostgreSQL

La API de contactos de S16-1 guardaba los datos en una lista en memoria. Ahora los guarda en PostgreSQL con Spring Data JPA (S06-2), y la base de datos corre en otro contenedor. El objetivo es ponerlo todo en marcha con `docker compose up -d`.

El plan tiene seis pasos: ver el proyecto, construir el JAR y la imagen de la API, conseguir la imagen de PostgreSQL, leer el `docker-compose.yml`, arrancar y probar, y mirar la base de datos con pgAdmin.

### El proyecto

El proyecto está en `s16-2-demos.zip`, carpeta `contactos-db`. Lo descomprimimos y lo abrimos en IntelliJ con `File > Open`, eligiendo la carpeta `contactos-db` (la que contiene directamente el `pom.xml`). Pulsamos `Trust Project` y, si aparece el aviso, `Load` (S06-1).

Se creó con el asistente de IntelliJ (Spring Boot, Build system Maven, S05-1) con Group `com.curso`, Artifact `contactos-db`, JDK `21`, Spring Boot `4.1.1` y las dependencias `Spring Web`, `Spring Data JPA`, `PostgreSQL Driver` y `Lombok`. Las clases son las de la API de contactos de S06-2: la entidad `Contacto`, el repositorio y el controlador. Lo único nuevo para esta parte es cómo se configura la conexión.

La entidad es una tabla de PostgreSQL (S06-2):

```java
package com.curso.model;

// Entity, Id, GeneratedValue, GenerationType y Column proceden de jakarta.persistence (S06-1),
// que trae spring-boot-starter-data-jpa.
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

// Getter, NoArgsConstructor y Setter proceden de la librería Lombok (S11-1).
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * S16-2 Demo 2: Contacto como entidad de PostgreSQL
 *
 * Objetivo: guardar los contactos en una tabla de PostgreSQL en lugar de en una lista.
 *
 * Aplica las técnicas de S16:
 *   1. @Entity y @Id, como en S06-1.
 *   2. Lombok para generar getters, setters y el constructor vacío (S11-1).
 *
 * Concepto clave: la clase es casi la misma de S16-1. Solo se le añaden las anotaciones de
 * JPA, y los datos pasan a vivir en PostgreSQL, que a su vez guarda los ficheros en un volumen.
 */
// @Entity indica que cada objeto de esta clase es una fila de la tabla "contacto".
@Entity
// @Getter y @Setter generan un getter y un setter por cada campo (S11-1).
@Getter
@Setter
// @NoArgsConstructor genera el constructor vacío que Hibernate y Jackson necesitan.
@NoArgsConstructor
public class Contacto {

    // Clave primaria. IDENTITY hace que PostgreSQL genere el número (1, 2, 3...) al insertar.
    // Es Long (no long) porque un contacto nuevo todavía no lo tiene.
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // nullable = false: la columna es obligatoria. Un POST sin nombre falla al guardar.
    @Column(nullable = false)
    private String nombre;

    private String email;

    // El teléfono es opcional: puede ser null.
    private String telefono;

    // Constructor con los datos del contacto, sin el id, que lo genera la base de datos.
    public Contacto(String nombre, String email, String telefono) {
        this.nombre = nombre;
        this.email = email;
        this.telefono = telefono;
    }
}
```

El repositorio es una interfaz que hereda de `JpaRepository` (S06-2), y Spring Data genera la implementación:

```java
package com.curso.repository;

// JpaRepository procede de spring-data-jpa, que trae el starter.
import org.springframework.data.jpa.repository.JpaRepository;

import com.curso.model.Contacto;

/**
 * S16-2 Demo 2: Repositorio de contactos con PostgreSQL
 *
 * Objetivo: guardar y buscar contactos en la base de datos.
 *
 * Aplica las técnicas de S16:
 *   1. Un repositorio de Spring Data declarado como interfaz vacía (S06-1).
 *   2. Los mismos nombres de método que tenía la clase en memoria de S16-1:
 *      findAll, findById y save.
 *
 * Concepto clave: el controlador no cambia al pasar de memoria a PostgreSQL, porque los
 * métodos se llaman igual. Spring Data escribe la implementación al arrancar.
 */
public interface ContactoRepository extends JpaRepository<Contacto, Long> {
}
```

El controlador expone las tres rutas de siempre, `GET /api/contactos`, `GET /api/contactos/{id}` (404 si no existe) y `POST /api/contactos` (201):

```java
package com.curso.controller;

import java.util.List;

// Estas clases proceden de spring-web, que trae spring-boot-starter-webmvc.
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.curso.model.Contacto;
import com.curso.repository.ContactoRepository;

// RequiredArgsConstructor procede de Lombok (S11-1).
import lombok.RequiredArgsConstructor;

/**
 * S16-2 Demo 2: API REST de contactos con PostgreSQL
 *
 * Objetivo: ofrecer tres operaciones sobre los contactos para comprobar que los datos
 * se guardan en PostgreSQL y sobreviven al borrado de los contenedores.
 *
 * Aplica las técnicas de S16:
 *   1. Una API REST con GET y POST (S09).
 *   2. Un código de respuesta distinto según el caso: 200, 201 y 404.
 *
 * Concepto clave: este controlador es el mismo de S16-1, línea por línea. El cambio de
 * lista en memoria a PostgreSQL no le afecta.
 */
@RestController
@RequestMapping("/api/contactos")
// @RequiredArgsConstructor genera el constructor con un parámetro por cada campo final (S11-1).
// Spring lo usa para entregar el repositorio (inyección por constructor, S06-1).
@RequiredArgsConstructor
public class ContactoController {

    private final ContactoRepository contactoRepository;

    /**
     * Lista todos los contactos.
     *
     * Ejemplo:
     *   GET /api/contactos  →  200 con [{"nombre":"Lucía Pérez","email":"lucia@example.com","telefono":null,"id":1}]
     *   GET /api/contactos  →  200 con [] si la tabla está vacía
     */
    @GetMapping
    public List<Contacto> listar() {
        return contactoRepository.findAll();
    }

    /**
     * Devuelve un contacto por su id.
     *
     * Ejemplo:
     *   GET /api/contactos/1   →  200 con {"nombre":"Lucía Pérez","email":"lucia@example.com","telefono":null,"id":1}
     *   GET /api/contactos/99  →  404 sin cuerpo
     */
    @GetMapping("/{id}")
    public ResponseEntity<Contacto> obtener(@PathVariable Long id) {
        // map() convierte el contacto, si existe, en una respuesta 200 con el contacto dentro;
        // orElse() devuelve el 404 cuando el Optional está vacío (S09).
        return contactoRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Crea un contacto nuevo.
     *
     * Ejemplo:
     *   POST /api/contactos con {"nombre":"Lucía Pérez","email":"lucia@example.com"}
     *       →  201 con {"nombre":"Lucía Pérez","email":"lucia@example.com","telefono":null,"id":1}
     */
    @PostMapping
    // @RequestBody convierte el JSON del cuerpo de la petición en un objeto Contacto (S09).
    public ResponseEntity<Contacto> crear(@RequestBody Contacto contacto) {
        // Anulamos el id recibido para que save() siempre inserte una fila nueva (S09).
        contacto.setId(null);
        Contacto guardado = contactoRepository.save(contacto);
        // 201 (Created) indica que se ha creado el recurso; el cuerpo lleva el contacto con su id.
        return ResponseEntity.status(HttpStatus.CREATED).body(guardado);
    }
}
```

### La conexión se lee de variables de entorno

Lo importante está en `application.properties`:

```properties
# Nombre de la aplicación: aparece entre corchetes en cada línea del log (S05-1).
spring.application.name=contactos-db

# Datos de la conexión con PostgreSQL. Cada valor se lee de una variable de entorno (S16-1):
# ${NOMBRE:valor} es "la variable NOMBRE, y si no existe, valor".
#
# DB_URL: dirección de la base de datos. Por defecto, el PostgreSQL de Windows (localhost:5432).
# Dentro de Docker Compose se sustituye por jdbc:postgresql://db:5432/contactos, donde "db"
# es el nombre del servicio de PostgreSQL en el docker-compose.yml.
spring.datasource.url=${DB_URL:jdbc:postgresql://localhost:5432/contactos}
spring.datasource.username=${DB_USER:postgres}
# La contraseña no tiene valor por defecto: nunca se escribe en un fichero que se versiona (S07).
spring.datasource.password=${DB_PASSWORD}

# update: Hibernate crea la tabla "contacto" si no existe y no toca sus datos al arrancar.
# Es lo cómodo para una demo. En un proyecto real el esquema lo gestiona un script (S07).
spring.jpa.hibernate.ddl-auto=update

# Desactivamos el aviso de open-in-view que Spring Boot escribe al arrancar (S06-1).
spring.jpa.open-in-view=false
```

Cada dato de la conexión es `${NOMBRE:valor}`: la variable de entorno `NOMBRE`, y si no existe, el valor de después de los dos puntos (S16-1). Así la **misma** aplicación funciona de dos maneras sin cambiar nada:

| Dónde se ejecuta | Qué ocurre |
|---|---|
| En IntelliJ o con `java -jar`, sin variables | Usa los valores por defecto: el PostgreSQL de Windows, `localhost:5432` |
| En un contenedor, con las variables de Compose | Usa la dirección `db:5432` y la contraseña del fichero |

La contraseña no tiene valor por defecto a propósito: no se escribe en un fichero que se versiona (S07). Sin la variable `DB_PASSWORD`, la aplicación no arranca. `ddl-auto=update` hace que Hibernate cree la tabla `contacto` la primera vez; es cómodo para una demo, y en un proyecto real el esquema lo gestiona un script (S07).

### Paso 1: construir el JAR

En la terminal de IntelliJ (`Alt+F12`):

```bash
mvn clean package -DskipTests
```

El proyecto trae una prueba, `AplicacionTests`, que arranca la aplicación entera para ver que el contexto de Spring se crea. Para eso necesita conectar con la base de datos, y en este momento no hay ninguna disponible desde Maven (la de PostgreSQL de Windows tiene otra contraseña, y la del contenedor aún no existe). Sin `-DskipTests`, la compilación fallaría. `-DskipTests` compila el código pero no ejecuta las pruebas. Salida esperada (abreviada):

<pre>
[INFO] Scanning for projects...
[INFO] -------------------------< com.curso:contactos-db >-------------------------
[INFO] Building contactos-db 0.0.1-SNAPSHOT
[INFO] --- clean:3.5.0:clean (default-clean) @ contactos-db ---
[INFO] --- compiler:3.15.0:compile (default-compile) @ contactos-db ---
[INFO] Compiling 4 source files with javac [debug parameters release 21] to target/classes
[INFO] --- surefire:3.5.6:test (default-test) @ contactos-db ---
[INFO] Tests are skipped.
[INFO] --- jar:3.5.1:jar (default-jar) @ contactos-db ---
[INFO] --- spring-boot:4.1.1:repackage (repackage) @ contactos-db ---
[INFO] BUILD SUCCESS
</pre>

El JAR es `target\contactos-db-0.0.1-SNAPSHOT.jar` y pesa unos 50 MB: lleva dentro Hibernate, el controlador de PostgreSQL y las demás librerías.

### Paso 2: la imagen de la API

Con `eclipse-temurin:21-jre` ya en el equipo (apartado "Antes de empezar"), el `Dockerfile` es el de S16-1 con otro nombre de JAR:

```dockerfile
# S16-2 Demo 2: Dockerfile de la API de contactos con PostgreSQL
#
# Objetivo: empaquetar la API de contactos en una imagen de Docker.
#
# Aplica las técnicas de S16:
#   1. FROM con una imagen que ya trae Java.
#   2. COPY del JAR que construye Maven en nuestro equipo.
#   3. EXPOSE y ENTRYPOINT para documentar el puerto y arrancar la aplicación.
#
# Concepto clave: es el mismo Dockerfile de S16-1 con otro nombre de JAR. La conexión con
# PostgreSQL no se escribe aquí: la aplicación la lee de las variables DB_URL, DB_USER y
# DB_PASSWORD, que define el docker-compose.yml al crear el contenedor.
#
# Se construye con:  docker build -t contactos-db:1.0 .
# (el JAR tiene que existir antes: se genera con mvn clean package -DskipTests)

# Partimos de la imagen oficial con Java 21 y solo el JRE: basta para ejecutar un JAR ya compilado.
FROM eclipse-temurin:21-jre

# Copiamos el JAR de Spring Boot que dejó Maven en target/. El nombre es artifactId-version.jar.
COPY target/contactos-db-0.0.1-SNAPSHOT.jar app.jar

# La aplicación escucha en el puerto 8080 del contenedor. EXPOSE solo lo anota: para llegar
# desde Windows hay que publicarlo con "ports" en el docker-compose.yml (o con -p en docker run).
EXPOSE 8080

# Comando que se ejecuta al arrancar un contenedor de esta imagen: java -jar app.jar.
ENTRYPOINT ["java", "-jar", "app.jar"]
```

Observamos que **no** hay ninguna referencia a PostgreSQL ni a contraseñas: la imagen es la misma para cualquier base de datos, y los datos de la conexión llegan al crear el contenedor. Construimos la imagen:

```bash
docker build -t contactos-db:1.0 .
```

Comprobamos que existe:

```bash
docker images
```

<pre>
C:\Users\Mananas\contactos-db>docker images
IMAGE                    ID             DISK USAGE   CONTENT SIZE   EXTRA
contactos-db:1.0         5b0e8c7d3a21        364MB          171MB
eclipse-temurin:21-jre   1a66e3b47da9        314MB          121MB
nginx:latest             a1b2c3d4e5f6        243MB         66.8MB
postgres:16              c4d9e1f02b83        454MB          161MB
</pre>

Los identificadores y tamaños son orientativos. Debe aparecer `postgres:16` (si no está, volvemos al apartado "Antes de empezar").

### Paso 3: el fichero docker-compose.yml

Está en la raíz del proyecto, junto al `pom.xml`:

```yaml
# S16-2 Demo 2: La API de contactos y su base de datos PostgreSQL
#
# Objetivo: levantar la API y PostgreSQL con un solo comando: docker compose up -d
#
# Aplica las técnicas de S16:
#   1. Dos servicios (db y api) que Compose conecta en una red propia, por nombre.
#   2. Un volumen para que los datos de PostgreSQL sobrevivan al borrado de los contenedores.
#   3. Una comprobación de salud para que la API espere a que la base de datos esté lista.
#
# Concepto clave: cada línea es una opción de "docker run" escrita en otro formato.
# La sangría (dos espacios, nunca tabuladores) forma parte de la sintaxis de YAML.

services:

  # Servicio de la base de datos. Su nombre, "db", es también su nombre en la red:
  # la API lo encuentra con jdbc:postgresql://db:5432/contactos.
  db:
    # Imagen con etiqueta fija (S16-1). Si ya está en el equipo, Compose no la descarga.
    image: postgres:16
    environment:
      # Contraseña del superusuario "postgres". Obligatoria en la imagen de PostgreSQL.
      POSTGRES_PASSWORD: secreto
      # Base de datos que se crea la primera vez que arranca con el volumen vacío.
      POSTGRES_DB: contactos
    ports:
      # Publicamos PostgreSQL en el 5433 del equipo solo para conectarnos con pgAdmin.
      # El 5432 lo ocupa el PostgreSQL instalado en Windows. La API NO usa este puerto.
      - "5433:5432"
    volumes:
      # Volumen con nombre "pgdata" montado en la carpeta donde PostgreSQL guarda sus datos.
      - pgdata:/var/lib/postgresql/data
    healthcheck:
      # pg_isready responde con éxito cuando PostgreSQL ya acepta conexiones.
      test: ["CMD-SHELL", "pg_isready -U postgres -d contactos"]
      interval: 5s
      timeout: 3s
      retries: 10

  # Servicio de la API. Usa la imagen que construimos con docker build.
  api:
    image: contactos-db:1.0
    ports:
      # Puerto 8081 del equipo (el 8080 lo ocupa Jenkins) hacia el 8080 del contenedor.
      - "8081:8080"
    environment:
      # Dentro de la red de Compose se usa el nombre del servicio y el puerto INTERNO (5432),
      # nunca localhost ni el 5433.
      DB_URL: jdbc:postgresql://db:5432/contactos
      DB_USER: postgres
      DB_PASSWORD: secreto
    depends_on:
      db:
        # No basta con que el contenedor de la base de datos haya arrancado:
        # la API espera a que pase la comprobación de salud.
        condition: service_healthy

# Volúmenes con nombre que usan los servicios. Compose los crea la primera vez.
volumes:
  pgdata:
```

Lo recorremos servicio por servicio.

**El servicio `db` (PostgreSQL)**

| Clave | Qué hace |
|---|---|
| `image: postgres:16` | La imagen oficial de PostgreSQL, con etiqueta fija |
| `POSTGRES_PASSWORD: secreto` | Contraseña del superusuario `postgres`. La imagen la exige |
| `POSTGRES_DB: contactos` | Crea la base de datos `contactos` la primera vez que arranca |
| `ports: "5433:5432"` | El 5433 del equipo va al 5432 del contenedor. Solo sirve para que pgAdmin llegue desde Windows |
| `volumes: pgdata:/var/lib/postgresql/data` | Guarda los datos en el volumen `pgdata`, para que sobrevivan |
| `healthcheck` | Cada 5 segundos ejecuta `pg_isready` dentro del contenedor. Si responde bien, el servicio está sano |

**El servicio `api`**

| Clave | Qué hace |
|---|---|
| `image: contactos-db:1.0` | La imagen que acabamos de construir |
| `ports: "8081:8080"` | La API de Spring Boot escucha en el 8080 del contenedor; en Windows usamos el 8081 porque el 8080 lo ocupa Jenkins |
| `DB_URL: jdbc:postgresql://db:5432/contactos` | La dirección de la base de datos |
| `DB_USER`, `DB_PASSWORD` | Usuario y contraseña. Tienen que coincidir con los del servicio `db` |
| `depends_on` con `condition: service_healthy` | No arrancar `api` hasta que `db` pase su comprobación de salud |

Las dos líneas en las que hay que fijarse más son estas:

1. **`DB_URL` usa `db:5432`**, no `localhost:5433`. Dentro del contenedor de la API, `localhost` es la propia API (teoría, apartado 2). Compose crea una red en la que cada servicio se encuentra por su nombre, y `db` es el nombre del servicio de PostgreSQL. El puerto es el **interno** (5432), porque la conexión no sale de la red de Docker: el 5433 solo existe en Windows.
2. **`depends_on` con `service_healthy`**. Con `depends_on: - db` a secas, Compose solo esperaría a que el contenedor de PostgreSQL hubiera **arrancado**, y PostgreSQL tarda unos segundos más en aceptar conexiones. La API arrancaría antes, no podría conectar y se pararía con un error. Con `service_healthy`, Compose espera a que `pg_isready` responda bien.

### Paso 4: arrancar

```bash
docker compose up -d
```

Compose crea la red y el volumen, arranca `db`, espera a que esté sano y entonces arranca `api`. Se ve en el orden de las líneas:

<pre>
C:\Users\Mananas\contactos-db>docker compose up -d
 Network contactos-db_default Creating
 Volume contactos-db_pgdata Creating
 Volume contactos-db_pgdata Created
 Network contactos-db_default Created
 Container contactos-db-db-1 Creating
 Container contactos-db-db-1 Created
 Container contactos-db-api-1 Creating
 Container contactos-db-api-1 Created
 Container contactos-db-db-1 Starting
 Container contactos-db-db-1 Started
 Container contactos-db-db-1 Waiting
 Container contactos-db-db-1 Healthy
 Container contactos-db-api-1 Starting
 Container contactos-db-api-1 Started
</pre>

Las líneas `Waiting` y `Healthy` de `db` aparecen **antes** de `Starting` de `api`: es `depends_on` funcionando. Los nombres son el del proyecto (la carpeta, `contactos-db`), el del servicio y un número. El volumen se llama `contactos-db_pgdata`, con el prefijo del proyecto. Vemos el estado:

```bash
docker compose ps
```

<pre>
C:\Users\Mananas\contactos-db>docker compose ps
NAME                 IMAGE              COMMAND                  SERVICE   CREATED         STATUS                   PORTS
contactos-db-api-1   contactos-db:1.0   "java -jar app.jar"      api       8 seconds ago   Up 1 second              0.0.0.0:8081->8080/tcp
contactos-db-db-1    postgres:16        "docker-entrypoint.s…"   db        8 seconds ago   Up 8 seconds (healthy)   0.0.0.0:5433->5432/tcp
</pre>

`(healthy)` es el resultado de la comprobación de salud. Si miramos justo después de arrancar el contenedor de PostgreSQL, aparece `(health: starting)`. Esperamos unos segundos a que Spring Boot arranque y miramos los registros de la API:

```bash
docker compose logs api
```

<pre>
C:\Users\Mananas\contactos-db>docker compose logs api
api-1  |   .   ____          _            __ _ _
...
api-1  | 2026-10-28T09:58:41.376Z  INFO 1 --- [contactos-db] [           main] com.curso.Aplicacion                     : Starting Aplicacion v0.0.1-SNAPSHOT using Java 21.0.12.1 with PID 1
api-1  | 2026-10-28T09:58:44.526Z  INFO 1 --- [contactos-db] [           main] com.zaxxer.hikari.HikariDataSource       : HikariPool-1 - Starting...
api-1  | 2026-10-28T09:58:44.774Z  INFO 1 --- [contactos-db] [           main] com.zaxxer.hikari.pool.HikariPool        : HikariPool-1 - Added connection org.postgresql.jdbc.PgConnection@3982206a
api-1  | 2026-10-28T09:58:44.777Z  INFO 1 --- [contactos-db] [           main] com.zaxxer.hikari.HikariDataSource       : HikariPool-1 - Start completed.
api-1  | 2026-10-28T09:58:47.003Z  INFO 1 --- [contactos-db] [           main] o.s.boot.tomcat.TomcatWebServer          : Tomcat started on port 8080 (http) with context path '/'
api-1  | 2026-10-28T09:58:47.024Z  INFO 1 --- [contactos-db] [           main] com.curso.Aplicacion                     : Started Aplicacion in 6.525 seconds (process running for 7.519)
</pre>

Las líneas de `HikariPool` son el pool de conexiones de Spring (S06-2): `Added connection ... PgConnection` quiere decir que la API ha conectado con PostgreSQL a través de la red de Compose. Es la prueba de que `db:5432` funciona.

### Paso 5: probar la API

En el navegador, `http://localhost:8081/api/contactos`:

<pre>
[]
</pre>

La lista está vacía: la base de datos es nueva. Creamos un contacto con Postman (S09): `POST http://localhost:8081/api/contactos`, `Body > raw > JSON`:

<pre>
{"nombre": "Lucía Pérez", "email": "lucia@example.com"}
</pre>

La respuesta es `201 Created`, con el contacto ya con su `id`:

<pre>
{"nombre":"Lucía Pérez","email":"lucia@example.com","telefono":null,"id":1}
</pre>

Volvemos a abrir `http://localhost:8081/api/contactos` y aparece en la lista. El contacto está en PostgreSQL, dentro del contenedor `db`.

### Paso 6: mirar la base de datos con pgAdmin

Podemos entrar en la base de datos del contenedor con pgAdmin (S07). Es el único motivo del `ports: "5433:5432"` del servicio `db`. En pgAdmin, `Register > Server` con estos datos:

| Campo | Valor |
|---|---|
| Name | `contactos-docker` |
| Host name/address | `localhost` |
| Port | `5433` (el puerto **publicado** en Windows) |
| Maintenance database | `contactos` |
| Username | `postgres` |
| Password | `secreto` |

Se usa el 5433 y no el 5432 porque pgAdmin está en Windows, **fuera** de Docker, y el 5432 de Windows lo ocupa el PostgreSQL instalado. Dentro de `contactos > Schemas > public > Tables` aparece la tabla `contacto`, creada por Hibernate al arrancar la API, con el registro de Lucía.

Sin pgAdmin, se puede consultar la tabla con `psql`, que ya viene en la imagen de PostgreSQL, usando `docker compose exec` de la Demo 1:

```bash
docker compose exec db psql -U postgres -d contactos -c "SELECT * FROM contacto;"
```

<pre>
C:\Users\Mananas\contactos-db>docker compose exec db psql -U postgres -d contactos -c "SELECT * FROM contacto;"
 id |       email       |   nombre    | telefono
----+-------------------+-------------+----------
  1 | lucia@example.com | Lucía Pérez |
(1 row)
</pre>

La columna `telefono` está vacía porque no la enviamos (`null`).

### Conviene saber

- **El error de `localhost`.** Si en `DB_URL` se escribe `jdbc:postgresql://localhost:5432/contactos`, la API se conecta consigo misma. La causa es la de la teoría: dentro del contenedor `localhost` es el propio contenedor. El mensaje es este:

<pre>
api-1  | ... WARN 1 --- [contactos-db] [  main] org.hibernate.orm.jdbc.error : Connection to localhost:5432 refused. Check that the hostname and port are correct and that the postmaster is accepting TCP/IP connections.
api-1  | ... Caused by: java.net.ConnectException: Connection refused
api-1  | ... ERROR 1 --- [contactos-db] [  main] j.LocalContainerEntityManagerFactoryBean : Failed to initialize JPA EntityManagerFactory
</pre>

  `Connection refused` más `localhost` es casi siempre este error. Se corrige poniendo el nombre del servicio, `db`.
- **Puertos ocupados.** Si `docker compose up` falla con `port is already allocated` o `address already in use`, el puerto del equipo (la parte izquierda de `ports`) lo usa otro programa: 8080 es Jenkins y 5432 es el PostgreSQL de Windows. Se cambia el número de la izquierda.
- **Cambios en el código.** El `docker-compose.yml` usa la imagen `contactos-db:1.0` ya construida. Si cambiamos el código, hay que repetir `mvn clean package -DskipTests` y `docker build`, y después `docker compose up -d` (que recrea solo el contenedor que ha cambiado). Con `build: .` en lugar de `image:` y `docker compose up --build`, Compose haría el `docker build` por nosotros; en esta parte usamos `image` para ver los dos pasos por separado.
- **Contraseña en el fichero.** `secreto` está escrito en el `docker-compose.yml`, y por tanto en el repositorio si se sube a Git. Es aceptable para una demo y no para un proyecto real. Se resuelve con un fichero `.env` en la Práctica 2.

### Resumen de comandos

| Comando | Qué hace |
|---|---|
| `mvn clean package -DskipTests` | Construye el JAR sin ejecutar las pruebas que necesitan base de datos |
| `docker build -t contactos-db:1.0 .` | Construye la imagen de la API |
| `docker compose up -d` | Crea la red y el volumen, y arranca `db` y después `api` |
| `docker compose ps` | Estado de los servicios, con `(healthy)` en los que tienen `healthcheck` |
| `docker compose logs api` | Registros del servicio `api` |
| `docker compose exec db psql -U postgres -d contactos -c "..."` | Ejecuta una consulta SQL dentro de PostgreSQL |

---

## Demo 3: Los datos frente a down y down -v

La API y la base de datos siguen en marcha, con un contacto guardado. Comprobamos qué hace cada orden con los datos. Es el contenido de la tabla "Qué conserva cada orden" de la teoría, ahora con comandos reales.

### Paso 1: el volumen existe aparte

```bash
docker volume ls
```

<pre>
C:\Users\Mananas\contactos-db>docker volume ls
DRIVER    VOLUME NAME
local     contactos-db_pgdata
</pre>

Es el volumen `pgdata` del fichero, con el prefijo del proyecto. Lo creó Compose en el `up`. Si hay otros volúmenes de otras pruebas, también aparecen.

### Paso 2: `down` conserva los datos

```bash
docker compose down
```

<pre>
C:\Users\Mananas\contactos-db>docker compose down
 Container contactos-db-api-1 Stopping
 Container contactos-db-api-1 Stopped
 Container contactos-db-api-1 Removing
 Container contactos-db-api-1 Removed
 Container contactos-db-db-1 Stopping
 Container contactos-db-db-1 Stopped
 Container contactos-db-db-1 Removing
 Container contactos-db-db-1 Removed
 Network contactos-db_default Removing
 Network contactos-db_default Removed
</pre>

Se han borrado los dos contenedores y la red, pero **no hay ninguna línea de `Volume`**. Se comprueba:

```bash
docker ps -a
```

```bash
docker volume ls
```

<pre>
C:\Users\Mananas\contactos-db>docker ps -a
CONTAINER ID   IMAGE     COMMAND   CREATED   STATUS    PORTS     NAMES

C:\Users\Mananas\contactos-db>docker volume ls
DRIVER    VOLUME NAME
local     contactos-db_pgdata
</pre>

No queda ningún contenedor, y el volumen sigue ahí. Volvemos a levantarlo todo:

```bash
docker compose up -d
```

<pre>
C:\Users\Mananas\contactos-db>docker compose up -d
 Network contactos-db_default Creating
 Network contactos-db_default Created
 Container contactos-db-db-1 Creating
 Container contactos-db-db-1 Created
 Container contactos-db-api-1 Creating
 Container contactos-db-api-1 Created
 Container contactos-db-db-1 Starting
 Container contactos-db-db-1 Started
 Container contactos-db-db-1 Waiting
 Container contactos-db-db-1 Healthy
 Container contactos-db-api-1 Starting
 Container contactos-db-api-1 Started
</pre>

Esta vez no aparece la línea `Volume ... Creating`: ya existe. Esperamos a que la API arranque y abrimos `http://localhost:8081/api/contactos`:

<pre>
[{"nombre":"Lucía Pérez","email":"lucia@example.com","telefono":null,"id":1}]
</pre>

**El contacto sigue ahí.** Los contenedores son nuevos, pero el contenedor `db` nuevo encontró en el volumen los datos que dejó el anterior. En S16-1, sin volumen, el contacto desaparecía al borrar el contenedor. Esta es la diferencia.

Un detalle: en este arranque PostgreSQL **no** ha vuelto a crear la base de datos ni a leer `POSTGRES_PASSWORD`, porque encontró la carpeta de datos ya inicializada. Esas variables solo se usan la primera vez (teoría, apartado 3). Se puede ver en los registros del servicio:

```bash
docker compose logs db
```

La imagen de PostgreSQL escribe al arrancar con datos existentes la línea `PostgreSQL Database directory appears to contain a database; Skipping initialization`. En el primer arranque, con el volumen vacío, escribe en su lugar `The files belonging to this database system will be owned by user "postgres"` y crea la base de datos `contactos`.

### Paso 3: `down -v` borra los datos

```bash
docker compose down -v
```

<pre>
C:\Users\Mananas\contactos-db>docker compose down -v
 Container contactos-db-api-1 Stopping
 Container contactos-db-api-1 Stopped
 Container contactos-db-api-1 Removing
 Container contactos-db-api-1 Removed
 Container contactos-db-db-1 Stopping
 Container contactos-db-db-1 Stopped
 Container contactos-db-db-1 Removing
 Container contactos-db-db-1 Removed
 Volume contactos-db_pgdata Removing
 Network contactos-db_default Removing
 Network contactos-db_default Removed
 Volume contactos-db_pgdata Removed
</pre>

La diferencia está en dos líneas: `Volume contactos-db_pgdata Removing` y `Removed`. `-v` (*volumes*) borra también los volúmenes que declara el fichero. Levantamos de nuevo:

```bash
docker compose up -d
```

Esperamos unos segundos y abrimos `http://localhost:8081/api/contactos`:

<pre>
[]
</pre>

**La lista está vacía.** El volumen se creó de nuevo (en el `up` aparece otra vez `Volume ... Created`), PostgreSQL lo encontró vacío, lo inicializó desde cero con `POSTGRES_DB: contactos` y Hibernate volvió a crear la tabla. Los datos se perdieron.

### Qué hemos comprobado

| Orden | Contenedores | Red | Volumen | El contacto de Lucía |
|---|---|---|---|---|
| `docker compose down` y después `up` | Se borran y se crean otros | Igual | Se conserva | **Sigue ahí** |
| `docker compose down -v` y después `up` | Se borran y se crean otros | Igual | **Se borra** y se crea uno vacío | **Desaparece** |

`down` es seguro; `down -v` borra los datos. En un proyecto real, la base de datos de producción no vive en un volumen de Docker Desktop del portátil, pero la regla es la misma: antes de escribir `-v`, hay que preguntarse si algo de esa base de datos hay que conservarlo.

### Limpiar

Dejamos el estado limpio para las prácticas:

```bash
docker compose down -v
```

Dejamos las imágenes en el equipo: se vuelven a usar en las prácticas. Si queremos borrar el volumen de una parada anterior que olvidamos con `-v`, se hace con `docker volume rm contactos-db_pgdata` (falla si algún contenedor lo está usando).

### Resumen de comandos

| Comando | Qué hace |
|---|---|
| `docker volume ls` | Lista los volúmenes |
| `docker compose down` | Borra contenedores y red; el volumen y los datos se conservan |
| `docker compose down -v` | Borra además los volúmenes: se pierden los datos |
| `docker volume rm nombre` | Borra un volumen concreto |
