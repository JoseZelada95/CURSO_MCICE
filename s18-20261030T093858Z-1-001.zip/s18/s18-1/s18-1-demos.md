# S18-1 Demos

## Objetivos

En esta parte damos el primer paso con Kubernetes: activamos el clúster que incluye Docker Desktop, hablamos con él mediante `kubectl`, creamos un pod de dos formas distintas y, por último, creamos un deployment que mantiene varias copias de ese pod y las repara solas. Todo se hace en el equipo, sin instalar nada más.

En este tutorial cada paso tiene una acción, el comando exacto para copiar y pegar, lo que debe salir y, cuando hay riesgo de que algo falle, qué hacer. Los conceptos se explican en el paso en el que aparecen por primera vez.

### ¿Para qué sirve Kubernetes?

Con Docker sabemos ejecutar un contenedor en un equipo. Pero una aplicación real no es un contenedor: son varios, repartidos en varias máquinas, y tienen que estar funcionando día y noche. En cuanto lo pensamos aparecen preguntas que a mano no se pueden resolver:

- ¿Qué pasa si un contenedor se cae a las tres de la madrugada y nadie lo ve?
- ¿Qué hacemos si llegan muchas más visitas y hacen falta diez copias en lugar de dos?
- ¿En qué máquina colocamos cada contenedor, y qué pasa si una máquina se apaga?
- ¿Cómo describimos todo esto de manera que se pueda repetir en otro sitio sin acordarnos de nada?

**Kubernetes** es el programa que se encarga de eso. Nosotros le decimos cómo queremos que esté el sistema ("tres copias de esta aplicación, siempre") y él lo mantiene: arranca lo que falta, repone lo que falla y reparte el trabajo entre las máquinas. Las ventajas que buscamos son recuperarse solo de los fallos, aumentar o reducir copias cambiando un número, y describir todo en ficheros que se guardan con el código y valen en cualquier clúster.

En esta parte lo vemos en pequeño, con un servidor web (`nginx`) como pieza de prueba, porque es lo más sencillo de arrancar y de comprobar en el navegador. Lo que aprendemos vale igual para cualquier aplicación empaquetada en un contenedor, por ejemplo una aplicación Java del curso.

### Qué conseguimos en cada parte

| Parte | Qué conseguimos | Por qué hace falta |
|---|---|---|
| Preparación | Entender imagen, contenedor y puerto | Son las piezas que Kubernetes gestiona; sin ellas no se entiende nada de lo que sigue |
| Demo 1 | Tener un clúster propio y saber hablar con él | Es el puesto de trabajo: sin clúster y sin `kubectl` no se puede probar nada |
| Demo 2 | Crear un pod de dos formas y aprender YAML | El pod es la unidad básica; los ficheros son la forma profesional de trabajar |
| Demo 3 | Ver réplicas, escalado y autorreparación | Es la ventaja real de Kubernetes frente a ejecutar contenedores a mano |

Al terminar esta parte los alumnos son capaces de:
- Explicar para qué sirve Kubernetes y qué problema resuelve frente a ejecutar contenedores a mano.
- Explicar qué son una imagen, un contenedor y un puerto, y publicar un puerto de un contenedor con Docker.
- Leer y escribir ficheros YAML sencillos.
- Comprobar que el clúster local está en marcha con `kubectl`.
- Explicar qué es un pod y crear uno con `kubectl run` y con un fichero YAML.
- Explicar la diferencia entre ordenar una acción (imperativo) y declarar un resultado (declarativo).
- Crear un deployment, escalarlo y comprobar que Kubernetes recrea un pod borrado.
- Acceder a una aplicación del clúster con `kubectl port-forward`.

### Antes de empezar

Cuatro comprobaciones previas, mejor el día anterior:

1. **Docker Desktop está instalado** en el equipo (Windows 11). Es el programa que ejecuta contenedores y que, en esta sesión, también nos da el clúster de Kubernetes. La instalación no forma parte de esta sesión.
2. **Tenemos a mano el fichero `nginx.tar`, por si acaso.** Normalmente el aula descarga sin problema de Docker Hub, pero con el fichero que se comparte por el Drive no dependemos de la red. Lo guardamos en la carpeta donde trabajamos. Es posible que algunos equipos ya tengan la imagen de `nginx` de clases anteriores; la Preparación lo comprueba primero.
3. **El puerto 8081 del equipo está libre.** Se comprueba en la Preparación. El 8080 no se puede usar porque lo ocupa Jenkins.
4. **El aula alcanza `registry.k8s.io`.** Al activar Kubernetes, Docker Desktop descarga de ahí las imágenes de los componentes del clúster. Si la red lo bloquea, el Paso 3 de la Demo 1 se queda esperando y no hay clúster. Esta comprobación está pendiente de hacer desde el aula.

Los ficheros YAML están en `s18-1-demos.zip`, en las carpetas `demo2` y `demo3`. Los descomprimimos en la carpeta donde guardamos los materiales del curso.

---

## Preparación: Docker mínimo (imagen, contenedor y puerto)

**Para qué sirve esta preparación.** Kubernetes no ejecuta nada por sí mismo: organiza contenedores. Si no sabemos qué es una imagen, un contenedor o un puerto, los comandos de Kubernetes son fórmulas sin sentido. Aquí conseguimos esas tres ideas con ejemplos que se ven y se tocan.

Kubernetes ejecuta **contenedores**, así que antes de usarlo necesitamos tener claro qué es un contenedor y qué es un puerto. Esta preparación es corta y no supone ningún conocimiento previo. Usa **Docker**, el programa que crea y ejecuta contenedores en nuestro equipo.

Dos ideas:

- Una **imagen** es un paquete de solo lectura que contiene un programa ya instalado y configurado, junto con todo lo que necesita para funcionar. Es como la receta de un plato: por sí sola no hace nada. Una imagen se identifica por su nombre y una **etiqueta** de versión (`nginx:1.27`). Si no se escribe etiqueta se entiende `latest` ("la última"), así que `nginx` y `nginx:latest` son lo mismo.
- Un **contenedor** es una imagen en ejecución: el programa funcionando, aislado del resto del equipo, con su propia red y sus propios ficheros. Es el plato cocinado con la receta. De una misma imagen se pueden crear tantos contenedores como queramos.

El programa que vamos a usar es **nginx**, un **servidor web**: un programa que espera peticiones de un navegador y responde con páginas web. Su imagen arranca sin configurar nada y muestra una página de bienvenida, de modo que sirve para probar.

### Paso 1. Abrir Docker Desktop

**Qué conseguimos:** Docker Desktop es el motor que ejecuta los contenedores. Sin él en marcha no funciona nada de lo que sigue, tampoco Kubernetes.

Abrimos Docker Desktop desde el menú de inicio de Windows y esperamos a que el indicador de la esquina inferior izquierda esté en verde con el texto `Engine running`.

Si no llega a ponerse en verde, o aparece un error de WSL, el motor de Docker no está arrancado y no seguimos: hay que revisar la instalación de Docker Desktop.

### Paso 2. Abrir una terminal

**Qué conseguimos:** Un puesto de mando desde el que dar todas las órdenes. Trabajar con comandos, y no con clics, permite repetir y documentar lo que hacemos.

Abrimos `cmd` (Windows + R, escribimos `cmd` y Enter). No hace falta que sea de administrador.

### Paso 3. Comprobar si ya tenemos la imagen

**Qué conseguimos:** Evitar descargar de nuevo algo que ya está en el equipo.

```bash
docker images
```

`images` lista las imágenes que hay en el equipo. Si aparece una línea con `nginx` en la columna `REPOSITORY` (o `IMAGE`, según la versión) y `latest` en la columna `TAG`, ya la tenemos de otras clases y saltamos al Paso 5:

<pre>
REPOSITORY   TAG       IMAGE ID       CREATED       SIZE
nginx        latest    a1b2c3d4e5f6   2 weeks ago   192MB
</pre>

Las columnas de tu pantalla pueden ser otras y el identificador y el tamaño serán distintos. Si la lista está vacía o `nginx` no aparece, seguimos con el Paso 4.

### Paso 4. Conseguir la imagen si falta

**Qué conseguimos:** Tener en el equipo la imagen de `nginx`, que es la materia prima de cualquier contenedor que arranquemos, con Docker o con Kubernetes.

La forma normal es descargarla de **Docker Hub**, el almacén público de imágenes:

```bash
docker pull nginx
```

`pull` significa "traer": descarga la imagen al equipo. Debe salir algo parecido a:

<pre>
Using default tag: latest
latest: Pulling from library/nginx
...
Status: Downloaded newer image for nginx:latest
docker.io/library/nginx:latest
</pre>

Si no sale: un error como `Error response from daemon: Get "https://registry-1.docker.io/v2/": ... no such host` o un tiempo de espera agotado indica que no hay acceso a Docker Hub desde este equipo. Usamos entonces el fichero `nginx.tar`. Entramos en la carpeta donde lo guardamos (cambiamos la ruta por la de nuestro equipo):

```bash
cd C:\ruta\a\la\carpeta
```

```bash
docker load -i nginx.tar
```

`load` significa "cargar": mete en Docker una imagen que alguien ha guardado antes en un fichero `.tar`, que es la forma de llevar imágenes a equipos sin acceso a Docker Hub. `-i` indica el fichero de entrada. Debe salir:

<pre>
Loaded image: nginx:latest
</pre>

Repetimos `docker images` y comprobamos que ahora aparece `nginx`.

### Paso 5. Entender los puertos

**Qué conseguimos:** Saber qué es un puerto es lo que nos permitirá ver en el navegador una aplicación que corre aislada dentro de un contenedor.

Todo equipo conectado a una red tiene una dirección (la **IP**). Dentro de un equipo corren muchos programas a la vez, y cada programa que espera conexiones lo hace en un **puerto**: un número, del 1 al 65535, que dice a cuál de ellos queremos hablar. Es como un edificio con muchas puertas: la IP es la dirección del edificio y el puerto es la puerta concreta. Un servidor web usa por costumbre el puerto 80.

Tres cosas que tenemos que saber:

- **`localhost`** es el nombre que significa "este mismo equipo". Una dirección como `localhost:8081` es "el programa que escucha en el puerto 8081 de mi equipo".
- **Solo un programa puede escuchar en un puerto a la vez.** Si intentamos usar uno ocupado, falla. En el aula ya están ocupados, entre otros, el 8080 (Jenkins), el 5432 (PostgreSQL) y el 27017 (MongoDB). Por eso usamos el **8081**.
- **Un contenedor tiene su propia red aislada.** nginx escucha en el puerto 80 *dentro del contenedor*, y desde el navegador del equipo no se llega a él. Para poder llegar hay que **publicar** el puerto, es decir, enlazar un puerto del equipo con uno del contenedor. En Docker se escribe `-p puerto-del-equipo:puerto-del-contenedor`: a la izquierda, el equipo; a la derecha, el contenedor. Con `-p 8081:80`, lo que llegue al puerto 8081 del equipo se entrega al puerto 80 del contenedor.

Lo que hacemos en los pasos siguientes es exactamente eso. El número de la derecha (80) no se elige: es donde escucha nginx. El de la izquierda (8081) sí, y buscamos uno libre.

### Paso 6. Comprobar que el puerto 8081 está libre

**Qué conseguimos:** Evitar de antemano el fallo más habitual, un puerto ocupado por otro programa.

```bash
netstat -ano | findstr :8081
```

`netstat -ano` lista los puertos que están en uso en el equipo y `findstr :8081` se queda solo con las líneas que contienen `:8081`.

Debe salir: nada. Si aparece una línea con `LISTENING`, hay otro programa en el 8081; la última columna es el número del proceso que lo usa. En ese caso usamos el 8082 en lugar del 8081 en todo el documento.

### Paso 7. Crear un contenedor y publicar el puerto

**Qué conseguimos:** Ver en pequeño la cadena completa: de la imagen sale un contenedor y su puerto queda accesible desde el equipo. Es lo que Kubernetes hará por nosotros a gran escala.

```bash
docker run -d --name prueba -p 8081:80 nginx
```

Leemos el comando:

- `docker run`: crea un contenedor a partir de una imagen y lo arranca.
- `-d`: lo deja funcionando en segundo plano, sin ocupar la terminal.
- `--name prueba`: le damos el nombre `prueba` para poder referirnos a él.
- `-p 8081:80`: publica el puerto, como vimos en el Paso 5.
- `nginx`: la imagen de la que se crea.

Debe salir un identificador largo de letras y números, el del contenedor:

<pre>
3f2a9c1b7d4e8a0b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b
</pre>

Si no sale: un error que menciona el puerto 8081 (`port is already allocated` o `Only one usage of each socket address`) quiere decir que otro programa lo ocupa. Repetimos el Paso 6 y, si hace falta, usamos el 8082. Un error con `The container name "/prueba" is already in use` quiere decir que ya existe uno con ese nombre: lo borramos con `docker rm -f prueba` y repetimos.

### Paso 8. Ver el contenedor

**Qué conseguimos:** Comprobar que está funcionando y qué puertos tiene enlazados. Es el equivalente en Docker de lo que luego veremos con `kubectl get pods`.

```bash
docker ps
```

`ps` lista los contenedores que están en marcha. Debe salir:

<pre>
CONTAINER ID   IMAGE   COMMAND                  CREATED         STATUS         PORTS                  NAMES
3f2a9c1b7d4e   nginx   "/docker-entrypoint.…"   5 seconds ago   Up 4 seconds   0.0.0.0:8081->80/tcp   prueba
</pre>

En la columna `PORTS`, `0.0.0.0:8081->80/tcp` es el enlace que hemos creado: puerto 8081 del equipo hacia puerto 80 del contenedor.

### Paso 9. Abrir la página en el navegador

**Qué conseguimos:** Confirmar con una prueba real que el servicio responde, como lo haría un usuario: que arranque no es lo mismo que que funcione.

Abrimos el navegador y escribimos:

<pre>
http://localhost:8081
</pre>

Debe salir la página de bienvenida de nginx, con el texto `Welcome to nginx!`. Con esto hemos visto la cadena completa: imagen, contenedor y puerto publicado.

### Paso 10. Parar y borrar el contenedor

**Qué conseguimos:** Dejar el equipo limpio y entender la diferencia entre parar un contenedor, borrarlo y borrar la imagen. Los contenedores son desechables y la imagen permanece; esa idea se mantiene en Kubernetes.

```bash
docker stop prueba
```

Debe salir `prueba`. El contenedor deja de funcionar y el navegador ya no responde, pero el contenedor sigue existiendo, parado. Lo borramos:

```bash
docker rm prueba
```

Debe salir `prueba`. Borrar el contenedor no borra la imagen: `docker images` sigue mostrando `nginx`, y se podría crear otro contenedor igual cuando queramos.

Comprobamos que no queda ninguno, ni en marcha ni parado:

```bash
docker ps -a
```

Debe salir solo la cabecera de columnas, sin ninguna línea debajo. A partir de aquí no necesitamos más comandos de Docker, salvo `docker images` para comprobar que la imagen sigue ahí.

---

## Demo 1: Clúster local y kubectl

**Para qué sirve esta demo.** Antes de gestionar contenedores necesitamos dos cosas: un clúster donde ponerlos y una herramienta para dar órdenes. Conseguimos un clúster propio de pruebas, sin servidores ni coste, y reconocemos sus piezas para saber dónde ocurre cada cosa cuando algo falle.

Un **clúster** de Kubernetes es un conjunto de máquinas que trabajan juntas para ejecutar contenedores. En producción son varias máquinas; en el aula es una sola, la nuestra, y Docker Desktop se encarga de montarlo. Aunque sea una sola máquina, el clúster tiene las mismas piezas que uno grande, así que lo que aprendemos aquí vale igual allí.

Un clúster se divide en dos partes:

- El **plano de control** (*control plane*) es quien decide: recibe lo que queremos, lo apunta y reparte el trabajo. Es el jefe de obra.
- Los **nodos** (*nodes*) son las máquinas que ejecutan los contenedores. Son los obreros. Cada nodo tiene un programa llamado **kubelet** que recibe órdenes del plano de control y arranca o para contenedores en esa máquina.

La puerta de entrada al plano de control es la **API de Kubernetes**: un servidor al que se le piden las cosas. La herramienta con la que le hablamos desde la terminal se llama **`kubectl`**, y viene incluida con Docker Desktop. Todo lo que hacemos en esta sesión es mandarle peticiones a la API con `kubectl`.

### Paso 1. Comprobar que Docker Desktop está abierto

**Qué conseguimos:** El clúster se monta sobre el motor de Docker; si este no está en marcha, Kubernetes no arranca.

Docker Desktop sigue abierto de la Preparación, con el indicador de la esquina inferior izquierda en verde y el texto `Engine running`. Si lo hemos cerrado, lo abrimos de nuevo desde el menú de inicio de Windows y esperamos a que vuelva a ponerse en verde.

Si no llega a ponerse en verde, el motor de Docker no está arrancado y no seguimos.

### Paso 2. Activar Kubernetes

**Qué conseguimos:** Conseguir un clúster real de un solo nodo sin instalar ni pagar servidores. Es suficiente para aprender y funciona igual que uno de producción.

Hacemos clic en el engranaje de la parte superior (`Settings`). En el panel izquierdo elegimos `Kubernetes` y activamos `Enable Kubernetes`.

Si Docker Desktop pregunta por el tipo de clúster, elegimos `Kubeadm`: es el de un solo nodo, el más sencillo y el que usa directamente las imágenes que ya tenemos en Docker (la de `nginx` de la Preparación). La otra opción (`kind`) crea varios contenedores para simular nodos y no la usamos.

Pulsamos `Apply` (o `Create`, según la versión) y confirmamos si lo pide.

### Paso 3. Esperar a que arranque

**Qué conseguimos:** Dar tiempo a que se descarguen y arranquen los componentes. Hasta que termine, cualquier comando falla.

Docker Desktop descarga las imágenes de los componentes del clúster y los arranca. Tarda entre uno y cinco minutos. Mientras tanto, en la parte inferior izquierda aparece `Starting Kubernetes...`.

Debe salir: cuando termina, en esa misma esquina aparece un segundo indicador en verde con el texto `Kubernetes running`.

Si no sale: pasados diez minutos sigue en `Starting`. Lo más probable es que la red bloquee `registry.k8s.io`. Se anota y no se insiste; la demo no puede continuar en ese equipo.

### Paso 4. Abrir una terminal

**Qué conseguimos:** Tener a mano la terminal desde la que hablaremos con el clúster.

Abrimos `cmd` (Windows + R, escribimos `cmd` y Enter). No hace falta que sea de administrador.

### Paso 5. Comprobar que `kubectl` existe

**Qué conseguimos:** `kubectl` es la única herramienta con la que damos órdenes a Kubernetes. Comprobarla ahora evita errores confusos después.

```bash
kubectl version --client
```

Debe salir:

<pre>
Client Version: v1.34.1
Kustomize Version: v5.7.1
</pre>

La versión de tu pantalla puede ser otra. Lo importante es que no diga que `kubectl` no se reconoce.

Si no sale: `'kubectl' no se reconoce como un comando interno o externo`. Cerramos `cmd` y abrimos otro, porque Docker Desktop añade `kubectl` al `PATH` al arrancar. Si sigue igual, reiniciamos Docker Desktop.

### Paso 6. Comprobar con qué clúster hablamos

**Qué conseguimos:** Asegurarnos de que las órdenes van a nuestro clúster de pruebas y no a otro. En un trabajo real, equivocarse aquí puede tocar un entorno de producción.

`kubectl` puede hablar con varios clústeres, y lo que se llama **contexto** es la elección del clúster al que van nuestras órdenes. Preguntamos cuál está activo:

```bash
kubectl config current-context
```

Debe salir:

<pre>
docker-desktop
</pre>

Si sale otro nombre (por ejemplo el de un clúster de otro curso), cambiamos de contexto con `kubectl config use-context docker-desktop`.

### Paso 7. Ver la dirección del plano de control

**Qué conseguimos:** Confirmar que la API responde: si contesta, el clúster está vivo y `kubectl` llega hasta él.

```bash
kubectl cluster-info
```

Debe salir:

<pre>
Kubernetes control plane is running at https://kubernetes.docker.internal:6443
CoreDNS is running at https://kubernetes.docker.internal:6443/api/v1/namespaces/kube-system/services/kube-dns:dns/proxy

To further debug and diagnose cluster problems, use 'kubectl cluster-info dump'.
</pre>

La primera línea es la dirección de la API de Kubernetes, y el `6443` es su puerto. Es la puerta a la que `kubectl` llama en cada comando. **CoreDNS** es la pieza que permite que los pods se encuentren por nombre dentro del clúster; hoy no la usamos.

Si no sale: `Unable to connect to the server` o `connection refused`. Kubernetes no está arrancado. Volvemos al Paso 3.

### Paso 8. Ver los nodos

**Qué conseguimos:** Comprobar que la máquina que ejecutará los contenedores está sana, y aprender el patrón `get` que usaremos todo el rato.

```bash
kubectl get nodes
```

Debe salir:

<pre>
NAME             STATUS   ROLES           AGE   VERSION
docker-desktop   Ready    control-plane   4m    v1.34.1
</pre>

Leemos las columnas:

- `NAME`: el nombre del nodo. Es nuestro único nodo.
- `STATUS`: `Ready` quiere decir que el nodo está sano y puede recibir trabajo. Cualquier otra cosa (`NotReady`) indica que algo falla.
- `ROLES`: `control-plane` indica que este nodo, además de ejecutar contenedores, hace de plano de control. En un clúster grande el plano de control y los nodos que trabajan serían máquinas distintas.

Este es el patrón de casi todos los comandos de `kubectl`: `kubectl get <tipo de objeto>` lista los objetos de ese tipo, con una columna por dato importante.

### Paso 9. Ver los componentes del clúster

**Qué conseguimos:** Ver que Kubernetes es, a su vez, un conjunto de programas que corren en contenedores, y saber qué hace cada uno ayuda a diagnosticar cuando algo falla. Comprobamos además que el namespace `default` está vacío: partimos de cero.

El propio plano de control se ejecuta en pods dentro del nodo. Los vemos con:

```bash
kubectl get pods -A
```

La opción `-A` (*all namespaces*) muestra los pods de todos los espacios. Un **namespace** (espacio de nombres) es una carpeta lógica para ordenar los objetos del clúster; los nuestros irán al namespace `default` y los del sistema viven en `kube-system`.

Debe salir algo parecido a:

<pre>
NAMESPACE     NAME                                     READY   STATUS    RESTARTS   AGE
kube-system   coredns-66bc5c9577-8xk2p                 1/1     Running   0          4m
kube-system   coredns-66bc5c9577-qv7tn                 1/1     Running   0          4m
kube-system   etcd-docker-desktop                      1/1     Running   0          4m
kube-system   kube-apiserver-docker-desktop            1/1     Running   0          4m
kube-system   kube-controller-manager-docker-desktop   1/1     Running   0          4m
kube-system   kube-proxy-5hz9d                         1/1     Running   0          4m
kube-system   kube-scheduler-docker-desktop            1/1     Running   0          4m
kube-system   storage-provisioner                      1/1     Running   0          4m
</pre>

Los nombres exactos y los números cambian de un equipo a otro. Lo que importa es que todos digan `Running`. Un **pod** es la unidad que ejecuta contenedores; se explica en la Demo 2. Identificamos las piezas del plano de control:

- `kube-apiserver`: la API a la que llama `kubectl`.
- `etcd`: la base de datos del clúster, donde se guarda el estado deseado.
- `kube-scheduler`: decide en qué nodo se coloca cada pod nuevo.
- `kube-controller-manager`: ejecuta los controladores, los programas que vigilan que lo real coincida con lo deseado. Es quien hará la autorreparación de la Demo 3.

Y dos que no son del plano de control: `kube-proxy` (reparte el tráfico de red dentro del clúster) y `coredns` (los nombres, como vimos en el Paso 7).

Para comprobar que el namespace `default` está vacío, que es donde trabajaremos:

```bash
kubectl get pods
```

Debe salir:

<pre>
No resources found in default namespace.
</pre>

Cuando no se indica namespace, `kubectl` usa `default`. Por eso este comando no muestra los pods del sistema.

---

## Demo 2: Primer pod, de forma imperativa y declarativa

**Para qué sirve esta demo.** Queremos ejecutar un contenedor en Kubernetes. Lo hacemos de dos formas para compararlas: la rápida, con una orden, sirve para probar; la de fichero sirve para trabajar de verdad, porque el fichero se puede guardar, revisar y repetir. Conseguimos entender la unidad básica (el pod) y aprender a leer los ficheros en los que está escrito todo en Kubernetes.

Un **pod** es la unidad mínima que Kubernetes ejecuta. Envuelve uno o varios contenedores que comparten red y se arrancan y paran juntos. En esta sesión cada pod tendrá un solo contenedor, de modo que podemos pensar en un pod como "un contenedor con una cubierta de Kubernetes alrededor".

Vamos a crear el mismo pod dos veces, para ver dos formas de trabajar:

- **Imperativa**: damos una orden concreta ("crea este pod ahora"). Es rápida, pero lo único que queda es el pod: nada describe cómo se creó.
- **Declarativa**: escribimos en un fichero cómo queremos que sea el pod y se lo entregamos a Kubernetes, que trabaja hasta conseguirlo. El fichero se guarda con el código, se versiona con Git y se puede repetir en cualquier clúster. Es la forma que se usa en la práctica.

### Paso 1. Comprobar que la imagen de nginx está en Docker

**Qué conseguimos:** Kubernetes arrancará el contenedor a partir de esta imagen. Comprobar que existe evita el error `ErrImagePull`.

Kubernetes arranca los contenedores a partir de imágenes, igual que `docker run`. Con el clúster que activa Docker Desktop, Kubernetes puede usar las imágenes que ya hay en Docker, así que no hay que descargar nada. Lo comprobamos:

```bash
docker images
```

Debe salir una línea con `nginx`. Si no aparece, repetimos los Pasos 3 y 4 de la Preparación.

### Paso 2. Crear el pod de forma imperativa

**Qué conseguimos:** Ejecutar nuestro primer contenedor en Kubernetes con una sola orden, para ver lo sencillo que es empezar.

```bash
kubectl run web --image=nginx --image-pull-policy=IfNotPresent --port=80
```

Leemos el comando:

- `kubectl run web`: crea un pod llamado `web`.
- `--image=nginx`: la imagen del contenedor.
- `--image-pull-policy=IfNotPresent`: la **política de descarga** de la imagen. `IfNotPresent` significa "solo si no está ya en el equipo", y la imagen de `nginx` ya está. Sin esta opción, una imagen sin etiqueta de versión (como `nginx`, que equivale a `nginx:latest`) se vuelve a consultar y descargar de Docker Hub cada vez que se crea un pod. Con ella usamos la del equipo: es más rápido y no depende de la red.
- `--port=80`: el puerto en el que escucha nginx dentro del contenedor, el 80 que vimos en la Preparación. Es solo una anotación: no publica nada.

Debe salir:

<pre>
pod/web created
</pre>

### Paso 3. Ver el pod

**Qué conseguimos:** Comprobar el estado y aprender a leer `READY`, `STATUS` y `RESTARTS`, que es lo primero que se mira cuando algo no va bien.

```bash
kubectl get pods
```

Debe salir:

<pre>
NAME   READY   STATUS    RESTARTS   AGE
web    1/1     Running   0          8s
</pre>

Si lo ejecutamos justo después de crearlo, puede decir `ContainerCreating` en lugar de `Running`. Repetimos el comando pasados unos segundos.

Leemos las columnas:

- `READY`: contenedores listos del pod frente a contenedores totales. `1/1` es un contenedor de uno.
- `STATUS`: `Running` es que el contenedor está en marcha.
- `RESTARTS`: cuántas veces ha reiniciado Kubernetes el contenedor. Lo normal es `0`.

Si no sale: el estado es `ErrImagePull` o `ImagePullBackOff`. Kubernetes no encuentra la imagen. Lo diagnosticamos en el Paso 4 y lo arreglamos consiguiendo la imagen (Paso 4 de la Preparación).

### Paso 4. Ver los detalles del pod

**Qué conseguimos:** Aprender la herramienta de diagnóstico principal. La sección `Events` cuenta paso a paso lo que ha hecho Kubernetes y en ella aparece la causa de la mayoría de los fallos.

```bash
kubectl describe pod web
```

La salida es larga. Nos fijamos en estas partes, de arriba a abajo:

<pre>
Name:             web
Namespace:        default
Node:             docker-desktop/192.168.65.3
Status:           Running
IP:               10.1.0.12
Containers:
  web:
    Image:          nginx
    Port:           80/TCP
    State:          Running
...
Events:
  Type    Reason     Age   From               Message
  ----    ------     ----  ----               -------
  Normal  Scheduled  25s   default-scheduler  Successfully assigned default/web to docker-desktop
  Normal  Pulled     24s   kubelet            Container image "nginx" already present on machine
  Normal  Created    24s   kubelet            Created container: web
  Normal  Started    24s   kubelet            Started container web
</pre>

- `Node`: en qué nodo se ejecuta.
- `IP`: la dirección propia del pod dentro del clúster. Cada pod tiene la suya.
- `Events`: lo que ha ido pasando, en orden. Es la sección más útil cuando algo falla. Se lee así: el planificador (`default-scheduler`) lo asigna a un nodo, el `kubelet` comprueba que la imagen ya está en el equipo, crea el contenedor y lo arranca.

Si algo falla, el motivo aparece al final de esta sección. Con el error del Paso 3 veríamos aquí mensajes como `Failed to pull image "nginx"` seguidos de `Back-off pulling image`.

### Paso 5. Ver los registros del contenedor

**Qué conseguimos:** Ver lo que dice el propio programa. Es la segunda herramienta de diagnóstico: `describe` explica lo que hace Kubernetes y `logs` lo que hace la aplicación.

```bash
kubectl logs web
```

`logs` muestra lo que el programa del contenedor va escribiendo por pantalla. Debe salir lo que escribe nginx al arrancar:

<pre>
/docker-entrypoint.sh: Configuration complete; ready for start up
...
2026/10/29 12:10:31 [notice] 1#1: start worker processes
</pre>

Las primeras líneas y las horas serán otras. Lo importante es que no salga ningún error.

### Paso 6. Borrar el pod

**Qué conseguimos:** Ver el límite del modo imperativo: al borrar, no queda rastro de cómo se creó el pod y nadie lo recrea.

```bash
kubectl delete pod web
```

Debe salir:

<pre>
pod "web" deleted
</pre>

Según la versión de `kubectl`, la línea puede terminar con `from default namespace`. Tarda unos segundos porque Kubernetes espera a que el contenedor se pare con calma.

Comprobamos que ha desaparecido:

```bash
kubectl get pods
```

Debe salir:

<pre>
No resources found in default namespace.
</pre>

Lo que acabamos de hacer es modo imperativo: dimos órdenes y las órdenes se las llevó el viento. Si mañana queremos el mismo pod, tenemos que acordarnos del comando exacto.

### Paso 7. Entrar en la carpeta de la demo

**Qué conseguimos:** Situarnos donde está el fichero para que el comando lo encuentre.

El fichero del pod está en la carpeta `demo2` del zip. Entramos en ella (cambiamos la ruta por la de nuestro equipo):

```bash
cd C:\ruta\a\s18-1-demos\demo2
```

Comprobamos que el fichero está:

```bash
dir pod-nginx.yaml
```

Debe salir una línea con `pod-nginx.yaml`. Si sale `No se encuentra el archivo`, estamos en otra carpeta.

### Paso 8. Aprender lo mínimo de YAML

**Qué conseguimos:** Entender el formato en el que está escrito todo en Kubernetes, para poder leer y escribir ficheros por nuestra cuenta y no solo copiarlos.

**YAML** es un formato de texto para describir datos con estructura. Los ficheros de Kubernetes se escriben en YAML (extensión `.yaml`). Tiene pocas reglas y todas se ven en este ejemplo, que describe a una persona:

```yaml
# Una persona descrita en YAML
nombre: Jesús
edad: 29
aficiones:
  - leer
  - running
direccion:
  calle: Mayor
  numero: 5
```

Las reglas, una a una:

1. **Pares `clave: valor`.** Cada línea dice una cosa: `nombre: Jesús` es "el nombre es Ana". Después de los dos puntos va siempre un espacio. Los números (`edad: 29`) y los textos (`Jesús`) se escriben igual, sin comillas.
2. **La sangría indica pertenencia.** `direccion:` no tiene valor en su línea; lo que está debajo, desplazado a la derecha, le pertenece: la dirección tiene una calle y un número. Se sangra con **espacios** (dos por nivel, por costumbre) y **nunca con tabuladores**. Dos líneas al mismo nivel tienen que empezar exactamente en la misma columna.
3. **Las listas llevan un guion.** Cada elemento de `aficiones` empieza por `- ` (guion y espacio). La lista de aficiones tiene dos elementos.
4. **Los comentarios empiezan por `#`.** Todo lo que sigue hasta el final de la línea se ignora. Los usamos para explicar el fichero.

Un elemento de una lista puede tener a su vez varias claves. En ese caso, el guion marca el principio del elemento y las demás claves se alinean con la primera:

```yaml
contenedores:
  - nombre: web
    puerto: 80
  - nombre: base
    puerto: 5432
```

Esa lista tiene dos elementos, cada uno con un `nombre` y un `puerto`. Nos fijamos en que `puerto` está justo debajo de `nombre`, no del guion.

Los errores típicos son un tabulador en lugar de espacios, una línea con un espacio de más o de menos, o un `clave:valor` sin espacio tras los dos puntos. Kubernetes los detecta al leer el fichero y los avisa con un mensaje de error que veremos en el Paso 10.

### Paso 9. Leer el fichero YAML del pod

**Qué conseguimos:** Comprobar que el fichero dice lo mismo que la orden del Paso 2 y aprender los cuatro bloques que se repiten en cualquier objeto de Kubernetes. Con ellos se puede leer casi cualquier fichero.

El fichero `pod-nginx.yaml` es este. Los comentarios explican cada línea:

```yaml
# S18-1 Demo 2: Primer pod, de forma imperativa y declarativa
#
# Objetivo: describir en un fichero el mismo pod que antes creamos con kubectl run.
#
# Lo que hace este fichero:
#   - Declara un pod llamado web-yaml con un único contenedor de nginx
#   - Se crea con: kubectl apply -f pod-nginx.yaml
#
# Concepto clave: en el modo declarativo no ordenamos "crea esto", sino que
# describimos cómo queremos que sea el pod, y Kubernetes trabaja hasta lograrlo.
# El fichero se puede guardar en Git y repetir en cualquier clúster.

# apiVersion: versión de la API de Kubernetes que define este tipo de objeto.
# Los pods pertenecen al grupo principal de la API, que se escribe simplemente v1.
apiVersion: v1

# kind: el tipo de objeto que describimos. Aquí, un pod.
kind: Pod

# metadata: datos que identifican al objeto.
metadata:
  # name: nombre del pod dentro del clúster. Tiene que ser único entre los pods.
  name: web-yaml
  # labels: etiquetas, pares clave-valor que sirven para agrupar y buscar objetos.
  # Aquí no las usamos todavía; en la Demo 3 veremos para qué sirven.
  labels:
    app: web

# spec: la especificación, es decir, el estado deseado del objeto.
spec:
  # containers: lista de contenedores del pod. Un pod puede llevar uno o varios;
  # el guion inicial de cada elemento marca que es un elemento de la lista.
  containers:
    # name: nombre del contenedor dentro del pod.
    - name: nginx
      # image: imagen de la que se crea el contenedor (la que descargamos o cargamos en Docker).
      image: nginx
      # imagePullPolicy: cuándo descarga Kubernetes la imagen.
      # IfNotPresent = solo si no está ya en el equipo. Sin esta línea, una imagen
      # sin etiqueta de versión se vuelve a consultar y descargar de Docker Hub
      # cada vez que se crea el pod.
      imagePullPolicy: IfNotPresent
      # ports: puertos en los que escucha el programa del contenedor. Es solo
      # documentación: no abre ni publica nada fuera del pod. nginx escucha en el 80.
      ports:
        - containerPort: 80
```

Aplicando las reglas de YAML, leemos el fichero. Todo objeto de Kubernetes escrito en un fichero tiene cuatro bloques que se repiten siempre:

| Bloque | Qué dice |
|---|---|
| `apiVersion` | A qué versión de la API pertenece el tipo de objeto |
| `kind` | Qué tipo de objeto es (`Pod`, `Deployment`...) |
| `metadata` | Cómo se llama y con qué etiquetas |
| `spec` | Cómo lo queremos: el estado deseado |

### Paso 10. Aplicar el fichero

**Qué conseguimos:** Conseguir el mismo pod desde un fichero, que es reproducible: se guarda con el código, se revisa y se repite en otro clúster.

```bash
kubectl apply -f pod-nginx.yaml
```

`apply` (aplicar) le entrega el fichero a Kubernetes, y `-f` indica el nombre del fichero. Kubernetes lee el estado deseado y trabaja hasta que el clúster coincide con él.

Debe salir:

<pre>
pod/web-yaml created
</pre>

Si no sale: un error como `error: error parsing pod-nginx.yaml: error converting YAML to JSON: yaml: line 25: mapping values are not allowed in this context` indica un fallo de sangría en el fichero (un espacio de más o de menos, o un tabulador). Si hemos copiado el fichero a mano, comparamos con el original del zip. El número de línea puede señalar la línea siguiente a la equivocada.

### Paso 11. Comprobar el pod

**Qué conseguimos:** Confirmar que el resultado es idéntico al del modo imperativo. La diferencia está en cómo se obtuvo, no en lo que se obtuvo.

```bash
kubectl get pods
```

Debe salir:

<pre>
NAME       READY   STATUS    RESTARTS   AGE
web-yaml   1/1     Running   0          6s
</pre>

Es el mismo resultado que en el Paso 3, pero conseguido desde un fichero.

### Paso 12. Aplicar el mismo fichero otra vez

**Qué conseguimos:** Descubrir que aplicar un fichero es seguro de repetir: si ya está como se pide, no pasa nada. Eso permite automatizar sin miedo a duplicar o romper cosas.

```bash
kubectl apply -f pod-nginx.yaml
```

Debe salir:

<pre>
pod/web-yaml unchanged
</pre>

Aquí se ve la idea del modo declarativo. No decimos "crea otro pod": decimos "quiero este pod". Como el clúster ya coincide con lo que pide el fichero, Kubernetes no hace nada y responde `unchanged`. Con `kubectl run`, repetir el comando habría dado el error `pods "web" already exists`.

### Paso 13. Borrar el pod con el mismo fichero

**Qué conseguimos:** Limpiar con el mismo fichero que creó el objeto, y quedarnos con la limitación del pod suelto, que es lo que resuelve la Demo 3.

```bash
kubectl delete -f pod-nginx.yaml
```

Debe salir:

<pre>
pod "web-yaml" deleted
</pre>

El mismo fichero que crea el objeto sirve para borrarlo. Comprobamos con `kubectl get pods` que ya no queda ninguno.

Nos quedamos con la idea: un pod suelto, que se borra, desaparece para siempre. Nadie lo vuelve a crear. En la Demo 3 veremos qué cambia cuando un pod lo gestiona un deployment.

---

## Demo 3: Deployment, réplicas y autorreparación

**Para qué sirve esta demo.** En producción nadie crea pods sueltos: si uno falla, el servicio se cae. Con un deployment pedimos "tres copias" y Kubernetes las mantiene. Conseguimos ver las dos ventajas principales de Kubernetes: disponibilidad (si algo falla, se repone solo) y capacidad (se aumentan o reducen las copias cambiando un número).

Un pod suelto tiene dos problemas: si se borra o falla, nadie lo recrea, y si queremos tres copias, tendríamos que crear tres pods a mano. Un **deployment** resuelve las dos cosas. Es un objeto que mantiene vivo un número de pods iguales. Le decimos "quiero tres pods de nginx" y él se ocupa de que existan tres, siempre.

Esa es la idea más importante de Kubernetes: el **estado deseado**. Nosotros declaramos cómo queremos que esté el sistema (tres pods), y Kubernetes compara continuamente lo que hay con lo que queremos. Si no coincide, actúa hasta que coincide. Los controladores del plano de control, que vimos en el Paso 9 de la Demo 1, hacen exactamente eso.

Cada copia de un pod se llama **réplica**.

### Paso 1. Entrar en la carpeta de la demo

**Qué conseguimos:** Situarnos donde está el fichero del deployment.

```bash
cd C:\ruta\a\s18-1-demos\demo3
```

Comprobamos que está el fichero:

```bash
dir deployment-nginx.yaml
```

### Paso 2. Leer el fichero YAML del deployment

**Qué conseguimos:** Ver cuánto cambia respecto al pod: casi nada. Solo se añade cuántas copias queremos y cómo reconocerlas.

El fichero `deployment-nginx.yaml` es este:

```yaml
# S18-1 Demo 3: Deployment, réplicas y autorreparación
#
# Objetivo: pedirle a Kubernetes tres copias de un pod de nginx y comprobar
# que mantiene ese número aunque borremos pods.
#
# Lo que hace este fichero:
#   - Declara un deployment llamado web con 3 réplicas
#   - Incluye la plantilla (template) con la que el deployment crea cada pod
#
# Concepto clave: un deployment no es un pod, es el encargado de mantener
# vivos N pods iguales. Si uno desaparece, crea otro para volver a N.

# Los deployments están en el grupo apps de la API, por eso la versión es apps/v1.
apiVersion: apps/v1
kind: Deployment
metadata:
  # Nombre del deployment.
  name: web
spec:
  # replicas: cuántos pods queremos. Este es el estado deseado.
  replicas: 3
  # selector: cómo sabe el deployment cuáles son sus pods.
  # Cuenta los pods que tengan la etiqueta app: web.
  selector:
    matchLabels:
      app: web
  # template: la plantilla de los pods. Todo lo que hay aquí dentro es,
  # casi literalmente, el pod de la Demo 2 (sin apiVersion ni kind).
  template:
    metadata:
      # Los pods que cree el deployment llevarán esta etiqueta.
      # Tiene que coincidir con la del selector: si no, el deployment
      # no reconocería sus propios pods y Kubernetes rechaza el fichero.
      labels:
        app: web
    spec:
      containers:
        - name: nginx
          image: nginx
          # IfNotPresent: usa la imagen que ya está en el equipo (se explica en la Demo 2).
          imagePullPolicy: IfNotPresent
          ports:
            - containerPort: 80
```

Lo leemos por partes. Los cuatro bloques de la Demo 2 (`apiVersion`, `kind`, `metadata`, `spec`) están igual. Lo nuevo está dentro de `spec`:

- `replicas: 3`: el estado deseado, tres pods.
- `template`: la **plantilla** de los pods. Es el molde con el que el deployment crea cada pod, y contiene lo mismo que el pod de la Demo 2 (etiquetas, contenedor, imagen, puerto).
- `selector` con `matchLabels`: la forma en que el deployment reconoce sus pods. Las **etiquetas** (*labels*) son pares clave-valor pegados a un objeto, y el deployment cuenta los pods que tienen la etiqueta `app: web`. Por eso la etiqueta de la plantilla y la del selector tienen que ser iguales: si no, el deployment crearía pods que luego no reconocería como suyos. Kubernetes rechaza el fichero en ese caso.

### Paso 3. Aplicar el deployment

**Qué conseguimos:** Entregar a Kubernetes el estado deseado: tres copias del pod.

```bash
kubectl apply -f deployment-nginx.yaml
```

Debe salir:

<pre>
deployment.apps/web created
</pre>

### Paso 4. Ver el deployment

**Qué conseguimos:** Comprobar que Kubernetes ha conseguido lo pedido (`3/3`).

```bash
kubectl get deployments
```

Debe salir (si lo ejecutamos pasados unos segundos):

<pre>
NAME   READY   UP-TO-DATE   AVAILABLE   AGE
web    3/3     3            3           14s
</pre>

Leemos las columnas:

- `READY`: pods listos frente a pods deseados. `3/3` es que los tres están en marcha. Al principio puede salir `0/3` o `2/3`; repetimos el comando.
- `UP-TO-DATE`: pods que ya tienen la plantilla actual.
- `AVAILABLE`: pods disponibles para atender peticiones.

### Paso 5. Ver los pods que ha creado

**Qué conseguimos:** Descubrir que los pods los ha creado Kubernetes, no nosotros, y entender la cadena deployment, ReplicaSet y pods, que sirve para diagnosticar.

```bash
kubectl get pods
```

Debe salir:

<pre>
NAME                   READY   STATUS    RESTARTS   AGE
web-6d4cf56db6-4xk2p   1/1     Running   0          20s
web-6d4cf56db6-9fh7w   1/1     Running   0          20s
web-6d4cf56db6-ltq8c   1/1     Running   0          20s
</pre>

Los tres pods no los hemos nombrado nosotros. El nombre se compone de tres trozos: `web` (el deployment), `6d4cf56db6` (un código que identifica la plantilla) y cinco letras al azar (cada pod). Los códigos de tu pantalla serán distintos.

Entre el deployment y los pods hay un objeto intermedio, el **ReplicaSet**, que es quien cuenta las réplicas de verdad. No lo manejamos directamente, pero se ve con:

```bash
kubectl get replicasets
```

Debe salir:

<pre>
NAME             DESIRED   CURRENT   READY   AGE
web-6d4cf56db6   3         3         3       35s
</pre>

Basta con recordar que el deployment crea un ReplicaSet y el ReplicaSet crea los pods.

### Paso 6. Filtrar pods por etiqueta

**Qué conseguimos:** Aprender a buscar objetos cuando hay muchos. Las etiquetas son la forma en que Kubernetes organiza todo.

Las etiquetas sirven para buscar. Pedimos solo los pods con la etiqueta `app=web`:

```bash
kubectl get pods -l app=web
```

Debe salir la misma lista de tres pods. La opción `-l` (*label*) filtra por etiqueta. Es el mismo criterio que usa el deployment para contar sus pods.

### Paso 7. Escalar a cinco réplicas

**Qué conseguimos:** Ver cómo se responde a más carga: se cambia un número y Kubernetes crea las copias que faltan, sin crear nada a mano.

Escalar es cambiar el número de réplicas. Le decimos a Kubernetes que ahora queremos cinco:

```bash
kubectl scale deployment web --replicas=5
```

Debe salir:

<pre>
deployment.apps/web scaled
</pre>

Comprobamos los pods:

```bash
kubectl get pods
```

Debe salir:

<pre>
NAME                   READY   STATUS              RESTARTS   AGE
web-6d4cf56db6-4xk2p   1/1     Running             0          2m
web-6d4cf56db6-9fh7w   1/1     Running             0          2m
web-6d4cf56db6-ltq8c   1/1     Running             0          2m
web-6d4cf56db6-m2p5n   0/1     ContainerCreating   0          3s
web-6d4cf56db6-zr9dv   1/1     Running             0          3s
</pre>

Los dos pods nuevos aparecen primero como `ContainerCreating` y pasan a `Running` en unos segundos. Los tres originales no se han tocado.

### Paso 8. Volver a tres réplicas

**Qué conseguimos:** Ver que también se reduce cuando ya no hace falta tanta capacidad, para no gastar recursos de más.

```bash
kubectl scale deployment web --replicas=3
```

Debe salir:

<pre>
deployment.apps/web scaled
</pre>

Comprobamos con `kubectl get pods`. Kubernetes elige dos pods, los marca como `Terminating` y desaparecen al cabo de unos segundos. Quedan tres.

### Paso 9. Provocar un fallo: borrar un pod

**Qué conseguimos:** Simular un fallo para comprobar la autorreparación. El servicio no se interrumpe porque quedan otras copias, y la que falta se repone sola. Es la razón principal por la que se usa Kubernetes.

Aquí está la parte importante. Copiamos el nombre de uno de los pods de la lista (el nombre completo, por ejemplo `web-6d4cf56db6-4xk2p`; el de tu pantalla será otro) y lo borramos:

```bash
kubectl delete pod web-6d4cf56db6-4xk2p
```

Cambiamos el nombre del ejemplo por el de uno de nuestros pods. Debe salir:

<pre>
pod "web-6d4cf56db6-4xk2p" deleted
</pre>

Inmediatamente después, sin esperar:

```bash
kubectl get pods
```

Debe salir:

<pre>
NAME                   READY   STATUS              RESTARTS   AGE
web-6d4cf56db6-4xk2p   1/1     Terminating         0          4m
web-6d4cf56db6-9fh7w   1/1     Running             0          4m
web-6d4cf56db6-ltq8c   1/1     Running             0          4m
web-6d4cf56db6-x7c2b   0/1     ContainerCreating   0          2s
</pre>

Leemos lo que ha pasado:

1. El pod borrado está en `Terminating`, apagándose.
2. Hay un pod nuevo, con otro nombre (`x7c2b`) y `AGE` de solo unos segundos. No lo hemos creado nosotros.

El ReplicaSet comparó lo que había (dos pods vivos) con lo que queremos (tres) y creó uno nuevo para igualarlos. Es la **autorreparación**. En la Demo 2 borramos un pod suelto y desapareció para siempre; aquí, el mismo borrado se corrige solo.

Repetimos `kubectl get pods` pasados unos segundos y vemos de nuevo los tres pods en `Running`, uno de ellos recién creado.

### Paso 10. Preparar el acceso desde el navegador

**Qué conseguimos:** Entender por qué hace falta abrir una puerta explícita para llegar a un pod desde el equipo, y evitar de antemano un puerto ocupado.

Cada pod tiene su propia dirección dentro del clúster, pero esa dirección no es alcanzable desde el equipo: el navegador de Windows no puede llegar a ella. Hace falta abrir una puerta explícita. La forma más sencilla, para probar, es **`kubectl port-forward`**, que enlaza un puerto de nuestro equipo con un puerto del pod.

Es lo mismo que hicimos con Docker en la Preparación al publicar el puerto con `-p`: enlazar un puerto del equipo con un puerto del que está dentro. Antes, volvemos a comprobar que el puerto 8081 está libre:

```bash
netstat -ano | findstr :8081
```

Debe salir: nada. Si aparece una línea con `LISTENING`, otro programa usa el 8081 (por ejemplo, el contenedor `prueba` de la Preparación, si no lo habíamos parado). Lo paramos con `docker stop prueba` o usamos el 8082 en el paso siguiente. No usamos el 8080: es el de Jenkins.

### Paso 11. Abrir la puerta con port-forward

**Qué conseguimos:** Abrir esa puerta de la forma más sencilla, que sirve para probar. En producción el acceso se resuelve con otros mecanismos que quedan fuera de esta parte.

```bash
kubectl port-forward deployment/web 8081:80
```

Leemos el comando:

- `deployment/web`: el objeto al que nos conectamos. Kubernetes elige uno de sus pods.
- `8081:80`: puerto del equipo a la izquierda, puerto del pod a la derecha. Es el mismo orden que `-p 8081:80` de la Preparación: el equipo a la izquierda, el que está dentro (aquí, el pod) a la derecha.

Debe salir:

<pre>
Forwarding from 127.0.0.1:8081 -> 80
Forwarding from [::1]:8081 -> 80
</pre>

La terminal se queda ocupada y sin indicador: es normal, el comando se mantiene ejecutándose mientras la puerta esté abierta. No la cerramos.

### Paso 12. Abrir la página en el navegador

**Qué conseguimos:** Comprobar desde fuera que la aplicación funciona, igual que lo haría un usuario.

Abrimos el navegador y escribimos:

<pre>
http://localhost:8081
</pre>

Debe salir la página de bienvenida de nginx con el texto `Welcome to nginx!`. En la terminal del `port-forward` aparece una línea nueva (`Handling connection for 8081`) por cada petición.

Si no sale: el navegador dice que no puede conectar y la terminal muestra `error: unable to listen on port 8081`. Había otro programa en el 8081 (volvemos al Paso 10).

### Paso 13. Cerrar la puerta

**Qué conseguimos:** Distinguir entre cerrar el acceso, que es provisional, y parar la aplicación, que sigue funcionando en el clúster.

Volvemos a la terminal del `port-forward` y pulsamos `Ctrl + C`. El comando termina y el navegador deja de responder en esa dirección. La aplicación sigue ejecutándose en el clúster: solo hemos cerrado la puerta.

### Paso 14. Limpiar

**Qué conseguimos:** Dejar el clúster vacío y ver que, al borrar el deployment, se borran sus pods y nadie los recrea: el estado deseado ahora es "nada".

Borramos el deployment con el mismo fichero que lo creó:

```bash
kubectl delete -f deployment-nginx.yaml
```

Debe salir:

<pre>
deployment.apps "web" deleted
</pre>

Comprobamos:

```bash
kubectl get pods
```

Los tres pods aparecen primero como `Terminating` y desaparecen. Al borrar el deployment se borran también sus pods, y esta vez nadie los recrea, porque ya no hay estado deseado que mantener.

---

## Qué nos llevamos

- Docker ejecuta un contenedor; Kubernetes gestiona muchos contenedores y mantiene el sistema como hemos declarado.
- En Kubernetes no se dan órdenes sueltas: se describe el **estado deseado** en un fichero YAML y Kubernetes trabaja hasta conseguirlo y lo vigila después.
- Un pod suelto no se recupera; un deployment sí. Esa diferencia es la razón de ser de Kubernetes: recuperarse solo de los fallos y cambiar la capacidad con un número.
- Para diagnosticar, el orden de trabajo es `get` (qué hay y en qué estado), `describe` (qué ha hecho Kubernetes) y `logs` (qué dice la aplicación).
- Quedan fuera de esta parte comunicar pods entre sí por nombre, actualizar versiones sin parada y guardar datos.

## Resumen de comandos

| Comando | Qué hace |
|---|---|
| `kubectl version --client` | Muestra la versión de `kubectl` |
| `kubectl config current-context` | Muestra el clúster al que hablamos |
| `kubectl cluster-info` | Muestra la dirección del plano de control |
| `kubectl get nodes` | Lista los nodos |
| `kubectl get pods` / `-A` / `-l app=web` | Lista pods (del namespace actual / de todos / filtrados por etiqueta) |
| `kubectl get deployments` / `replicasets` | Lista deployments / ReplicaSets |
| `kubectl run <nombre> --image=<imagen>` | Crea un pod de forma imperativa |
| `kubectl apply -f <fichero>` | Crea o actualiza lo que describe el fichero (declarativo) |
| `kubectl describe pod <nombre>` | Muestra los detalles y los eventos de un pod |
| `kubectl logs <pod>` | Muestra los registros del contenedor |
| `kubectl scale deployment <nombre> --replicas=N` | Cambia el número de réplicas |
| `kubectl delete pod <nombre>` / `-f <fichero>` | Borra un pod / lo que describe el fichero |
| `kubectl port-forward deployment/<nombre> 8081:80` | Enlaza el puerto 8081 del equipo con el 80 del pod |


