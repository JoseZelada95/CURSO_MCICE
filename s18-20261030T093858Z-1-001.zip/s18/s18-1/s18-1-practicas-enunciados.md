# S18-1 Prácticas

## Objetivos

Se aplica lo visto en las demos: se escribe un fichero YAML desde cero, se comprueba que Kubernetes mantiene el número de pods pedido aunque se borren y se llega a una aplicación del clúster desde el navegador. Las tres prácticas giran en torno a la web de una tienda ficticia, servida con `nginx`, y cada una parte de lo que ha dejado la anterior.

Con ellas se consigue pasar de leer ficheros de Kubernetes a escribirlos, que es lo que se hace en un trabajo real, y aprender a diagnosticar cuando algo no sale: leer un mensaje de error, mirar los eventos de un pod, consultar sus registros.

### Antes de empezar

1. **Docker Desktop está abierto y Kubernetes activo.** En `cmd`: `kubectl get nodes` debe mostrar el nodo `docker-desktop` con `STATUS` `Ready`.
2. **La imagen de `nginx` está en Docker.** En `cmd`: `docker images` debe mostrar una línea con `nginx`. Si no aparece, se descarga con `docker pull nginx` o se carga del fichero `nginx.tar` con `docker load -i nginx.tar`.
3. **El clúster está vacío.** `kubectl get pods` debe responder `No resources found in default namespace.` Si quedan pods o deployments de las demos, se borran antes con `kubectl delete -f` y el fichero que los creó, para no confundirlos con los de las prácticas.
4. **Hay una carpeta de trabajo.** Se crea `s18-1-practicas` con una subcarpeta por práctica (`practica1`, `practica2`). Los ficheros se escriben a mano, sin copiarlos de las demos.

---

## Práctica 1: Pod de nginx con YAML

Se escribe el fichero YAML de un pod que publica la web de la tienda, se aplica y se comprueba hasta que está en ejecución. Después se provocan a propósito dos errores en copias del fichero, para aprender a leer los mensajes con los que Kubernetes los rechaza.

**Qué se consigue.** Escribir el fichero sin copiarlo obliga a recordar la estructura fija de todo objeto de Kubernetes (`apiVersion`, `kind`, `metadata`, `spec`). Provocar los errores sirve para reconocerlos cuando aparezcan sin querer, porque en la práctica los fallos de YAML son lo más habitual al escribir ficheros a mano.

**Pasos**

1. Creamos la carpeta `practica1` dentro de `s18-1-practicas` y, en ella, un fichero `pod-tienda.yaml` con un editor de texto (IntelliJ, Visual Studio Code o el Bloc de notas). Sangramos solo con espacios, nunca con la tecla Tab.
2. Escribimos los cuatro bloques de un objeto de Kubernetes. El objeto es un pod llamado `tienda-web`.
3. En `metadata` añadimos dos etiquetas: `app` con el valor `tienda` y `entorno` con el valor `aula`.
4. En `spec` declaramos un único contenedor llamado `nginx`, de la imagen `nginx`, con la política de descarga `IfNotPresent` y con el puerto 80 declarado.
5. Entramos en la carpeta `practica1` desde `cmd` y aplicamos el fichero con `kubectl apply`. Comprobamos que la respuesta es `created`.
6. Consultamos los pods con `kubectl get pods` hasta que `tienda-web` aparezca como `Running`.
7. Con `kubectl describe pod tienda-web` localizamos y anotamos: el nodo en el que se ejecuta, la dirección IP del pod, sus etiquetas y los eventos. De cada evento anotamos qué componente lo genera (columna `From`).
8. Buscamos el pod por etiqueta: con `app=tienda` debe aparecer y con `app=blog` no. Repetimos la búsqueda con la etiqueta `entorno`.
9. Hacemos una copia del fichero con el nombre `pod-error-campo.yaml`. En la copia escribimos el nombre `contenedores` en lugar del campo que contiene la lista de contenedores y la aplicamos. Anotamos el mensaje que da Kubernetes y qué campo señala.
10. Hacemos otra copia del fichero original con el nombre `pod-error-sangria.yaml`. En la copia quitamos dos espacios de sangría a la línea de `image` y la aplicamos. Anotamos el mensaje y el número de línea que indica.
11. Aplicamos de nuevo el fichero original y comprobamos qué responde Kubernetes.
12. Borramos el pod usando el fichero `pod-tienda.yaml` y comprobamos que no queda ninguno.

**Pistas**

- Los pods pertenecen al grupo principal de la API, cuya versión es `v1`. El tipo se escribe con la inicial en mayúscula.
- `containers` es una lista: cada elemento empieza por un guion y las demás claves del elemento se alinean con la primera (`name`). `ports` también es una lista, y el campo del puerto del contenedor se llama `containerPort`.
- La política de descarga se escribe `imagePullPolicy`, con esa mezcla de mayúsculas y minúsculas. YAML distingue entre mayúsculas y minúsculas.
- Si el pod queda en `ErrImagePull` o `ImagePullBackOff`, hay que revisar que la imagen esté en Docker y que la política de descarga esté escrita exactamente así. `describe` muestra el motivo al final, en `Events`.
- En los mensajes de error: si dicen `unknown field` (o algo equivalente), un nombre de campo está mal escrito y el mensaje lo nombra; si empiezan por `error parsing` o mencionan `yaml:` y un número de línea, el fallo es de formato o de sangría. El número de línea puede señalar una línea después de la equivocada.
- Cuando el fichero ya coincide con el clúster, `apply` no crea nada nuevo.

---

## Práctica 2: Deployment y autorreparación

Se escribe el fichero de un deployment con tres réplicas de la web de la tienda, se borra un pod para comprobar que Kubernetes lo repone y se cambia el número de réplicas de dos formas: con el comando `kubectl scale` y editando el fichero.

**Qué se consigue.** Comprobar con los propios ojos que el sistema repara lo que se rompe es lo que explica por qué se usa Kubernetes y no contenedores sueltos. Cambiar el número de réplicas de las dos formas deja ver la diferencia entre ordenar una acción y declarar un resultado: la orden se aplica y el fichero queda desfasado; el fichero es la fuente de verdad.

**Pasos**

1. Creamos la carpeta `practica2` dentro de `s18-1-practicas` y, en ella, el fichero `deployment-tienda.yaml`.
2. Escribimos un deployment llamado `tienda` con tres réplicas. Su plantilla crea pods iguales que el de la Práctica 1: etiqueta `app: tienda`, un contenedor `nginx`, imagen `nginx`, política de descarga `IfNotPresent` y puerto 80. El selector tiene que reconocer esos pods por su etiqueta.
3. Aplicamos el fichero y comprobamos con `kubectl get deployments` que llega a `3/3`.
4. Listamos los pods con `kubectl get pods -l app=tienda` y los ReplicaSets con `kubectl get replicasets`. Anotamos cómo se construye el nombre de cada pod.
5. Copiamos el nombre de uno de los pods y lo borramos con `kubectl delete pod`. Sin esperar, repetimos `kubectl get pods` y anotamos qué pasa con el pod borrado y qué aparece nuevo.
6. Escalamos a cinco réplicas con `kubectl scale` y comprobamos que hay cinco pods.
7. Sin tocar el fichero, volvemos a aplicarlo y observamos cuántos pods quedan. Anotamos por qué ocurre.
8. Editamos el fichero para que pida cuatro réplicas y lo aplicamos. Anotamos la palabra con la que responde Kubernetes y comprobamos que hay cuatro pods.
9. Editamos el fichero para que vuelva a pedir tres réplicas y lo aplicamos de nuevo. Dejamos el deployment en marcha para la práctica siguiente.

**Pistas**

- Los deployments pertenecen al grupo `apps` de la API: su versión es `apps/v1`.
- El nombre de cada pod se compone del nombre del deployment, un código que identifica la plantilla y cinco letras al azar.
- La etiqueta de la plantilla y la del selector tienen que ser iguales. Si no lo son, Kubernetes rechaza el fichero.
- Un pod borrado pasa por `Terminating` mientras se apaga. Hay que mirar la lista justo después de borrarlo, porque el pod nuevo tarda solo unos segundos en estar listo.
- `kubectl scale` es una orden; no cambia el fichero. Lo que dice el fichero y lo que hay en el clúster pueden dejar de coincidir hasta que se vuelve a aplicar.
- Al aplicar un fichero que cambia un objeto que ya existe, la respuesta no es `created` ni `unchanged`.

---

## Práctica 3: Acceder a una aplicación del clúster

Con el deployment de la práctica anterior en marcha, se abre una puerta con `kubectl port-forward` para ver la web de la tienda desde el navegador y se consultan los registros de los pods para averiguar cuál ha atendido las peticiones.

**Qué se consigue.** Un pod tiene una dirección propia dentro del clúster y llegar a él desde el equipo exige un paso explícito. Saberlo evita la sensación de que la aplicación no responde cuando, en realidad, solo falta abrir el acceso. Consultar los registros enseña a comprobar qué ha pasado dentro de un pod concreto, que es lo primero que se hace cuando una aplicación se comporta de forma extraña.

**Pasos**

1. Comprobamos que el deployment `tienda` está en marcha con tres pods. Si no lo está, aplicamos el fichero de la Práctica 2.
2. Comprobamos que el puerto 8082 del equipo está libre con `netstat`. Usamos el 8082 para no chocar con el 8081 de las demos ni con el 8080 de Jenkins.
3. Abrimos el acceso con `kubectl port-forward` al deployment `tienda`: puerto 8082 del equipo hacia el puerto 80 del pod. La terminal queda ocupada: la dejamos así.
4. Abrimos el navegador en `http://localhost:8082` y comprobamos que se ve la página de bienvenida de `nginx`. Recargamos la página tres o cuatro veces.
5. Observamos la terminal del `port-forward` y anotamos qué línea aparece por cada recarga.
6. Abrimos una segunda terminal `cmd` y listamos los pods. Consultamos los registros de cada uno de los tres con `kubectl logs` y localizamos en cuál aparecen las peticiones de nuestras recargas. Anotamos la línea que registra una de ellas.
7. Volvemos a la primera terminal y cerramos el acceso con `Ctrl + C`. Comprobamos que el navegador deja de responder y que los tres pods siguen en `Running`.
8. Borramos el deployment con el fichero que lo creó y comprobamos que no queda ningún pod.

**Pistas**

- `kubectl port-forward` se escribe con el objeto (`deployment/tienda`) y después `puerto-del-equipo:puerto-del-pod`, con el equipo a la izquierda.
- Si aparece `unable to listen on port 8082`, otro programa ocupa ese puerto. Se busca con `netstat -ano | findstr :8082` y se usa otro puerto libre.
- Al abrir el acceso sobre un deployment, Kubernetes elige uno de sus pods y mantiene la conexión con ese durante toda la vida del comando. Por eso las peticiones aparecen en un solo pod y no repartidas.
- `kubectl logs` necesita el nombre completo de un pod. Con la opción `-l` se pueden pedir los registros de todos los pods que tengan una etiqueta, y la opción `--prefix` antepone a cada línea el nombre del pod que la ha escrito.
- Las líneas de petición de `nginx` contienen el método y la ruta, como `GET / HTTP/1.1`, y el código de respuesta (`200` si todo ha ido bien).
- Cerrar el acceso con `Ctrl + C` no para ni borra nada del clúster: solo cierra la puerta.
