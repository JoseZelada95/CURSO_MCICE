# S18-1 Soluciones

Los ficheros YAML de estas soluciones están en `s18-1-practicas.zip`, en las carpetas `practica1` y `practica2`. La Práctica 3 no tiene ficheros propios: trabaja sobre el deployment de la Práctica 2. Las salidas que se muestran son orientativas: los nombres de los pods, los códigos, los tiempos, las direcciones IP y la redacción exacta de algunos mensajes cambian de un equipo a otro y de una versión de `kubectl` a otra.

---

## Práctica 1: Pod de nginx con YAML

El fichero describe un pod con un único contenedor de `nginx`. Es el mismo tipo de objeto que el de la Demo 2 pero con otro nombre y con dos etiquetas, lo que obliga a escribirlo de memoria y a pensar qué va en cada bloque. Los cuatro bloques (`apiVersion`, `kind`, `metadata`, `spec`) están siempre y en ese orden.

```yaml
# S18-1 Práctica 1: Pod de nginx con YAML
#
# Objetivo: describir en un fichero el pod que publica la web de una tienda
# y comprobar que Kubernetes lo crea y lo ejecuta.
#
# Aplica las técnicas de S18-1:
#   1. Escribir un objeto de Kubernetes con sus cuatro bloques: apiVersion,
#      kind, metadata y spec
#   2. Aplicar el fichero con kubectl apply y comprobar el resultado con
#      get y describe
#
# Concepto clave: el fichero es el estado deseado. Si algo de lo que escribimos
# no encaja con lo que Kubernetes espera (un campo mal escrito, una sangría
# equivocada), no crea el objeto y explica el motivo en un mensaje de error.

# apiVersion: versión de la API a la que pertenece el tipo de objeto.
# Los pods están en el grupo principal de la API, que se escribe v1.
apiVersion: v1

# kind: tipo de objeto que describimos. Se escribe tal cual, con la P mayúscula.
kind: Pod

# metadata: datos que identifican al objeto.
metadata:
  # name: nombre del pod dentro del clúster.
  name: tienda-web
  # labels: etiquetas, pares clave-valor pegados al objeto. Permiten agrupar
  # y buscar objetos, por ejemplo con kubectl get pods -l app=tienda.
  # Ponemos dos para poder buscar por cualquiera de ellas.
  labels:
    app: tienda
    entorno: aula

# spec: especificación, es decir, cómo queremos que sea el pod.
spec:
  # containers: lista de contenedores del pod. Es una lista porque un pod
  # puede llevar varios; el guion marca cada elemento.
  containers:
    # name: nombre del contenedor dentro del pod.
    - name: nginx
      # image: imagen de la que se crea el contenedor.
      image: nginx
      # imagePullPolicy: cuándo descarga Kubernetes la imagen.
      # IfNotPresent = solo si no está ya en el equipo. Sin esta línea, una imagen
      # sin etiqueta de versión se vuelve a consultar y descargar de Docker Hub
      # cada vez que se crea el pod.
      imagePullPolicy: IfNotPresent
      # ports: puertos en los que escucha el programa del contenedor.
      # Es solo documentación: no publica nada fuera del pod. nginx escucha en el 80.
      ports:
        - containerPort: 80
```

Aplicamos el fichero desde la carpeta `practica1`:

```bash
kubectl apply -f pod-tienda.yaml
```

<pre>
pod/tienda-web created
</pre>

```bash
kubectl get pods
```

<pre>
NAME         READY   STATUS    RESTARTS   AGE
tienda-web   1/1     Running   0          9s
</pre>

En `kubectl describe pod tienda-web` los datos que se pedían salen en estas partes (se omiten líneas intermedias):

<pre>
Name:             tienda-web
Namespace:        default
Node:             docker-desktop/192.168.65.3
Status:           Running
IP:               10.1.0.15
Labels:           app=tienda
                  entorno=aula
...
Events:
  Type    Reason     Age   From               Message
  ----    ------     ----  ----               -------
  Normal  Scheduled  20s   default-scheduler  Successfully assigned default/tienda-web to docker-desktop
  Normal  Pulled     19s   kubelet            Container image "nginx" already present on machine
  Normal  Created    19s   kubelet            Created container: nginx
  Normal  Started    19s   kubelet            Started container nginx
</pre>

El evento `Scheduled` lo genera `default-scheduler`, el componente que decide en qué nodo se coloca el pod. Los otros tres los genera `kubelet`, el programa del nodo que trabaja con los contenedores. El evento `Pulled` con el texto `already present on machine` confirma que `imagePullPolicy: IfNotPresent` ha funcionado: no se ha descargado nada.

La búsqueda por etiqueta:

```bash
kubectl get pods -l app=tienda
```

Devuelve el pod. Con `-l app=blog` responde `No resources found in default namespace.`, porque ningún pod tiene esa etiqueta. Con `-l entorno=aula` vuelve a aparecer: cada etiqueta funciona de forma independiente.

### Los dos errores

Para el primer error usamos el fichero `pod-tienda-error-campo.yaml`, que es el original con `containers` escrito como `contenedores`:

```yaml
# S18-1 Práctica 1: Fichero con un campo mal escrito (apoyo)
#
# Objetivo: ver qué mensaje da Kubernetes cuando un nombre de campo no existe.
#
# Aplica las técnicas de S18-1:
#   1. Aplicar un fichero con kubectl apply
#   2. Leer un mensaje de error de Kubernetes para localizar el fallo
#
# Concepto clave: Kubernetes comprueba el fichero contra la definición de cada
# tipo de objeto y rechaza los campos que no existen. Este fichero NO se puede
# aplicar: es el pod-tienda.yaml con un error intencionado.

apiVersion: v1
kind: Pod
metadata:
  name: tienda-web
  labels:
    app: tienda
    entorno: aula
spec:
  # ERROR INTENCIONADO: el campo se llama containers, en inglés.
  # Con contenedores, Kubernetes no lo reconoce como un campo de spec.
  contenedores:
    - name: nginx
      image: nginx
      imagePullPolicy: IfNotPresent
      ports:
        - containerPort: 80
```

```bash
kubectl apply -f pod-tienda-error-campo.yaml
```

La respuesta varía según la versión de `kubectl`, pero siempre nombra el campo desconocido. Una forma habitual es esta:

<pre>
Error from server (BadRequest): error when creating "pod-tienda-error-campo.yaml": Pod in version "v1" cannot be handled as a Pod: strict decoding error: unknown field "spec.contenedores"
</pre>

Otras versiones lo escriben como `error validating data: ValidationError(Pod.spec): unknown field "contenedores" in io.k8s.api.core.v1.PodSpec`. En todos los casos la clave está en `unknown field` y en el nombre que viene después: ese campo no existe en la definición de un pod. Si Kubernetes además se queja de que falta `containers`, es la misma causa vista desde el otro lado.

Para el segundo error usamos `pod-tienda-error-sangria.yaml`, que es el original con la línea de `image` sangrada dos espacios menos:

```yaml
# S18-1 Práctica 1: Fichero con una sangría equivocada (apoyo)
#
# Objetivo: ver qué mensaje da Kubernetes cuando el YAML está mal sangrado.
#
# Aplica las técnicas de S18-1:
#   1. Aplicar un fichero con kubectl apply
#   2. Leer un mensaje de error de Kubernetes para localizar el fallo
#
# Concepto clave: en YAML la sangría indica a qué pertenece cada línea. Si no
# se respeta, el fichero no se puede ni leer. Este fichero NO se puede aplicar:
# es el pod-tienda.yaml con un error intencionado.

apiVersion: v1
kind: Pod
metadata:
  name: tienda-web
  labels:
    app: tienda
    entorno: aula
spec:
  containers:
    - name: nginx
    # ERROR INTENCIONADO: image debería estar alineada con name (seis espacios).
    # Con cuatro espacios queda alineada con el guion, en lugar de dentro del
    # elemento de la lista, y el YAML deja de ser válido.
    image: nginx
      imagePullPolicy: IfNotPresent
      ports:
        - containerPort: 80
```

```bash
kubectl apply -f pod-tienda-error-sangria.yaml
```

<pre>
error: error parsing pod-tienda-error-sangria.yaml: error converting YAML to JSON: yaml: line 26: did not find expected '-' indicator
</pre>

Aquí Kubernetes ni siquiera llega a mirar los campos: el fichero no es YAML válido. La línea `image` ha quedado alineada con el guion de la lista, y el lector de YAML espera que, en ese nivel, empiece otro elemento de la lista con su guion. El número de línea del mensaje depende del fichero de cada uno (el fichero del zip lleva comentarios y el de cada alumno seguramente no) y puede señalar una línea posterior a la equivocada.

Los dos errores se diferencian en algo importante: uno es de **contenido** (el YAML se lee bien pero un campo no existe) y el otro es de **formato** (el YAML no se puede leer). Saber en cuál estamos orienta dónde mirar.

Al volver a aplicar el original:

```bash
kubectl apply -f pod-tienda.yaml
```

<pre>
pod/tienda-web unchanged
</pre>

Los dos intentos con error no han creado ni modificado nada, y el pod sigue como estaba. Para limpiar:

```bash
kubectl delete -f pod-tienda.yaml
```

<pre>
pod "tienda-web" deleted
</pre>

**Decisiones tomadas**

- Dos etiquetas (`app` y `entorno`) en lugar de una: con una sola no se puede comprobar que cada etiqueta se busca por separado y que una búsqueda con un valor que no existe devuelve vacío.
- `imagePullPolicy: IfNotPresent` explícito: sin él, una imagen sin etiqueta de versión se vuelve a consultar y descargar de Docker Hub al crear el pod. Con él se usa la imagen del equipo, que es más rápido y no depende de la red.
- Errores en copias del fichero y no en el original: así el original queda siempre correcto y se puede comparar con las copias con error, y no hay riesgo de perderlo.
- Un error de contenido y otro de formato: son los dos tipos de fallo que más aparecen al escribir YAML, y los mensajes son distintos en cada caso.
- `containerPort: 80` se declara aunque no haga nada: es documentación sobre dónde escucha `nginx` y la información que luego se necesitará para abrir el acceso.

---

## Práctica 2: Deployment y autorreparación

El deployment pide tres réplicas del mismo pod de la tienda. La plantilla contiene casi literalmente el pod de la práctica anterior, sin `apiVersion` ni `kind`. La etiqueta `app: tienda` aparece dos veces: en la plantilla, para que los pods la lleven, y en el selector, para que el deployment los reconozca como suyos.

```yaml
# S18-1 Práctica 2: Deployment y autorreparación
#
# Objetivo: pedir a Kubernetes tres copias de la web de la tienda, ver que las
# mantiene aunque borremos pods y cambiar su número de dos formas distintas.
#
# Aplica las técnicas de S18-1:
#   1. Escribir un deployment con su plantilla y su selector
#   2. Comprobar la autorreparación borrando un pod
#   3. Escalar con kubectl scale y cambiando el fichero
#
# Concepto clave: un deployment mantiene el estado deseado. Si cambiamos el
# número de réplicas en el fichero y lo aplicamos, Kubernetes actualiza el
# deployment existente en lugar de crear otro.

# Los deployments están en el grupo apps de la API, por eso la versión es apps/v1.
apiVersion: apps/v1
kind: Deployment
metadata:
  # Nombre del deployment. Los pods que cree se llamarán tienda-<código>-<letras>.
  name: tienda
spec:
  # replicas: cuántos pods queremos. Es el estado deseado y es la línea que
  # cambiamos para escalar desde el fichero.
  replicas: 3
  # selector: cómo reconoce el deployment sus pods. Cuenta los que tienen
  # la etiqueta app: tienda.
  selector:
    matchLabels:
      app: tienda
  # template: molde con el que el deployment crea cada pod.
  template:
    metadata:
      # Etiqueta de los pods creados. Tiene que coincidir con la del selector;
      # si no, Kubernetes rechaza el fichero.
      labels:
        app: tienda
    spec:
      containers:
        - name: nginx
          image: nginx
          # IfNotPresent: usa la imagen que ya está en el equipo sin volver a descargarla.
          imagePullPolicy: IfNotPresent
          ports:
            - containerPort: 80
```

```bash
kubectl apply -f deployment-tienda.yaml
```

<pre>
deployment.apps/tienda created
</pre>

```bash
kubectl get deployments
```

<pre>
NAME     READY   UP-TO-DATE   AVAILABLE   AGE
tienda   3/3     3            3           12s
</pre>

```bash
kubectl get pods -l app=tienda
```

<pre>
NAME                      READY   STATUS    RESTARTS   AGE
tienda-7b9f6c8d5-4kq2m    1/1     Running   0          25s
tienda-7b9f6c8d5-9xw7t    1/1     Running   0          25s
tienda-7b9f6c8d5-lz5hc    1/1     Running   0          25s
</pre>

El nombre de cada pod se compone de `tienda` (el deployment), `7b9f6c8d5` (un código que identifica la plantilla, igual para los tres) y cinco letras al azar (distintas en cada pod). El ReplicaSet, que es quien cuenta las réplicas, lleva el nombre del deployment más el código de la plantilla:

```bash
kubectl get replicasets
```

<pre>
NAME               DESIRED   CURRENT   READY   AGE
tienda-7b9f6c8d5   3         3         3       40s
</pre>

### Autorreparación

Borramos uno de los pods (cambiando el nombre por el de uno de nuestros pods) y, sin esperar, listamos de nuevo:

```bash
kubectl delete pod tienda-7b9f6c8d5-4kq2m
```

```bash
kubectl get pods
```

<pre>
NAME                      READY   STATUS              RESTARTS   AGE
tienda-7b9f6c8d5-4kq2m    1/1     Terminating         0          2m
tienda-7b9f6c8d5-9xw7t    1/1     Running             0          2m
tienda-7b9f6c8d5-lz5hc    1/1     Running             0          2m
tienda-7b9f6c8d5-s8d6r    0/1     ContainerCreating   0          2s
</pre>

El pod borrado pasa por `Terminating` y aparece uno nuevo con otro nombre (`s8d6r`) y `AGE` de unos segundos. Lo ha creado el ReplicaSet al ver que había dos pods vivos y se pedían tres. Durante todo el proceso quedan pods atendiendo, así que el servicio no se interrumpe.

### Dos formas de cambiar el número de réplicas

Primero, con la orden:

```bash
kubectl scale deployment tienda --replicas=5
```

<pre>
deployment.apps/tienda scaled
</pre>

Hay cinco pods. Pero el fichero sigue diciendo `replicas: 3`. Al aplicarlo de nuevo:

```bash
kubectl apply -f deployment-tienda.yaml
```

<pre>
deployment.apps/tienda configured
</pre>

Los pods vuelven a ser tres (dos de ellos pasan por `Terminating`). El fichero manda: Kubernetes compara lo que hay (cinco) con lo que pide el fichero (tres) y actúa hasta igualarlos. Por eso `kubectl scale` es cómodo para una prueba rápida, pero un cambio que debe durar se escribe en el fichero.

Segundo, cambiando el fichero. Editamos la línea `replicas: 3` para que diga `replicas: 4` y aplicamos:

```bash
kubectl apply -f deployment-tienda.yaml
```

<pre>
deployment.apps/tienda configured
</pre>

La palabra es `configured`: el deployment ya existía y Kubernetes lo ha modificado. Las tres respuestas posibles de `apply` se distinguen así: `created` (no existía y se ha creado), `unchanged` (existía y ya coincidía con el fichero) y `configured` (existía y se ha cambiado para que coincida). Hay cuatro pods. Volvemos a `replicas: 3`, aplicamos y quedan tres, que es como dejamos el deployment para la práctica siguiente.

**Decisiones tomadas**

- Nombre `tienda` en lugar de `web`: no coincide con ningún objeto de las demos, así que ningún comando aplicado por costumbre sobre un objeto de las demos afecta a este.
- Selector y plantilla con la misma etiqueta `app: tienda`: es lo que exige Kubernetes. Si no coinciden, el deployment crearía pods que luego no reconocería como suyos y por eso rechaza el fichero.
- Escalar de las dos formas y reaplicar el fichero entre medias: es la forma más rápida de ver que el fichero es la fuente de verdad. Quien escala con la orden y no actualiza el fichero se encuentra con un clúster que cambia de repente la próxima vez que alguien aplica el fichero.
- Dejar el deployment en marcha al final: la Práctica 3 trabaja sobre él, y evita repetir el apply.

---

## Práctica 3: Acceder a una aplicación del clúster

Esta práctica no tiene ficheros: todo son comandos sobre el deployment `tienda` de la práctica anterior. Si no estuviera en marcha, se aplicaría de nuevo `deployment-tienda.yaml`.

Comprobamos que el puerto 8082 está libre:

```bash
netstat -ano | findstr :8082
```

No debe salir nada. Abrimos el acceso:

```bash
kubectl port-forward deployment/tienda 8082:80
```

<pre>
Forwarding from 127.0.0.1:8082 -> 80
Forwarding from [::1]:8082 -> 80
</pre>

La terminal queda ocupada mientras la puerta esté abierta. Abrimos el navegador en `http://localhost:8082` y vemos la página `Welcome to nginx!`. Cada recarga añade una línea en la terminal del `port-forward`:

<pre>
Handling connection for 8082
Handling connection for 8082
Handling connection for 8082
</pre>

Esa línea la escribe `kubectl` y significa que ha entregado una petición al pod. No dice a qué pod. Para averiguarlo abrimos una segunda terminal:

```bash
kubectl get pods
```

Y consultamos los registros de cada pod (con el nombre completo de cada uno):

```bash
kubectl logs tienda-7b9f6c8d5-9xw7t
```

En dos de los tres pods solo aparecen las líneas de arranque de `nginx`. En el tercero, además, aparecen las peticiones recibidas:

<pre>
127.0.0.1 - - [29/Oct/2026:12:41:07 +0000] "GET / HTTP/1.1" 200 615 "-" "Mozilla/5.0 ..." "-"
127.0.0.1 - - [29/Oct/2026:12:41:09 +0000] "GET / HTTP/1.1" 200 615 "-" "Mozilla/5.0 ..." "-"
</pre>

Cada línea dice el método y la ruta pedida (`GET /`), el código con el que respondió `nginx` (`200`, es decir, todo correcto) y el tamaño de la respuesta. Si la página pidiera además el icono de la pestaña, se vería una línea adicional con `/favicon.ico`, que suele terminar en `404`: es normal, `nginx` no tiene ese fichero.

Para ver los tres a la vez, sin ir pod por pod:

```bash
kubectl logs -l app=tienda --prefix
```

Con `-l` pide los registros de todos los pods con esa etiqueta, y `--prefix` antepone a cada línea el nombre del pod. Las peticiones salen con el mismo prefijo, el del pod que las atendió.

Cerramos el acceso con `Ctrl + C` en la primera terminal. El navegador deja de responder, pero `kubectl get pods` sigue mostrando los tres pods en `Running`: solo se ha cerrado la puerta. Para terminar, limpiamos desde la carpeta `practica2`:

```bash
kubectl delete -f deployment-tienda.yaml
```

<pre>
deployment.apps "tienda" deleted
</pre>

Los tres pods pasan por `Terminating` y desaparecen. Al borrar el deployment ya no queda estado deseado que mantener y nadie los recrea.

**Decisiones tomadas**

- Puerto 8082 y no el 8081 de las demos: si alguien dejó abierto un `port-forward` de la demo en otra terminal, el 8081 estaría ocupado. El 8080 sigue descartado por Jenkins.
- `port-forward` sobre `deployment/tienda` y no sobre un pod concreto: no hay que copiar el nombre de un pod. El inconveniente es el que se descubre al mirar los registros: todo el tráfico va a un solo pod.
- Consultar los registros de los tres pods: la línea `Handling connection` no dice qué pod ha respondido, y los registros del propio `nginx` son la única forma de saberlo. Es el reflejo que conviene tener ante cualquier comportamiento extraño de una aplicación.
- `logs -l ... --prefix` como alternativa: pod por pod es lo que se hace al diagnosticar un pod concreto, pero con muchas réplicas es inviable, y esta forma muestra las líneas de todos de una vez.
