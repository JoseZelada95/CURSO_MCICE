# S17-2 Prácticas

## Objetivos

Las tres prácticas repiten con otros proyectos lo que se vio en las demos, cada vez con menos ayuda. En la Práctica 1 se escribe el `docker-compose.yml` de una API con PostgreSQL sin tenerlo delante, con el `.env` y el `.gitignore`. En la Práctica 2 se hace lo mismo con una API y MongoDB, cambiando lo que cambia de una base de datos a otra. En la Práctica 3 se prepara el Compose del proyecto del grupo para que cualquier compañero lo arranque con un solo comando.

Las Prácticas 1 y 2 trabajan con `s17-2-practicas.zip`, que contiene dos carpetas de proyecto: `practica1-tareas-db` y `practica2-notas-api`. Ninguna de las dos tiene `docker-compose.yml`: hay que escribirlo. Cada proyecto se abre en su propia ventana de IntelliJ con `File > Open`, sobre la carpeta que contiene directamente el `pom.xml`, `Trust Project` y `New Window`. Si aparece el aviso `Maven build scripts found`, se pulsa `Load`.

Reglas comunes a las tres prácticas:

- Los puertos 8080 (Jenkins), 5432 (PostgreSQL) y 27017 (MongoDB) están ocupados en el equipo. Se publica la API en el 8081, PostgreSQL en el 5433 y MongoDB en el 27018.
- Si queda en marcha algún contenedor de S17-1 en el 8081, se borra antes con `docker rm -f` seguido de su nombre.
- Las imágenes son `postgres:16`, `mongo:7` y `eclipse-temurin:21-jre`, las mismas de las demos. Si alguna no está en el equipo, se consigue con la variante A, B o C de la Demo 1 de esta parte.
- Cada comando se ejecuta desde la carpeta correcta: `mvn` desde la carpeta del proyecto (la que contiene el `pom.xml`); `docker compose` desde la carpeta que contiene el `docker-compose.yml` y el `.env`; `docker volume`, `docker network`, `docker ps` y `docker logs`, desde cualquier carpeta.
- El `Dockerfile` de cada proyecto ya está escrito. Lo que falta es el Compose.
- Al terminar cada práctica se deja el equipo limpio con `docker compose down -v`, salvo que se indique otra cosa.

---

## Práctica 1: Compose de una API con PostgreSQL, sin ayuda

`practica1-tareas-db` es una API de tareas con Spring Data JPA que guarda los datos en PostgreSQL. Responde a estas rutas:

| Ruta | Qué hace | Respuesta |
|---|---|---|
| `GET /api/tareas` | Lista todas las tareas | `200` con una lista (vacía al principio) |
| `GET /api/tareas/{id}` | Devuelve una tarea | `200` con la tarea, o `404` si no existe |
| `POST /api/tareas` | Crea una tarea con el cuerpo `{"titulo":"...","descripcion":"...","completada":false}` | `201` con la tarea creada |
| `DELETE /api/tareas/{id}` | Borra una tarea | `204`, o `404` si no existe |

La aplicación escucha en el 8080 y lee tres variables de entorno: `DB_URL` (la dirección JDBC de la base de datos), `DB_USER` y `DB_PASSWORD`. La contraseña no tiene valor por defecto. El proyecto **no tiene `docker-compose.yml`, ni `.env`, ni `.gitignore`**: hay que escribirlos.

**Pasos**
1. Se abre la carpeta `practica1-tareas-db` en IntelliJ y se carga Maven.
2. Se genera el JAR con Maven, sin ejecutar las pruebas (la aplicación necesita una base de datos que todavía no hay). Se comprueba su nombre en la carpeta `target`.
3. Se crean en la raíz del proyecto el `.env` (con `DB_NAME`, `DB_USER` y `DB_PASSWORD`, la base de datos se llama `tareas`), el `.env.example` y el `.gitignore`.
4. Se escribe el `docker-compose.yml` **por bloques**, probando después de cada uno: primero solo la base de datos con su volumen, después la API.
5. Se comprueba el fichero con las variables ya sustituidas y se levanta todo con una sola orden, construyendo la imagen de la API.
6. Se comprueba con `docker compose ps` que la base de datos está `healthy` y la API `Up`.
7. Con Postman se crean dos tareas y se consulta la lista con `curl.exe` o con Postman.
8. Se bajan los contenedores sin borrar el volumen, se vuelven a levantar y se comprueba que las dos tareas siguen ahí.
9. Se bajan los contenedores borrando también el volumen, se vuelven a levantar y se comprueba que la lista está vacía.
10. Se contesta por escrito: ¿qué diferencia hay entre los dos `down`? ¿Cómo se llama el volumen en `docker volume ls` y por qué?

**Pistas**
- El nombre del servicio de la base de datos es la dirección que usa la API. El puerto de esa dirección es el de dentro de la red de Compose, no el que se publica en el equipo.
- PostgreSQL guarda sus datos en `/var/lib/postgresql/data`. El volumen se monta ahí y se declara al final del fichero.
- El `healthcheck` de PostgreSQL usa `pg_isready`. Si el comando lleva variables de la imagen (`POSTGRES_USER`, `POSTGRES_DB`), cada `$` se escribe doble.
- La API tiene que esperar a que la base de datos esté `healthy`, no solo `Up`.
- Si la API sale con `Exited (1)`, se aplica el orden de siempre: `docker compose ps -a`, `docker compose logs api` y `docker compose config`.
- `down -v` borra los datos. Si no se quiere perderlos, se usa `down` a secas.
- El `.env.example` lleva los mismos nombres que el `.env`, pero sin la contraseña. El `.gitignore` debe impedir que se suba el `.env`.

---

## Práctica 2: Compose de una API con MongoDB

`practica2-notas-api` es una API de notas con Spring Data MongoDB. Responde a estas rutas:

| Ruta | Qué hace | Respuesta |
|---|---|---|
| `GET /api/notas` | Lista todas las notas, o solo las que contienen la palabra `?texto=...` | `200` con una lista |
| `GET /api/notas/{id}` | Devuelve una nota | `200` con la nota, o `404` si no existe |
| `POST /api/notas` | Crea una nota con el cuerpo `{"titulo":"...","texto":"...","importante":false}` | `201` con la nota creada |
| `DELETE /api/notas/{id}` | Borra una nota | `204`, o `404` si no existe |

La aplicación escucha en el 8080 y lee la dirección de MongoDB de la variable de entorno `MONGO_URI`. Esta MongoDB no tiene usuario ni contraseña, así que no hace falta `.env`. El proyecto **no tiene `docker-compose.yml`**: hay que escribirlo.

**Pasos**
1. Se abre la carpeta `practica2-notas-api` en IntelliJ y se carga Maven.
2. Se genera el JAR con Maven. En este proyecto las pruebas pasan aunque no haya MongoDB en marcha; durante la ejecución aparecen líneas de excepciones del driver que no son un fallo del build.
3. Se escribe el `docker-compose.yml` con dos servicios: MongoDB (volumen, `healthcheck`, puerto 27018) y la API (puerto 8081, dirección por nombre de servicio, espera a que MongoDB esté `healthy`). La base de datos se llama `notas`.
4. Se levanta todo con una sola orden y se comprueba el estado con `docker compose ps`.
5. Con Postman se crean tres notas. Una de ellas lleva la palabra `café` en el texto. Se prueba el filtro `?texto=café` y la consulta de una nota que no existe (debe dar `404`).
6. Se bajan los contenedores sin borrar el volumen, se vuelven a levantar y se comprueba que las tres notas siguen ahí, con los mismos `id`.
7. Se comprueba con `docker volume ls` que el volumen existe, y con `docker volume inspect` a qué proyecto pertenece.
8. Se escribe una tabla con tres diferencias entre este Compose y el de la Práctica 1 (ruta del volumen, comprobación de salud y forma de la dirección).

**Pistas**
- MongoDB guarda sus datos en `/data/db`. Si se monta el volumen en otra ruta, el volumen se crea igual, pero los datos se pierden al bajar y no aparece ningún error.
- La comprobación de MongoDB usa `mongosh`, el cliente de línea de comandos, para hacer un `ping`. Se toma de la Demo 2.
- La dirección de MongoDB empieza por `mongodb://`, lleva el nombre del servicio y el puerto de dentro (27017), y termina en el nombre de la base de datos.
- Con MongoDB, si la API arranca antes de que el servidor esté listo, la aplicación arranca igualmente (la conexión es perezosa, S12-1) y el error aparece en la primera petición. Por eso conviene la espera.
- El nombre del volumen en `docker volume ls` lleva delante el nombre de la carpeta del proyecto.
- Para el `POST` se usa Postman (`Body > raw > JSON`, S09).

---

## Práctica 3: Compose del proyecto en grupo

Cada grupo escribe el `docker-compose.yml` de su proyecto para que otra persona lo ponga en marcha con una sola orden de Compose. La prueba final es real: un compañero del grupo clona el repositorio, crea su propio `.env` y lo arranca. No hay zip: se trabaja sobre el repositorio del grupo.

**Pasos**
1. Cada grupo abre su proyecto en IntelliJ y localiza la carpeta que contiene el `pom.xml` y el `Dockerfile` de S17-1. Todos los comandos de Compose se ejecutan desde esa carpeta, o desde la raíz del repositorio si el Compose se coloca allí (se decide en grupo y se anota).
2. Se decide qué servicios hacen falta: la aplicación y su base de datos (PostgreSQL o MongoDB, según el proyecto). Se anota qué variables de entorno lee la aplicación para su base de datos.
3. Se escribe el `.env` con las credenciales, el `.env.example` con los mismos nombres sin los valores secretos y el `.gitignore` que excluye el `.env`. Se comprueba con `git status` que el `.env` no aparece como pendiente de subir.
4. Se genera el JAR con Maven, sin ejecutar las pruebas, porque las que arrancan la aplicación completa necesitan una base de datos que todavía no hay.
5. Se escribe el `docker-compose.yml` con volumen, red por nombre de servicio, `healthcheck` y `depends_on` con `service_healthy`. Los puertos que se publican en el equipo se eligen libres (el 8083 no lo usa ninguna práctica anterior).
6. Se comprueba el fichero con las variables sustituidas, se levanta con una sola orden y se comprueba que la aplicación responde.
7. Se crea un dato, se bajan los contenedores sin borrar el volumen, se vuelven a levantar y se comprueba que el dato sigue ahí.
8. Se sube al repositorio el `docker-compose.yml`, el `.env.example` y el `.gitignore` (nunca el `.env`).
9. **Prueba con otra persona.** Un compañero del grupo clona el repositorio en una carpeta nueva, copia el `.env.example` como `.env`, escribe sus valores, genera el JAR con Maven sin pruebas y arranca todo con una sola orden de Compose. Si algo falla, se diagnostica y se corrige el repositorio hasta que funcione a la primera.
10. Se deja un párrafo en el `README` del proyecto con las instrucciones exactas para arrancar la aplicación con Compose.

**Pistas**
- Compose pone en marcha todo con una sola orden, pero el JAR no se sube a Git (la carpeta `target` está en el `.gitignore`). Quien clona el repositorio genera antes el JAR con Maven, sin pruebas. Ese paso va en el `README`.
- El puerto de dentro de la aplicación y el de la base de datos no cambian; el que se elige libre es el de la izquierda de cada `ports`.
- Si el proyecto usa PostgreSQL, el volumen va en `/var/lib/postgresql/data`; si usa MongoDB, en `/data/db`.
- La dirección de la base de datos en el Compose lleva el nombre del servicio, nunca `localhost`.
- Si el proyecto tiene la dirección de la base de datos escrita en `application.properties`, no hace falta tocar el código. Spring Boot permite sobrescribir cualquier propiedad con una variable de entorno cuyo nombre es el de la propiedad en mayúsculas y con guiones bajos en lugar de puntos y guiones (por ejemplo, `spring.datasource.url` se sobrescribe con `SPRING_DATASOURCE_URL`).
- Si un compañero ve el aviso `The "X" variable is not set. Defaulting to a blank string.`, le falta esa variable en su `.env`.
- Un `.env` ya subido a Git no se arregla añadiéndolo al `.gitignore` después. Se avisa al profesor antes de seguir.
- Las pruebas del proyecto que necesitan una base de datos fallan al construir el JAR sin ella. Mientras no haya una base de datos de pruebas, el JAR se construye con `-DskipTests`.
- Si algo falla, se aplica el orden de siempre: `docker compose ps -a`, `docker compose logs <servicio>` y `docker compose config`.
