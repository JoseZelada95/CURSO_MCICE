# S17-2 Demos

## Objetivos

Esta parte no trae herramientas nuevas: todo lo que aparece se vio en S16-2. Lo que cambia es cómo se trabaja con ello. En la Demo 1 el `docker-compose.yml` de una API con PostgreSQL no se lee ya escrito: se escribe desde un fichero vacío, **bloque a bloque**, y después de cada bloque se comprueba qué ocurre. Dos de los bloques fallan a propósito, para reconocer el mensaje la primera vez que se vea. En la Demo 2 se aplica lo mismo a una base de datos distinta, MongoDB, y se comprueba que los datos sobreviven a `docker compose down`.

Cada demo trabaja con su propio proyecto Spring Boot, ya preparado en `s17-2-demos.zip`: `libros` (Demo 1) y `tareas-mongo` (Demo 2). Son dos proyectos independientes; cada uno se abre en su propia ventana de IntelliJ.

### Antes de empezar

Necesitamos cuatro cosas en el equipo:

- Docker Desktop en marcha (la ballena de la barra de tareas, sin animación).
- Las imágenes `eclipse-temurin:21-jre` y `postgres:16` (Demo 1) y `mongo:7` (Demo 2).
- Los puertos 8081, 5433 y 27018 libres. Recordamos por qué no usamos los habituales: el 8080 lo ocupa Jenkins, el 5432 el PostgreSQL instalado en el equipo y el 27017 el MongoDB instalado en el equipo.
- Los dos proyectos abiertos en IntelliJ: `File > Open`, seleccionamos la carpeta del proyecto (la que contiene directamente el `pom.xml`), `Trust Project` y `New Window`. Si aparece el aviso `Maven build scripts found`, pulsamos `Load`.

Comprobamos las imágenes desde cualquier carpeta:

```bash
docker images
```

Si en la lista aparecen las tres, seguimos. Si falta alguna, la conseguimos con la variante que funcione en la red del aula (se decide probando `docker pull hello-world`). Los ejemplos usan `postgres:16`; para las otras dos imágenes se cambia el nombre.

**Variante A: Docker Hub.** Desde cualquier carpeta:

```bash
docker pull postgres:16
docker pull mongo:7
docker pull eclipse-temurin:21-jre
```

**Variante B: espejo `mirror.gcr.io`.** Desde cualquier carpeta. Descargamos con el nombre largo, añadimos el nombre corto y quitamos el largo, para que todos los comandos de este documento sean iguales en las tres variantes:

```bash
docker pull mirror.gcr.io/library/postgres:16
docker tag mirror.gcr.io/library/postgres:16 postgres:16
docker rmi mirror.gcr.io/library/postgres:16

docker pull mirror.gcr.io/library/mongo:7
docker tag mirror.gcr.io/library/mongo:7 mongo:7
docker rmi mirror.gcr.io/library/mongo:7
```

**Variante C: ficheros `.tar` de la carpeta `imagenes-docker` del Drive.** Descargamos los ficheros y los cargamos. El comando `docker load -i` se ejecuta desde la carpeta donde están los `.tar` o escribiendo la ruta completa; el nombre del fichero es el que tenga el descargado (aquí `postgres-16.tar`):

```bash
cd C:\Users\TuUsuario\Downloads
docker load -i postgres-16.tar
```

En cualquiera de las tres variantes, el resultado tiene que ser una línea `postgres:16` y otra `mongo:7` en `docker images`. Con la variante C, si la etiqueta de la imagen cargada fuera otra (por ejemplo `mongo:latest`), se añade el nombre que usan los ficheros de esta parte:

```bash
docker tag mongo:latest mongo:7
```

---

## Demo 1: Un Compose escrito por bloques

Una API con su base de datos son dos contenedores que tienen que cumplir tres cosas para funcionar juntos, y cada una se resuelve con una pieza del `docker-compose.yml`:

| Necesidad | Pieza del fichero | Qué pasa si falta |
|---|---|---|
| Los datos tienen que sobrevivir al contenedor | Un volumen con nombre en la ruta de datos de la imagen | Los datos se pierden al hacer `down` |
| La API tiene que encontrar la base de datos | El nombre del servicio como dirección | `Connection refused` |
| La API no puede arrancar antes de que la base de datos esté lista | `healthcheck` y `depends_on` con `condition: service_healthy` | Falla a veces, según la velocidad |

En lugar de leer el fichero terminado, se escribe en seis bloques y se prueba después de cada uno. Los bloques 3 y 5 son fallos provocados a propósito.

### El proyecto libros

`libros` es una API de Spring Boot con Spring Data JPA que guarda libros en PostgreSQL. Responde a tres rutas: `GET /api/libros`, `GET /api/libros/{id}` y `POST /api/libros`. Es el mismo tipo de proyecto de S06-1 y S16-2: la clase `Libro` es la entidad, `LibroRepository` el repositorio y `LibroController` el controlador.

Descomprimimos `s17-2-demos.zip` y abrimos la carpeta `libros` como proyecto independiente (`File > Open`, `Trust Project`, `New Window`). Si preferimos crearlo desde cero, se usa el generador de Spring Boot (`File > New > Project`, `Generators > Spring Boot`) con estos valores: **Name** `libros`, **Location** la carpeta de proyectos del curso, **Type** `Maven`, **Language** `Java`, **Group** `com.curso`, **Artifact** `libros`, **Package name** `com.curso`, **JDK** `21`, **Java** `21`, **Packaging** `Jar`, **Configuration** `Properties`. En la pantalla siguiente, **Spring Boot** `4.1.1` y las dependencias `Spring Web`, `Spring Data JPA` y `PostgreSQL Driver`. El código de las clases y de `application.properties` es el que sigue.

El `pom.xml` lo genera el asistente, así que solo lo leemos. Lo que importa en esta demo es el trío `groupId`, `artifactId` y `version`, que da nombre al JAR (`libros-0.0.1-SNAPSHOT.jar`), y las dos dependencias de datos: `spring-boot-starter-data-jpa` y el controlador `postgresql`.

<pre>
&amp;lt;?xml version="1.0" encoding="UTF-8"?&amp;gt;
&amp;lt;project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd"&amp;gt;
    &amp;lt;modelVersion&amp;gt;4.0.0&amp;lt;/modelVersion&amp;gt;

    &amp;lt;!-- parent: el POM padre de Spring Boot. Fija las versiones de todas las librerías,
         por eso ninguna dependencia de este fichero lleva &amp;lt;version&amp;gt;. --&amp;gt;
    &amp;lt;parent&amp;gt;
        &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
        &amp;lt;artifactId&amp;gt;spring-boot-starter-parent&amp;lt;/artifactId&amp;gt;
        &amp;lt;version&amp;gt;4.1.1&amp;lt;/version&amp;gt;
        &amp;lt;relativePath/&amp;gt;
    &amp;lt;/parent&amp;gt;

    &amp;lt;!-- groupId, artifactId y version dan nombre al JAR que Maven genera:
         artifactId-version.jar, es decir, target/libros-0.0.1-SNAPSHOT.jar.
         Ese es exactamente el nombre que el COPY del Dockerfile tiene que escribir. --&amp;gt;
    &amp;lt;groupId&amp;gt;com.curso&amp;lt;/groupId&amp;gt;
    &amp;lt;artifactId&amp;gt;libros&amp;lt;/artifactId&amp;gt;
    &amp;lt;version&amp;gt;0.0.1-SNAPSHOT&amp;lt;/version&amp;gt;
    &amp;lt;name&amp;gt;libros&amp;lt;/name&amp;gt;
    &amp;lt;description&amp;gt;S17-2 Demo 1: API de libros con PostgreSQL para ejecutar con Docker Compose&amp;lt;/description&amp;gt;

    &amp;lt;properties&amp;gt;
        &amp;lt;java.version&amp;gt;21&amp;lt;/java.version&amp;gt;
    &amp;lt;/properties&amp;gt;

    &amp;lt;dependencies&amp;gt;
        &amp;lt;!-- Spring MVC con Tomcat embebido y Jackson: lo necesario para una API REST. --&amp;gt;
        &amp;lt;dependency&amp;gt;
            &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
            &amp;lt;artifactId&amp;gt;spring-boot-starter-webmvc&amp;lt;/artifactId&amp;gt;
        &amp;lt;/dependency&amp;gt;

        &amp;lt;!-- Spring Data JPA, Hibernate y HikariCP: guardar entidades en una base de datos relacional. --&amp;gt;
        &amp;lt;dependency&amp;gt;
            &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
            &amp;lt;artifactId&amp;gt;spring-boot-starter-data-jpa&amp;lt;/artifactId&amp;gt;
        &amp;lt;/dependency&amp;gt;

        &amp;lt;!-- Controlador JDBC de PostgreSQL. Scope runtime: solo hace falta al ejecutar, no al compilar. --&amp;gt;
        &amp;lt;dependency&amp;gt;
            &amp;lt;groupId&amp;gt;org.postgresql&amp;lt;/groupId&amp;gt;
            &amp;lt;artifactId&amp;gt;postgresql&amp;lt;/artifactId&amp;gt;
            &amp;lt;scope&amp;gt;runtime&amp;lt;/scope&amp;gt;
        &amp;lt;/dependency&amp;gt;

        &amp;lt;!-- JUnit y las utilidades de Spring para pruebas (solo en src/test/java). --&amp;gt;
        &amp;lt;dependency&amp;gt;
            &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
            &amp;lt;artifactId&amp;gt;spring-boot-starter-test&amp;lt;/artifactId&amp;gt;
            &amp;lt;scope&amp;gt;test&amp;lt;/scope&amp;gt;
        &amp;lt;/dependency&amp;gt;
    &amp;lt;/dependencies&amp;gt;

    &amp;lt;build&amp;gt;
        &amp;lt;plugins&amp;gt;
            &amp;lt;!-- Reempaqueta el JAR para que sea ejecutable con java -jar (lleva dentro las librerías). --&amp;gt;
            &amp;lt;plugin&amp;gt;
                &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
                &amp;lt;artifactId&amp;gt;spring-boot-maven-plugin&amp;lt;/artifactId&amp;gt;
            &amp;lt;/plugin&amp;gt;
        &amp;lt;/plugins&amp;gt;
    &amp;lt;/build&amp;gt;
&amp;lt;/project&amp;gt;
</pre>

`application.properties` es el fichero clave de esta demo. La dirección, el usuario y la contraseña de la base de datos no están escritos: se leen de variables de entorno. `${DB_URL:valor}` significa "el valor de la variable `DB_URL` y, si no existe, el valor que sigue a los dos puntos". Así la misma aplicación funciona en el equipo (sin variables, con `localhost`) y en un contenedor (con la dirección que le pase Compose). La contraseña no tiene valor por defecto a propósito: no se escribe una contraseña en un fichero que se sube a Git.

```properties
# Nombre de la aplicación: aparece entre corchetes en cada línea del registro.
spring.application.name=libros

# Dirección, usuario y contraseña de PostgreSQL, leídos de variables de entorno.
# ${VARIABLE:valor} significa "el valor de la variable y, si no existe, el valor tras los dos puntos".
# Por defecto la base de datos está en localhost:5432, que sirve al ejecutar la API en el equipo.
# Dentro de un contenedor, localhost es el propio contenedor: la dirección llega por DB_URL.
spring.datasource.url=${DB_URL:jdbc:postgresql://localhost:5432/libros}
spring.datasource.username=${DB_USER:postgres}

# La contraseña no tiene valor por defecto: si DB_PASSWORD no existe, la aplicación no arranca bien.
# Una contraseña nunca se escribe en un fichero que se sube a Git.
spring.datasource.password=${DB_PASSWORD}

# update crea la tabla si no existe y la deja como está si ya existe: los datos no se tocan.
spring.jpa.hibernate.ddl-auto=update

# Evita el aviso de Spring Boot sobre la sesión abierta durante la vista (S06-1).
spring.jpa.open-in-view=false
```

La clase principal, la entidad, el repositorio y el controlador son los de siempre. Se leen rápido; el interés de la demo está en los ficheros de Compose.

```java
package com.curso;

// Importamos SpringApplication y @SpringBootApplication de Spring Boot.
// Maven los ha descargado con el starter de la dependencia; no hay que buscar ningún JAR a mano.
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * S17-2 Demo 1: Un Compose escrito por bloques
 *
 * Objetivo: arrancar la API que se va a ejecutar junto a su base de datos con Docker Compose.
 *
 * Lo que hace este ejemplo:
 *   - Arranca una API de Spring Boot que guarda sus datos en PostgreSQL
 *   - Lee la dirección de la base de datos de una variable de entorno
 *
 * Concepto clave: la aplicación no cambia según se ejecute en el equipo o en un contenedor.
 * Lo que cambia es la dirección de la base de datos, y llega desde fuera por variables de entorno.
 */
@SpringBootApplication
public class Aplicacion {

    // main() es el punto de entrada. SpringApplication.run() crea el contenedor de Spring,
    // arranca Tomcat y deja la aplicación esperando peticiones.
    public static void main(String[] args) {
        SpringApplication.run(Aplicacion.class, args);
    }
}
```

```java
package com.curso.model;

// Importamos las anotaciones de JPA (Jakarta Persistence). Vienen con spring-boot-starter-data-jpa.
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

/**
 * S17-2 Demo 1: Un Compose escrito por bloques
 *
 * Objetivo: representar un libro que se guarda en la tabla libro de PostgreSQL.
 *
 * Lo que hace este ejemplo:
 *   - Marca la clase como entidad: Hibernate crea la tabla a partir de ella (ddl-auto=update)
 *   - Declara los campos, que se convierten en columnas
 *
 * Concepto clave: una entidad es una clase Java que se corresponde con una tabla.
 * La clase es la tabla, cada campo una columna y cada objeto una fila (S06-1).
 */
@Entity
public class Libro {

    // @Id marca la clave primaria. IDENTITY hace que la genere la base de datos (1, 2, 3...).
    // Es Long y no long porque una entidad nueva todavía no tiene id y vale null hasta guardarse.
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Título del libro (columna titulo, varchar(255)).
    private String titulo;

    // Autor del libro (columna autor, varchar(255)).
    private String autor;

    // Año de publicación. Se escribe anio y no año para evitar la eñe en nombres de campo y de columna (S06-1).
    private int anio;


    // Hibernate crea primero un objeto vacío con este constructor y después rellena sus campos.
    // Jackson hace lo mismo al convertir el JSON de una petición en un objeto.
    public Libro() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }
}
```

```java
package com.curso.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.curso.model.Libro;

/**
 * S17-2 Demo 1: Un Compose escrito por bloques
 *
 * Objetivo: guardar y buscar los libros en PostgreSQL sin escribir SQL.
 *
 * Lo que hace este ejemplo:
 *   - Declara una interfaz vacía que extiende JpaRepository
 *   - Hereda save(), findAll(), findById(), existsById() y deleteById()
 *
 * Concepto clave: el repositorio se declara, no se escribe. Al arrancar, Spring Data genera
 * en memoria una clase que implementa esta interfaz y la registra como bean (S06-1).
 */
public interface LibroRepository extends JpaRepository<Libro, Long> {
}
```

```java
package com.curso.controller;

import java.util.List;

// Importamos las anotaciones de Spring MVC y ResponseEntity.
// Vienen con spring-boot-starter-webmvc: Maven las ha descargado con el starter.
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.curso.model.Libro;
import com.curso.repository.LibroRepository;

/**
 * S17-2 Demo 1: Un Compose escrito por bloques
 *
 * Objetivo: exponer los libros como una API REST.
 *
 * Lo que hace este ejemplo:
 *   - Declara GET /api/libros, GET /api/libros/{id} y POST /api/libros
 *   - Guarda y lee de PostgreSQL a través del repositorio
 *
 * Concepto clave: los datos están en la base de datos, no en el contenedor de la API.
 * Se pueden borrar y recrear los dos contenedores y los datos siguen ahí si la base de datos tiene volumen.
 */
@RestController
@RequestMapping("/api/libros")
public class LibroController {

    // Inyección por constructor: Spring entrega el repositorio que ha creado (S06-1).
    private final LibroRepository repository;

    public LibroController(LibroRepository repository) {
        this.repository = repository;
    }

    /**
     * Lista todos los registros.
     *
     * Ejemplo:
     *   GET /api/libros  →  200 [{"anio":1605,"autor":"Cervantes","id":1,"titulo":"El Quijote"}, ...]
     *   GET /api/libros  →  200 [] (si no hay datos todavía)
     *
     * @return la lista completa
     */
    @GetMapping
    public List<Libro> listar() {
        return repository.findAll();
    }

    /**
     * Devuelve un registro por su identificador.
     *
     * Ejemplo:
     *   GET /api/libros/1   →  200 con el registro 1
     *   GET /api/libros/99  →  404 sin cuerpo
     *
     * @param id identificador buscado
     * @return 200 con el registro, o 404 si no existe
     */
    @GetMapping("/{id}")
    public ResponseEntity<Libro> obtener(@PathVariable Long id) {
        // map(ResponseEntity::ok) convierte el registro en una respuesta 200 si el Optional lo contiene.
        // orElse(...) devuelve un 404 si el Optional está vacío (S09).
        return repository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Crea un registro nuevo.
     *
     * Ejemplo:
     *   POST /api/libros {"titulo":"El Quijote","autor":"Cervantes","anio":1605}  →  201 con el registro creado y su id
     *   POST /api/libros {"titulo":"La Regenta","autor":"Clarín","anio":1885}  →  201 con el siguiente id
     *
     * @param nuevo cuerpo JSON de la petición
     * @return 201 con el registro guardado
     */
    @PostMapping
    public ResponseEntity<Libro> crear(@RequestBody Libro nuevo) {
        // Anulamos el id recibido: save() inserta con id null y actualiza si el id existe.
        // Así un POST siempre crea, aunque el cliente envíe un id (S09).
        nuevo.setId(null);
        return ResponseEntity.status(HttpStatus.CREATED).body(repository.save(nuevo));
    }
}
```

El test generado solo comprueba que la aplicación arranca:

```java
package com.curso;

// Importamos @Test de JUnit 5 y @SpringBootTest de Spring Boot.
// Los trae spring-boot-starter-test, declarado en el pom.xml con scope test.
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * S17-2 Demo 1: Un Compose escrito por bloques
 *
 * Objetivo: comprobar que la aplicación arranca.
 *
 * Lo que hace este ejemplo:
 *   - Arranca la aplicación completa dentro de un test
 *
 * Concepto clave: este test necesita la base de datos en marcha, porque arranca la aplicación entera.
 * Por eso el JAR para Docker se construye con mvn clean package -DskipTests mientras no hay base de datos
 * en el equipo de construcción.
 */
@SpringBootTest
class AplicacionTests {

    // El test no comprueba ninguna operación: pasa si Spring consigue crear todos sus beans.
    @Test
    void contextLoads() {
    }
}
```

Este test arranca la aplicación completa, y la aplicación necesita PostgreSQL. Sin base de datos en el equipo, `mvn clean package` falla en la fase de pruebas con `Connection to localhost:5432 refused` y no genera el JAR. Por eso, para preparar la imagen, el JAR se construye saltándose las pruebas con `-DskipTests`.

### El Dockerfile

Es el de S16-1 y S17-1 con otro nombre de JAR: `FROM` elige la imagen base, `COPY` mete el JAR, `EXPOSE` anota el puerto y `ENTRYPOINT` es el comando de arranque.

```dockerfile
# S17-2 Demo 1: Dockerfile de la API libros
#
# Se construye desde la carpeta del proyecto, la que contiene este fichero y el pom.xml.
# Con Compose no hace falta escribir el comando: lo ejecuta docker compose up --build.
# A mano sería:
#   docker build -t libros:1.0 .
#
# Antes hay que generar el JAR, porque la imagen solo contiene Java y el JAR:
#   mvn clean package -DskipTests

# FROM: imagen base con Java 21 (solo el JRE, sin Maven ni el código fuente).
FROM eclipse-temurin:21-jre

# COPY: copia el JAR de la carpeta target del proyecto a la imagen, con el nombre app.jar.
COPY target/libros-0.0.1-SNAPSHOT.jar app.jar

# EXPOSE: solo anota que la aplicación escucha en el 8080 dentro del contenedor.
# No publica nada: la puerta la abre ports en el docker-compose.yml (o -p en docker run).
EXPOSE 8080

# ENTRYPOINT: el comando que se ejecuta al arrancar el contenedor.
ENTRYPOINT ["java", "-jar", "app.jar"]
```

### Preparar el JAR

Abrimos la terminal de IntelliJ (`Alt+F12`), que se abre ya en la carpeta del proyecto. Generamos el JAR **desde la carpeta `libros`** (la que contiene el `pom.xml`):

```bash
mvn clean package -DskipTests
```

Al terminar, la carpeta `target` contiene `libros-0.0.1-SNAPSHOT.jar`. No construimos la imagen a mano: lo hará Compose, con `build: .`.

### Las credenciales: .env, .env.example y .gitignore

Antes del primer bloque preparamos tres ficheros pequeños en la carpeta `libros`, la misma que tendrá el `docker-compose.yml`. El primero es el `.env`, con los valores reales. Compose lo lee solo, sin que se lo pidamos, siempre que esté en la carpeta desde la que se ejecuta `docker compose`:

```properties
# Credenciales de la demo. Este fichero NO se sube a Git (está en .gitignore).
# Compose lo lee solo, siempre que esté en la misma carpeta que el docker-compose.yml.
DB_NAME=libros
DB_USER=postgres
DB_PASSWORD=secreto
```

El segundo es `.env.example`, la plantilla que sí se sube a Git: los mismos nombres, sin la contraseña. Quien clone el proyecto la copia como `.env` y escribe sus valores.

```properties
# Plantilla del .env. Este fichero SÍ se sube a Git: lleva los nombres, no los valores secretos.
# Cada persona copia este fichero como .env y escribe sus propios valores.
DB_NAME=libros
DB_USER=postgres
DB_PASSWORD=
```

El tercero es `.gitignore`, que impide que el `.env` (y la carpeta `target`) se suban al repositorio:

```gitignore
# Credenciales: nunca al repositorio
.env

# Compilación de Maven
target/
```

Comprobamos que Compose lee el `.env`. **Desde la carpeta `libros`**, con el bloque 1 que escribimos a continuación, `docker compose config` mostrará el fichero con las variables sustituidas.

### Cómo se trabaja con los bloques

El fichero se llama `docker-compose.yml`. En esta demo se escribe poco a poco, así que en el zip cada estado del fichero está guardado como `docker-compose.bloque1.yml`, `docker-compose.bloque2.yml` y así hasta el `bloque6`. Quien escribe el fichero desde cero lo guarda siempre como `docker-compose.yml` y quita la opción `-f` de los comandos; quien usa los del zip deja la opción `-f` para elegir el bloque. Los ejemplos de este documento usan `-f`. El `docker-compose.yml` del zip es la copia del bloque 6, el fichero final.

Todos los comandos de `docker compose` se ejecutan **desde la carpeta `libros`**, la que contiene los ficheros `.yml` y el `.env`. Los de `docker volume` y `docker network` se pueden ejecutar desde cualquier carpeta.

### Bloque 1: solo la base de datos, sin volumen

Empezamos por lo mínimo: un servicio `db` con la imagen de PostgreSQL y las tres variables que la imagen lee la primera vez que arranca (nombre de la base de datos, usuario y contraseña). Los valores no están escritos: son `${...}`, y Compose los toma del `.env`.

```yaml
# Bloque 1: solo la base de datos, sin volumen.
# Se ejecuta desde la carpeta que contiene este fichero y el .env:
#   docker compose -f docker-compose.bloque1.yml up -d
services:
  # db es el nombre del servicio. Será también su nombre en la red de Compose.
  db:
    # Imagen oficial de PostgreSQL, versión 16.
    image: postgres:16
    # Variables que la imagen lee la primera vez que arranca con el volumen vacío.
    # ${...} se sustituye por el valor que hay en el fichero .env.
    environment:
      POSTGRES_DB: ${DB_NAME}
      POSTGRES_USER: ${DB_USER}
      POSTGRES_PASSWORD: ${DB_PASSWORD}
    # 5433 es el puerto del equipo (el 5432 es el PostgreSQL local); 5432 es el de dentro del contenedor.
    ports:
      - "5433:5432"
```

La línea `ports` publica el puerto: `"5433:5432"` se lee "lo que llegue al 5433 del equipo se entrega al 5432 del contenedor". El número de la derecha es el puerto en el que PostgreSQL escucha por dentro (siempre el 5432); el de la izquierda se elige, y usamos el 5433 porque el 5432 es el PostgreSQL del equipo.

Comprobamos primero el fichero con las variables ya sustituidas. **Desde la carpeta `libros`**:

```bash
docker compose -f docker-compose.bloque1.yml config
```

Salida esperada (resumida):

<pre>
name: libros
services:
  db:
    environment:
      POSTGRES_DB: libros
      POSTGRES_PASSWORD: secreto
      POSTGRES_USER: postgres
    image: postgres:16
    networks:
      default: null
    ports:
      - mode: ingress
        target: 5432
        published: "5433"
        protocol: tcp
networks:
  default:
    name: libros_default
</pre>

`POSTGRES_PASSWORD: secreto` confirma que el `.env` se ha leído. Si el `.env` no estuviera en la carpeta, Compose avisaría con `The "DB_NAME" variable is not set. Defaulting to a blank string.` para cada variable y seguiría con valores vacíos: ese aviso hay que leerlo siempre. Levantamos la base de datos:

```bash
docker compose -f docker-compose.bloque1.yml up -d
```
<pre>
 Network libros_default Created
 Container libros-db-1 Creating
 Container libros-db-1 Created
 Container libros-db-1 Starting
 Container libros-db-1 Started
</pre>

Compose ha creado dos cosas: una red, `libros_default`, y el contenedor `libros-db-1`. El nombre del contenedor sale de `carpeta-servicio-número`. Esperamos unos segundos y miramos el estado:

```bash
docker compose -f docker-compose.bloque1.yml ps
```
<pre>
NAME          IMAGE         COMMAND                  SERVICE   CREATED         STATUS         PORTS
libros-db-1   postgres:16   "docker-entrypoint.s…"   db        8 seconds ago   Up 8 seconds   0.0.0.0:5433-&gt;5432/tcp
</pre>

Funciona. Pero, ¿sobreviven los datos? Entramos en el contenedor con `exec`, que ejecuta un comando dentro de un contenedor que ya está en marcha, y con `psql` (el cliente de PostgreSQL) creamos una tabla con un dato. `db` es el nombre del servicio:

```bash
docker compose -f docker-compose.bloque1.yml exec db psql -U postgres -d libros -c "CREATE TABLE prueba (dato text); INSERT INTO prueba VALUES ('hola');"
```
<pre>
CREATE TABLE
INSERT 0 1
</pre>

Ahora borramos los contenedores y la red con `down`, y volvemos a levantar:

```bash
docker compose -f docker-compose.bloque1.yml down
docker compose -f docker-compose.bloque1.yml up -d
```

Esperamos unos segundos y buscamos el dato:

```bash
docker compose -f docker-compose.bloque1.yml exec db psql -U postgres -d libros -c "SELECT * FROM prueba;"
```
<pre>
ERROR:  relation "prueba" does not exist
LINE 1: SELECT * FROM prueba;
                      ^
</pre>

Los datos han desaparecido. La imagen de PostgreSQL declara que sus datos van en una carpeta aparte, y Docker crea por su cuenta un volumen **anónimo** aunque el fichero no diga nada. Lo vemos con `docker volume ls` (desde cualquier carpeta):

```bash
docker volume ls
```
<pre>
DRIVER    VOLUME NAME
local     831f9bc7dbf2d811dca8c547125ac91ace0e9c80f2a68bfd9ad46acc1e5598e1
local     545858f7385369190c1037b92ee3a8504aff07d45b6699a793b10ef7f4f2a784
</pre>

Hay dos volúmenes con nombres largos de letras y números: uno por cada vez que se ha levantado el contenedor. El primero tenía el dato y nadie lo usa ya; el segundo es el de ahora, vacío. Un volumen anónimo no se reutiliza, y por eso un volumen se escribe siempre con nombre. Limpiamos antes de seguir. `down -v` borra los volúmenes que el fichero conoce (el segundo); el huérfano hay que borrarlo a mano, con el nombre que salga en nuestra lista:

```bash
docker compose -f docker-compose.bloque1.yml down -v
docker volume rm 545858f7385369190c1037b92ee3a8504aff07d45b6699a793b10ef7f4f2a784
```

Atención: `docker volume prune` borra **todos** los volúmenes que no use ningún contenedor del equipo, no solo los de esta demo. No se usa en el aula.

### Bloque 2: la base de datos con volumen

Añadimos dos cosas, y las dos son necesarias. En el servicio `db`, la línea `volumes`, con el nombre del volumen a la izquierda de los dos puntos y la ruta de datos de PostgreSQL a la derecha. Y al final del fichero, la declaración del volumen:

```yaml
# Bloque 2: la base de datos con volumen.
# Se ejecuta desde la carpeta que contiene este fichero y el .env:
#   docker compose -f docker-compose.bloque2.yml up -d
services:
  # db es el nombre del servicio. Será también su nombre en la red de Compose.
  db:
    # Imagen oficial de PostgreSQL, versión 16.
    image: postgres:16
    # Variables que la imagen lee la primera vez que arranca con el volumen vacío.
    # ${...} se sustituye por el valor que hay en el fichero .env.
    environment:
      POSTGRES_DB: ${DB_NAME}
      POSTGRES_USER: ${DB_USER}
      POSTGRES_PASSWORD: ${DB_PASSWORD}
    # 5433 es el puerto del equipo (el 5432 es el PostgreSQL local); 5432 es el de dentro del contenedor.
    ports:
      - "5433:5432"
    # volumen:ruta. A la izquierda el volumen y a la derecha la carpeta donde PostgreSQL guarda los datos.
    volumes:
      - pgdata:/var/lib/postgresql/data

# Declaración de los volúmenes. Sin esta sección, Compose rechaza el fichero.
volumes:
  pgdata:
```

La ruta de la derecha la decide la imagen, no nosotros. PostgreSQL guarda sus datos en `/var/lib/postgresql/data`; si se monta en otra ruta, el volumen se crea igual pero la base de datos sigue guardando en otro sitio y los datos se pierden sin ningún error.

Repetimos la prueba, ahora con el volumen:

```bash
docker compose -f docker-compose.bloque2.yml up -d
docker volume ls
```
<pre>
DRIVER    VOLUME NAME
local     libros_pgdata
</pre>

El volumen se llama `libros_pgdata`, no `pgdata`: Compose antepone el nombre de la carpeta del proyecto. Con otro nombre de carpeta, el prefijo cambia. Creamos el dato, borramos todo con `down` y levantamos de nuevo:

```bash
docker compose -f docker-compose.bloque2.yml exec db psql -U postgres -d libros -c "CREATE TABLE prueba (dato text); INSERT INTO prueba VALUES ('hola');"
docker compose -f docker-compose.bloque2.yml down
docker volume ls
docker compose -f docker-compose.bloque2.yml up -d
```
<pre>
CREATE TABLE
INSERT 0 1
 Container libros-db-1 Stopped
 Container libros-db-1 Removed
 Network libros_default Removed

DRIVER    VOLUME NAME
local     libros_pgdata
</pre>

`down` ha borrado el contenedor y la red, pero el volumen sigue en la lista. Esperamos unos segundos y buscamos el dato:

```bash
docker compose -f docker-compose.bloque2.yml exec db psql -U postgres -d libros -c "SELECT * FROM prueba;"
```
<pre>
 dato
------
 hola
(1 row)
</pre>

El dato sobrevive. Un volumen es una carpeta que Docker guarda fuera del contenedor y que se monta dentro. Inspeccionamos el volumen:

```bash
docker volume inspect libros_pgdata
```
<pre>
[
    {
        "CreatedAt": "2026-10-29T08:05:48+01:00",
        "Driver": "local",
        "Labels": {
            "com.docker.compose.config-hash": "496840521be93f40d5aa12450bb20a3f700fb50efa97d7a88e1f7d9df3a3c35d",
            "com.docker.compose.project": "libros",
            "com.docker.compose.version": "5.6.1",
            "com.docker.compose.volume": "pgdata"
        },
        "Mountpoint": "/var/lib/docker/volumes/libros_pgdata/_data",
        "Name": "libros_pgdata",
        "Options": null,
        "Scope": "local"
    }
]
</pre>

Las etiquetas `com.docker.compose.*` dicen a qué proyecto pertenece el volumen. `Mountpoint` es dónde guarda Docker los datos: en Docker Desktop esa ruta está dentro de la máquina virtual de Docker, no en una carpeta de Windows que se pueda abrir con el Explorador. El resto de campos no hace falta tocarlos.

Dejamos el volumen para el bloque siguiente y bajamos solo los contenedores:

```bash
docker compose -f docker-compose.bloque2.yml down
```

### Bloque 3: se añade la API con `localhost` (falla a propósito)

Añadimos el servicio `api`. `build: .` construye la imagen con el `Dockerfile` de esta carpeta (el punto es la carpeta actual). El servicio no escribe la dirección de la base de datos con el nombre de la máquina, sino la que parece lógica: `localhost`.

```yaml
# Bloque 3: se añade la API con la dirección localhost (falla a propósito).
# Se ejecuta desde la carpeta que contiene este fichero y el .env:
#   docker compose -f docker-compose.bloque3.yml up -d
services:
  # db es el nombre del servicio. Será también su nombre en la red de Compose.
  db:
    # Imagen oficial de PostgreSQL, versión 16.
    image: postgres:16
    # Variables que la imagen lee la primera vez que arranca con el volumen vacío.
    # ${...} se sustituye por el valor que hay en el fichero .env.
    environment:
      POSTGRES_DB: ${DB_NAME}
      POSTGRES_USER: ${DB_USER}
      POSTGRES_PASSWORD: ${DB_PASSWORD}
    # 5433 es el puerto del equipo (el 5432 es el PostgreSQL local); 5432 es el de dentro del contenedor.
    ports:
      - "5433:5432"
    # volumen:ruta. A la izquierda el volumen y a la derecha la carpeta donde PostgreSQL guarda los datos.
    volumes:
      - pgdata:/var/lib/postgresql/data

  # api es el servicio de la aplicación Spring Boot.
  api:
    # build: construye la imagen con el Dockerfile de esta carpeta (el punto es la carpeta actual).
    build: .
    environment:
      # localhost dentro del contenedor de la API es la propia API, no la base de datos.
      DB_URL: jdbc:postgresql://localhost:5432/${DB_NAME}
      DB_USER: ${DB_USER}
      DB_PASSWORD: ${DB_PASSWORD}
    # 8081 es el puerto del equipo (el 8080 es Jenkins); 8080 es el de dentro del contenedor.
    ports:
      - "8081:8080"

# Declaración de los volúmenes. Sin esta sección, Compose rechaza el fichero.
volumes:
  pgdata:
```

Levantamos los dos servicios. `--build` obliga a construir la imagen de la API (la primera vez se construye sola, pero conviene acostumbrarse):

```bash
docker compose -f docker-compose.bloque3.yml up -d --build
```

Esperamos unos segundos y miramos el estado con `-a`, que incluye los contenedores parados:

```bash
docker compose -f docker-compose.bloque3.yml ps -a
```
<pre>
NAME           IMAGE         COMMAND                  SERVICE   CREATED          STATUS                      PORTS
libros-api-1   libros-api    "java -jar app.jar"      api       28 seconds ago   Exited (1) 15 seconds ago
libros-db-1    postgres:16   "docker-entrypoint.s…"   db        28 seconds ago   Up 26 seconds               0.0.0.0:5433-&gt;5432/tcp
</pre>

El diagnóstico sigue el orden de S17-1. Primera pregunta, el estado: la base de datos está `Up` y la API `Exited (1)`, es decir, la API falló al arrancar. Segunda pregunta, los registros de la API:

```bash
docker compose -f docker-compose.bloque3.yml logs api
```

La salida es larga, como siempre que Java escribe una excepción. La línea que importa es la primera de aviso:

<pre>
api-1  | ... WARN 1 --- [libros] [main] org.hibernate.orm.jdbc.error : Connection to localhost:5432 refused. Check that the hostname and port are correct and that the postmaster is accepting TCP/IP connections.
</pre>

La API intenta conectar con `localhost:5432` y la conexión es rechazada. La base de datos está en marcha, y aun así no la encuentra. La razón es la de S17-1: **dentro de un contenedor, `localhost` es el propio contenedor**. La API busca PostgreSQL dentro de sí misma, donde no hay nada.

### Bloque 4: la dirección es el nombre del servicio

Compose crea una red para el proyecto (`libros_default`, la que vimos al levantar) y conecta a ella todos los contenedores. En esa red, cada servicio se encuentra por su **nombre de servicio**: la base de datos es `db`. Cambiamos una línea, la dirección:

```yaml
# Bloque 4: la API usa el nombre del servicio como dirección.
# Se ejecuta desde la carpeta que contiene este fichero y el .env:
#   docker compose -f docker-compose.bloque4.yml up -d
services:
  # db es el nombre del servicio. Será también su nombre en la red de Compose.
  db:
    # Imagen oficial de PostgreSQL, versión 16.
    image: postgres:16
    # Variables que la imagen lee la primera vez que arranca con el volumen vacío.
    # ${...} se sustituye por el valor que hay en el fichero .env.
    environment:
      POSTGRES_DB: ${DB_NAME}
      POSTGRES_USER: ${DB_USER}
      POSTGRES_PASSWORD: ${DB_PASSWORD}
    # 5433 es el puerto del equipo (el 5432 es el PostgreSQL local); 5432 es el de dentro del contenedor.
    ports:
      - "5433:5432"
    # volumen:ruta. A la izquierda el volumen y a la derecha la carpeta donde PostgreSQL guarda los datos.
    volumes:
      - pgdata:/var/lib/postgresql/data

  # api es el servicio de la aplicación Spring Boot.
  api:
    # build: construye la imagen con el Dockerfile de esta carpeta (el punto es la carpeta actual).
    build: .
    environment:
      # db es el nombre del servicio de la base de datos. Dentro de la red de Compose es su dirección.
      # 5432 es el puerto de dentro del contenedor, no el 5433 publicado.
      DB_URL: jdbc:postgresql://db:5432/${DB_NAME}
      DB_USER: ${DB_USER}
      DB_PASSWORD: ${DB_PASSWORD}
    # 8081 es el puerto del equipo (el 8080 es Jenkins); 8080 es el de dentro del contenedor.
    ports:
      - "8081:8080"

# Declaración de los volúmenes. Sin esta sección, Compose rechaza el fichero.
volumes:
  pgdata:
```

Con esa dirección, `jdbc:postgresql://db:5432/${DB_NAME}`, hay dos números y dos mundos. El 5432 es el puerto de **dentro** de la red de Compose, el que escucha PostgreSQL. El 5433 que publicamos en `ports` es solo la puerta del equipo para quien llegue desde fuera (por ejemplo, un cliente de base de datos); entre contenedores no se usa. Recreamos solo lo que cambia:

```bash
docker compose -f docker-compose.bloque4.yml down
docker compose -f docker-compose.bloque4.yml up -d
```

Esperamos unos segundos y probamos la API desde el equipo, con el puerto 8081. `curl.exe` (con la extensión, porque en PowerShell `curl` es otro comando):

```bash
curl.exe http://localhost:8081/api/libros
```
<pre>
[]
</pre>

Responde, con una lista vacía: la API habla con PostgreSQL y no hay libros todavía. Para el `POST` usamos Postman (`Body > raw > JSON`, S09), porque con `curl.exe` en PowerShell las comillas del JSON dan problemas de escape. Hacemos dos peticiones `POST` a `http://localhost:8081/api/libros` con estos cuerpos:

```json
{"titulo":"El Quijote","autor":"Cervantes","anio":1605}
```
```json
{"titulo":"La Regenta","autor":"Clarín","anio":1885}
```

Y consultamos la lista y un libro que no existe:

```bash
curl.exe http://localhost:8081/api/libros
curl.exe -i http://localhost:8081/api/libros/99
```
<pre>
[{"anio":1605,"autor":"Cervantes","id":1,"titulo":"El Quijote"},{"anio":1885,"autor":"Clarín","id":2,"titulo":"La Regenta"}]

HTTP/1.1 404
Content-Length: 0
</pre>

Los campos salen en orden alfabético porque Jackson, la librería que genera el JSON, los ordena así por defecto en Spring Boot 4. Inspeccionamos ahora la red del proyecto, desde cualquier carpeta:

```bash
docker network inspect libros_default
```

La salida es larga; el apartado que interesa es `Containers`, que lista los contenedores conectados a la red con su dirección:

<pre>
        "Containers": {
            "97997c99...": {
                "Name": "libros-api-1",
                "IPv4Address": "172.18.0.3/16",
                ...
            },
            "b9c9b28e...": {
                "Name": "libros-db-1",
                "IPv4Address": "172.18.0.2/16",
                ...
            }
        },
</pre>

Los dos contenedores están en la misma red. Las direcciones `172.18.0.x` las asigna Docker y pueden cambiar cada vez que se recrea un contenedor, por eso nunca se escriben: el **nombre del servicio** es la dirección estable, y Docker lo traduce a la IP que toque.

### Bloque 5: `depends_on` sin `healthcheck`

Hasta ahora la base de datos y la API arrancan a la vez. PostgreSQL tarda unos segundos en inicializarse, y durante ese tiempo hay un contenedor `Up` que todavía no acepta conexiones. Si la API intenta conectar en ese hueco, falla. Añadimos `depends_on`, que parece la solución:

```yaml
# Bloque 5: depends_on sin healthcheck (puede fallar según la velocidad).
# Se ejecuta desde la carpeta que contiene este fichero y el .env:
#   docker compose -f docker-compose.bloque5.yml up -d
services:
  # db es el nombre del servicio. Será también su nombre en la red de Compose.
  db:
    # Imagen oficial de PostgreSQL, versión 16.
    image: postgres:16
    # Variables que la imagen lee la primera vez que arranca con el volumen vacío.
    # ${...} se sustituye por el valor que hay en el fichero .env.
    environment:
      POSTGRES_DB: ${DB_NAME}
      POSTGRES_USER: ${DB_USER}
      POSTGRES_PASSWORD: ${DB_PASSWORD}
    # 5433 es el puerto del equipo (el 5432 es el PostgreSQL local); 5432 es el de dentro del contenedor.
    ports:
      - "5433:5432"
    # volumen:ruta. A la izquierda el volumen y a la derecha la carpeta donde PostgreSQL guarda los datos.
    volumes:
      - pgdata:/var/lib/postgresql/data

  # api es el servicio de la aplicación Spring Boot.
  api:
    # build: construye la imagen con el Dockerfile de esta carpeta (el punto es la carpeta actual).
    build: .
    environment:
      # db es el nombre del servicio de la base de datos. Dentro de la red de Compose es su dirección.
      # 5432 es el puerto de dentro del contenedor, no el 5433 publicado.
      DB_URL: jdbc:postgresql://db:5432/${DB_NAME}
      DB_USER: ${DB_USER}
      DB_PASSWORD: ${DB_PASSWORD}
    # 8081 es el puerto del equipo (el 8080 es Jenkins); 8080 es el de dentro del contenedor.
    ports:
      - "8081:8080"
    # depends_on a secas espera a que el contenedor db haya arrancado, no a que PostgreSQL esté listo.
    depends_on:
      - db

# Declaración de los volúmenes. Sin esta sección, Compose rechaza el fichero.
volumes:
  pgdata:
```

Pero `depends_on` a secas solo espera a que el contenedor **haya arrancado**, no a que el programa de dentro esté listo. Probamos con el volumen vacío, que es el caso más lento porque PostgreSQL tiene que inicializar la base de datos. `down -v` borra los volúmenes, y por eso lo usamos aquí y solo aquí:

```bash
docker compose -f docker-compose.bloque5.yml down -v
docker compose -f docker-compose.bloque5.yml up -d
```

Esperamos unos segundos y miramos el estado:

```bash
docker compose -f docker-compose.bloque5.yml ps -a
```

Puede ocurrir una de dos cosas, y esa es precisamente la trampa:

| Resultado | Qué significa |
|---|---|
| `api` en `Up` | La base de datos estuvo lista a tiempo. Esta vez funciona |
| `api` en `Exited (1)` y los registros hablan de una conexión rechazada con `db:5432` o de que la base de datos se está iniciando | La API llegó antes que PostgreSQL. La dirección ya es la correcta (`db`), así que el fallo no es el del bloque 3 |

Repetimos varias veces `down -v` y `up -d`. En un equipo rápido puede que no falle nunca, y en otro falle a la primera. Un fallo que "a veces ocurre" es el más difícil de diagnosticar: hay que reconocerlo por sus pistas (la dirección es correcta, la base de datos está `Up`, y el fallo desaparece al volver a levantar). Que haya funcionado no demuestra que el fichero esté bien: depende de la velocidad del equipo. El `depends_on` sin comprobación no garantiza nada.

### Bloque 6: `healthcheck` y `depends_on` con `service_healthy`

La solución son dos piezas que trabajan juntas. En el servicio `db`, un `healthcheck`: Compose ejecuta un comando dentro del contenedor cada pocos segundos, y el servicio pasa a `healthy` cuando el comando funciona. `pg_isready` es el comando de PostgreSQL que termina bien solo cuando el servidor ya acepta conexiones. En el servicio `api`, `depends_on` con `condition: service_healthy`: la API no arranca hasta que la base de datos esté `healthy`.

```yaml
# Bloque 6: healthcheck en db y depends_on con service_healthy en api (fichero final).
# Se ejecuta desde la carpeta que contiene este fichero y el .env:
#   docker compose -f docker-compose.bloque6.yml up -d
services:
  # db es el nombre del servicio. Será también su nombre en la red de Compose.
  db:
    # Imagen oficial de PostgreSQL, versión 16.
    image: postgres:16
    # Variables que la imagen lee la primera vez que arranca con el volumen vacío.
    # ${...} se sustituye por el valor que hay en el fichero .env.
    environment:
      POSTGRES_DB: ${DB_NAME}
      POSTGRES_USER: ${DB_USER}
      POSTGRES_PASSWORD: ${DB_PASSWORD}
    # 5433 es el puerto del equipo (el 5432 es el PostgreSQL local); 5432 es el de dentro del contenedor.
    ports:
      - "5433:5432"
    # healthcheck: Compose ejecuta este comando dentro del contenedor cada interval.
    # pg_isready termina bien solo cuando PostgreSQL ya acepta conexiones.
    # CMD-SHELL ejecuta el texto como un comando de shell; $$ evita que Compose sustituya la variable
    # y deja que la sustituya el contenedor.
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U $${POSTGRES_USER} -d $${POSTGRES_DB}"]
      # interval: cada cuánto se ejecuta. timeout: cuánto se espera la respuesta.
      # retries: fallos seguidos antes de marcar el servicio como unhealthy.
      interval: 5s
      timeout: 3s
      retries: 10
    # volumen:ruta. A la izquierda el volumen y a la derecha la carpeta donde PostgreSQL guarda los datos.
    volumes:
      - pgdata:/var/lib/postgresql/data

  # api es el servicio de la aplicación Spring Boot.
  api:
    # build: construye la imagen con el Dockerfile de esta carpeta (el punto es la carpeta actual).
    build: .
    environment:
      # db es el nombre del servicio de la base de datos. Dentro de la red de Compose es su dirección.
      # 5432 es el puerto de dentro del contenedor, no el 5433 publicado.
      DB_URL: jdbc:postgresql://db:5432/${DB_NAME}
      DB_USER: ${DB_USER}
      DB_PASSWORD: ${DB_PASSWORD}
    # 8081 es el puerto del equipo (el 8080 es Jenkins); 8080 es el de dentro del contenedor.
    ports:
      - "8081:8080"
    # La API no arranca hasta que db esté healthy, es decir, hasta que el healthcheck de db tenga éxito.
    depends_on:
      db:
        condition: service_healthy

# Declaración de los volúmenes. Sin esta sección, Compose rechaza el fichero.
volumes:
  pgdata:
```

Los tres parámetros del `healthcheck` son `interval` (cada cuánto se ejecuta la comprobación), `timeout` (cuánto se espera la respuesta) y `retries` (cuántos fallos seguidos antes de marcar el servicio como `unhealthy`). El `$$` de la comprobación es un detalle de Compose: un `$` solo lo sustituiría Compose con el `.env`, y dos `$$` dejan que sea el contenedor quien lea sus propias variables `POSTGRES_USER` y `POSTGRES_DB`.

Para ver el estado `starting` levantamos solo la base de datos y miramos enseguida:

```bash
docker compose -f docker-compose.bloque6.yml down -v
docker compose -f docker-compose.bloque6.yml up -d db
docker compose -f docker-compose.bloque6.yml ps
```
<pre>
NAME          IMAGE         COMMAND                  SERVICE   CREATED                  STATUS                                     PORTS
libros-db-1   postgres:16   "docker-entrypoint.s…"   db        Less than a second ago   Up Less than a second (health: starting)   0.0.0.0:5433-&gt;5432/tcp
</pre>

Mientras está `health: starting`, Compose todavía no da la base de datos por lista. Esperamos unos segundos y repetimos el `ps`:

<pre>
NAME          IMAGE         COMMAND                  SERVICE   CREATED          STATUS                    PORTS
libros-db-1   postgres:16   "docker-entrypoint.s…"   db        12 seconds ago   Up 12 seconds (healthy)   0.0.0.0:5433-&gt;5432/tcp
</pre>

Ahora levantamos todo. Compose espera a la base de datos antes de arrancar la API:

```bash
docker compose -f docker-compose.bloque6.yml up -d
```
<pre>
 Container libros-db-1 Waiting
 Container libros-db-1 Healthy
 Container libros-api-1 Starting
 Container libros-api-1 Started
</pre>

Las líneas `Waiting` y `Healthy` son la espera. Con este fichero la API arranca bien siempre, en el equipo rápido y en el lento. El fichero final, `docker-compose.yml`, es esta copia del bloque 6.

### Datos, `down` y `down -v`

Con el fichero final, repasamos la regla de oro. Creamos un libro con Postman (como en el bloque 4) y comprobamos que sobrevive a `down`. **Desde la carpeta `libros`**:

```bash
docker compose down
docker compose up -d
curl.exe http://localhost:8081/api/libros
```
<pre>
[{"anio":1605,"autor":"Cervantes","id":1,"titulo":"El Quijote"}]
</pre>

El libro sigue ahí: `down` borra los contenedores y la red, y conserva el volumen. Ahora la otra opción:

```bash
docker compose down -v
docker compose up -d
curl.exe http://localhost:8081/api/libros
```
<pre>
[]
</pre>

Esta vez la lista está vacía: `down -v` ha borrado también el volumen.

| Comando | Contenedores y red | Volúmenes | Los datos |
|---|---|---|---|
| `docker compose down` | Se borran | Se conservan | Siguen ahí |
| `docker compose down -v` | Se borran | Se borran | Se pierden |

### Dos trampas del `.env`

La primera trampa: **las variables de PostgreSQL solo se aplican la primera vez**, con el volumen vacío. Con el volumen ya creado, cambiamos `DB_PASSWORD=secreto` por `DB_PASSWORD=otra` en el `.env` y levantamos de nuevo:

```bash
docker compose down
docker compose up -d
```

Esperamos unos segundos. La API sale con `Exited (1)`, y sus registros dicen:

<pre>
api-1  | ... WARN 1 --- [libros] [main] org.hibernate.orm.jdbc.error : FATAL: password authentication failed for user "postgres"
</pre>

La base de datos conserva la contraseña con la que se creó (`secreto`), porque el volumen ya existía y PostgreSQL no vuelve a leer `POSTGRES_PASSWORD`. La API usa la nueva y no entra. La solución en esta demo es volver a escribir `secreto` en el `.env`; si de verdad queremos cambiar la contraseña, se parte de cero con `docker compose down -v` (que borra los datos).

La segunda trampa es el `.env` que no se lee, por estar en otra carpeta o llamarse de otra forma. Compose no se detiene: avisa con `The "DB_NAME" variable is not set. Defaulting to a blank string.` y sigue con valores vacíos. Por eso `docker compose config` es la primera comprobación cuando algo extraño ocurre: muestra el fichero con las variables ya sustituidas.

Dejamos el entorno limpio para la Demo 2. **Desde la carpeta `libros`**:

```bash
docker compose down -v
```

---

## Demo 2: MongoDB en Compose

La Demo 1 se ha hecho con PostgreSQL, pero las tres piezas (volumen, nombre de servicio y espera) son las mismas con cualquier base de datos. Cambian tres datos de la base de datos concreta: la ruta de datos, el puerto y el comando de comprobación.

| | PostgreSQL | MongoDB |
|---|---|---|
| Ruta de datos del volumen | `/var/lib/postgresql/data` | `/data/db` |
| Puerto de dentro | 5432 | 27017 |
| Comprobación | `pg_isready` | un `ping` con `mongosh` |
| Dirección desde la API | `jdbc:postgresql://db:5432/libros` | `mongodb://mongo:27017/tareas` |

### El proyecto tareas-mongo

`tareas-mongo` es la API de tareas de S12-1 con Spring Data MongoDB: una tarea tiene título, descripción, estado y una lista de etiquetas. Responde a `GET /api/tareas` (con filtro opcional `?etiqueta=...`), `GET /api/tareas/{id}`, `POST /api/tareas` y `DELETE /api/tareas/{id}`. Este proyecto es una versión rehecha para la demo, con el mismo comportamiento que el de S12-1; si el `tareas-mongo` de S12-1 se parece, también sirve.

Abrimos la carpeta `tareas-mongo` como proyecto independiente (`File > Open`, `Trust Project`, `New Window`). Si preferimos crearlo desde cero, se usa el generador de Spring Boot con **Name** `tareas-mongo`, **Group** `com.curso`, **Artifact** `tareas-mongo`, **Package name** `com.curso`, **JDK** `21`, **Packaging** `Jar`, **Configuration** `Properties`; **Spring Boot** `4.1.1` y las dependencias `Spring Web` y `Spring Data MongoDB`.

<pre>
&amp;lt;?xml version="1.0" encoding="UTF-8"?&amp;gt;
&amp;lt;project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd"&amp;gt;
    &amp;lt;modelVersion&amp;gt;4.0.0&amp;lt;/modelVersion&amp;gt;

    &amp;lt;!-- parent: el POM padre de Spring Boot. Fija las versiones de todas las librerías,
         por eso ninguna dependencia de este fichero lleva &amp;lt;version&amp;gt;. --&amp;gt;
    &amp;lt;parent&amp;gt;
        &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
        &amp;lt;artifactId&amp;gt;spring-boot-starter-parent&amp;lt;/artifactId&amp;gt;
        &amp;lt;version&amp;gt;4.1.1&amp;lt;/version&amp;gt;
        &amp;lt;relativePath/&amp;gt;
    &amp;lt;/parent&amp;gt;

    &amp;lt;!-- groupId, artifactId y version dan nombre al JAR que Maven genera:
         artifactId-version.jar, es decir, target/tareas-mongo-0.0.1-SNAPSHOT.jar.
         Ese es exactamente el nombre que el COPY del Dockerfile tiene que escribir. --&amp;gt;
    &amp;lt;groupId&amp;gt;com.curso&amp;lt;/groupId&amp;gt;
    &amp;lt;artifactId&amp;gt;tareas-mongo&amp;lt;/artifactId&amp;gt;
    &amp;lt;version&amp;gt;0.0.1-SNAPSHOT&amp;lt;/version&amp;gt;
    &amp;lt;name&amp;gt;tareas-mongo&amp;lt;/name&amp;gt;
    &amp;lt;description&amp;gt;S17-2 Demo 2: API de tareas con MongoDB para ejecutar con Docker Compose&amp;lt;/description&amp;gt;

    &amp;lt;properties&amp;gt;
        &amp;lt;java.version&amp;gt;21&amp;lt;/java.version&amp;gt;
    &amp;lt;/properties&amp;gt;

    &amp;lt;dependencies&amp;gt;
        &amp;lt;!-- Spring MVC con Tomcat embebido y Jackson: lo necesario para una API REST. --&amp;gt;
        &amp;lt;dependency&amp;gt;
            &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
            &amp;lt;artifactId&amp;gt;spring-boot-starter-webmvc&amp;lt;/artifactId&amp;gt;
        &amp;lt;/dependency&amp;gt;

        &amp;lt;!-- Spring Data MongoDB y el controlador de MongoDB: guardar documentos en una colección. --&amp;gt;
        &amp;lt;dependency&amp;gt;
            &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
            &amp;lt;artifactId&amp;gt;spring-boot-starter-data-mongodb&amp;lt;/artifactId&amp;gt;
        &amp;lt;/dependency&amp;gt;

        &amp;lt;!-- JUnit y las utilidades de Spring para pruebas (solo en src/test/java). --&amp;gt;
        &amp;lt;dependency&amp;gt;
            &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
            &amp;lt;artifactId&amp;gt;spring-boot-starter-test&amp;lt;/artifactId&amp;gt;
            &amp;lt;scope&amp;gt;test&amp;lt;/scope&amp;gt;
        &amp;lt;/dependency&amp;gt;
    &amp;lt;/dependencies&amp;gt;

    &amp;lt;build&amp;gt;
        &amp;lt;plugins&amp;gt;
            &amp;lt;!-- Reempaqueta el JAR para que sea ejecutable con java -jar (lleva dentro las librerías). --&amp;gt;
            &amp;lt;plugin&amp;gt;
                &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
                &amp;lt;artifactId&amp;gt;spring-boot-maven-plugin&amp;lt;/artifactId&amp;gt;
            &amp;lt;/plugin&amp;gt;
        &amp;lt;/plugins&amp;gt;
    &amp;lt;/build&amp;gt;
&amp;lt;/project&amp;gt;
</pre>

`application.properties` usa el mismo mecanismo que en la Demo 1: la dirección de MongoDB se lee de la variable `MONGO_URI` y, si no existe, vale `mongodb://localhost:27017/tareas`, que sirve al ejecutar la API en el equipo. En un contenedor, esa variable cambia `localhost` por el nombre del servicio.

```properties
# Nombre de la aplicación: aparece entre corchetes en cada línea del registro.
spring.application.name=tareas-mongo

# Dirección de MongoDB, leída de la variable de entorno MONGO_URI.
# ${VARIABLE:valor} significa "el valor de la variable y, si no existe, el valor tras los dos puntos".
# Por defecto la base de datos está en localhost:27017, que sirve al ejecutar la API en el equipo.
# Dentro de un contenedor, localhost es el propio contenedor: la dirección llega por MONGO_URI.
spring.mongodb.uri=${MONGO_URI:mongodb://localhost:27017/tareas}
```

```java
package com.curso;

// Importamos SpringApplication y @SpringBootApplication de Spring Boot.
// Maven los ha descargado con el starter de la dependencia; no hay que buscar ningún JAR a mano.
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * S17-2 Demo 2: MongoDB en Compose
 *
 * Objetivo: arrancar la API que se va a ejecutar junto a su base de datos con Docker Compose.
 *
 * Lo que hace este ejemplo:
 *   - Arranca una API de Spring Boot que guarda sus datos en MongoDB
 *   - Lee la dirección de la base de datos de una variable de entorno
 *
 * Concepto clave: la aplicación no cambia según se ejecute en el equipo o en un contenedor.
 * Lo que cambia es la dirección de la base de datos, y llega desde fuera por variables de entorno.
 */
@SpringBootApplication
public class Aplicacion {

    // main() es el punto de entrada. SpringApplication.run() crea el contenedor de Spring,
    // arranca Tomcat y deja la aplicación esperando peticiones.
    public static void main(String[] args) {
        SpringApplication.run(Aplicacion.class, args);
    }
}
```

```java
package com.curso.model;

import java.util.ArrayList;
import java.util.List;

// Importamos las anotaciones de Spring Data. @Id es la de org.springframework.data.annotation:
// la de jakarta.persistence es de JPA y no vale para MongoDB.
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * S17-2 Demo 2: MongoDB en Compose
 *
 * Objetivo: representar una tarea con sus etiquetas que se guarda como documento en la colección tareas de MongoDB.
 *
 * Lo que hace este ejemplo:
 *   - Marca la clase como documento con @Document (equivale a @Entity en JPA)
 *   - Declara los campos, que se guardan como campos del documento
 *
 * Concepto clave: en MongoDB no hay tablas ni script SQL. La colección y la base de datos
 * se crean al guardar el primer documento (S12-1).
 */
@Document(collection = "tareas")
public class Tarea {

    // @Id marca el campo _id del documento. En MongoDB es un texto (String) que genera la propia base de datos
    // si vale null: 24 caracteres hexadecimales (un ObjectId). No hace falta @GeneratedValue.
    @Id
    private String id;

    // Título de la tarea.
    private String titulo;

    // Descripción opcional (puede valer null).
    private String descripcion;

    // true si la tarea está terminada.
    private boolean completada;

    // Lista de etiquetas. Se guarda como un array dentro del mismo documento, sin tabla intermedia (S12-1).
    // Se inicializa con una lista vacía para no tener nunca null.
    private List<String> etiquetas = new ArrayList<>();


    // Spring Data crea primero un objeto vacío con este constructor y después rellena sus campos.
    public Tarea() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public boolean isCompletada() {
        return completada;
    }

    public void setCompletada(boolean completada) {
        this.completada = completada;
    }

    public List<String> getEtiquetas() {
        return etiquetas;
    }

    public void setEtiquetas(List<String> etiquetas) {
        this.etiquetas = etiquetas;
    }
}
```

```java
package com.curso.repository;

import java.util.List;


import org.springframework.data.mongodb.repository.MongoRepository;

import com.curso.model.Tarea;

/**
 * S17-2 Demo 2: MongoDB en Compose
 *
 * Objetivo: guardar y buscar las tareas en MongoDB sin escribir consultas.
 *
 * Lo que hace este ejemplo:
 *   - Declara una interfaz que extiende MongoRepository<Tarea, String>
 *   - Hereda los mismos métodos que JpaRepository: save(), findAll(), findById(), existsById(), deleteById()
 *   - Añade findByEtiquetas(), un método derivado del nombre (S12-1)
 *
 * Concepto clave: el repositorio es casi idéntico al de JPA. Solo cambia la interfaz que se extiende
 * y el tipo del id (String).
 */
public interface TareaRepository extends MongoRepository<Tarea, String> {

    /**
     * Busca las tareas cuya lista de etiquetas contiene el valor indicado.
     *
     * Ejemplo:
     *   findByEtiquetas("curso")   →  las tareas con la etiqueta "curso"
     *   findByEtiquetas("compra")  →  las tareas con la etiqueta "compra"
     *
     * @param etiqueta etiqueta buscada
     * @return las tareas que la contienen
     */
    List<Tarea> findByEtiquetas(String etiqueta);
}
```

```java
package com.curso.controller;

import java.util.List;

// Importamos las anotaciones de Spring MVC y ResponseEntity.
// Vienen con spring-boot-starter-webmvc: Maven las ha descargado con el starter.
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.curso.model.Tarea;
import com.curso.repository.TareaRepository;

/**
 * S17-2 Demo 2: MongoDB en Compose
 *
 * Objetivo: exponer las tareas como una API REST sobre MongoDB.
 *
 * Lo que hace este ejemplo:
 *   - Declara GET /api/tareas (con filtro opcional), GET /api/tareas/{id}, POST /api/tareas y DELETE /api/tareas/{id}
 *   - Guarda y lee de MongoDB a través del repositorio
 *
 * Concepto clave: el controlador es el de JPA (S09-S11) con el id como String.
 * Con Compose, MongoDB corre en otro contenedor y la API lo encuentra por el nombre de su servicio.
 */
@RestController
@RequestMapping("/api/tareas")
public class TareaController {

    // Inyección por constructor: Spring entrega el repositorio que ha creado (S06-1).
    private final TareaRepository repository;

    public TareaController(TareaRepository repository) {
        this.repository = repository;
    }

    /**
     * Lista todos los documentos, o solo los que cumplen el filtro.
     *
     * Ejemplo:
     *   GET /api/tareas                 →  200 con todos
     *   GET /api/tareas?etiqueta=curso  →  200 con los que contienen esa etiqueta
     *
     * @param etiqueta filtro opcional
     * @return la lista de documentos
     */
    @GetMapping
    public List<Tarea> listar(@RequestParam(required = false) String etiqueta) {
        // Si el parámetro no viene, vale null y se devuelve todo (S12-1).
        if (etiqueta == null) {
            return repository.findAll();
        }
        return repository.findByEtiquetas(etiqueta);
    }

    /**
     * Devuelve un documento por su identificador.
     *
     * Ejemplo:
     *   GET /api/tareas/65f1a2b3c4d5e6f7a8b9c0d1  →  200 con el documento
     *   GET /api/tareas/no-existe                  →  404 sin cuerpo
     *
     * @param id identificador buscado (24 caracteres hexadecimales)
     * @return 200 con el documento, o 404 si no existe
     */
    @GetMapping("/{id}")
    public ResponseEntity<Tarea> obtener(@PathVariable String id) {
        return repository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Crea un documento nuevo.
     *
     * Ejemplo:
     *   POST /api/tareas {"titulo":"Instalar Docker","descripcion":null,"completada":false,"etiquetas":["curso","docker"]}  →  201 con el documento y su id
     *   POST /api/tareas {"titulo":"Comprar pan","descripcion":null,"completada":false,"etiquetas":["compra"]}  →  201 con otro id
     *
     * @param nuevo cuerpo JSON de la petición
     * @return 201 con el documento guardado
     */
    @PostMapping
    public ResponseEntity<Tarea> crear(@RequestBody Tarea nuevo) {
        // Anulamos el id recibido: save() inserta si el id es null y reemplaza si existe (S12-1).
        nuevo.setId(null);
        return ResponseEntity.status(HttpStatus.CREATED).body(repository.save(nuevo));
    }

    /**
     * Borra un documento.
     *
     * Ejemplo:
     *   DELETE /api/tareas/65f1a2b3c4d5e6f7a8b9c0d1  →  204 sin cuerpo
     *   DELETE /api/tareas/no-existe                  →  404 sin cuerpo
     *
     * @param id identificador del documento
     * @return 204 si se ha borrado, 404 si no existe
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> borrar(@PathVariable String id) {
        if (!repository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        repository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
```

El test generado arranca la aplicación. A diferencia de la Demo 1, aquí **no necesita MongoDB en marcha**: la conexión de MongoDB es perezosa (S12-1), el driver se conecta al hacer la primera operación, no al arrancar.

```java
package com.curso;

// Importamos @Test de JUnit 5 y @SpringBootTest de Spring Boot.
// Los trae spring-boot-starter-test, declarado en el pom.xml con scope test.
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * S17-2 Demo 2: MongoDB en Compose
 *
 * Objetivo: comprobar que la aplicación arranca.
 *
 * Lo que hace este ejemplo:
 *   - Arranca la aplicación completa dentro de un test
 *
 * Concepto clave: la conexión a MongoDB es perezosa (S12-1): el driver se conecta al hacer la primera
 * operación, así que este test pasa aunque no haya ningún servidor MongoDB en marcha.
 */
@SpringBootTest
class AplicacionTests {

    // El test no comprueba ninguna operación: pasa si Spring consigue crear todos sus beans.
    @Test
    void contextLoads() {
    }
}
```

El `Dockerfile` es el mismo de la Demo 1 con otro nombre de JAR:

```dockerfile
# S17-2 Demo 2: Dockerfile de la API tareas-mongo
#
# Se construye desde la carpeta del proyecto, la que contiene este fichero y el pom.xml.
# Con Compose no hace falta escribir el comando: lo ejecuta docker compose up --build.
# A mano sería:
#   docker build -t tareas-mongo:1.0 .
#
# Antes hay que generar el JAR, porque la imagen solo contiene Java y el JAR:
#   mvn clean package

# FROM: imagen base con Java 21 (solo el JRE, sin Maven ni el código fuente).
FROM eclipse-temurin:21-jre

# COPY: copia el JAR de la carpeta target del proyecto a la imagen, con el nombre app.jar.
COPY target/tareas-mongo-0.0.1-SNAPSHOT.jar app.jar

# EXPOSE: solo anota que la aplicación escucha en el 8080 dentro del contenedor.
# No publica nada: la puerta la abre ports en el docker-compose.yml (o -p en docker run).
EXPOSE 8080

# ENTRYPOINT: el comando que se ejecuta al arrancar el contenedor.
ENTRYPOINT ["java", "-jar", "app.jar"]
```

Generamos el JAR **desde la carpeta `tareas-mongo`**. Esta vez no hace falta `-DskipTests`:

```bash
mvn clean package
```

Durante las pruebas aparecen en pantalla bastantes líneas de excepciones de MongoDB (`MongoSocketOpenException`, `Connection refused`). No son un fallo del build: son los hilos de vigilancia del driver, que intentan conectar con un servidor que no existe en el equipo. Mientras el resultado final sea `BUILD SUCCESS`, todo va bien.

### El docker-compose.yml

Aquí no hay `.env`, porque esta MongoDB no tiene usuario ni contraseña. El fichero tiene las mismas tres piezas de la Demo 1 con los datos de MongoDB:

```yaml
# Demo 2: la API de tareas con MongoDB.
# Se ejecuta desde la carpeta que contiene este fichero:
#   docker compose up -d --build
services:
  # mongo es el nombre del servicio. Será también su nombre en la red de Compose.
  mongo:
    # Imagen oficial de MongoDB, versión 7.
    image: mongo:7
    # 27018 es el puerto del equipo (el 27017 es el MongoDB local); 27017 es el de dentro del contenedor.
    ports:
      - "27018:27017"
    # La imagen de MongoDB guarda los datos en /data/db. Es la ruta que hay que montar.
    volumes:
      - mongodata:/data/db
    # Comprueba que MongoDB responde a un ping. mongosh es el cliente de línea de comandos de MongoDB.
    # La opción --quiet quita los mensajes de bienvenida y --eval ejecuta el texto que sigue.
    # db.adminCommand('ping').ok devuelve 1 si el servidor está listo.
    healthcheck:
      test: ["CMD", "mongosh", "--quiet", "--eval", "db.adminCommand('ping').ok"]
      interval: 5s
      timeout: 5s
      retries: 10

  # api es el servicio de la aplicación Spring Boot.
  api:
    # build: construye la imagen con el Dockerfile de esta carpeta (el punto es la carpeta actual).
    build: .
    environment:
      # mongo es el nombre del servicio de MongoDB. Dentro de la red de Compose es su dirección.
      # 27017 es el puerto de dentro del contenedor, no el 27018 publicado.
      # tareas es el nombre de la base de datos: MongoDB la crea al guardar el primer documento.
      MONGO_URI: mongodb://mongo:27017/tareas
    # 8081 es el puerto del equipo (el 8080 es Jenkins); 8080 es el de dentro del contenedor.
    ports:
      - "8081:8080"
    # La API no arranca hasta que mongo esté healthy.
    depends_on:
      mongo:
        condition: service_healthy

# Declaración de los volúmenes.
volumes:
  mongodata:
```

Tres detalles. El volumen se monta en `/data/db`, que es donde guarda MongoDB; en otra ruta se crearía el volumen vacío y los datos se perderían sin error. La comprobación usa `mongosh`, el cliente de línea de comandos de MongoDB, para hacer un `ping`. Y la dirección `mongodb://mongo:27017/tareas` lleva el nombre del servicio (`mongo`) y el puerto de dentro (27017, no el 27018 publicado).

### Levantar y probar

Levantamos los dos servicios. **Desde la carpeta `tareas-mongo`**:

```bash
docker compose up -d --build
```

Esperamos unos segundos hasta que `mongo` aparezca como `healthy`. Miramos el estado:

```bash
docker compose ps
```
<pre>
NAME                  IMAGE               COMMAND                  SERVICE   CREATED          STATUS                    PORTS
tareas-mongo-api-1    tareas-mongo-api    "java -jar app.jar"      api       25 seconds ago   Up 12 seconds             0.0.0.0:8081-&gt;8080/tcp
tareas-mongo-mongo-1  mongo:7             "docker-entrypoint.s…"   mongo     25 seconds ago   Up 25 seconds (healthy)   0.0.0.0:27018-&gt;27017/tcp
</pre>

Con Postman hacemos un `POST` a `http://localhost:8081/api/tareas` con este cuerpo:

```json
{"titulo":"Instalar Docker","descripcion":null,"completada":false,"etiquetas":["curso","docker"]}
```

Y consultamos la lista:

```bash
curl.exe http://localhost:8081/api/tareas
```
<pre>
[{"completada":false,"descripcion":null,"etiquetas":["curso","docker"],"id":"6821f0a2c4d5e6f7a8b9c0d1","titulo":"Instalar Docker"}]
</pre>

El `id` es un `ObjectId` de MongoDB, 24 caracteres hexadecimales; el tuyo será distinto. Ahora la prueba que importa: borramos los contenedores y la red con `down` y levantamos de nuevo.

```bash
docker compose down
docker compose up -d
curl.exe http://localhost:8081/api/tareas
```
<pre>
[{"completada":false,"descripcion":null,"etiquetas":["curso","docker"],"id":"6821f0a2c4d5e6f7a8b9c0d1","titulo":"Instalar Docker"}]
</pre>

La tarea sigue ahí, con el mismo `id`. Los dos contenedores se han destruido y creado de nuevo, pero la carpeta `/data/db` vivía en el volumen `tareas-mongo_mongodata`. Lo comprobamos desde cualquier carpeta:

```bash
docker volume ls
```
<pre>
DRIVER    VOLUME NAME
local     tareas-mongo_mongodata
</pre>

Si ahora ejecutamos `docker compose down -v`, el volumen se borra y, al levantar, la lista estará vacía. Al terminar la demo dejamos el entorno limpio. **Desde la carpeta `tareas-mongo`**:

```bash
docker compose down -v
```

### Qué hemos visto

Escribir un `docker-compose.yml` es poner en el fichero, una a una, las piezas que resuelven problemas concretos. Un volumen en la ruta de datos de la imagen para que los datos sobrevivan. El nombre del servicio como dirección para que un contenedor encuentre a otro. Un `healthcheck` con `service_healthy` para que no arranque nadie antes de tiempo. Y las credenciales en un `.env` que no se sube a Git. En las prácticas se escribe el fichero sin tenerlo delante.
