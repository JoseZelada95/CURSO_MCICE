# S17-2 Soluciones

## Práctica 1: Compose de una API con PostgreSQL, sin ayuda

El proyecto `practica1-tareas-db` ya traía todo el código Java y el `Dockerfile`. Faltaban cuatro ficheros: el `.env`, el `.env.example`, el `.gitignore` y el `docker-compose.yml`. La solución los crea en ese orden y escribe el Compose por bloques, probando después de cada uno, como en la Demo 1.

### El JAR

Desde la carpeta `practica1-tareas-db` (la que contiene el `pom.xml`). Se saltan las pruebas porque `contextLoads` arranca la aplicación completa y necesita una base de datos:

```bash
mvn clean package -DskipTests
```

El JAR es `tareas-db-0.0.1-SNAPSHOT.jar`, que es el nombre que ya escribe el `COPY` del `Dockerfile`.

### Las credenciales

En la misma carpeta, junto al `pom.xml`. El `.env` lleva los valores reales y no se sube a Git:

```properties
# Credenciales de la API de tareas. Este fichero NO se sube a Git (está en .gitignore).
DB_NAME=tareas
DB_USER=postgres
DB_PASSWORD=secreto
```

La plantilla `.env.example` lleva los mismos nombres, sin la contraseña, y sí se sube:

```properties
# Plantilla del .env. Este fichero SÍ se sube a Git: lleva los nombres, no los valores secretos.
# Cada persona copia este fichero como .env y escribe sus propios valores.
DB_NAME=tareas
DB_USER=postgres
DB_PASSWORD=
```

Y el `.gitignore` impide que el `.env` y la carpeta `target` lleguen al repositorio:

```gitignore
# Credenciales: nunca al repositorio
.env

# Compilación de Maven
target/
```

### El docker-compose.yml

El fichero final tiene dos servicios. Se escribe primero `db` con su volumen y se prueba con `docker compose up -d db` y `docker compose ps`; después se añade `api`.

```yaml
# Práctica 1: API de tareas con PostgreSQL.
# Se ejecuta desde la carpeta que contiene este fichero y el .env:
#   docker compose up -d --build
services:
  db:
    image: postgres:16
    environment:
      POSTGRES_DB: ${DB_NAME}
      POSTGRES_USER: ${DB_USER}
      POSTGRES_PASSWORD: ${DB_PASSWORD}
    # 5433 en el equipo porque el 5432 es el PostgreSQL local.
    ports:
      - "5433:5432"
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U $${POSTGRES_USER} -d $${POSTGRES_DB}"]
      interval: 5s
      timeout: 3s
      retries: 10
    # PostgreSQL guarda los datos en /var/lib/postgresql/data.
    volumes:
      - pgdata:/var/lib/postgresql/data

  api:
    build: .
    environment:
      # db es el nombre del servicio; 5432 es el puerto de dentro del contenedor.
      DB_URL: jdbc:postgresql://db:5432/${DB_NAME}
      DB_USER: ${DB_USER}
      DB_PASSWORD: ${DB_PASSWORD}
    # 8081 en el equipo porque el 8080 es Jenkins.
    ports:
      - "8081:8080"
    depends_on:
      db:
        condition: service_healthy

volumes:
  pgdata:
```

### Comprobar y levantar

Todos los comandos de Compose, **desde la carpeta `practica1-tareas-db`**, la que contiene el `docker-compose.yml` y el `.env`. Primero el fichero con las variables ya sustituidas:

```bash
docker compose config
```

En la salida tiene que aparecer `DB_URL: jdbc:postgresql://db:5432/tareas`, con el nombre de la base de datos tomado del `.env`. Si en su lugar aparece `jdbc:postgresql://db:5432/` y el aviso `variable is not set`, el `.env` no se está leyendo. Levantamos todo con una sola orden:

```bash
docker compose up -d --build
```

Esperamos unos segundos y miramos el estado:

```bash
docker compose ps
```
<pre>
NAME                      IMAGE                   COMMAND                  SERVICE   CREATED          STATUS                    PORTS
practica1-tareas-db-api-1   practica1-tareas-db-api   "java -jar app.jar"      api       25 seconds ago   Up 21 seconds             0.0.0.0:8081-&gt;8080/tcp
practica1-tareas-db-db-1    postgres:16             "docker-entrypoint.s…"   db        31 seconds ago   Up 30 seconds (healthy)   0.0.0.0:5433-&gt;5432/tcp
</pre>

Con Postman hacemos dos `POST` a `http://localhost:8081/api/tareas`. El primero:

```json
{"titulo":"Instalar Docker","descripcion":"Docker Desktop","completada":false}
```

El segundo:

```json
{"titulo":"Escribir el Compose","descripcion":null,"completada":false}
```

Y se consulta la lista. Los `id` los ha generado PostgreSQL:

```bash
curl.exe http://localhost:8081/api/tareas
```
<pre>
[{"completada":false,"descripcion":"Docker Desktop","id":1,"titulo":"Instalar Docker"},{"completada":false,"descripcion":null,"id":2,"titulo":"Escribir el Compose"}]
</pre>

### `down` conserva, `down -v` borra

Primero `down` a secas, y se levanta de nuevo:

```bash
docker compose down
docker compose up -d
curl.exe http://localhost:8081/api/tareas
```
<pre>
[{"completada":false,"descripcion":"Docker Desktop","id":1,"titulo":"Instalar Docker"},{"completada":false,"descripcion":null,"id":2,"titulo":"Escribir el Compose"}]
</pre>

Las dos tareas siguen ahí. Ahora la otra opción, que borra el volumen:

```bash
docker compose down -v
docker compose up -d
curl.exe http://localhost:8081/api/tareas
```
<pre>
[]
</pre>

La lista está vacía. Se comprueba el nombre del volumen con `docker volume ls` desde cualquier carpeta, mientras los contenedores están levantados:

```bash
docker volume ls
```
<pre>
DRIVER    VOLUME NAME
local     practica1-tareas-db_pgdata
</pre>

Respuesta por escrito. `docker compose down` borra los contenedores y la red y conserva el volumen, así que los datos siguen; `docker compose down -v` borra también el volumen y los datos se pierden. El volumen se llama `practica1-tareas-db_pgdata` porque Compose antepone el nombre de la carpeta del proyecto (`practica1-tareas-db`) al nombre `pgdata` que está escrito en el fichero. Al terminar se deja limpio con `docker compose down -v`.

**Decisiones tomadas**

- **El nombre del servicio, `db`, es la dirección.** `DB_URL` termina con `db:5432`, no con `localhost:5432` ni con `localhost:5433`. Dentro de la red de Compose cada servicio se encuentra por su nombre, y el puerto es el de dentro del contenedor, 5432. El 5433 es solo la puerta del equipo.
- **El volumen está en `/var/lib/postgresql/data`.** Es la ruta donde la imagen de PostgreSQL guarda sus datos. En otra ruta el volumen se crearía vacío y los datos se perderían sin error.
- **`healthcheck` con `pg_isready` y `depends_on` con `service_healthy`.** Con `depends_on` a secas la API puede llegar antes de que PostgreSQL acepte conexiones y salir con `Exited (1)`; con la espera arranca bien siempre.
- **`$$` en el `healthcheck`.** Un `$` solo lo sustituiría Compose con el `.env`; el `$$` deja que las variables `POSTGRES_USER` y `POSTGRES_DB` las lea el propio contenedor.
- **Las credenciales están en el `.env`, no en el fichero.** El `docker-compose.yml` solo lleva los nombres `${DB_USER}`, `${DB_PASSWORD}` y `${DB_NAME}`. El `.env.example` documenta qué variables hacen falta sin revelar la contraseña.
- **Se publican el 5433 y el 8081.** El 5432 es el PostgreSQL instalado en el equipo y el 8080 es Jenkins.
- **El JAR se construye con `-DskipTests`.** La aplicación completa necesita PostgreSQL y en el momento de construir la imagen todavía no hay base de datos.
- **`build: .` en la API.** Así `docker compose up -d --build` construye la imagen con el `Dockerfile` del proyecto, sin un `docker build` aparte.

---

## Práctica 2: Compose de una API con MongoDB

El proyecto `practica2-notas-api` ya traía el código Java y el `Dockerfile`. Falta solo el `docker-compose.yml`, que no necesita `.env` porque esta MongoDB no tiene usuario ni contraseña.

### El JAR

Desde la carpeta `practica2-notas-api` (la que contiene el `pom.xml`). En este proyecto las pruebas pasan sin MongoDB, porque la conexión es perezosa:

```bash
mvn clean package
```

Durante las pruebas se ven líneas de excepciones del driver de MongoDB (`Connection refused`): son los hilos de vigilancia buscando un servidor que no existe en el equipo, no un fallo. El resultado final es `BUILD SUCCESS` y el JAR `notas-api-0.0.1-SNAPSHOT.jar`.

### El docker-compose.yml

Es la misma estructura de la Práctica 1 con los tres datos de MongoDB: la ruta de datos (`/data/db`), el puerto (27017 dentro, 27018 fuera) y la comprobación (un `ping` con `mongosh`).

```yaml
# Práctica 2: API de notas con MongoDB.
# Se ejecuta desde la carpeta que contiene este fichero:
#   docker compose up -d --build
services:
  mongo:
    image: mongo:7
    # 27018 en el equipo porque el 27017 es el MongoDB local.
    ports:
      - "27018:27017"
    # MongoDB guarda los datos en /data/db.
    volumes:
      - mongodata:/data/db
    healthcheck:
      test: ["CMD", "mongosh", "--quiet", "--eval", "db.adminCommand('ping').ok"]
      interval: 5s
      timeout: 5s
      retries: 10

  api:
    build: .
    environment:
      # mongo es el nombre del servicio; 27017 es el puerto de dentro del contenedor.
      MONGO_URI: mongodb://mongo:27017/notas
    # 8081 en el equipo porque el 8080 es Jenkins.
    ports:
      - "8081:8080"
    depends_on:
      mongo:
        condition: service_healthy

volumes:
  mongodata:
```

### Levantar y probar

Todos los comandos de Compose, **desde la carpeta `practica2-notas-api`**, la que contiene el `docker-compose.yml`:

```bash
docker compose up -d --build
docker compose ps
```
<pre>
NAME                        IMAGE                   COMMAND                  SERVICE   CREATED          STATUS                    PORTS
practica2-notas-api-api-1     practica2-notas-api-api   "java -jar app.jar"      api       25 seconds ago   Up 12 seconds             0.0.0.0:8081-&gt;8080/tcp
practica2-notas-api-mongo-1   mongo:7                 "docker-entrypoint.s…"   mongo     25 seconds ago   Up 25 seconds (healthy)   0.0.0.0:27018-&gt;27017/tcp
</pre>

Con Postman hacemos tres `POST` a `http://localhost:8081/api/notas`. Por ejemplo:

```json
{"titulo":"Reunión","texto":"Hablar del café de la oficina","importante":false}
```
```json
{"titulo":"Compra","texto":"Comprar pan y leche","importante":true}
```
```json
{"titulo":"Tarea","texto":"Revisar el Compose","importante":false}
```

Filtro por la palabra `café` (en Postman, sin problemas de codificación) y nota inexistente:

```bash
curl.exe "http://localhost:8081/api/notas?texto=caf%C3%A9"
curl.exe -i http://localhost:8081/api/notas/no-existe
```
<pre>
[{"id":"6821f0a2c4d5e6f7a8b9c0d1","importante":false,"texto":"Hablar del café de la oficina","titulo":"Reunión"}]

HTTP/1.1 404
Content-Length: 0
</pre>

Se bajan los contenedores sin borrar el volumen y se vuelven a levantar:

```bash
docker compose down
docker compose up -d
curl.exe http://localhost:8081/api/notas
```
<pre>
[{"id":"6821f0a2c4d5e6f7a8b9c0d1","importante":false,"texto":"Hablar del café de la oficina","titulo":"Reunión"},{"id":"6821f0a2c4d5e6f7a8b9c0d2","importante":true,"texto":"Comprar pan y leche","titulo":"Compra"},{"id":"6821f0a2c4d5e6f7a8b9c0d3","importante":false,"texto":"Revisar el Compose","titulo":"Tarea"}]
</pre>

Las tres notas siguen ahí, con los mismos `id`. El volumen se comprueba con:

```bash
docker volume ls
docker volume inspect practica2-notas-api_mongodata
```
<pre>
DRIVER    VOLUME NAME
local     practica2-notas-api_mongodata

[
    {
        "Driver": "local",
        "Labels": {
            "com.docker.compose.project": "practica2-notas-api",
            "com.docker.compose.volume": "mongodata"
        },
        "Mountpoint": "/var/lib/docker/volumes/practica2-notas-api_mongodata/_data",
        "Name": "practica2-notas-api_mongodata",
        "Scope": "local"
    }
]
</pre>

Al terminar se deja limpio con `docker compose down -v`.

Las tres diferencias con el Compose de la Práctica 1:

| | Práctica 1 (PostgreSQL) | Práctica 2 (MongoDB) |
|---|---|---|
| Ruta del volumen | `/var/lib/postgresql/data` | `/data/db` |
| Comprobación de salud | `pg_isready` | `ping` con `mongosh` |
| Dirección | `jdbc:postgresql://db:5432/tareas` | `mongodb://mongo:27017/notas` |

**Decisiones tomadas**

- **El volumen está en `/data/db`.** Es la ruta donde guarda MongoDB. Si se monta en otra, el volumen se crea igual, pero los datos se pierden al bajar y no aparece ningún error.
- **La dirección es `mongodb://mongo:27017/notas`.** `mongo` es el nombre del servicio, 27017 es el puerto de dentro y `notas` es la base de datos, que MongoDB crea al guardar el primer documento. No se usa `localhost` ni el 27018.
- **Se mantiene el `healthcheck` aunque la conexión de MongoDB sea perezosa.** Sin él la API arranca igualmente, pero la primera petición puede fallar si MongoDB todavía se está iniciando. Es la misma estructura que con PostgreSQL y evita ese primer error.
- **No hay `.env`.** Esta MongoDB no tiene usuario ni contraseña, así que el fichero no lleva nada que ocultar. Si hubiera credenciales, irían en un `.env` como en la Práctica 1.
- **Se publica el 27018 y el 8081.** El 27017 es el MongoDB instalado en el equipo y el 8080 es Jenkins.
- **`mvn clean package` sin `-DskipTests`.** Con MongoDB las pruebas pasan sin servidor: el driver no se conecta hasta la primera operación.

---

## Práctica 3: Compose del proyecto en grupo

No hay solución única, porque cada grupo tiene su proyecto. Lo que sigue es una solución orientativa con un proyecto genérico llamado `proyecto`: Spring Boot, Spring Data JPA y PostgreSQL, con la dirección escrita en `application.properties`:

```properties
spring.datasource.url=jdbc:postgresql://localhost:5432/tareas
spring.datasource.username=postgres
spring.datasource.password=postgres
```

El camino es el de la Práctica 1. Hay dos diferencias: el proyecto no se toca, y quien clona el repositorio tiene que generar el JAR antes de levantar.

### Los ficheros que se suben al repositorio

El `.gitignore` excluye el `.env` y `target`; el `.env.example` documenta las variables:

```properties
# .gitignore
.env
target/
```
```properties
# .env.example
DB_NAME=tareas
DB_USER=postgres
DB_PASSWORD=
```

El `docker-compose.yml`. El proyecto tiene la dirección de la base de datos escrita en `application.properties`, y no hace falta cambiarla: Spring Boot permite sobrescribir cualquier propiedad con una variable de entorno cuyo nombre es la propiedad en mayúsculas y con guiones bajos. `spring.datasource.url` se sobrescribe con `SPRING_DATASOURCE_URL`, `spring.datasource.username` con `SPRING_DATASOURCE_USERNAME` y `spring.datasource.password` con `SPRING_DATASOURCE_PASSWORD`.

```yaml
services:
  db:
    image: postgres:16
    environment:
      POSTGRES_DB: ${DB_NAME}
      POSTGRES_USER: ${DB_USER}
      POSTGRES_PASSWORD: ${DB_PASSWORD}
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U $${POSTGRES_USER} -d $${POSTGRES_DB}"]
      interval: 5s
      timeout: 3s
      retries: 10
    volumes:
      - pgdata:/var/lib/postgresql/data

  api:
    build: .
    environment:
      SPRING_DATASOURCE_URL: jdbc:postgresql://db:5432/${DB_NAME}
      SPRING_DATASOURCE_USERNAME: ${DB_USER}
      SPRING_DATASOURCE_PASSWORD: ${DB_PASSWORD}
    ports:
      - "8083:8080"
    depends_on:
      db:
        condition: service_healthy

volumes:
  pgdata:
```

Con un proyecto MongoDB cambian los mismos tres datos que en la Práctica 2: el servicio `mongo` con su volumen en `/data/db` y su `ping`, y la variable de la API, que sería `SPRING_MONGODB_URI` con `mongodb://mongo:27017/nombre-de-la-base`.

### La prueba con otra persona

Un compañero clona el repositorio en una carpeta nueva y, **desde la carpeta que contiene el `pom.xml`**, prepara el JAR y las credenciales. El JAR no está en el repositorio, porque `target` está en el `.gitignore`:

```bash
copy .env.example .env
mvn clean package -DskipTests
```

Abre el `.env` y escribe su propia contraseña en `DB_PASSWORD`. Después, **desde la carpeta que contiene el `docker-compose.yml` y el `.env`**, una sola orden:

```bash
docker compose up -d --build
```

Y comprueba que responde:

```bash
docker compose ps
curl.exe http://localhost:8083/api/tareas
```

Si olvida crear el `.env`, `docker compose config` lo delata con el aviso `The "DB_PASSWORD" variable is not set. Defaulting to a blank string.`, y PostgreSQL se niega a arrancar con una contraseña vacía.

El `README` del proyecto lleva estas instrucciones, en este orden: copiar `.env.example` como `.env` y rellenarlo, `mvn clean package -DskipTests` y `docker compose up -d --build`.

**Decisiones tomadas**

- **No se toca `application.properties`.** Sobrescribir la propiedad con `SPRING_DATASOURCE_URL` deja el proyecto funcionando igual en el equipo (con `localhost`) y en Compose (con `db`), sin dos versiones del fichero.
- **El `.env` no se sube; el `.env.example` sí.** Quien clona sabe qué variables hacen falta y escribe sus propios valores. Un `.env` subido por error no se arregla añadiéndolo al `.gitignore` después: la contraseña ya está en el historial de Git y hay que cambiarla.
- **El JAR se construye fuera de Compose.** `target` no se sube a Git, así que quien clona tiene que generarlo. Se hace con `-DskipTests` porque las pruebas que arrancan la aplicación necesitan una base de datos que todavía no existe.
- **El puerto 8083 de fuera, 8080 de dentro.** El 8083 no lo usa ninguna práctica anterior; el de dentro lo decide la aplicación.
- **No se publica el puerto de la base de datos.** En este Compose solo la API habla con PostgreSQL, y lo hace por la red de Compose. Publicarlo solo hace falta si queremos conectar desde el equipo con un cliente de base de datos, y entonces se elige un puerto libre (por ejemplo, el 5433).
- **Misma estructura que la Práctica 1.** Volumen en la ruta de datos, nombre de servicio como dirección y `healthcheck` con `service_healthy`: el fichero del grupo no inventa nada nuevo.
