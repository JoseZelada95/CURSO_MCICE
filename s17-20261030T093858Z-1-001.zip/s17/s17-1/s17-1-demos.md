# S17-1 Demos

## Objetivos

Esta parte no trae herramientas nuevas: consolida lo visto en S16. Ya sabemos construir una imagen con un `Dockerfile` y ejecutarla con `docker run`. Lo que falta es soltura, y sobre todo saber qué hacer cuando algo no responde, que es lo que más tiempo hace perder en el trabajo real. Las dos demos se reparten ese objetivo.

En la Demo 1 provocamos a propósito los fallos más habituales (contenedor parado, nombre en uso, puerto ocupado y `COPY` con un JAR que no existe) y los diagnosticamos siempre en el mismo orden: estado (`docker ps -a`), registros (`docker logs`) y configuración (`docker inspect`). En la Demo 2 levantamos tres contenedores de la misma imagen en tres puertos distintos, para ver con los propios ojos la diferencia entre el puerto de dentro, que pertenece al contenedor, y el puerto de fuera, que se elige en cada equipo.

Cada demo trabaja con su propio proyecto Spring Boot, ya preparado en `s17-1-demos.zip`: `fallos` (Demo 1) y `puertos` (Demo 2). Son dos proyectos independientes; cada uno se abre en su propia ventana de IntelliJ.

### Antes de empezar

Necesitamos tres cosas en el equipo:

- Docker Desktop en marcha (la ballena de la barra de tareas, sin animación).
- La imagen `eclipse-temurin:21-jre`, la imagen base de nuestros `Dockerfile`.
- Los puertos 8081, 8082, 8083 y 8084 libres. Recordamos por qué no usamos el 8080: en los equipos del aula lo ocupa Jenkins.

Comprobamos la imagen base desde cualquier carpeta:

```bash
docker images
```
Si en la lista aparece `eclipse-temurin:21-jre`, seguimos. Si no aparece, la conseguimos con la misma variante que usamos en S16-1, la que funcione en la red del aula. Se decide probando `docker pull hello-world`.

**Variante A: Docker Hub.** Desde cualquier carpeta:

```bash
docker pull eclipse-temurin:21-jre
```
**Variante B: espejo `mirror.gcr.io`.** Desde cualquier carpeta. Descargamos con el nombre largo, añadimos el nombre corto y quitamos el largo, para que todos los comandos de este documento sean iguales en las tres variantes:

```bash
docker pull mirror.gcr.io/library/eclipse-temurin:21-jre
docker tag mirror.gcr.io/library/eclipse-temurin:21-jre eclipse-temurin:21-jre
docker rmi mirror.gcr.io/library/eclipse-temurin:21-jre
```
**Variante C: fichero `.tar` de la carpeta `imagenes-docker` del Drive.** Descargamos el fichero de `eclipse-temurin` y lo cargamos. El comando `docker load -i` se ejecuta desde la carpeta donde está el `.tar` o escribiendo la ruta completa; el nombre del fichero es el que tenga el descargado (aquí `eclipse-temurin-21-jre.tar`):

```bash
cd C:\Users\TuUsuario\Downloads
docker load -i eclipse-temurin-21-jre.tar
```
En cualquiera de las tres variantes, el resultado es una línea `eclipse-temurin:21-jre` en `docker images`.

---

## Demo 1: Los fallos más habituales, uno a uno

Cuando un contenedor no responde, casi nunca hay que tocar la aplicación. El problema suele estar en uno de cuatro sitios, y cada uno deja una pista distinta. La forma de encontrarla es hacerse tres preguntas, siempre en el mismo orden:

1. **¿Existe y está en marcha?** `docker ps -a` lista todos los contenedores, incluidos los parados. La columna `STATUS` dice si está `Up` (en marcha) o `Exited` (parado) y con qué número de salida.
2. **¿Qué cuenta él mismo?** `docker logs <contenedor>` muestra lo que ha escrito el programa. Las últimas líneas casi siempre dicen la causa.
3. **¿Cómo está configurado?** `docker inspect <contenedor>` devuelve todos los datos del contenedor (puertos, variables de entorno, comando de arranque). Con `--format` se saca solo el dato que interesa.

En esta demo provocamos cada fallo a propósito, uno detrás de otro, para reconocer su mensaje a la primera. Los cuatro fallos son: contenedor parado, nombre en uso, puerto ocupado y `COPY` con un JAR que no existe.

### El proyecto fallos

`fallos` es una API de Spring Boot mínima con una sola ruta, `GET /api/estado`, que responde con un JSON con el estado y el nombre del equipo en el que se ejecuta. Dentro de un contenedor, el nombre del equipo es el identificador corto del contenedor, y eso nos permite comprobar que la respuesta viene del contenedor.

Descomprimimos `s17-1-demos.zip` y abrimos la carpeta `fallos` como proyecto independiente: `File > Open`, seleccionamos la carpeta `fallos` (la que contiene directamente el `pom.xml`, no la carpeta superior), clic en `OK` y en `Trust Project`, y `New Window` para que quede en su propia ventana. Si aparece el aviso `Maven build scripts found`, pulsamos `Load`.

Si preferimos crear el proyecto desde cero en lugar de abrir el del zip, se usa el generador de Spring Boot (`File > New > Project`, `Generators > Spring Boot`) con estos valores: **Name** `fallos`, **Location** la carpeta de proyectos del curso, **Type** `Maven`, **Language** `Java`, **Group** `com.curso`, **Artifact** `fallos`, **Package name** `com.curso`, **JDK** `21`, **Java** `21`, **Packaging** `Jar`, **Configuration** `Properties`. En la pantalla siguiente, **Spring Boot** `4.1.1` y la dependencia `Spring Web`. Es el mismo procedimiento de S05-1 y S06-1; el código de las clases y de `application.properties` es el que sigue.

El `pom.xml` lo genera el asistente, así que solo lo leemos. Lo único que importa en esta demo es el trío `groupId`, `artifactId` y `version`: Maven construye con ellos el nombre del JAR, `artifactId-version.jar`, es decir, `fallos-0.0.1-SNAPSHOT.jar`. Ese es el nombre que el `COPY` del `Dockerfile` tiene que escribir exactamente.

<pre>
&amp;lt;?xml version="1.0" encoding="UTF-8"?&amp;gt;
&amp;lt;project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd"&amp;gt;
    &amp;lt;modelVersion&amp;gt;4.0.0&amp;lt;/modelVersion&amp;gt;

    &amp;lt;!-- parent: el POM padre de Spring Boot. Fija las versiones de todas las librerías,
         por eso ninguna dependencia de este fichero lleva &amp;lt;version&amp;gt;. --&amp;gt;
    &amp;lt;parent&amp;gt;
        &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
        &amp;lt;artifactId&amp;gt;spring-boot-starter-parent&amp;lt;/artifactId&amp;gt;
        &amp;lt;version&amp;gt;4.1.1&amp;lt;/version&amp;gt;
        &amp;lt;relativePath/&amp;gt;
    &amp;lt;/parent&amp;gt;

    &amp;lt;!-- groupId, artifactId y version dan nombre al JAR que Maven genera:
         artifactId-version.jar, es decir, target/fallos-0.0.1-SNAPSHOT.jar.
         Ese es exactamente el nombre que el COPY del Dockerfile tiene que escribir. --&amp;gt;
    &amp;lt;groupId&amp;gt;com.curso&amp;lt;/groupId&amp;gt;
    &amp;lt;artifactId&amp;gt;fallos&amp;lt;/artifactId&amp;gt;
    &amp;lt;version&amp;gt;0.0.1-SNAPSHOT&amp;lt;/version&amp;gt;
    &amp;lt;name&amp;gt;fallos&amp;lt;/name&amp;gt;
    &amp;lt;description&amp;gt;S17-1 Demo 1: API mínima para provocar y diagnosticar los fallos habituales de Docker&amp;lt;/description&amp;gt;

    &amp;lt;properties&amp;gt;
        &amp;lt;java.version&amp;gt;21&amp;lt;/java.version&amp;gt;
    &amp;lt;/properties&amp;gt;

    &amp;lt;dependencies&amp;gt;
        &amp;lt;!-- Spring MVC con Tomcat embebido y Jackson: lo necesario para una API REST. --&amp;gt;
        &amp;lt;dependency&amp;gt;
            &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
            &amp;lt;artifactId&amp;gt;spring-boot-starter-webmvc&amp;lt;/artifactId&amp;gt;
        &amp;lt;/dependency&amp;gt;

        &amp;lt;!-- JUnit y las utilidades de Spring para pruebas (solo en src/test/java). --&amp;gt;
        &amp;lt;dependency&amp;gt;
            &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
            &amp;lt;artifactId&amp;gt;spring-boot-starter-test&amp;lt;/artifactId&amp;gt;
            &amp;lt;scope&amp;gt;test&amp;lt;/scope&amp;gt;
        &amp;lt;/dependency&amp;gt;
    &amp;lt;/dependencies&amp;gt;

    &amp;lt;build&amp;gt;
        &amp;lt;plugins&amp;gt;
            &amp;lt;!-- Reempaqueta el JAR para que sea ejecutable con java -jar (lleva dentro las librerías). --&amp;gt;
            &amp;lt;plugin&amp;gt;
                &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
                &amp;lt;artifactId&amp;gt;spring-boot-maven-plugin&amp;lt;/artifactId&amp;gt;
            &amp;lt;/plugin&amp;gt;
        &amp;lt;/plugins&amp;gt;
    &amp;lt;/build&amp;gt;
&amp;lt;/project&amp;gt;
</pre>
`application.properties` define el puerto en el que escucha la aplicación. `${PUERTO:8080}` significa "el valor de la variable de entorno `PUERTO` y, si no existe, 8080", el mismo mecanismo que vimos en S16-1:

```properties
# Nombre de la aplicación: aparece entre corchetes en cada línea del registro.
spring.application.name=fallos

# Puerto en el que escucha Tomcat DENTRO del contenedor.
# ${PUERTO:8080} se lee "de la variable de entorno PUERTO y, si no existe, 8080".
# Con docker run -e PUERTO=9090 se cambia sin reconstruir la imagen.
server.port=${PUERTO:8080}
```
La clase principal arranca la aplicación:

```java
package com.curso;

// Importamos SpringApplication y @SpringBootApplication de Spring Boot.
// Maven los ha descargado con el starter de la dependencia; no hay que buscar ningún JAR a mano.
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * S17-1 Demo 1: Los fallos más habituales, uno a uno
 *
 * Objetivo: tener una aplicación mínima que se pueda empaquetar en una imagen
 * y romper de cuatro formas distintas para aprender a diagnosticarlas.
 *
 * Lo que hace este ejemplo:
 *   - Arranca una API de Spring Boot con una sola ruta, GET /api/estado
 *   - Lee el puerto de escucha de la variable de entorno PUERTO (8080 por defecto)
 *
 * Concepto clave: la aplicación es sencilla a propósito. Los errores de Docker
 * casi nunca se deben al código de la aplicación, sino al contenedor que la envuelve:
 * estado, nombre, puerto o ficheros que el Dockerfile no encuentra.
 */
@SpringBootApplication
public class Aplicacion {

    // main() es el punto de entrada. SpringApplication.run() crea el contenedor de Spring,
    // arranca Tomcat y deja la aplicación esperando peticiones.
    public static void main(String[] args) {
        SpringApplication.run(Aplicacion.class, args);
    }
}
```
El controlador tiene la única ruta:

```java
package com.curso.controller;

import java.net.InetAddress;
import java.net.UnknownHostException;

// Importamos las anotaciones de Spring MVC. Vienen con spring-boot-starter-webmvc.
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * S17-1 Demo 1: Los fallos más habituales, uno a uno
 *
 * Objetivo: ofrecer una ruta que responde con el estado de la aplicación y con
 * el nombre del equipo en el que se ejecuta.
 *
 * Lo que hace este ejemplo:
 *   - Declara GET /api/estado
 *   - Devuelve un JSON con el estado y el nombre del equipo
 *
 * Concepto clave: dentro de un contenedor, el nombre del equipo es el identificador
 * corto del contenedor. Sirve para comprobar que la respuesta viene del contenedor
 * y no de la aplicación que corre en Windows.
 */
@RestController
@RequestMapping("/api")
public class EstadoController {

    // Un record es una clase de solo datos. Jackson lo convierte en JSON con los nombres de sus campos:
    // {"estado":"en marcha","equipo":"a1b2c3d4e5f6"}
    public record Estado(String estado, String equipo) {
    }

    /**
     * Devuelve el estado de la aplicación y el nombre del equipo.
     *
     * Ejemplo:
     *   GET /api/estado  →  {"estado":"en marcha","equipo":"a1b2c3d4e5f6"}
     *   GET /api/estado  →  {"estado":"en marcha","equipo":"DESKTOP-ABC123"} (fuera de Docker)
     *
     * @return el estado y el nombre del equipo
     * @throws UnknownHostException si el sistema no sabe decir cómo se llama
     */
    @GetMapping("/estado")
    public Estado estado() throws UnknownHostException {
        // getLocalHost().getHostName() pregunta al sistema cómo se llama el equipo.
        // En un contenedor devuelve su identificador corto: es lo que lo distingue de los demás.
        String equipo = InetAddress.getLocalHost().getHostName();

        // Creamos el objeto con el estado fijo y el nombre del equipo. Spring lo convierte a JSON.
        return new Estado("en marcha", equipo);
    }
}
```
Y el test generado, que solo comprueba que la aplicación arranca:

```java
package com.curso;

// Importamos @Test de JUnit 5 y @SpringBootTest de Spring Boot.
// Los trae spring-boot-starter-test, declarado en el pom.xml con scope test.
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * S17-1 Demo 1: Los fallos más habituales, uno a uno
 *
 * Objetivo: comprobar que la aplicación arranca antes de empaquetarla.
 *
 * Lo que hace este ejemplo:
 *   - Arranca la aplicación completa dentro de un test
 *
 * Concepto clave: mvn clean package ejecuta este test antes de generar el JAR.
 * Si el contexto de Spring no arranca, no hay JAR y, por tanto, tampoco imagen.
 */
@SpringBootTest
class AplicacionTests {

    // El test no comprueba ninguna operación: pasa si Spring consigue crear todos sus beans.
    @Test
    void contextLoads() {
    }
}
```
### El Dockerfile

Es el de S16-1, con otro nombre de JAR. Se lee instrucción por instrucción: `FROM` elige la imagen base (Java 21), `COPY` mete el JAR en la imagen con el nombre `app.jar`, `EXPOSE` anota el puerto y `ENTRYPOINT` es el comando que se ejecuta al arrancar el contenedor.

```dockerfile
# S17-1 Demo 1: Dockerfile de la API "fallos" (versión correcta)
#
# Se construye desde la carpeta del proyecto, la que contiene este fichero y el pom.xml.
# El punto final del comando es esa carpeta (el contexto de construcción):
#   docker build -t fallos:1.0 .
#
# Antes hay que generar el JAR, porque la imagen solo contiene Java y el JAR:
#   mvn clean package

# FROM: imagen base con Java 21 (solo el JRE, sin Maven ni el código fuente).
FROM eclipse-temurin:21-jre

# COPY: copia el JAR de la carpeta target del proyecto a la imagen, con el nombre app.jar.
# El nombre de origen es artifactId-version.jar tal como lo genera Maven.
COPY target/fallos-0.0.1-SNAPSHOT.jar app.jar

# EXPOSE: solo anota que la aplicación escucha en el 8080 dentro del contenedor.
# No publica nada: la puerta la abre -p en docker run.
EXPOSE 8080

# ENTRYPOINT: el comando que se ejecuta al arrancar el contenedor.
# La forma de lista hace que Java sea el proceso principal y reciba docker stop.
ENTRYPOINT ["java", "-jar", "app.jar"]
```
### Preparar la imagen

Abrimos la terminal de IntelliJ (`Alt+F12`), que se abre ya en la carpeta del proyecto. Generamos el JAR. **Desde la carpeta `fallos`** (la que contiene el `pom.xml`):

```bash
mvn clean package
```
Al terminar, la carpeta `target` contiene `fallos-0.0.1-SNAPSHOT.jar`. Construimos la imagen. **Desde la carpeta `fallos`** (la que contiene el `Dockerfile`); el punto final es esa carpeta, el contexto de construcción:

```bash
docker build -t fallos:1.0 .
```
Salida esperada (resumida; los números de paso y los identificadores varían):

<pre>
#1 [internal] load build definition from Dockerfile
#2 [internal] load metadata for docker.io/library/eclipse-temurin:21-jre
#3 [internal] load .dockerignore
#4 [internal] load build context
#5 [1/2] FROM docker.io/library/eclipse-temurin:21-jre@sha256:a899edb8...
#6 [2/2] COPY target/fallos-0.0.1-SNAPSHOT.jar app.jar
#7 naming to docker.io/library/fallos:1.0 done
</pre>
Los comandos que siguen hablan con Docker, no con ficheros, así que se pueden ejecutar desde cualquier carpeta; seguimos en la terminal de IntelliJ.

### Fallo 1: el contenedor está parado

Un contenedor vive mientras viva su programa. Arrancamos uno y comprobamos que responde:

```bash
docker run -d --name fallos -p 8081:8080 fallos:1.0
curl.exe http://localhost:8081/api/estado
```
En PowerShell, `curl` es otro comando distinto; por eso escribimos `curl.exe`, que funciona igual en `cmd` y en PowerShell. También se puede abrir la dirección en el navegador.

Salida esperada del `curl.exe` (el valor de `equipo` es el identificador del contenedor, distinto en cada equipo):

<pre>
{"estado":"en marcha","equipo":"87252a9fca0f"}
</pre>
Ahora paramos el contenedor y repetimos la petición, como si alguien lo hubiera parado sin que nos enteráramos:

```bash
docker stop fallos
curl.exe http://localhost:8081/api/estado
```
La petición falla. Salida esperada:

<pre>
curl: (7) Failed to connect to localhost port 8081 ...
</pre>
Aplicamos las tres preguntas. Primera pregunta, el estado. **`docker ps` a secas solo muestra los contenedores en marcha**, así que no sale nada:

```bash
docker ps
```<pre>
CONTAINER ID   IMAGE     COMMAND   CREATED   STATUS    PORTS     NAMES
</pre>
Un contenedor parado no aparece. Si buscamos un contenedor y no sale, probamos con `-a` antes de pensar que no existe:

```bash
docker ps -a
```<pre>
CONTAINER ID   IMAGE        COMMAND               CREATED          STATUS                                PORTS     NAMES
87252a9fca0f   fallos:1.0   "java -jar app.jar"   10 seconds ago   Exited (143) Less than a second ago             fallos
</pre>
El contenedor existe y está parado. La columna `STATUS` dice `Exited (143)`. El número que acompaña a `Exited` es el código con el que terminó el programa, y distingue tres situaciones:

| `STATUS` | Qué significa |
|---|---|
| `Exited (0)` | El programa terminó bien (por ejemplo, `hello-world`, que escribe un mensaje y acaba) |
| `Exited (1)` | El programa falló al arrancar: hay que leer los registros |
| `Exited (143)` | Alguien lo paró con `docker stop`: el programa recibió la orden de terminar y la cumplió |

Segunda pregunta, los registros. Las dos últimas líneas confirman que fue una parada ordenada, no un error:

```bash
docker logs --tail 4 fallos
```<pre>
2026-10-29T06:23:44.104Z  INFO 1 --- [fallos] [nio-8080-exec-1] o.s.web.servlet.DispatcherServlet        : Initializing Servlet 'dispatcherServlet'
2026-10-29T06:23:44.106Z  INFO 1 --- [fallos] [nio-8080-exec-1] o.s.web.servlet.DispatcherServlet        : Completed initialization in 2 ms
2026-10-29T06:23:44.264Z  INFO 1 --- [fallos] [ionShutdownHook] o.s.boot.tomcat.GracefulShutdown         : Commencing graceful shutdown. Waiting for active requests to complete
2026-10-29T06:23:44.270Z  INFO 1 --- [fallos] [tomcat-shutdown] o.s.boot.tomcat.GracefulShutdown         : Graceful shutdown complete
</pre>
`Commencing graceful shutdown` y `Graceful shutdown complete` quieren decir "me han pedido que termine y he terminado limpiamente". No hay nada roto: solo hay que volver a arrancarlo. `docker start` conserva todas las opciones con las que se creó el contenedor (el puerto, el nombre), no hay que repetirlas:

```bash
docker start fallos
curl.exe http://localhost:8081/api/estado
docker ps
```<pre>
{"estado":"en marcha","equipo":"87252a9fca0f"}

CONTAINER ID   IMAGE        COMMAND               CREATED          STATUS         PORTS                    NAMES
87252a9fca0f   fallos:1.0   "java -jar app.jar"   20 seconds ago   Up 9 seconds   0.0.0.0:8081-&gt;8080/tcp   fallos
</pre>
El `equipo` es el mismo de antes: es el mismo contenedor, que se ha parado y vuelto a arrancar, no uno nuevo. La columna `PORTS` muestra `0.0.0.0:8081->8080/tcp`, que se lee "lo que llegue al 8081 del equipo se entrega al 8080 del contenedor".

### Fallo 2: el nombre ya está en uso

`docker run` siempre crea un contenedor nuevo; no reutiliza uno anterior. Si ya existe uno con el mismo nombre, Docker se niega, aunque el viejo esté parado y llevemos días sin acordarnos de él. Repetimos el mismo comando de antes, con otro puerto de fuera para que no haya duda de que el problema es el nombre:

```bash
docker run -d --name fallos -p 8082:8080 fallos:1.0
```<pre>
docker: Error response from daemon: Conflict. The container name "/fallos" is already in use by container "87252a9fca0f68f65ef9c1d915a0a3f634115963774b2195649439e0cf2b65f7". You have to remove (or rename) that container to be able to reuse that name.

Run 'docker run --help' for more information
</pre>
El mensaje lo dice casi todo: el nombre `/fallos` ya lo usa el contenedor `87252a9fca0f...`, y hay que quitarlo o renombrarlo para reutilizar el nombre. Hay tres salidas, según lo que queramos:

| Quiero... | Comando |
|---|---|
| Quitar el viejo y crear uno nuevo | `docker rm -f fallos` y de nuevo `docker run` |
| Seguir con el viejo | `docker start fallos` (si estaba parado) |
| Tener los dos | Elegir otro nombre en `--name` |

### Fallo 3: el puerto está ocupado

Un puerto del equipo solo puede estar en uso por un programa a la vez. Intentamos arrancar un segundo contenedor, con otro nombre, pero publicándolo en el 8081, que ya usa el primero:

```bash
docker run -d --name fallos2 -p 8081:8080 fallos:1.0
```<pre>
27f9159be8b836ecb827534a7d665e20c4558366605dc6278ed52eddc454e5cf
docker: Error response from daemon: failed to set up container networking: driver failed programming external connectivity on endpoint fallos2 (451fff6049e9...): Bind for 0.0.0.0:8081 failed: port is already allocated

Run 'docker run --help' for more information
</pre>
El fragmento que identifica el fallo es `Bind for 0.0.0.0:8081 failed: port is already allocated`. "Bind" es el momento en que Docker intenta abrir la puerta del puerto 8081 del equipo; "already allocated" dice que otro ya lo tiene. En Windows, si el que lo ocupa no es un contenedor sino un programa (el caso de Jenkins en el 8080), el mensaje de Docker Desktop tiene otra redacción, pero sigue hablando de que el puerto no está disponible o ya está en uso. La solución es siempre la misma: **cambiar el número de la izquierda de `-p`**.

Hay una trampa. Miramos el estado:

```bash
docker ps -a
```<pre>
CONTAINER ID   IMAGE        COMMAND               CREATED                  STATUS         PORTS                    NAMES
27f9159be8b8   fallos:1.0   "java -jar app.jar"   Less than a second ago   Created                                 fallos2
87252a9fca0f   fallos:1.0   "java -jar app.jar"   20 seconds ago           Up 9 seconds   0.0.0.0:8081-&gt;8080/tcp   fallos
</pre>
El contenedor `fallos2` existe, con estado `Created`: Docker lo creó antes de intentar abrir la puerta, y como la puerta falló, nunca llegó a arrancar. **Ese contenedor a medias sigue reservando su nombre.** Si repetimos el comando con otro puerto y el mismo nombre, nos encontraremos con el fallo 2. Antes de reintentar lo borramos, y entonces sí, con un puerto libre:

```bash
docker rm fallos2
docker run -d --name fallos2 -p 8082:8080 fallos:1.0
curl.exe http://localhost:8082/api/estado
```<pre>
{"estado":"en marcha","equipo":"3c7e0a91b5d2"}
</pre>
Los dos contenedores conviven, cada uno en su puerto. El `equipo` es distinto porque son dos contenedores distintos.

### Fallo 4: el COPY apunta a un JAR que no existe

Este es el único de los cuatro que ocurre al **construir**, no al ejecutar. La instrucción `COPY` copia un fichero del proyecto a la imagen; si el fichero no está, `docker build` se detiene y señala la línea del `Dockerfile` que falló. El proyecto incluye un `Dockerfile.roto` con un error a propósito: el nombre del JAR es `fallos-1.0.jar` y en `target` no existe.

```dockerfile
# S17-1 Demo 1: Dockerfile de la API "fallos" (versión ROTA a propósito)
#
# Se usa para provocar el cuarto fallo. Como no se llama Dockerfile, hay que
# indicarlo con -f. Desde la carpeta del proyecto:
#   docker build -f Dockerfile.roto -t fallos:roto .
#
# El error está en la línea del COPY: el JAR se llama fallos-0.0.1-SNAPSHOT.jar
# y aquí se ha escrito fallos-1.0.jar, un nombre que no existe en la carpeta target.

FROM eclipse-temurin:21-jre

# ERROR: este fichero no existe. El build se detiene aquí y marca esta línea.
COPY target/fallos-1.0.jar app.jar

EXPOSE 8080

ENTRYPOINT ["java", "-jar", "app.jar"]
```
Como no se llama `Dockerfile`, hay que indicarlo con `-f`. **Desde la carpeta `fallos`**:

```bash
docker build -f Dockerfile.roto -t fallos:roto .
```<pre>
------
 &gt; [2/2] COPY target/fallos-1.0.jar app.jar:
------
Dockerfile.roto:13
--------------------
  11 |
  12 |     # ERROR: este fichero no existe. El build se detiene aquí y marca esta línea.
  13 | &gt;&gt;&gt; COPY target/fallos-1.0.jar app.jar
  14 |
  15 |     EXPOSE 8080
--------------------
ERROR: failed to build: failed to solve: failed to compute cache key: failed to calculate checksum of ref pwddsf5bnhx6737s6bclc8gt7::zvml2z3890yc9uyt9yf136xrs: "/target/fallos-1.0.jar": not found
</pre>
El error se lee de abajo arriba: el fichero `"/target/fallos-1.0.jar"` `not found`, y encima, el fragmento del `Dockerfile` con la línea culpable marcada con `>>>`. Comprobamos qué hay de verdad en `target`:

```bash
dir target
```
Aparece `fallos-0.0.1-SNAPSHOT.jar` y su versión `.jar.original`; ninguno se llama `fallos-1.0.jar`. Hay tres causas habituales de este fallo:

| Causa | Cómo se reconoce |
|---|---|
| No se ha ejecutado `mvn clean package` | La carpeta `target` no existe o está vacía |
| El nombre del JAR no coincide | En `target` hay otro nombre (recordar: `artifactId-versión.jar`) |
| Se ejecuta `docker build` desde otra carpeta | El contexto (el punto final) no es la carpeta del proyecto |

Aquí es la segunda. La corrección es escribir en el `COPY` el nombre real, que es exactamente el que tiene el `Dockerfile` original.

### Un caso más: Exited (1)

Queda el caso de `Exited (1)`, que es el que más veremos cuando una aplicación no encuentra algo que necesita. Lo provocamos con una variable de entorno inválida: el puerto `abc` no es un número.

```bash
docker run -d --name fallos3 -e PUERTO=abc -p 8083:8080 fallos:1.0
docker ps -a
```<pre>
CONTAINER ID   IMAGE        COMMAND               CREATED          STATUS                     PORTS                    NAMES
586175292d8a   fallos:1.0   "java -jar app.jar"   8 seconds ago    Exited (1) 5 seconds ago                            fallos3
27f9159be8b8   fallos:1.0   "java -jar app.jar"   8 seconds ago    Up 7 seconds               0.0.0.0:8082-&gt;8080/tcp   fallos2
87252a9fca0f   fallos:1.0   "java -jar app.jar"   28 seconds ago   Up 18 seconds              0.0.0.0:8081-&gt;8080/tcp   fallos
</pre>
`fallos3` está en `Exited (1)`: el programa falló al arrancar. La pista de verdad está en los registros:

```bash
docker logs fallos3
```
Salida esperada (las últimas líneas):

<pre>
***************************
APPLICATION FAILED TO START
***************************

Description:

Failed to bind properties under 'server.port' to java.lang.Integer:

    Property: server.port
    Value: "${PUERTO:8080}"
    Origin: class path resource [application.properties] from app.jar - 7:13
    Reason: failed to convert java.lang.String to java.lang.Integer (caused by java.lang.NumberFormatException: For input string: "abc")

Action:

Update your application's configuration
</pre>
Spring Boot lo explica con todas las letras: `server.port` no se puede convertir a número porque el valor es `"abc"`. Y la tercera pregunta, la configuración, confirma de dónde salió el valor:

```bash
docker inspect --format "{{.Config.Env}}" fallos3
```<pre>
[PUERTO=abc PATH=/opt/java/openjdk/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin JAVA_HOME=/opt/java/openjdk ...]
</pre>
`PUERTO=abc` está en las variables del contenedor. Este es el patrón de `Exited (1)` que veremos en la Práctica 3: la aplicación se para, los registros dicen por qué.

### Limpieza

Dejamos el equipo como estaba. Los contenedores parados también hay que borrarlos. Desde cualquier carpeta:

```bash
docker rm -f fallos fallos2 fallos3
docker ps -a
```
---

## Demo 2: Puerto de dentro y puerto de fuera

Es la confusión más frecuente al empezar con Docker. En esta demo no se explica con palabras: se ve. Levantamos tres contenedores de la **misma imagen**, cada uno en un puerto distinto del equipo, y comprobamos que por dentro los tres escuchan en el mismo puerto. Después vemos qué hace `-p` y qué hace `EXPOSE`.

La idea de fondo es esta. El contenedor es un mundo aparte, con su propia red. Dentro de él, la aplicación escucha en el 8080, y ese 8080 no choca con el 8080 de Jenkins, porque son dos mundos distintos. Por eso la imagen puede dejar el puerto de dentro escrito de una vez y funciona en cualquier equipo. Lo único que se decide en cada equipo es el puerto de fuera, el que se escribe a la izquierda de `-p`.

### El proyecto puertos

`puertos` es una API como `fallos`, con una sola ruta, `GET /api/info`, que responde con el nombre del equipo y con el puerto en el que escucha la aplicación por dentro. Se abre igual que `fallos`: `File > Open` sobre la carpeta `puertos` del zip (la que contiene el `pom.xml`), `Trust Project` y `New Window`. Para crearlo desde cero se usa el generador de Spring Boot con los mismos valores que `fallos`, cambiando **Name** y **Artifact** por `puertos`.

El `pom.xml` es el de `fallos` con otro `artifactId`, así que el JAR se llama `puertos-0.0.1-SNAPSHOT.jar`:

<pre>
&amp;lt;?xml version="1.0" encoding="UTF-8"?&amp;gt;
&amp;lt;project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd"&amp;gt;
    &amp;lt;modelVersion&amp;gt;4.0.0&amp;lt;/modelVersion&amp;gt;

    &amp;lt;!-- parent: el POM padre de Spring Boot. Fija las versiones de todas las librerías,
         por eso ninguna dependencia de este fichero lleva &amp;lt;version&amp;gt;. --&amp;gt;
    &amp;lt;parent&amp;gt;
        &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
        &amp;lt;artifactId&amp;gt;spring-boot-starter-parent&amp;lt;/artifactId&amp;gt;
        &amp;lt;version&amp;gt;4.1.1&amp;lt;/version&amp;gt;
        &amp;lt;relativePath/&amp;gt;
    &amp;lt;/parent&amp;gt;

    &amp;lt;!-- groupId, artifactId y version dan nombre al JAR que Maven genera:
         artifactId-version.jar, es decir, target/puertos-0.0.1-SNAPSHOT.jar.
         Ese es exactamente el nombre que el COPY del Dockerfile tiene que escribir. --&amp;gt;
    &amp;lt;groupId&amp;gt;com.curso&amp;lt;/groupId&amp;gt;
    &amp;lt;artifactId&amp;gt;puertos&amp;lt;/artifactId&amp;gt;
    &amp;lt;version&amp;gt;0.0.1-SNAPSHOT&amp;lt;/version&amp;gt;
    &amp;lt;name&amp;gt;puertos&amp;lt;/name&amp;gt;
    &amp;lt;description&amp;gt;S17-1 Demo 2: API mínima para ver el puerto de dentro y el de fuera de un contenedor&amp;lt;/description&amp;gt;

    &amp;lt;properties&amp;gt;
        &amp;lt;java.version&amp;gt;21&amp;lt;/java.version&amp;gt;
    &amp;lt;/properties&amp;gt;

    &amp;lt;dependencies&amp;gt;
        &amp;lt;!-- Spring MVC con Tomcat embebido y Jackson: lo necesario para una API REST. --&amp;gt;
        &amp;lt;dependency&amp;gt;
            &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
            &amp;lt;artifactId&amp;gt;spring-boot-starter-webmvc&amp;lt;/artifactId&amp;gt;
        &amp;lt;/dependency&amp;gt;

        &amp;lt;!-- JUnit y las utilidades de Spring para pruebas (solo en src/test/java). --&amp;gt;
        &amp;lt;dependency&amp;gt;
            &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
            &amp;lt;artifactId&amp;gt;spring-boot-starter-test&amp;lt;/artifactId&amp;gt;
            &amp;lt;scope&amp;gt;test&amp;lt;/scope&amp;gt;
        &amp;lt;/dependency&amp;gt;
    &amp;lt;/dependencies&amp;gt;

    &amp;lt;build&amp;gt;
        &amp;lt;plugins&amp;gt;
            &amp;lt;!-- Reempaqueta el JAR para que sea ejecutable con java -jar (lleva dentro las librerías). --&amp;gt;
            &amp;lt;plugin&amp;gt;
                &amp;lt;groupId&amp;gt;org.springframework.boot&amp;lt;/groupId&amp;gt;
                &amp;lt;artifactId&amp;gt;spring-boot-maven-plugin&amp;lt;/artifactId&amp;gt;
            &amp;lt;/plugin&amp;gt;
        &amp;lt;/plugins&amp;gt;
    &amp;lt;/build&amp;gt;
&amp;lt;/project&amp;gt;
</pre>
`application.properties` es el mismo de la Demo 1 con otro nombre de aplicación:

```properties
# Nombre de la aplicación: aparece entre corchetes en cada línea del registro.
spring.application.name=puertos

# Puerto en el que escucha Tomcat DENTRO del contenedor.
# ${PUERTO:8080} se lee "de la variable de entorno PUERTO y, si no existe, 8080".
# En esta demo no se define la variable: la aplicación escucha siempre en el 8080 de dentro,
# y lo único que cambia entre contenedores es el puerto del equipo que se elige con -p.
server.port=${PUERTO:8080}
```
La clase principal:

```java
package com.curso;

// Importamos SpringApplication y @SpringBootApplication de Spring Boot.
// Maven los ha descargado con el starter de la dependencia; no hay que buscar ningún JAR a mano.
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * S17-1 Demo 2: Puerto de dentro y puerto de fuera
 *
 * Objetivo: tener una aplicación que diga en qué puerto escucha y cómo se llama
 * el contenedor que la ejecuta, para comparar tres contenedores de la misma imagen.
 *
 * Lo que hace este ejemplo:
 *   - Arranca una API de Spring Boot con una sola ruta, GET /api/info
 *   - Escucha siempre en el 8080 del contenedor
 *
 * Concepto clave: el puerto de dentro pertenece al contenedor y no choca con nada del equipo.
 * Lo único que se decide en cada equipo es el puerto de fuera, el de la izquierda en -p.
 */
@SpringBootApplication
public class Aplicacion {

    // main() es el punto de entrada. SpringApplication.run() crea el contenedor de Spring,
    // arranca Tomcat y deja la aplicación esperando peticiones.
    public static void main(String[] args) {
        SpringApplication.run(Aplicacion.class, args);
    }
}
```
El controlador. `@Value("${server.port}")` entrega el valor de la propiedad `server.port` ya resuelta, es decir, el puerto de dentro. Se recibe por el constructor, la inyección por constructor de S06-1:

```java
package com.curso.controller;

import java.net.InetAddress;
import java.net.UnknownHostException;

// Importamos las anotaciones de Spring. Vienen con spring-boot-starter-webmvc.
// @Value es de spring-beans y entrega el valor de una propiedad de application.properties.
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * S17-1 Demo 2: Puerto de dentro y puerto de fuera
 *
 * Objetivo: responder con el nombre del equipo y con el puerto en el que escucha la aplicación.
 *
 * Lo que hace este ejemplo:
 *   - Declara GET /api/info
 *   - Devuelve el nombre del equipo y el puerto de escucha dentro del contenedor
 *
 * Concepto clave: el puerto que aparece en la respuesta es siempre el de dentro (8080),
 * aunque desde el navegador se haya llegado por el 8081, el 8082 o el 8083.
 */
@RestController
@RequestMapping("/api")
public class InfoController {

    // Un record es una clase de solo datos. Jackson lo convierte en JSON con los nombres de sus campos:
    // {"equipo":"a1b2c3d4e5f6","puertoInterno":"8080"}
    public record Info(String equipo, String puertoInterno) {
    }

    // @Value("${server.port}") entrega el valor de la propiedad server.port, ya resuelta:
    // 8080 si no existe la variable PUERTO. Es el puerto de DENTRO del contenedor.
    // Se recibe por el constructor (inyección por constructor, vista en S06-1).
    private final String puertoInterno;

    public InfoController(@Value("${server.port}") String puertoInterno) {
        this.puertoInterno = puertoInterno;
    }

    /**
     * Devuelve el nombre del equipo y el puerto de escucha de la aplicación.
     *
     * Ejemplo:
     *   GET http://localhost:8081/api/info  →  {"equipo":"a1b2c3d4e5f6","puertoInterno":"8080"}
     *   GET http://localhost:8082/api/info  →  {"equipo":"f6e5d4c3b2a1","puertoInterno":"8080"}
     *
     * @return el nombre del equipo y el puerto interno
     * @throws UnknownHostException si el sistema no sabe decir cómo se llama
     */
    @GetMapping("/info")
    public Info info() throws UnknownHostException {
        // En un contenedor, el nombre del equipo es el identificador corto del contenedor:
        // tres contenedores de la misma imagen darán tres nombres distintos.
        String equipo = InetAddress.getLocalHost().getHostName();

        // El puerto interno es el mismo en los tres: lo decide la aplicación, no el equipo.
        return new Info(equipo, puertoInterno);
    }
}
```
El test generado:

```java
package com.curso;

// Importamos @Test de JUnit 5 y @SpringBootTest de Spring Boot.
// Los trae spring-boot-starter-test, declarado en el pom.xml con scope test.
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * S17-1 Demo 2: Puerto de dentro y puerto de fuera
 *
 * Objetivo: comprobar que la aplicación arranca antes de empaquetarla.
 *
 * Lo que hace este ejemplo:
 *   - Arranca la aplicación completa dentro de un test
 *
 * Concepto clave: mvn clean package ejecuta este test antes de generar el JAR.
 * Si el contexto de Spring no arranca, no hay JAR y, por tanto, tampoco imagen.
 */
@SpringBootTest
class AplicacionTests {

    // El test no comprueba ninguna operación: pasa si Spring consigue crear todos sus beans.
    @Test
    void contextLoads() {
    }
}
```
Y el `Dockerfile`. Fijémonos en el comentario de `EXPOSE`, que es el centro de esta demo:

```dockerfile
# S17-1 Demo 2: Dockerfile de la API "puertos"
#
# Se construye desde la carpeta del proyecto, la que contiene este fichero y el pom.xml.
# El punto final del comando es esa carpeta (el contexto de construcción):
#   docker build -t puertos:1.0 .
#
# Antes hay que generar el JAR, porque la imagen solo contiene Java y el JAR:
#   mvn clean package

# FROM: imagen base con Java 21 (solo el JRE, sin Maven ni el código fuente).
FROM eclipse-temurin:21-jre

# COPY: copia el JAR de la carpeta target del proyecto a la imagen, con el nombre app.jar.
COPY target/puertos-0.0.1-SNAPSHOT.jar app.jar

# EXPOSE: solo anota en la imagen que la aplicación escucha en el 8080 dentro del contenedor.
# Es un cartel: no abre ninguna puerta. docker inspect lo muestra como ExposedPorts.
EXPOSE 8080

# ENTRYPOINT: el comando que se ejecuta al arrancar el contenedor.
ENTRYPOINT ["java", "-jar", "app.jar"]
```
### Preparar la imagen

Igual que antes. **Desde la carpeta `puertos`** (la que contiene el `pom.xml` y el `Dockerfile`):

```bash
mvn clean package
docker build -t puertos:1.0 .
```
### Tres contenedores, una sola imagen

Arrancamos tres contenedores de `puertos:1.0`. El segundo número de `-p` es siempre el 8080; solo cambia el primero. Desde cualquier carpeta:

```bash
docker run -d --name puertos-a -p 8081:8080 puertos:1.0
docker run -d --name puertos-b -p 8082:8080 puertos:1.0
docker run -d --name puertos-c -p 8083:8080 puertos:1.0
docker ps
```<pre>
CONTAINER ID   IMAGE         COMMAND               CREATED          STATUS          PORTS                    NAMES
1b937c645513   puertos:1.0   "java -jar app.jar"   10 seconds ago   Up 10 seconds   0.0.0.0:8083-&gt;8080/tcp   puertos-c
ab466a76a465   puertos:1.0   "java -jar app.jar"   11 seconds ago   Up 10 seconds   0.0.0.0:8082-&gt;8080/tcp   puertos-b
864ff07fd90d   puertos:1.0   "java -jar app.jar"   11 seconds ago   Up 11 seconds   0.0.0.0:8081-&gt;8080/tcp   puertos-a
</pre>
Los tres usan el 8080 por dentro y no hay ningún choque. Esperamos unos segundos a que Spring Boot arranque y llamamos a cada uno por su puerto de fuera:

```bash
curl.exe http://localhost:8081/api/info
curl.exe http://localhost:8082/api/info
curl.exe http://localhost:8083/api/info
```<pre>
{"equipo":"864ff07fd90d","puertoInterno":"8080"}
{"equipo":"ab466a76a465","puertoInterno":"8080"}
{"equipo":"1b937c645513","puertoInterno":"8080"}
</pre>
Aquí está la demostración. El `equipo` es distinto en cada respuesta: son tres contenedores. El `puertoInterno` es **8080 en los tres**, aunque hemos llegado por el 8081, el 8082 y el 8083. El puerto de dentro pertenece al contenedor; el de fuera lo elegimos nosotros en cada equipo.

| Contenedor | Comando | Desde el navegador |
|---|---|---|
| `puertos-a` | `-p 8081:8080` | `http://localhost:8081` |
| `puertos-b` | `-p 8082:8080` | `http://localhost:8082` |
| `puertos-c` | `-p 8083:8080` | `http://localhost:8083` |

### `EXPOSE` es el cartel, `-p` es la puerta

El `Dockerfile` dice `EXPOSE 8080`. Preguntamos a Docker qué ha anotado la imagen y qué puerta ha abierto el contenedor:

```bash
docker inspect --format "{{.Config.ExposedPorts}}" puertos:1.0
docker inspect --format "{{.NetworkSettings.Ports}}" puertos-a
```<pre>
map[8080/tcp:{}]
map[8080/tcp:[{0.0.0.0 8081}]]
</pre>
El primero lee la imagen: `ExposedPorts` dice `8080/tcp`, el cartel que escribió `EXPOSE`. Sin más datos. El segundo lee el contenedor: `8080/tcp` del contenedor está conectado a `0.0.0.0:8081` del equipo, la puerta que abrió `-p`. Una sola línea del `Dockerfile` anota; la puerta solo la abre `docker run -p`.

Para verlo, arrancamos un cuarto contenedor **sin `-p`**:

```bash
docker run -d --name puertos-sin-p puertos:1.0
docker ps
```<pre>
CONTAINER ID   IMAGE         COMMAND               CREATED          STATUS          PORTS                    NAMES
57cc6b2afabb   puertos:1.0   "java -jar app.jar"   10 seconds ago   Up 9 seconds    8080/tcp                 puertos-sin-p
1b937c645513   puertos:1.0   "java -jar app.jar"   21 seconds ago   Up 20 seconds   0.0.0.0:8083-&gt;8080/tcp   puertos-c
...
</pre>
Mirad la columna `PORTS` de `puertos-sin-p`: `8080/tcp`, **sin flecha**. Es solo el cartel de `EXPOSE`; no hay ningún puerto del equipo conectado. Desde el equipo no se llega a esa aplicación. Probamos con el navegador o con `curl.exe` en un puerto que no tiene ningún contenedor:

```bash
curl.exe http://localhost:8084/api/info
```<pre>
curl: (7) Failed to connect to localhost port 8084 ...
</pre>
Para llegar al contenedor sin puerta, no hay forma desde fuera. Pero la aplicación está funcionando por dentro. Con `docker exec` ejecutamos un comando dentro del contenedor, y ahí sí responde:

```bash
docker exec puertos-sin-p curl -s http://localhost:8080/api/info
```<pre>
{"equipo":"57cc6b2afabb","puertoInterno":"8080"}
</pre>
Una frase para recordar: **`-p` es la puerta y `EXPOSE` es el cartel.** Un cartel sin puerta no deja entrar a nadie, y una puerta sin cartel funciona igual. Si `curl` no estuviera disponible dentro de la imagen, el mismo comando funciona con `wget -qO- http://localhost:8080/api/info`.

### Qué significa localhost

`localhost` quiere decir "esta misma máquina", y "esta máquina" cambia según desde dónde se mire. Dentro del contenedor `puertos-a`, el 8080 es su aplicación y el 8081 no existe:

```bash
docker exec puertos-a curl -s http://localhost:8080/api/info
docker exec puertos-a curl -s http://localhost:8081/api/info
```<pre>
{"equipo":"864ff07fd90d","puertoInterno":"8080"}
(sin respuesta: curl termina con el error 7)
</pre>
La primera funciona: desde dentro se usa el puerto de dentro. La segunda no: el 8081 es una puerta del equipo, no existe dentro del contenedor. Y al revés, desde el equipo:

| Quien escribe `localhost` | A qué máquina se refiere | Puerto que usa |
|---|---|---|
| El navegador en Windows | Al equipo Windows | El de fuera (8081) |
| Un programa dentro del contenedor | Al propio contenedor | El de dentro (8080) |

En Windows, `http://localhost:8080` no llega a ninguno de nuestros contenedores: llega a **Jenkins**, que es quien escucha en el 8080 del equipo. Cada lado usa su propio número. Esto volverá en S17-2: cuando la aplicación necesite hablar con una base de datos, `localhost` desde dentro del contenedor apuntará a la propia aplicación y no a la base de datos.

### Qué pasa si cambia el puerto de dentro

El puerto de dentro lo decide la aplicación. Como `application.properties` lo lee de la variable `PUERTO`, podemos cambiarlo con `-e` sin tocar la imagen. Si cambia, hay que cambiar también el segundo número de `-p`:

```bash
docker run -d --name puertos-d -e PUERTO=9090 -p 8084:9090 puertos:1.0
curl.exe http://localhost:8084/api/info
docker ps
```<pre>
{"equipo":"cf94a78b3b73","puertoInterno":"9090"}

CONTAINER ID   IMAGE         COMMAND               CREATED          STATUS          PORTS                              NAMES
cf94a78b3b73   puertos:1.0   "java -jar app.jar"   9 seconds ago    Up 9 seconds    8080/tcp, 0.0.0.0:8084-&gt;9090/tcp   puertos-d
...
</pre>
La aplicación escucha ahora en el 9090 por dentro, y `-p 8084:9090` conecta el 8084 del equipo con ese 9090. La columna `PORTS` muestra los dos datos: `8080/tcp` es el cartel de la imagen, que sigue diciendo 8080 porque `EXPOSE` no se actualiza cuando cambia la variable (es solo documentación), y `0.0.0.0:8084->9090/tcp` es la puerta real. Si hubiéramos escrito `-p 8084:8080`, Docker habría abierto la puerta hacia un puerto donde nadie escucha, y la aplicación no habría respondido.

### Lo que decide cada sitio

Un contenedor es independiente por dentro. Lo único que se decide en cada equipo es el puerto de fuera.

| Se decide en... | Qué se decide | Cambia entre equipos |
|---|---|---|
| La imagen | Java, el JAR, el puerto de dentro, el comando de arranque | No: es la misma en todos |
| `docker run -e` | Variables de entorno (saludo, puerto de la aplicación) | Sí, si se quiere |
| `docker run -p` | El puerto de fuera, el del equipo | Sí: es lo que se elige en cada equipo |
| `docker run --name` | El nombre del contenedor | Sí, pero no se puede repetir en el mismo equipo |

### Limpieza

Desde cualquier carpeta:

```bash
docker rm -f puertos-a puertos-b puertos-c puertos-d puertos-sin-p
docker ps -a
```
Quedan en el equipo las imágenes `fallos:1.0` y `puertos:1.0`, que se pueden conservar o borrar con `docker rmi`. Con las dos imágenes borradas se puede repetir la demo entera desde el `mvn clean package`.
