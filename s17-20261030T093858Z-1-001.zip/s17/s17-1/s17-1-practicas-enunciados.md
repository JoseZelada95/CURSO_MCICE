# S17-1 Prácticas

## Objetivos

Las tres prácticas repiten con otros proyectos lo que se vio en las demos, cada vez con menos ayuda. En la Práctica 1 se escribe un `Dockerfile` desde cero, sin el fichero delante. En la Práctica 2 se diagnostica un proyecto ajeno que no funciona, siguiendo el orden estado, registros y configuración. En la Práctica 3 se construye la imagen del proyecto del grupo y se lee el primer error real de una aplicación que no encuentra su base de datos.

Las Prácticas 1 y 2 trabajan con `s17-1-practicas.zip`, que contiene dos carpetas de proyecto: `practica1-tareas` y `practica2-tareas-rota`. Cada proyecto se abre en su propia ventana de IntelliJ con `File > Open`, sobre la carpeta que contiene directamente el `pom.xml`, `Trust Project` y `New Window`. Si aparece el aviso `Maven build scripts found`, se pulsa `Load`.

Reglas comunes a las tres prácticas:

- Los puertos 8080 (Jenkins) y 5432 (PostgreSQL) están ocupados en el equipo. Se publica en el 8081 o en otro libre.
- La imagen base es `eclipse-temurin:21-jre`, la misma de S16 y de las demos. Si no está en el equipo, se consigue con la variante A, B o C de S16-1.
- Cada comando se ejecuta desde la carpeta correcta: `mvn clean package` y `docker build` desde la carpeta del proyecto (la que contiene el `pom.xml` y el `Dockerfile`); `docker run`, `ps`, `logs`, `inspect` y `rm`, desde cualquier carpeta.
- Al terminar cada práctica no se borra nada hasta que se pida: la Práctica 2 usa el contenedor de la Práctica 1.

---

## Práctica 1: Dockerfile de una API nueva, sin ayuda

`practica1-tareas` es una API de tareas con los datos en una lista en memoria. Responde a estas rutas:

| Ruta | Qué hace | Respuesta |
|---|---|---|
| `GET /api/tareas` | Lista todas las tareas | `200` con una lista (arranca con dos tareas) |
| `GET /api/tareas/{id}` | Devuelve una tarea | `200` con la tarea, o `404` si no existe |
| `POST /api/tareas` | Crea una tarea con el cuerpo `{"titulo":"..."}` | `201` con la tarea creada |

La aplicación escucha en el 8080 y no depende de ninguna base de datos. El proyecto **no tiene `Dockerfile`**: hay que escribirlo.

**Pasos**
1. Se abre la carpeta `practica1-tareas` en IntelliJ y se carga Maven.
2. Se genera el JAR con Maven y se comprueba su nombre exacto en la carpeta `target`.
3. Se crea, en la raíz del proyecto, el `Dockerfile` de la aplicación.
4. Se construye la imagen con el nombre `tareas` y la etiqueta `1.0`.
5. Se ejecuta un contenedor llamado `tareas`, en segundo plano, que atienda en el puerto 8081 del equipo.
6. Se comprueban las rutas con `curl.exe` o con Postman: la lista, una tarea concreta, una tarea que no existe (debe dar `404`) y la creación de una tarea nueva.
7. Se crean dos tareas y se consulta de nuevo la lista: deben aparecer las dos nuevas. Se anota qué pasaría con ellas si se borrara el contenedor.
8. **No se borra el contenedor `tareas`**: la Práctica 2 lo necesita.

**Pistas**
- El nombre del JAR es `artifactId-versión.jar`. Se mira en `target`, no se adivina.
- La imagen no lleva Maven ni el código fuente: solo Java y el JAR. El JAR se construye antes del `docker build`.
- El punto final de `docker build` es la carpeta del proyecto, el contexto de construcción.
- En `-p equipo:contenedor`, el número de la derecha es el puerto en el que escucha la aplicación por dentro. Está en `application.properties`, o más bien en lo que **no** está: sin `server.port`, Spring Boot usa su puerto por defecto.
- Para comprobar el `POST` se usa Postman (`Body > raw > JSON`, S09). Con `curl.exe` en PowerShell las comillas dobles del JSON dan problemas de escape.
- Si algo falla, se aplica el orden de las demos: `docker ps -a`, `docker logs`, `docker inspect`.

---

## Práctica 2: Encontrar los fallos

`practica2-tareas-rota` es la misma API de tareas, pero con un `Dockerfile` y un fichero `comandos.txt` que no funcionan. Un compañero los escribió, los ejecutó y no consiguió que la aplicación respondiera. Entre el `Dockerfile` y los comandos hay **tres errores**: uno en el nombre del JAR, uno en el puerto publicado y uno en el nombre del contenedor. El contenedor `tareas` de la Práctica 1 sigue en marcha.

**Pasos**
1. Se abre la carpeta `practica2-tareas-rota` en IntelliJ y se carga Maven. Se leen el `Dockerfile` y `comandos.txt` sin ejecutar nada todavía.
2. Se ejecutan los comandos de `comandos.txt` **uno a uno, en orden**, desde la carpeta del proyecto. Después de cada uno se lee con atención el mensaje que Docker devuelve.
3. Cada vez que un comando falle, se anota: el síntoma, el comando con el que se diagnostica (`docker ps -a`, `docker logs` o `docker inspect`), la causa y la corrección. No se prueba al azar.
4. Se corrigen los ficheros (`Dockerfile` y `comandos.txt`) y se vuelve a ejecutar desde el comando que falló.
5. Hay un fallo que no da ningún error al ejecutar: el contenedor se crea, aparece en `Up` y la petición no obtiene respuesta. Se encuentra comparando lo que dice `docker ps` con lo que dicen los registros de la aplicación.
6. Se comprueba que `http://localhost:8082/api/tareas` responde con la lista de tareas y que el contenedor de la Práctica 1 sigue respondiendo en el 8081.
7. Se escribe una tabla con los tres errores, su síntoma y su corrección.

**Pistas**
- Un error de `docker build` es un problema del proyecto; un error de `docker run` es un problema del contenedor. Saber cuál de los dos es estrecha mucho la búsqueda.
- `docker ps` a secas no muestra los contenedores parados. Con `-a` se ven todos.
- Un nombre de contenedor no se puede repetir en el mismo equipo, ni siquiera si el viejo está parado.
- `docker logs` de una aplicación Spring Boot incluye una línea `Tomcat started on port ...` que dice en qué puerto escucha de verdad.
- El segundo número de `-p` tiene que ser el puerto en el que escucha la aplicación por dentro, no uno cualquiera.
- Un `COPY` apunta a un fichero que existe en `target`: se compara lo que dice el `Dockerfile` con lo que hay en la carpeta.

---

## Práctica 3: Imagen del proyecto en grupo

Cada grupo escribe el `Dockerfile` de su proyecto, construye el JAR y la imagen, la ejecuta y lee en los registros el error que aparece al arrancar sin base de datos. Es un fallo esperado: no se arregla en esta parte. La imagen que se deja construida es la pieza que usarán Compose y Kubernetes. No hay zip: se trabaja sobre el repositorio del grupo.

**Pasos**
1. Cada grupo abre su proyecto en IntelliJ (con `File > Open`, o clonándolo si no lo tiene) y localiza la carpeta que contiene el `pom.xml`. Todos los comandos se ejecutan desde ella.
2. Se genera el JAR con Maven, sin ejecutar las pruebas, porque las que arrancan la aplicación completa necesitan una base de datos que todavía no hay: `mvn clean package -DskipTests`. Se comprueba el nombre exacto del JAR en `target`.
3. Se escribe el `Dockerfile` en esa misma carpeta, con la misma estructura que en la Práctica 1.
4. Se construye la imagen con el nombre del proyecto y la etiqueta `1.0`.
5. Se ejecuta un contenedor de esa imagen, en segundo plano, con nombre propio y publicando el puerto de la aplicación en un puerto libre del equipo (el 8083 no lo usa ninguna práctica anterior).
6. Se espera unos segundos y se mira el estado del contenedor con `docker ps -a`. Se anota el valor de `STATUS`.
7. Se leen los registros con `docker logs` y se busca la primera línea que explica la causa. Se anota qué dice, a qué servidor intenta conectar y con qué dirección.
8. Se contesta por escrito: ¿por qué falla la aplicación en el contenedor? ¿Fallaría igual si la base de datos estuviera en marcha en el equipo, y por qué `localhost` no sirve dentro del contenedor?
9. Se deja la imagen construida y el contenedor parado; se borra el contenedor, no la imagen.

**Pistas**
- Si el proyecto usa PostgreSQL con Spring Data JPA, el estado esperado es `Exited (1)` y los registros terminan con una excepción de conexión rechazada. El puerto `5432` es el de PostgreSQL.
- Si el proyecto usa MongoDB, el comportamiento es distinto: la aplicación arranca y el contenedor sigue `Up`, porque el driver se conecta al hacer la primera operación (S12-1). El error aparece al hacer la primera petición, tarda unos treinta segundos y se lee en `docker logs`.
- El puerto de dentro es el que usa la aplicación (por defecto, el 8080); el de fuera se elige en el equipo.
- Si el proyecto lee la contraseña de una variable de entorno (`POSTGRES_PASSWORD`, S07), el fallo de conexión llega antes que cualquier problema de contraseña.
- Si el proyecto está en una subcarpeta del repositorio, el `Dockerfile` y los comandos de Maven y de Docker se ejecutan desde esa subcarpeta.
- La imagen se nombra distinto en cada grupo y con etiqueta de versión; no se usa `latest`.
