# S17-1 Soluciones

## Práctica 1: Dockerfile de una API nueva, sin ayuda

El proyecto `practica1-tareas` ya traía todo el código Java: el `Dockerfile` era lo único que faltaba. La solución tiene tres partes: leer el nombre exacto del JAR, escribir el `Dockerfile` con las cuatro instrucciones de S16-1 y ejecutar el contenedor con el puerto de dentro correcto.

### El JAR

Desde la carpeta `practica1-tareas` (la que contiene el `pom.xml`):

```bash
mvn clean package
```
El nombre del JAR sale del `pom.xml`: `artifactId` `tareas` y `version` `0.0.1-SNAPSHOT`, es decir, `tareas-0.0.1-SNAPSHOT.jar`. Se comprueba con `dir target` en lugar de adivinarlo.

### El Dockerfile

Se crea en la raíz del proyecto, junto al `pom.xml`, con el nombre exacto `Dockerfile` (sin extensión):

```dockerfile
# S17-1 Práctica 1: Dockerfile de la API de tareas
#
# Se construye desde la carpeta del proyecto, la que contiene este fichero y el pom.xml.
# El punto final del comando es esa carpeta (el contexto de construcción):
#   docker build -t tareas:1.0 .
#
# Antes hay que generar el JAR, porque la imagen solo contiene Java y el JAR:
#   mvn clean package

# FROM: imagen base con Java 21 (solo el JRE, sin Maven ni el código fuente).
FROM eclipse-temurin:21-jre

# COPY: copia el JAR de la carpeta target del proyecto a la imagen, con el nombre app.jar.
# El nombre de origen es artifactId-version.jar tal como lo genera Maven.
COPY target/tareas-0.0.1-SNAPSHOT.jar app.jar

# EXPOSE: solo anota que la aplicación escucha en el 8080 dentro del contenedor.
# No publica nada: la puerta la abre -p en docker run.
EXPOSE 8080

# ENTRYPOINT: el comando que se ejecuta al arrancar el contenedor.
# La forma de lista hace que Java sea el proceso principal y reciba docker stop.
ENTRYPOINT ["java", "-jar", "app.jar"]
```
### Construir y ejecutar

Desde la carpeta `practica1-tareas`, la que contiene el `Dockerfile`; el punto final es esa carpeta:

```bash
docker build -t tareas:1.0 .
```
Y el contenedor. Desde cualquier carpeta:

```bash
docker run -d --name tareas -p 8081:8080 tareas:1.0
```
Comprobamos las rutas. En `curl.exe` la lista y la tarea inexistente:

```bash
curl.exe http://localhost:8081/api/tareas
curl.exe -i http://localhost:8081/api/tareas/99
```<pre>
[{"id":1,"titulo":"Instalar Docker Desktop","completada":false},{"id":2,"titulo":"Construir la primera imagen","completada":false}]
</pre>
La primera petición devuelve la lista con las dos tareas con que arranca la aplicación. La segunda (`-i` muestra las cabeceras) devuelve la línea de estado `HTTP/1.1 404`. La creación de una tarea con Postman (`POST`, `Body > raw > JSON`, `{"titulo":"Comprar pan"}`) devuelve el estado `201` y el cuerpo:

<pre>
{"id":3,"titulo":"Comprar pan","completada":false}
</pre>
**Decisiones tomadas**

- **`FROM eclipse-temurin:21-jre` y no una imagen con JDK ni con Maven.** La imagen solo ejecuta el JAR, no compila nada: el JRE basta y la imagen pesa menos. Maven y el código fuente se quedan fuera, en el equipo de desarrollo.
- **El JAR se copia con su nombre completo (`tareas-0.0.1-SNAPSHOT.jar`) y se renombra a `app.jar`.** Así el `ENTRYPOINT` es el mismo en todos los proyectos y solo cambia el origen del `COPY`. Un `COPY` con un nombre distinto del que hay en `target` es el primero de los cuatro fallos habituales.
- **`EXPOSE 8080` sin más.** La aplicación no fija `server.port`, así que escucha en el puerto por defecto de Spring Boot, el 8080. `EXPOSE` es el cartel que lo anota; no abre ninguna puerta.
- **`ENTRYPOINT` en forma de lista.** Así Java es el proceso principal del contenedor y recibe `docker stop`, y el contenedor se para de forma ordenada (`Exited (143)`).
- **`-p 8081:8080`.** El de la derecha es el puerto de dentro, el que decide la aplicación; el de la izquierda es el del equipo, 8081 porque el 8080 lo ocupa Jenkins. El nombre `tareas` deja el contenedor identificado, y es el que reutiliza la Práctica 2.
- **No se borra el contenedor.** Si se borrara, la Práctica 2 no tendría el choque de nombres que necesita. Además las tareas creadas viven en una lista en memoria: desaparecen con el contenedor. Es lo esperado en esta parte, y es el motivo de los volúmenes y de las bases de datos en contenedores de S17-2.

---

## Práctica 2: Encontrar los fallos

Los tres errores se descubren ejecutando `comandos.txt` en orden y leyendo lo que Docker contesta. El primero para el `docker build`, el segundo para el `docker run` y el tercero no da error: se descubre comparando lo que dice `docker ps` con lo que dice la aplicación. El contenedor `tareas` de la Práctica 1 sigue en marcha.

Los ficheros originales, con los errores, son estos:

```dockerfile
# S17-1 Práctica 2: Dockerfile de la API de tareas (CON ERRORES)
#
# Este fichero y comandos.txt contienen tres fallos que hay que encontrar con
# docker ps -a, docker logs y docker inspect. Se construye desde la carpeta
# del proyecto, la que contiene este fichero y el pom.xml.

FROM eclipse-temurin:21-jre

COPY target/tareas.jar app.jar

EXPOSE 8080

ENTRYPOINT ["java", "-jar", "app.jar"]
``````text
S17-1 Práctica 2: comandos del proyecto tareas-rota (CON ERRORES)

Los ejecutó un compañero y no le funcionaron. Hay que ejecutarlos uno a uno,
desde la carpeta del proyecto, leer cada mensaje y corregir lo que haga falta.

1. Generar el JAR:
   mvn clean package

2. Construir la imagen:
   docker build -t tareas-rota:1.0 .

3. Ejecutar el contenedor:
   docker run -d --name tareas -p 8082:8081 tareas-rota:1.0

4. Probar la API:
   curl http://localhost:8082/api/tareas
```
### Error 1: nombre del JAR (falla el build)

Desde la carpeta `practica2-tareas-rota`:

```bash
mvn clean package
docker build -t tareas-rota:1.0 .
```<pre>
   7 |     FROM eclipse-temurin:21-jre
   8 |
   9 | &gt;&gt;&gt; COPY target/tareas.jar app.jar
  10 |
  11 |     EXPOSE 8080
--------------------
ERROR: failed to build: failed to solve: failed to compute cache key: failed to calculate checksum of ref ...: "/target/tareas.jar": not found
</pre>
`"/target/tareas.jar": not found` y la línea 9 marcada con `>>>`. Es un error de `docker build`, así que es un problema del proyecto. Se mira qué hay en `target`:

```bash
dir target
```
Está `tareas-rota-0.0.1-SNAPSHOT.jar`, porque el `artifactId` del `pom.xml` es `tareas-rota`. La corrección es escribir ese nombre en el `COPY`. Tras corregirlo, `docker build` termina bien.

### Error 2: nombre del contenedor (falla el run)

Con la imagen construida, se ejecuta el comando del fichero:

```bash
docker run -d --name tareas -p 8082:8081 tareas-rota:1.0
```<pre>
docker: Error response from daemon: Conflict. The container name "/tareas" is already in use by container "aa06c7195ac2813bac8d36efa04f51ecc3cc49f9f380fb034b033bf182419c81". You have to remove (or rename) that container to be able to reuse that name.

Run 'docker run --help' for more information
</pre>
El nombre `/tareas` ya lo usa el contenedor de la Práctica 1. `docker ps -a` lo confirma. Las tres salidas posibles son quitar el viejo, seguir con el viejo o elegir otro nombre. Aquí hay que **conservar el viejo** (la Práctica 1 sigue en marcha) y por tanto se elige otro nombre: `tareas-rota`.

### Error 3: puerto publicado (el contenedor arranca, pero no responde)

Con el nombre corregido pero sin tocar el puerto:

```bash
docker run -d --name tareas-rota -p 8082:8081 tareas-rota:1.0
curl.exe http://localhost:8082/api/tareas
```<pre>
curl: (56) Recv failure: Connection reset by peer
</pre>
No hay ningún mensaje de Docker: el contenedor se crea y arranca. Pero la petición no obtiene respuesta (el mensaje exacto de `curl` depende del sistema; el navegador muestra que no puede mostrar la página). Se aplican las tres preguntas. El estado:

```bash
docker ps
```<pre>
NAMES         PORTS                              STATUS
tareas-rota   8080/tcp, 0.0.0.0:8082-&gt;8081/tcp   Up 12 seconds
tareas        0.0.0.0:8081-&gt;8080/tcp             Up 26 seconds
</pre>
El contenedor está `Up`. En `PORTS` aparecen dos cosas: `8080/tcp`, el cartel del `EXPOSE` de la imagen, y `0.0.0.0:8082->8081/tcp`, la puerta real: lo que llega al 8082 del equipo se entrega al 8081 **del contenedor**. Los registros dicen en qué puerto escucha la aplicación:

```bash
docker logs tareas-rota
```<pre>
... o.s.boot.tomcat.TomcatWebServer          : Tomcat started on port 8080 (http) with context path '/'
</pre>
La aplicación escucha en el 8080 por dentro, no en el 8081. La puerta está conectada a un puerto donde nadie escucha. La corrección es el segundo número de `-p`: `8080`. Se borra el contenedor mal publicado y se crea de nuevo:

```bash
docker rm -f tareas-rota
docker run -d --name tareas-rota -p 8082:8080 tareas-rota:1.0
curl.exe http://localhost:8082/api/tareas
docker ps
```<pre>
[{"id":1,"titulo":"Instalar Docker Desktop","completada":false},{"id":2,"titulo":"Construir la primera imagen","completada":false}]

NAMES         PORTS                    STATUS
tareas-rota   0.0.0.0:8082-&gt;8080/tcp   Up 12 seconds
tareas        0.0.0.0:8081-&gt;8080/tcp   Up 39 seconds
</pre>
Los dos contenedores conviven, cada uno en su puerto de fuera y los dos con el 8080 por dentro.

### Los ficheros corregidos

```dockerfile
# S17-1 Práctica 2: Dockerfile de la API de tareas (CORREGIDO)
#
# Se construye desde la carpeta del proyecto, la que contiene este fichero y el pom.xml.
# El punto final del comando es esa carpeta (el contexto de construcción):
#   docker build -t tareas-rota:1.0 .

FROM eclipse-temurin:21-jre

# CORRECCIÓN 1: el JAR que genera Maven se llama artifactId-version.jar,
# es decir, tareas-rota-0.0.1-SNAPSHOT.jar, y no tareas.jar.
COPY target/tareas-rota-0.0.1-SNAPSHOT.jar app.jar

EXPOSE 8080

ENTRYPOINT ["java", "-jar", "app.jar"]
``````text
S17-1 Práctica 2: comandos del proyecto tareas-rota (CORREGIDOS)

Desde la carpeta del proyecto:

1. Generar el JAR:
   mvn clean package

2. Construir la imagen (el Dockerfile ya tiene el nombre correcto del JAR):
   docker build -t tareas-rota:1.0 .

3. Ejecutar el contenedor:
   CORRECCIÓN 2: el nombre "tareas" ya lo usa el contenedor de la Práctica 1.
   Se elige un nombre propio:
   CORRECCIÓN 3: la aplicación escucha en el 8080 dentro del contenedor, así que
   el número de la derecha de -p es el 8080 (y no el 8081).
   docker run -d --name tareas-rota -p 8082:8080 tareas-rota:1.0

4. Probar la API:
   curl http://localhost:8082/api/tareas
```
### Tabla de errores

| # | Dónde | Síntoma | Cómo se diagnostica | Corrección |
|---|---|---|---|---|
| 1 | `Dockerfile` | `docker build` falla: `"/target/tareas.jar": not found` | Mirar `target` y comparar el nombre | `COPY target/tareas-rota-0.0.1-SNAPSHOT.jar app.jar` |
| 2 | `comandos.txt` | `docker run` falla: nombre `/tareas` ya en uso | `docker ps -a` | `--name tareas-rota` |
| 3 | `comandos.txt` | El contenedor está `Up` pero no responde | `docker ps` (puerta al 8081) y `docker logs` (`Tomcat started on port 8080`) | `-p 8082:8080` |

**Decisiones tomadas**

- **Se sigue el orden estado, registros y configuración en cada fallo.** Es más rápido que probar cosas al azar, y es el mismo orden en los tres casos. El primer fallo ni siquiera necesita Docker: basta mirar `target`.
- **Se conserva el contenedor de la Práctica 1 y se cambia el nombre del nuevo.** Quitar el viejo habría resuelto el mensaje, pero habría dejado de responder en el 8081. El contexto manda: aquí interesa que convivan.
- **El tercer error se arregla con el segundo número de `-p`, no con el primero.** El 8082 está libre; el problema es que la puerta apunta a un puerto de dentro que no es el de la aplicación. Cambiar el primer número no habría arreglado nada.
- **No se toca `EXPOSE`.** Ya decía 8080, que era correcto, y el cartel no abre ninguna puerta: el fallo estaba en `docker run -p`. El síntoma del tercer error es precisamente tener un cartel correcto y una puerta mal puesta.
- **Se borra el contenedor mal publicado antes de crear el bueno.** `docker run` siempre crea uno nuevo; reutilizar el nombre sin borrar el viejo daría el fallo 2.

---

## Práctica 3: Imagen del proyecto en grupo

No hay solución única, porque cada grupo tiene su proyecto. Lo que sigue es una solución orientativa con un proyecto genérico llamado `proyecto`: Spring Boot, Spring Data JPA y PostgreSQL, con `spring.datasource.url=jdbc:postgresql://localhost:5432/tareas` en `application.properties`. El camino es el mismo que en la Práctica 1, con un resultado final distinto y esperado: la aplicación se para.

Desde la carpeta del proyecto (la que contiene el `pom.xml`). El JAR se construye sin pruebas, porque `contextLoads` arranca la aplicación completa y necesita una base de datos:

```bash
mvn clean package -DskipTests
```
El `Dockerfile` es el de las prácticas anteriores, con el nombre del JAR del proyecto (`artifactId-versión.jar`, que se comprueba en `target`):

```dockerfile
FROM eclipse-temurin:21-jre
COPY target/proyecto-0.0.1-SNAPSHOT.jar app.jar
EXPOSE 8080
ENTRYPOINT ["java", "-jar", "app.jar"]
```

Se construye y se ejecuta, desde la carpeta del proyecto y desde cualquier carpeta respectivamente. El 8081 y el 8082 pueden estar en uso por las prácticas anteriores, así que se publica en el 8083:

```bash
docker build -t proyecto:1.0 .
docker run -d --name proyecto -p 8083:8080 proyecto:1.0
```
Pasados unos segundos, se mira el estado:

```bash
docker ps -a
```<pre>
NAMES         STATUS
proyecto      Exited (1) 23 seconds ago
tareas-rota   Up About a minute
tareas        Up 2 minutes
</pre>
`Exited (1)`: el programa falló al arrancar. Los registros dicen por qué (aquí, solo las líneas que identifican la causa):

```bash
docker logs proyecto
```<pre>
WARN 1 --- [           main] org.hibernate.orm.jdbc.error             : Connection to localhost:5432 refused. Check that the hostname and port are correct and that the postmaster is accepting TCP/IP connections.
org.hibernate.exception.JDBCConnectionException: Unable to obtain isolated JDBC connection [Connection to localhost:5432 refused. ...]
Caused by: org.postgresql.util.PSQLException: Connection to localhost:5432 refused. ...
Caused by: java.net.ConnectException: Connection refused
ERROR 1 --- [           main] j.LocalContainerEntityManagerFactoryBean : Failed to initialize JPA EntityManagerFactory: Unable to create requested service [org.hibernate.engine.jdbc.env.spi.JdbcEnvironment] due to: Unable to determine ...
</pre>
La causa está en `Connection to localhost:5432 refused` y `Connection refused`. La aplicación intenta conectarse a PostgreSQL en `localhost:5432` y nadie contesta. Con Hibernate, la conexión es imprescindible al arrancar (S07), por lo que un fallo de conexión termina la aplicación y el contenedor pasa a `Exited (1)`.

Respuesta a la pregunta del enunciado. **`localhost` dentro de un contenedor es el propio contenedor.** Dentro del contenedor no hay ningún PostgreSQL, aunque en el equipo sí lo haya (y en Windows lo hay: es el que escucha en el 5432). La aplicación no puede salir del contenedor con `localhost` para llegar a la base de datos del equipo, ni a otro contenedor. Por tanto, aunque la base de datos estuviera en marcha en el equipo, el error sería el mismo. El arreglo no es cambiar la aplicación, sino darle una dirección que funcione dentro del contenedor: ese es el trabajo de S17-2, con la red de Compose y el nombre del servicio.

Si el proyecto del grupo usa MongoDB, el comportamiento es otro: la aplicación **arranca** y el contenedor sigue `Up`, porque el driver se conecta de forma perezosa (S12-1). El error aparece con la primera petición, unos treinta segundos después, con `MongoSocketOpenException` en `docker logs`. El mensaje y el motivo son los mismos: `localhost` dentro del contenedor no es el MongoDB del equipo.

Se limpia el contenedor y se conserva la imagen:

```bash
docker rm proyecto
docker images
```
**Decisiones tomadas**

- **`mvn clean package -DskipTests` en lugar de `mvn clean package`.** `contextLoads` arranca la aplicación completa y, sin base de datos, falla; con el JAR sin construir no hay imagen. Saltar las pruebas es una decisión provisional que se revierte cuando la base de datos exista en el entorno de construcción. Quienes tengan la base de datos y la variable de entorno en su equipo pueden construir con pruebas.
- **El `Dockerfile` no cambia entre proyectos.** Solo cambia el nombre del JAR y, si la aplicación escucha en otro puerto, el `EXPOSE`. Es la gran ventaja de un `Dockerfile` pequeño y común.
- **No se arregla el error en esta parte.** No se pasa `-e` para apuntar a la base de datos del equipo ni se cambia la aplicación. Que falle es el resultado de la práctica: hace ver, con un caso real, que un contenedor solo no basta, y plantea S17-2.
- **Se borra el contenedor y se conserva la imagen.** La imagen es lo que se reutiliza después (Compose, Kubernetes); el contenedor parado solo reservaría el nombre.
- **Se publica en un puerto de fuera libre (8083).** El número de la derecha sigue siendo el que usa la aplicación por dentro, y por eso la imagen funciona igual en cualquier equipo.
